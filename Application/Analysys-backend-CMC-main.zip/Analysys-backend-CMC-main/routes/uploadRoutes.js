const express = require('express')
const {
    uploadSingleFile,
    uploadMultipleFiles,
    serveFile,
    deleteFile,
    getFileInfo,
    listFiles
} = require('../controllers/uploadController.js')

const router = express.Router()

// POST /api/uploads/single - Upload single file
router.post('/single', uploadSingleFile)

// POST /api/uploads/multiple - Upload multiple files
router.post('/multiple', uploadMultipleFiles)

// GET /api/uploads/:category/files - List files in category (renamed to avoid conflict)
router.get('/:category/files', listFiles)

// GET /api/uploads/:category/:filename/info - Get file info
router.get('/:category/:filename/info', getFileInfo)

// DELETE /api/uploads/:category/:filename - Delete file
router.delete('/:category/:filename', deleteFile)

// GET /api/uploads/:category/:filename - Serve/download file (should be last)
router.get('/:category/:filename', serveFile)

module.exports = router
