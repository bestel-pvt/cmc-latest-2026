import { useState, useEffect } from 'react'
import { useSearchParams, useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { format } from 'date-fns'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover'
import { CalendarIcon, Funnel, Trash2 } from 'lucide-react'

import { useChannelRecordingColumns } from './columns'
import DataTable from '@/components/ui/data-table/data-table'
import { getChannelRecordings } from '@/services/channels/channelApi'
import { useDebounce } from 'react-haiku'
import { VIDEO_EXPORT_FORMATS } from '@/constants/recording'

const RecordingTable = () => {
  const { id } = useParams()
  const [searchParams, setSearchParams] = useSearchParams()

  // read from URL
  const [filters, setFilters] = useState({
    page: Number(searchParams.get('page')) || 1,
    limit: Number(searchParams.get('limit')) || 10,
    status: searchParams.get('status') || '',
    format: searchParams.get('format') || '',
    sortBy: searchParams.get('sortBy') || 'startTime',
    sortOrder: searchParams.get('sortOrder') || 'desc',
    dateFrom: searchParams.get('dateFrom') || '',
    dateTo: searchParams.get('dateTo') || ''
  })

  // debounce all filter updates
  const debouncedFilters = useDebounce(filters, 1000)

  // sync filters to URL
  useEffect(() => {
    const params = new URLSearchParams()
    Object.entries(debouncedFilters).forEach(([key, value]) => {
      if (value !== '' && value !== null && value !== undefined) {
        params.set(key, value)
      }
    })
    setSearchParams(params)
  }, [debouncedFilters, setSearchParams])

  const { data, isPending } = useQuery({
    queryKey: ['channel-recordings', id, debouncedFilters],
    queryFn: () => getChannelRecordings(id, debouncedFilters),
    enabled: !!id
  })

  const channelRecordings = data?.recordings
  const columns = useChannelRecordingColumns()

  // helpers
  const updateFilter = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
      page: key === 'page' || key === 'limit' ? value : 1
    }))
  }

  const clearFilters = () => {
    setFilters({
      status: '',
      format: '',
      sortBy: 'startTime',
      sortOrder: 'desc',
      dateFrom: '',
      dateTo: ''
    })
  }

  return (
    <div>
      <Card>
        <CardHeader>
          <CardTitle>
            <h4>Channel Recordings</h4>
          </CardTitle>
        </CardHeader>
        <Separator />
        {/* Filters */}
        <div className="px-4 flex flex-wrap gap-4 items-center">
          {/* Status */}
          <Select value={filters.status} onValueChange={(val) => updateFilter('status', val)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recording">Recording</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="stopped">Stopped</SelectItem>
            </SelectContent>
          </Select>

          {/* Format */}
          <Select value={filters.format} onValueChange={(val) => updateFilter('format', val)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Format" />
            </SelectTrigger>
            <SelectContent>
              {VIDEO_EXPORT_FORMATS.map((format) => (
                <SelectItem key={format.value} value={format.value}>
                  {format.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Sort By */}
          <Select value={filters.sortBy} onValueChange={(val) => updateFilter('sortBy', val)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="fileName">File Name</SelectItem>
              <SelectItem value="startTime">Start Time</SelectItem>
              <SelectItem value="endTime">End Time</SelectItem>
              <SelectItem value="status">Status</SelectItem>
              <SelectItem value="fileSize">File Size</SelectItem>
              <SelectItem value="createdAt">Created At</SelectItem>
            </SelectContent>
          </Select>

          {/* Sort Order */}
          <Select value={filters.sortOrder} onValueChange={(val) => updateFilter('sortOrder', val)}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Order" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="asc">Asc</SelectItem>
              <SelectItem value="desc">Desc</SelectItem>
            </SelectContent>
          </Select>

          {/* Date From */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-[180px] justify-start">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {filters.dateFrom ? format(new Date(filters.dateFrom), 'yyyy-MM-dd') : 'Date From'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="p-0">
              <Calendar
                mode="single"
                selected={filters.dateFrom ? new Date(filters.dateFrom) : undefined}
                onSelect={(val) => updateFilter('dateFrom', val ? format(val, 'yyyy-MM-dd') : '')}
              />
            </PopoverContent>
          </Popover>

          {/* Date To */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-[180px] justify-start">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {filters.dateTo ? format(new Date(filters.dateTo), 'yyyy-MM-dd') : 'Date To'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="p-0">
              <Calendar
                mode="single"
                captionLayout="dropdown"
                selected={filters.dateTo ? new Date(filters.dateTo) : undefined}
                onSelect={(val) => updateFilter('dateTo', val ? format(val, 'yyyy-MM-dd') : '')}
              />
            </PopoverContent>
          </Popover>

          {/* Clear Filters */}
          {(filters.status ||
            filters.format ||
            filters.dateFrom ||
            filters.dateTo ||
            filters.sortBy !== 'startTime' ||
            filters.sortOrder !== 'desc') && (
            <Button variant="destructive" size="icon" onClick={clearFilters}>
              <Trash2 />
            </Button>
          )}
        </div>

        <Separator />
        <CardContent className="min-h-[50vh]">
          <DataTable
            data={channelRecordings || []}
            columns={columns}
            isPending={isPending}
            isPagination
            pagination={{
              page: filters.page,
              limit: filters.limit,
              totalPages: data?.pagination?.totalPages || 1
            }}
            onPageChange={(newPage) => updateFilter('page', newPage)}
            onLimitChange={(newLimit) => updateFilter('limit', newLimit)}
          />
        </CardContent>
      </Card>
    </div>
  )
}

export default RecordingTable
