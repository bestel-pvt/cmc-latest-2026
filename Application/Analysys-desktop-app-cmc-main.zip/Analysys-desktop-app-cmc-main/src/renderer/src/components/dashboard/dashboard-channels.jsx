import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '../ui/badge'
import { formatDate, getHoursSince } from '@/lib/utils'
import { Clock } from 'lucide-react'
import { Skeleton } from '../ui/skeleton'

const Dashboardchannels = ({ data, isPending = false }) => {
  if (isPending) {
    return <Skeleton className="h-96 w-full" />
  }
  return (
    <div>
      {/* Channel Details Table */}
      <Card>
        <CardHeader>
          <CardTitle>
            <h6>Channel Details</h6>
          </CardTitle>
          <CardDescription>
            Comprehensive overview of all channels with key performance indicators
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Channel</th>
                  <th className="text-left p-2">Status</th>
                  <th className="text-left p-2">Priority</th>
                  <th className="text-right p-2">Created</th>
                  <th className="text-right p-2">Last Updated</th>
                  <th className="text-right p-2">Uptime %</th>
                  <th className="text-right p-2">Data Transfer</th>
                  <th className="text-right p-2">Avg Throughput</th>
                  <th className="text-right p-2">Switches</th>
                </tr>
              </thead>
              <tbody>
                {data.map((item) => (
                  <tr key={item.id} className="border-b hover:bg-gray-50">
                    <td className="p-2 font-medium">{item.channel.name}</td>
                    <td className="p-2">
                      <Badge
                        variant={item.streamStoppedAt ? 'destructive' : 'default'}
                        className={
                          item.streamStoppedAt
                            ? 'bg-red-100 text-red-800'
                            : 'bg-green-100 text-green-800'
                        }
                      >
                        {item.streamStoppedAt ? 'Offline' : 'Online'}
                      </Badge>
                    </td>
                    <td className="p-2">
                      {item.channel.isPriority && <Badge variant="secondary">Priority</Badge>}
                    </td>
                    <td className="p-2 text-right text-xs">
                      <Tooltip>
                        <TooltipTrigger>
                          <Clock className="h-3 w-3 inline mr-1" />
                          {getHoursSince(item.createdAt)}h ago
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>{formatDate(item.createdAt)}</p>
                        </TooltipContent>
                      </Tooltip>
                    </td>
                    <td className="p-2 text-right text-xs">
                      <Tooltip>
                        <TooltipTrigger>
                          <Clock className="h-3 w-3 inline mr-1" />
                          {getHoursSince(item.updatedAt)}h ago
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>{formatDate(item.updatedAt)}</p>
                        </TooltipContent>
                      </Tooltip>
                    </td>
                    <td className="p-2 text-right">
                      {item.totalUptime + item.totalDowntime > 0
                        ? (
                            (item.totalUptime / (item.totalUptime + item.totalDowntime)) *
                            100
                          ).toFixed(2)
                        : 0}
                      %
                    </td>
                    <td className="p-2 text-right">
                      {(parseInt(item.totalBytes) / (1024 * 1024)).toFixed(1)} MB
                    </td>
                    <td className="p-2 text-right">
                      {(item.avgBytesPerSec / 1024).toFixed(1)} KB/s
                    </td>
                    <td className="p-2 text-right">{item.switchCount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboardchannels
