import { FormControl, FormField, FormItem, FormLabel, FormMessage } from '../ui/form'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { useQuery } from '@tanstack/react-query'

import { Loader2 } from 'lucide-react'
import { getAllChannels } from '@/services/channels/channelApi'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'
import { getInitials } from '@/lib/utils'

const ChannelSelect = ({ form, isDisabled = false }) => {
  const { data, isPending, isError } = useQuery({
    queryKey: ['channels'],
    queryFn: () => getAllChannels({ page: 1, limit: 1000000000000 }),
    enabled: !!form
  })

  const channels = data?.data

  return (
    <FormField
      control={form.control}
      name="channelId"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Channel</FormLabel>
          <Select
            onValueChange={field.onChange}
            defaultValue={field.value}
            disabled={isPending || isDisabled}
          >
            <FormControl>
              <SelectTrigger className="w-full">
                {isPending ? (
                  <div className="flex items-center gap-2 text-gray-500">
                    <Loader2 className="animate-spin h-4 w-4" />
                    Loading...
                  </div>
                ) : (
                  <SelectValue placeholder="Select a channel" />
                )}
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              {isError && (
                <div className="px-2 py-1 text-sm text-red-500">Failed to load channels</div>
              )}
              {channels?.map((channel) => (
                <SelectItem key={channel.id} value={channel.id}>
                  <Avatar>
                    <AvatarFallback>{getInitials(channel.name)}</AvatarFallback>
                    <AvatarImage src={channel?.logo} />
                  </Avatar>{' '}
                  <p className="font-semibold"> {channel.name}</p>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <FormMessage />
        </FormItem>
      )}
    />
  )
}

export default ChannelSelect
