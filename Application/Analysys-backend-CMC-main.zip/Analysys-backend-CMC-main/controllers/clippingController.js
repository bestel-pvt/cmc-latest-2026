const clippingService = require('../services/clippingService.js')
const { idSchema } = require('../utils/validation.js')
const Joi = require('joi')

// Validation schemas
const createClipSchema = Joi.object({
    clipName: Joi.string().min(1).max(100).required(),
    description: Joi.string().max(500).optional(),
    startTime: Joi.number().min(0).required(),
    endTime: Joi.number().min(0).required(),
    format: Joi.string().valid('mp4', 'mkv').default('mp4'),
    tags: Joi.array().items(Joi.string()).optional()
})

const updateClipSchema = Joi.object({
    clipName: Joi.string().min(1).max(100).optional(),
    description: Joi.string().max(500).optional(),
    tags: Joi.array().items(Joi.string()).optional()
})

const querySchema = Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(10),
    sortBy: Joi.string().valid('clipName', 'createdAt', 'startTime', 'endTime', 'status').default('createdAt'),
    sortOrder: Joi.string().valid('asc', 'desc').default('desc'),
    status: Joi.string().valid('processing', 'completed', 'failed').optional(),
    tags: Joi.string().allow('').empty('').optional(),
    recordingId: Joi.string().optional(),
    channelName: Joi.string().optional(),
    dateFrom: Joi.string().optional(),
    dateTo: Joi.string().optional(),
    clipName: Joi.string().optional(),
    search: Joi.string().optional()
})

// Helper function to format validation errors
const formatValidationError = (error) => {
    const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
    }))
    return {
        error: 'Validation failed',
        details: errors
    }
}

// Create a new clip
const createClip = async (req, res) => {
    try {
        // Validate recording ID
        const { error: idError } = idSchema.validate(req.params.recordingId)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        // Validate clip data
        const { error: dataError, value } = createClipSchema.validate(req.body)
        if (dataError) {
            return res.status(400).json(formatValidationError(dataError))
        }

        // Validate time range
        if (value.startTime >= value.endTime) {
            return res.status(400).json({
                success: false,
                error: 'Start time must be less than end time'
            })
        }

        const clipData = {
            recordingId: req.params.recordingId,
            ...value
        }

        const result = await clippingService.createClip(clipData)

        res.status(201).json({
            success: true,
            message: result.message,
            clip: result.clip
        })

    } catch (error) {
        console.error('Create clip error:', error)

        let statusCode = 500
        if (error.message.includes('Recording not found')) {
            statusCode = 404
        } else if (error.message.includes('Recording file not found')) {
            statusCode = 404
        } else if (error.message.includes('Start time') || error.message.includes('negative')) {
            statusCode = 400
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to create clip'
        })
    }
}

// Get all clips with pagination and filters
const getAllClips = async (req, res) => {
    try {
        const { error, value } = querySchema.validate(req.query)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const result = await clippingService.getAllClips(value)

        res.json({
            success: true,
            ...result
        })

    } catch (error) {
        console.error('Get all clips error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get clips'
        })
    }
}

// Get clip by ID
const getClipById = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const clip = await clippingService.getClipById(req.params.id)

        if (!clip) {
            return res.status(404).json({
                success: false,
                error: 'Clip not found'
            })
        }

        res.json({
            success: true,
            clip
        })

    } catch (error) {
        console.error('Get clip by ID error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get clip'
        })
    }
}

// Update clip
const updateClip = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.id)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const { error: dataError, value } = updateClipSchema.validate(req.body)
        if (dataError) {
            return res.status(400).json(formatValidationError(dataError))
        }

        const updatedClip = await clippingService.updateClip(req.params.id, value)

        res.json({
            success: true,
            message: 'Clip updated successfully',
            clip: updatedClip
        })

    } catch (error) {
        console.error('Update clip error:', error)

        let statusCode = 500
        if (error.code === 'P2025' || error.message.includes('Clip not found')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to update clip'
        })
    }
}

// Delete clip
const deleteClip = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const result = await clippingService.deleteClip(req.params.id)

        res.json({
            success: true,
            message: result.message
        })

    } catch (error) {
        console.error('Delete clip error:', error)

        let statusCode = 500
        if (error.message.includes('Clip not found')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to delete clip'
        })
    }
}

// Get clips for a specific recording
const getRecordingClips = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.recordingId)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const queryOptions = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 10,
            sortBy: req.query.sortBy || 'createdAt',
            sortOrder: req.query.sortOrder || 'desc'
        }

        const result = await clippingService.getRecordingClips(req.params.recordingId, queryOptions)

        res.json({
            success: true,
            ...result
        })

    } catch (error) {
        console.error('Get recording clips error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get recording clips'
        })
    }
}

// Serve clip file
const serveClipFile = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const clip = await clippingService.getClipById(req.params.id)

        if (!clip) {
            return res.status(404).json({
                success: false,
                error: 'Clip not found'
            })
        }

        const fs = require('fs-extra')

        if (!await fs.pathExists(clip.filePath)) {
            return res.status(404).json({
                success: false,
                error: 'Clip file not found'
            })
        }

        // Set appropriate headers for video streaming
        res.setHeader('Content-Type', clip.format === 'mp4' ? 'video/mp4' : 'video/x-matroska')
        res.setHeader('Content-Disposition', `inline; filename="${clip.fileName}"`)
        res.setHeader('Accept-Ranges', 'bytes')

        // Get file stats for content length
        const stats = await fs.stat(clip.filePath)
        const fileSize = stats.size

        // Handle range requests for video streaming
        const range = req.headers.range
        if (range) {
            const parts = range.replace(/bytes=/, "").split("-")
            const start = parseInt(parts[0], 10)
            const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1
            const chunksize = (end - start) + 1

            res.status(206)
            res.setHeader('Content-Range', `bytes ${start}-${end}/${fileSize}`)
            res.setHeader('Content-Length', chunksize)

            const stream = fs.createReadStream(clip.filePath, { start, end })
            stream.pipe(res)
        } else {
            res.setHeader('Content-Length', fileSize)
            const stream = fs.createReadStream(clip.filePath)
            stream.pipe(res)
        }

    } catch (error) {
        console.error('Serve clip file error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to serve clip file'
        })
    }
}

module.exports = {
    createClip,
    getAllClips,
    getClipById,
    updateClip,
    deleteClip,
    getRecordingClips,
    serveClipFile
}
