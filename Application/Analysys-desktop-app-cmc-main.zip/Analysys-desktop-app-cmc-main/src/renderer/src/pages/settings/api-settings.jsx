import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useMutation } from '@tanstack/react-query'

import { zodResolver } from '@hookform/resolvers/zod'
import { ConfigSchema } from './schema'
import { resetApi } from '@/lib/axios-instance'

export default function ApiSettings() {
  const form = useForm({
    defaultValues: {
      API_BASE_URL: '',
      API_WS_BASE_URL: ''
    },
    mode: 'onSubmit',
    resolver: zodResolver(ConfigSchema)
  })

  // Load config into form
  useEffect(() => {
    window.apiConfig?.get().then((config) => {
      form.reset(config)
    })
  }, [form])

  // Mutation for updating config
  const mutation = useMutation({
    mutationFn: async (values) => {
      return await window.apiConfig?.update(values)
    },
    onSuccess: () => {
      resetApi()
      ToastSuccess('Config updated successfully!')
    },
    onError: (error) => {
      ToastError(`Failed to update config: ${error.message}`)
    }
  })

  const onSubmit = (values) => {
    mutation.mutate(values)
  }

  return (
    <div className="p-4">
      <Card className="min-h-[calc(100svh-96px)]">
        <CardHeader>
          <CardTitle>
            <h5>API Base URL Update</h5>
          </CardTitle>
          <CardDescription></CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 max-w-lg ">
              <FormField
                control={form.control}
                name="API_BASE_URL"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Back-end URL</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. http://192.168.1.1:4000/api" type="" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="API_WS_BASE_URL"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Back-end Socket URL</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. ws://192.168.1.1:4000" type="" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end">
                <Button type="submit" loading={form.formState.isSubmitting}>
                  Submit
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
