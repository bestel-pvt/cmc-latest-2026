const express = require('express')
const {
    getChannels,
    getChannelById,
    createChannel,
    updateChannel,
    deleteChannel,
    startRecording,
    stopRecording,
    getRecordingStatus,
    getChannelRecordings,
    testChannelStream
} = require('../controllers/channelController.js')

const router = express.Router()

// GET /api/channels - Get all channels with pagination and filters
router.get('/', getChannels)

// GET /api/channels/:id - Get channel by ID
router.get('/:id', getChannelById)

// POST /api/channels - Create new channel
router.post('/', createChannel)

// PUT /api/channels/:id - Update channel
router.put('/:id', updateChannel)

// DELETE /api/channels/:id - Delete channel
router.delete('/:id', deleteChannel)

// Recording endpoints
// POST /api/channels/:id/recording/start - Start recording for channel
router.post('/:id/recording/start', startRecording)

// POST /api/channels/:id/recording/stop - Stop recording for channel  
router.post('/:id/recording/stop', stopRecording)

// GET /api/channels/:id/recording/status - Get recording status for channel
router.get('/:id/recording/status', getRecordingStatus)

// GET /api/channels/:id/recordings - Get all recordings for channel
router.get('/:id/recordings', getChannelRecordings)

// GET /api/channels/:id/test-stream - Test UDP stream connection
router.get('/:id/test-stream', testChannelStream)

module.exports = router
