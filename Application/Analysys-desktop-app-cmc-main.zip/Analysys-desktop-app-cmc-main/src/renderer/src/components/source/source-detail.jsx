import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button, buttonVariants } from '@/components/ui/button'
import {
  Copy,
  Edit,
  RefreshCw,
  Activity,
  Server,
  Link,
  Wifi,
  WifiOff,
  Gauge,
  AlertCircle,
  Signal,
  ChartArea,
  Network,
  Video
} from 'lucide-react'
import { format } from 'date-fns'
import { cn, copyToClipboard } from '@/lib/utils'
import { Link as RouterLink, useNavigate } from 'react-router-dom'
import { getPriorityLabel } from '@/lib/utils'
import { useMutation } from '@tanstack/react-query'
import { connectivitySourceTest, getSourceHealth } from '@/services/source/sourceApi'
import toast from 'react-hot-toast'
import { Progress } from '../ui/progress'

const SourceDetail = ({ source, isPending = false }) => {
  const navigate = useNavigate()

  const mutationSourceHealth = useMutation({
    mutationFn: async () => {
      return await getSourceHealth(source.id)
    },
    onSuccess: (data) => {
      console.log(data)
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || 'An error occurred')
    }
  })

  const mutationSourceTest = useMutation({
    mutationFn: async () => {
      return await connectivitySourceTest(source.id)
    },
    onSuccess: (data) => {
      console.log(data)
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || 'An error occurred')
    }
  })

  const healthData = mutationSourceHealth.data?.data
  const testData = mutationSourceTest.data?.data

  return (
    <div className="space-y-4">
      {/* Header Card */}
      <Card>
        <CardHeader className="flex flex-row items-start gap-4">
          <div className="space-y-1 flex-1">
            <div className="flex justify-between items-start">
              <div className="space-y-4">
                <h1 className="text-2xl font-bold">{source?.type}</h1>
                <p className="font-semibold">
                  Channel:
                  <RouterLink
                    className={cn(
                      buttonVariants({
                        variant: 'link',
                        size: 'sm'
                      })
                    )}
                    to={`/channel/${source.channel.id}`}
                  >
                    {source?.channel?.name}
                  </RouterLink>
                </p>
              </div>
              <Badge variant={source?.isActive ? 'default' : 'destructive'}>
                {source?.isActive ? 'Active' : 'Inactive'}
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* <div className="grid grid-cols-1 lg:grid-cols-2 gap-4"> */}
      {/* Health & Test Cards - appears first on mobile */}
      {/* <div className="order-2 lg:order-1 space-y-4">
               
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                            <CardTitle className="flex items-center gap-2">
                                <Activity className="h-5 w-5" />
                                Health Status
                            </CardTitle>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => mutationSourceHealth.mutate()}
                                disabled={mutationSourceHealth.isPending}
                            >
                                <RefreshCw className={`h-4 w-4 mr-2 ${mutationSourceHealth.isPending ? 'animate-spin' : ''}`} />
                                Refresh
                            </Button>
                        </CardHeader>
                        <CardContent>
                            {healthData ? (
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                                        <div className="flex items-center gap-2 mt-1">
                                            {healthData.isOnline ? (
                                                <Wifi className="h-4 w-4 text-green-500" />
                                            ) : (
                                                <WifiOff className="h-4 w-4 text-red-500" />
                                            )}
                                            <span>{healthData.isOnline ? 'Online' : 'Offline'}</span>
                                        </div>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-medium text-muted-foreground">Last Seen</h3>
                                        <p className="font-medium">
                                            {healthData.lastSeen ? format(new Date(healthData.lastSeen), "PPpp") : 'Never'}
                                        </p>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-medium text-muted-foreground">Quality</h3>
                                        <div className="flex items-center gap-2 mt-1">
                                            <Gauge className="h-4 w-4" />
                                            <span>{healthData.qualityScore}/100</span>
                                        </div>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-medium text-muted-foreground">Packet Loss</h3>
                                        <div className="flex items-center gap-2 mt-1">
                                            <AlertCircle className="h-4 w-4" />
                                            <span>{healthData.packetLoss}%</span>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex items-center justify-center py-8">
                                    <Button
                                        variant="outline"
                                        onClick={() => mutationSourceHealth.mutate()}
                                        disabled={mutationSourceHealth.isPending}
                                    >
                                        <RefreshCw className={`h-4 w-4 mr-2 ${mutationSourceHealth.isPending ? 'animate-spin' : ''}`} />
                                        Check Health
                                    </Button>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                            <CardTitle className="flex items-center gap-2">
                                <Signal className="h-5 w-5" />
                                Connectivity Test
                            </CardTitle>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => mutationSourceTest.mutate()}
                                disabled={mutationSourceTest.isPending}
                            >
                                <RefreshCw className={`h-4 w-4 mr-2 ${mutationSourceTest.isPending ? 'animate-spin' : ''}`} />
                                Test Now
                            </Button>
                        </CardHeader>
                        <CardContent>
                            {testData ? (
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                                        <Badge variant={testData.isReachable ? "default" : "destructive"}>
                                            {testData.isReachable ? 'Reachable' : 'Unreachable'}
                                        </Badge>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-medium text-muted-foreground">Response Time</h3>
                                        <div className="flex items-center gap-2">
                                            <Gauge className="h-4 w-4" />
                                            <span>{testData.responseTime} ms</span>
                                        </div>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-medium text-muted-foreground">Test Time</h3>
                                        <p className="font-medium">
                                            {format(new Date(testData.testTime), "PPpp")}
                                        </p>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-medium text-muted-foreground">Test Status</h3>
                                        <p className="font-medium">{testData.status}</p>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex items-center justify-center py-8">
                                    <Button
                                        variant="outline"
                                        onClick={() => mutationSourceTest.mutate()}
                                        disabled={mutationSourceTest.isPending}
                                    >
                                        <RefreshCw className={`h-4 w-4 mr-2 ${mutationSourceTest.isPending ? 'animate-spin' : ''}`} />
                                        Run Test
                                    </Button>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div> */}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Source Details Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Source Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Type</h3>
                <p className="font-medium">{source?.type}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Primary Source</h3>
                <Badge variant={source?.isPrimary ? 'default' : 'outline'}>
                  {source?.isPrimary ? 'Yes' : 'No'}
                </Badge>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Priority</h3>
                <p className="font-medium">{getPriorityLabel(source?.priority)}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                <Badge variant={source?.isActive ? 'default' : 'destructive'}>
                  {source?.isActive ? 'Active' : 'Inactive'}
                </Badge>
              </div>
            </div>

            <div className="pt-2">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Connection</h3>
              <div className="flex items-center gap-2">
                <code className="text-sm bg-muted rounded px-3 py-2 flex-1 truncate">
                  {source?.ip}:{source?.port}
                </code>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => copyToClipboard(`${source?.ip}:${source?.port}`)}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Channel Info Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Link className="h-5 w-5" />
              Channel Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Channel Name</h3>
                <p className="font-medium">{source?.channel?.name}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Channel Status</h3>
                <Badge variant={source?.channel?.isActive ? 'default' : 'destructive'}>
                  {source?.channel?.isActive ? 'Active' : 'Inactive'}
                </Badge>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Channel ID</h3>
                <p className="font-mono text-sm truncate">{source?.channelId}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      {/* </div> */}

      {/* <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <ChartArea />
                        Stream Health Metrics
                        <Badge variant="outline" className="ml-auto">
                            {source?.streamMetrics?.[0]?.isOnline ? (
                                <span className="flex items-center">
                                    <span className="h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                                    Online
                                </span>
                            ) : (
                                <span className="flex items-center">
                                    <span className="h-2 w-2 rounded-full bg-red-500 mr-2"></span>
                                    Offline
                                </span>
                            )}
                        </Badge>
                    </CardTitle>
                    <CardDescription>
              
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    {source?.streamMetrics?.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        
                            <div className="border rounded-lg p-4 space-y-2">
                                <div className="flex items-center justify-between">
                                    <h5 className="font-medium flex items-center gap-2">
                                        <Video /> Video Quality
                                    </h5>
                                    <div className="text-sm text-muted-foreground">
                                        {source.streamMetrics[0].fps > 0 ? `${source.streamMetrics[0].fps} FPS` : 'N/A'}
                                    </div>
                                </div>
                                <div className="space-y-1">
                                    <div className="flex justify-between text-sm">
                                        <span>Bitrate</span>
                                        <span>
                                            {source.streamMetrics[0].bitrate > 0
                                                ? `${(source.streamMetrics[0].bitrate / 1000).toFixed(2)} Mbps`
                                                : 'N/A'}
                                        </span>
                                    </div>
                                    <Progress
                                        value={source.streamMetrics[0].bitrate > 0
                                            ? Math.min(source.streamMetrics[0].bitrate / 10000, 100)
                                            : 0}
                                        className="h-2"
                                    />
                                </div>
                            </div>

                            <div className="border rounded-lg p-4 space-y-2">
                                <h5 className="font-medium flex items-center gap-2">
                                    <Network /> Network Health
                                </h5>
                                <div className="space-y-1">
                                    <div className="flex justify-between text-sm">
                                        <span>Packet Loss</span>
                                        <span>
                                            {source.streamMetrics[0].packetLoss > 0
                                                ? `${source.streamMetrics[0].packetLoss}%`
                                                : '0%'}
                                        </span>
                                    </div>
                                    <Progress
                                        value={100 - Math.min(source.streamMetrics[0].packetLoss, 100)}
                                        className="h-2"
                                        indicatorColor={
                                            source.streamMetrics[0].packetLoss > 5 ? 'bg-red-500' :
                                                source.streamMetrics[0].packetLoss > 2 ? 'bg-yellow-500' : 'bg-green-500'
                                        }
                                    />
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span>Latency</span>
                                    <span>
                                        {source.streamMetrics[0].latency > 0
                                            ? `${source.streamMetrics[0].latency}ms`
                                            : 'N/A'}
                                    </span>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span>Jitter</span>
                                    <span>
                                        {source.streamMetrics[0].jitter > 0
                                            ? `${source.streamMetrics[0].jitter}ms`
                                            : 'N/A'}
                                    </span>
                                </div>
                            </div>

 
                            <div className="border rounded-lg p-4 space-y-2">
                                <h5 className="font-medium flex items-center gap-2">
                                    <Signal /> Signal Quality
                                </h5>
                                <div className="flex justify-between text-sm">
                                    <span>Signal Strength</span>
                                    <span>
                                        {source.streamMetrics[0].signalStrength > 0
                                            ? `${source.streamMetrics[0].signalStrength} dB`
                                            : 'N/A'}
                                    </span>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span>Quality Score</span>
                                    <span>
                                        {source.streamMetrics[0].qualityScore > 0
                                            ? `${source.streamMetrics[0].qualityScore}/100`
                                            : 'N/A'}
                                    </span>
                                </div>
                                <Progress
                                    value={source.streamMetrics[0].qualityScore || 0}
                                    className="h-2"
                                />
                            </div>

                       
                            <div className="border rounded-lg p-4 space-y-2 col-span-1 md:col-span-2 lg:col-span-3">
                                <h3 className="font-medium flex items-center gap-2">
                                    <AlertCircle className="h-4 w-4" /> Error Counts
                                </h3>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    <div className="flex flex-col items-center p-2 border rounded">
                                        <span className="text-sm text-muted-foreground">PAT Errors</span>
                                        <span className="text-lg font-medium">
                                            {source.streamMetrics[0].patErrors || 0}
                                        </span>
                                    </div>
                                    <div className="flex flex-col items-center p-2 border rounded">
                                        <span className="text-sm text-muted-foreground">PMT Errors</span>
                                        <span className="text-lg font-medium">
                                            {source.streamMetrics[0].pmtErrors || 0}
                                        </span>
                                    </div>
                                    <div className="flex flex-col items-center p-2 border rounded">
                                        <span className="text-sm text-muted-foreground">PCR Errors</span>
                                        <span className="text-lg font-medium">
                                            {source.streamMetrics[0].pcrErrors || 0}
                                        </span>
                                    </div>
                                    <div className="flex flex-col items-center p-2 border rounded">
                                        <span className="text-sm text-muted-foreground">Continuity</span>
                                        <span className="text-lg font-medium">
                                            {source.streamMetrics[0].continuityErrors || 0}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-8 space-y-2">
                            <RefreshCw className="h-8 w-8 text-muted-foreground animate-spin" />
                            <p className="text-muted-foreground">No metrics data available</p>
                        </div>
                    )}
                </CardContent>
            </Card> */}

      {/* Dates Card */}
      <Card>
        <CardHeader>
          <CardTitle>Timestamps</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Created</h3>
              <p className="font-medium">{format(new Date(source?.createdAt), 'PPPpp')}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Last Updated</h3>
              <p className="font-medium">{format(new Date(source?.updatedAt), 'PPPpp')}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end gap-2">
        <Button onClick={() => navigate(`/source/edit/${source?.id}`)} size="sm">
          <Edit className="h-4 w-4" />
          Edit Source
        </Button>
        <Button
          variant="outline"
          onClick={() => navigate(`/channel/${source?.channelId}`)}
          size="sm"
        >
          <Link className="h-4 w-4" />
          View Channel
        </Button>
      </div>
    </div>
  )
}

export default SourceDetail
