@echo off
REM Portable-folder launcher. Flat layout — all DLLs sit next to
REM CMC-VideoWall.exe so Windows loads them from the app directory
REM (required for opengl32 override). Only GStreamer plugins live
REM in a subfolder, pointed at via GST_PLUGIN_PATH.
setlocal
cd /d "%~dp0" 2>nul
if errorlevel 1 (
    echo Cannot cd to launcher directory. Extract the ZIP to a
    echo regular local drive ^(C:, D:, ...^) and try again.
    pause
    exit /b 1
)

set "GST_PLUGIN_PATH=%~dp0gst-plugins"
set "GST_PLUGIN_SCANNER=%~dp0gst-plugin-scanner.exe"
set "GST_PLUGIN_SYSTEM_PATH="
set "GST_REGISTRY=%~dp0registry.cache"

REM Nuke any stale plugin registry from a previous extraction. If the
REM cache says "d3d11videosink not available" (because a prior scan
REM happened on a host without the plugin loaded, or with a different
REM plugin set) GStreamer never re-scans — element lookups just fail
REM with "no element ...". Deleting the cache forces a fresh scan
REM (~1 s on first launch, then cached again). Safe: only affects
REM the app-local cache we set above.
if exist "%GST_REGISTRY%" del /q "%GST_REGISTRY%" 2>nul

REM No GALLIUM_DRIVER / LIBGL_ALWAYS_SOFTWARE here. Setting those
REM globally forces Mesa's software OpenGL even on hosts that HAVE
REM a real GPU (Intel UHD, AMD Radeon, NVIDIA) — which then makes
REM gstopengl.dll fail plugin_init trying to reconcile a software
REM context with the real display, and cascades into gstd3d11.dll
REM (GL interop code) also getting black-listed. Result: no HW
REM decode, no D3D11 render, everything falls back to CPU +
REM software D3D9 sink. On a UHD-770 iGPU that meant Video-Decode
REM graph stayed at 0 % while CPU pegged at 80 %.
REM
REM With no override: Windows loads whichever OpenGL / D3D11 the
REM host actually has, plugins register cleanly, QuickSync/NVDEC
REM does the decode.

REM h264decoder / h265decoder emit "Couldn't find first picture" and
REM "DPB size exceeds max" ERROR-level messages every time a satellite
REM feed's first UDP packet lands mid-GOP (before the next keyframe).
REM They're harmless — recover within ~2 s once the next SPS/PPS+IDR
REM arrives — but at ERROR level they flood the console with hundreds
REM of lines per second across 30 tiles. Silence just those categories.
if "%GST_DEBUG%"=="" set "GST_DEBUG=*:1,libav:0,h264decoder:0,h265decoder:0"
if "%RUST_LOG%"=="" set "RUST_LOG=info"

"%~dp0CMC-VideoWall.exe" %*
