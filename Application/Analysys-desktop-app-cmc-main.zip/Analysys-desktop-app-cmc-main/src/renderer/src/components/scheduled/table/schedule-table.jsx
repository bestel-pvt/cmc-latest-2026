import DataTable from '@/components/ui/data-table/data-table'
import { useScheduleColumns } from './columns'
import { useQuery } from '@tanstack/react-query'
import { getAllScheduleRecording } from '@/services/scheduled-recordings/scheduledRecordingApi'
import { useSearchParams } from 'react-router-dom'
import { useState, useMemo } from 'react'
import ScheduleFilters from '../schedule-filters'

const ScheduleTable = () => {
  const [searchParams, setSearchParams] = useSearchParams()

  // Pagination
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1)
  const [limit, setLimit] = useState(Number(searchParams.get('limit')) || 10)

  // Convert searchParams → filters object
  const filters = useMemo(() => {
    const obj = {}
    searchParams.forEach((value, key) => {
      if (value) obj[key] = value
    })
    return obj
  }, [searchParams])

  // Query with pagination + filters
  const { data, isPending } = useQuery({
    queryKey: ['schedule-recordings', page, limit, filters],
    queryFn: () =>
      getAllScheduleRecording({
        page,
        limit,
        ...filters
      }),
    keepPreviousData: true
  })

  const columns = useScheduleColumns()
  const schedules = data?.data || []
  console.log(schedules)
  return (
    <div>
      {/* Filters */}
      <ScheduleFilters />

      {/* Table */}
      <DataTable
        columns={columns}
        data={schedules}
        isPending={isPending}
        isPagination
        pagination={{
          page,
          limit,
          totalPages: data?.pagination?.totalPages || 1
        }}
        onPageChange={setPage}
        onLimitChange={(newLimit) => {
          setLimit(newLimit)
          setPage(1)
          searchParams.set('limit', String(newLimit))
          setSearchParams(searchParams, { replace: true })
        }}
      />
    </div>
  )
}

export default ScheduleTable
