import ChannelTable from '@/components/channel/table/channel-table'
import Container from '@/components/common/dash-container'

import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { Link } from 'react-router-dom'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const ChannelPage = () => {
  return (
    <Container>
      <Card>
        <CardHeader>
          <CardTitle>
            <div className="flex items-center justify-between">
              <h4>Channel List</h4>
              <Link
                to="/channel/new"
                className={cn(
                  buttonVariants({
                    variant: 'default',
                    size: 'sm'
                  })
                )}
              >
                Create Channel
              </Link>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChannelTable />
        </CardContent>
      </Card>
    </Container>
  )
}

export default ChannelPage
