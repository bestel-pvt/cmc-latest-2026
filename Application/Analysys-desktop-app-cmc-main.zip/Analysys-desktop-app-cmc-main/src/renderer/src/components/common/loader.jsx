import { Loader as LoaderIcon } from 'lucide-react'

const Loader = ({ name }) => {
  return (
    <div className="flex flex-col items-center justify-center gap-3 min-h-[calc(100vh-64px)] text-muted-foreground">
      <LoaderIcon className="size-8 animate-spin" />
      <p className="font-semibold">Loading {name && name} ...</p>
    </div>
  )
}

export default Loader
