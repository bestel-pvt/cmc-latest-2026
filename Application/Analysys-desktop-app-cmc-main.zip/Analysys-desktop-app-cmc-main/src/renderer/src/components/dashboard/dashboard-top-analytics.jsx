import React from 'react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Activity, TrendingUp, Wifi, WifiOff, Clock, BarChart3, Info } from 'lucide-react'
import { format } from 'date-fns'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '../ui/chart'
import { chartConfig } from '@/lib/chart-config'
import { formatNumberShort, getPriorityLabel } from '@/lib/utils'
import { useTopActiveChannels, useTopStableSources } from '@/hooks/use-analytics'
import { Tooltip, TooltipContent, TooltipTrigger } from '../ui/tooltip'
import { Button } from '../ui/button'

const DashboardTopAnalytics = () => {
  const { data, error } = useTopStableSources()
  const { data: channelData, error: channelError } = useTopActiveChannels()
  console.log(data)
  // Helper functions
  const formatBytes = (bytes) => {
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
    if (bytes === 0) return '0 B'
    const i = Math.floor(Math.log(bytes) / Math.log(1024))
    return Math.round((bytes / Math.pow(1024, i)) * 100) / 100 + ' ' + sizes[i]
  }

  const formatNumber = (num) => {
    return new Intl.NumberFormat().format(num)
  }

  // Prepare chart data
  const sourcePerformanceData = data
    .map((item) => ({
      name: `${item.source.type} (${item.source.channel.name})`,
      packets: parseInt(item.totalPackets),
      bytes: parseInt(item.totalBytes),
      avgPacketsPerSec: item.avgPacketsPerSec,
      avgBytesPerSec: item.avgBytesPerSec,
      isActive: item.isCurrentlyActive,
      sourceType: item.source.type,
      channel: item.source.channel.name,
      priority: item.source.priority
    }))
    .filter((item) => item.packets > 0)

  const sourceTypeData = data.reduce((acc, item) => {
    const type = item.source.type
    const existing = acc.find((a) => a.name === type)
    if (existing) {
      existing.count += 1
      existing.totalPackets += parseInt(item.totalPackets)
    } else {
      acc.push({
        name: type,
        count: 1,
        totalPackets: parseInt(item.totalPackets),
        fill: type === 'PTCL' ? '#3b82f6' : type === 'SATELLITE' ? '#10b981' : '#f59e0b'
      })
    }
    return acc
  }, [])

  const channelPerformanceData = channelData.map((item) => ({
    name: item.channel.name,
    totalPackets: parseInt(item.totalPackets),
    totalBytes: parseInt(item.totalBytes),
    avgPacketsPerSec: item.avgPacketsPerSec,
    avgBytesPerSec: item.avgBytesPerSec,
    switchCount: item.switchCount,
    uptime: item.totalUptime,
    downtime: item.totalDowntime,
    streamStarted: item.streamStartedAt,
    streamStopped: item.streamStoppedAt
  }))

  const uptimeData = data.map((item) => ({
    name: `${item.source.type} - ${item.source.channel.name}`,
    uptime: item.totalUptime,
    downtime: item.totalDowntime,
    uptimePercentage: item.uptimePercentage,
    isActive: item.isCurrentlyActive
  }))

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']

  const CustomTooltip = ({ active, payload, label, formatter }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg border-gray-200">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {`${entry.dataKey}: ${formatter ? formatter(entry.value) : entry.value}`}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  return (
    <div className="">
      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Sources</CardTitle>
            <Activity className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {data.filter((d) => d.isCurrentlyActive).length}
            </div>
            <p className="text-xs text-muted-foreground">of {data.length} total sources</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Packets</CardTitle>
            <BarChart3 className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {formatNumber(data.reduce((sum, d) => sum + parseInt(d.totalPackets), 0))}
            </div>
            <p className="text-xs text-muted-foreground">across all sources</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Data Processed</CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {formatBytes(data.reduce((sum, d) => sum + parseInt(d.totalBytes), 0))}
            </div>
            <p className="text-xs text-muted-foreground">total bandwidth used</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Channel Health</CardTitle>
            <Wifi className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {data.length > 0
                ? Math.round(
                    data.reduce((sum, d) => sum + (Number(d.uptimePercentage) || 0), 0) /
                      data.length
                  )
                : 0}{' '}
              %
            </div>
            <p className="text-xs text-muted-foreground">average uptime</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Source Performance Chart */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Source Performance by Packets
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs ">
                <p className="text-sm">
                  This chart shows the total packet volume processed by each streaming source.
                  Higher packet counts indicate more active and stable data streams. Use this to
                  identify which sources are handling the most traffic and ensure optimal load
                  distribution.
                </p>
              </TooltipContent>
            </Tooltip>
          </CardHeader>
          <CardContent>
            <div className="h-">
              {/* <ResponsiveContainer width="100%" height="100%"> */}
              <ChartContainer config={chartConfig}>
                <BarChart
                  data={sourcePerformanceData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="name"
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    fontSize={12}
                    tickLine={false}
                    tickMargin={10}
                    axisLine={false}
                  />
                  <YAxis
                    dataKey="packets"
                    tickFormatter={formatNumberShort}
                    tickLine={false}
                    tickMargin={10}
                    axisLine={false}
                  />
                  <ChartTooltip content={<ChartTooltipContent indicator="line" />} />
                  <Bar dataKey="packets" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ChartContainer>
              {/* </ResponsiveContainer> */}
            </div>
          </CardContent>
        </Card>

        {/* Source Type Distribution */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Source Type Distribution
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs ">
                <p className="text-sm">
                  Distribution of streaming sources by connection type (PTCL, Satellite, RTSP). This
                  helps you understand your infrastructure mix and identify which connection types
                  are most utilized in your streaming setup.
                </p>
              </TooltipContent>
            </Tooltip>
          </CardHeader>
          <CardContent>
            <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sourceTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, count }) => `${name} (${count})`}
                    fontSize={12}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="count"
                  >
                    {sourceTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <RechartsTooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload
                        return (
                          <div className="bg-white p-3 border rounded-lg shadow-lg">
                            <p className="font-medium">{data.name}</p>
                            <p className="text-sm text-gray-600">Sources: {data.count}</p>
                            <p className="text-sm text-gray-600">
                              Total Packets: {formatNumber(data.totalPackets)}
                            </p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Bandwidth Usage Chart */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Bandwidth Usage by Source
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs ">
                <p className="text-sm">
                  Real-time bandwidth consumption across all streaming sources. Monitor data
                  transfer rates to optimize network utilization and identify potential bottlenecks
                  or unusually high consumption patterns.
                </p>
              </TooltipContent>
            </Tooltip>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={sourcePerformanceData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} fontSize={12} />
                  <YAxis tickFormatter={(value) => formatBytes(value)} fontSize={12} />
                  <RechartsTooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white p-3 border rounded-lg shadow-lg">
                            <p className="font-medium">{label}</p>
                            <p className="text-sm text-gray-600">
                              Bytes: {formatBytes(payload[0].value)}
                            </p>
                            <p className="text-sm text-gray-600">
                              Avg Rate: {formatBytes(payload[0].payload.avgBytesPerSec)}
                              /s
                            </p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="bytes"
                    stroke="#8b5cf6"
                    fill="#8b5cf6"
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Channel Activity Status */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <Wifi className="h-5 w-5" />
              Channel Activity Status
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs ">
                <p className="text-sm">
                  Current activity status of all channels showing uptime vs downtime. Green
                  indicates healthy channels, red shows channels with downtime. Use this to quickly
                  identify channels requiring attention.
                </p>
              </TooltipContent>
            </Tooltip>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={uptimeData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} fontSize={12} />
                  <YAxis />
                  <RechartsTooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload
                        return (
                          <div className="bg-white p-3 border rounded-lg shadow-lg">
                            <p className="font-medium">{label}</p>
                            <p className="text-sm text-gray-600">Uptime: {data.uptime}s</p>
                            <p className="text-sm text-gray-600">Downtime: {data.downtime}s</p>
                            <p className="text-sm text-gray-600">
                              Status: {data.isActive ? 'Active' : 'Inactive'}
                            </p>
                            <p className="text-sm text-gray-600">
                              Uptime %: {data.uptimePercentage}%
                            </p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                  <Bar dataKey="uptime" fill="#10b981" name="Uptime" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="downtime" fill="#ef4444" name="Downtime" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Average Throughput Performance */}
        <Card className="hover:shadow-lg transition-shadow lg:col-span-2">
          <CardHeader className="flex items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Average Throughput Performance
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs ">
                <p className="text-sm">
                  Real-time throughput metrics showing packets per second and bytes per second for
                  each source. This dual-metric view helps identify performance bottlenecks and
                  compare efficiency across different source types and channels.
                </p>
              </TooltipContent>
            </Tooltip>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={sourcePerformanceData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} fontSize={12} />
                  <YAxis yAxisId="left" fontSize={12} />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    tickFormatter={(value) => formatBytes(value)}
                    fontSize={12}
                  />
                  <RechartsTooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white p-3 border rounded-lg shadow-lg">
                            <p className="font-medium">{label}</p>
                            <p className="text-sm text-blue-600">
                              Packets/sec: {payload[0]?.value}
                            </p>
                            <p className="text-sm text-purple-600">
                              Bytes/sec: {formatBytes(payload[1]?.value)}
                            </p>
                            <p className="text-sm text-gray-600">
                              Source Type: {payload[0]?.payload?.sourceType}
                            </p>
                            <p className="text-sm text-gray-600">
                              Priority: {getPriorityLabel(payload[0]?.payload?.priority)}
                            </p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="avgPacketsPerSec"
                    stroke="#3b82f6"
                    strokeWidth={3}
                    dot={{ r: 6 }}
                    name="Packets/sec"
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="avgBytesPerSec"
                    stroke="#8b5cf6"
                    strokeWidth={3}
                    dot={{ r: 6 }}
                    name="Bytes/sec"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Channel Overview Table */}
        <Card className="lg:col-span-2 hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Channel Overview
            </CardTitle>
            <CardDescription>
              Comprehensive overview of all channels including stream timing, packet statistics, and
              switch history. Monitor channel health and identify patterns in streaming behavior
              across your network infrastructure.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Channel</th>
                    <th className="text-left p-2">Packets</th>
                    <th className="text-left p-2">Bandwidth</th>
                    <th className="text-left p-2">Switches</th>
                    <th className="text-left p-2">Stream Status</th>
                    <th className="text-left p-2">Last Activity</th>
                  </tr>
                </thead>
                <tbody>
                  {channelData.length === 0 ? (
                    <tr>
                      <td colSpan="6" className="p-4 text-center text-gray-500">
                        <div className="flex flex-col items-center justify-center py-8">
                          <div className="rounded-full bg-gray-100 p-3 mb-3">
                            <WifiOff className="h-6 w-6 text-gray-400" />
                          </div>
                          <p className="font-medium">No channels available</p>
                          <p className="text-sm mt-1">
                            Channels will appear here once they start streaming data
                          </p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    channelData.map((channel, index) => (
                      <tr key={channel.id} className="border-b hover:bg-gray-50">
                        <td className="p-2">
                          <div>
                            <div className="font-medium">{channel.channel.name}</div>
                            <div className="text-xs text-gray-500">
                              {channel.channel.description}
                            </div>
                          </div>
                        </td>
                        <td className="p-2">
                          <div className="text-sm font-mono">
                            {formatNumber(parseInt(channel.totalPackets))}
                          </div>
                          <div className="text-xs text-gray-500">
                            {channel.avgPacketsPerSec}/s avg
                          </div>
                        </td>
                        <td className="p-2">
                          <div className="text-sm font-mono">
                            {formatBytes(parseInt(channel.totalBytes))}
                          </div>
                          <div className="text-xs text-gray-500">
                            {formatBytes(channel.avgBytesPerSec)}/s avg
                          </div>
                        </td>
                        <td className="p-2">
                          <Badge variant={channel.switchCount > 0 ? 'destructive' : 'secondary'}>
                            {channel.switchCount} switches
                          </Badge>
                        </td>
                        <td className="p-2">
                          <div className="flex items-center gap-2">
                            {channel.streamStoppedAt ? (
                              <WifiOff className="h-4 w-4 text-red-500" />
                            ) : (
                              <Wifi className="h-4 w-4 text-green-500" />
                            )}
                            <span className="text-xs">
                              {channel.streamStoppedAt ? 'Stopped' : 'Active'}
                            </span>
                          </div>
                        </td>
                        <td className="p-2 text-xs text-gray-500">
                          {channel.streamStartedAt
                            ? format(new Date(channel.streamStartedAt), 'MMM dd, HH:mm')
                            : 'No data'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Source Status Summary */}
      {/* <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {data.map((source) => (
                    <Card key={source.id} className="hover:shadow-lg transition-shadow">
                        <CardHeader className="pb-3">
                            <div className="flex items-center justify-between">
                                <CardTitle className="text-lg">{source.source.channel.name}</CardTitle>
                                <Badge variant={source.isCurrentlyActive ? "default" : "secondary"}>
                                    {source.isCurrentlyActive ? "Active" : "Inactive"}
                                </Badge>
                            </div>
                            <CardDescription className="text-sm">
                                {source.source.type} • Priority {source.source.priority} • Port {source.source.port}
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                    <p className="text-gray-500">Total Packets</p>
                                    <p className="font-mono font-medium">{formatNumber(parseInt(source.totalPackets))}</p>
                                </div>
                                <div>
                                    <p className="text-gray-500">Total Bytes</p>
                                    <p className="font-mono font-medium">{formatBytes(parseInt(source.totalBytes))}</p>
                                </div>
                                <div>
                                    <p className="text-gray-500">Avg Packets/sec</p>
                                    <p className="font-mono font-medium">{source.avgPacketsPerSec}</p>
                                </div>
                                <div>
                                    <p className="text-gray-500">Avg Bytes/sec</p>
                                    <p className="font-mono font-medium">{formatBytes(source.avgBytesPerSec)}</p>
                                </div>
                            </div>

                            <div className="border-t pt-3">
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-gray-500">Uptime</span>
                                    <span className="font-medium">{source.uptimeFormatted}</span>
                                </div>
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-gray-500">Last Updated</span>
                                    <span className="font-medium">
                                        {format(new Date(source.updatedAt), 'MMM dd, HH:mm')}
                                    </span>
                                </div>
                            </div>

                            {source.lastHealthyAt && (
                                <div className="text-xs text-green-600 bg-green-50 p-2 rounded">
                                    Last healthy: {format(new Date(source.lastHealthyAt), 'MMM dd, HH:mm:ss')}
                                </div>
                            )}

                            {source.lastUnhealthyAt && (
                                <div className="text-xs text-red-600 bg-red-50 p-2 rounded">
                                    Last unhealthy: {format(new Date(source.lastUnhealthyAt), 'MMM dd, HH:mm:ss')}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                ))}
            </div> */}
    </div>
  )
}

export default DashboardTopAnalytics
