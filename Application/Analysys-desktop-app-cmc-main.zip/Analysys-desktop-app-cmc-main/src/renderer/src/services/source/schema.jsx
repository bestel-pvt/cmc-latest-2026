import { z } from 'zod'

export const sourceSchema = z.object({
  type: z.string().min(1, 'Source type is required'),
  ip: z.ipv4().min(1, 'IP address is required'),
  port: z.coerce.number().min(1, 'Port is required').max(9999),
  isPrimary: z.boolean().default(false),
  isActive: z.boolean().default(false),
  priority: z.coerce
    .number()
    .min(1, 'Priority must be at least 1')
    .max(3, 'Priority cannot exceed 3')
})
export const sourceCreateSchema = z.object({
  channelId: z.string().min(1, 'Channel is required'),
  type: z.string().min(1, 'Source type is required'),
  ip: z.ipv4().min(1, 'IP address is required'),
  port: z.coerce.number().min(1, 'Port is required').max(9999),
  isPrimary: z.boolean().default(false),
  isActive: z.boolean().default(false),
  priority: z.coerce
    .number()
    .min(1, 'Priority must be at least 1')
    .max(3, 'Priority cannot exceed 3')
})
