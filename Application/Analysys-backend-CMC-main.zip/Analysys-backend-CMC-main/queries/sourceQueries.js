const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')

class SourceQueries {
    // Get all sources with pagination and filtering
    static getSources({ page = 1, pageSize = 10, channelId, isActive = 'all', isPrimary = 'all', search = '', type = 'all', sort = 'desc' }) {
        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        if (channelId) {
            whereClauses.push('s.channelId = :channelId')
            params.channelId = channelId
        }

        if (search && search.trim() !== '') {
            whereClauses.push('(c.name LIKE :search OR c.description LIKE :search)')
            params.search = `%${search}%`
        }

        if (type !== 'all') {
            whereClauses.push('s.type = :type')
            params.type = type
        }

        if (isActive !== 'all') {
            whereClauses.push('s.isActive = :isActive')
            params.isActive = isActive === 'true' ? 1 : 0
        }

        if (isPrimary !== 'all') {
            whereClauses.push('s.isPrimary = :isPrimary')
            params.isPrimary = isPrimary === 'true' ? 1 : 0
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Build ORDER BY clause
        let orderBy
        if (sort === 'asc') {
            orderBy = 'ORDER BY s.priority ASC, s.createdAt ASC'
        } else if (sort === 'dsc' || sort === 'desc') {
            orderBy = 'ORDER BY s.priority DESC, s.createdAt DESC'
        } else {
            orderBy = 'ORDER BY s.priority DESC, s.createdAt DESC'
        }

        // Get total count
        const countQuery = `
            SELECT COUNT(*) as count 
            FROM sources s
            LEFT JOIN channels c ON s.channelId = c.id
            ${whereClause}
        `
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Calculate pagination
        const take = parseInt(pageSize, 10) || 10
        const skip = (parseInt(page, 10) - 1) * take

        // Get sources with channel info
        const query = `
            SELECT 
                s.*,
                c.name as channelName,
                c.description as channelDescription
            FROM sources s
            LEFT JOIN channels c ON s.channelId = c.id
            ${whereClause}
            ${orderBy}
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        const rows = db.prepare(query).all(params)

        const sources = rows.map(row => ({
            ...row,
            isActive: Boolean(row.isActive),
            isPrimary: Boolean(row.isPrimary),
            channel: {
                name: row.channelName,
                description: row.channelDescription
            }
        }))

        return {
            data: serializeBigInt(sources),
            pagination: {
                total: totalCount,
                page: parseInt(page, 10),
                pageSize: take,
                totalPages: Math.ceil(totalCount / take)
            }
        }
    }

    // Get source by ID
    static getSourceById(id) {
        const query = `
            SELECT 
                s.*,
                c.name as channelName,
                c.description as channelDescription
            FROM sources s
            LEFT JOIN channels c ON s.channelId = c.id
            WHERE s.id = ?
        `

        const row = db.prepare(query).get(id)
        if (!row) return null

        return serializeBigInt({
            ...row,
            isActive: Boolean(row.isActive),
            isPrimary: Boolean(row.isPrimary),
            channel: {
                name: row.channelName,
                description: row.channelDescription
            }
        })
    }

    // Get sources by channel ID
    static getSourcesByChannelId(channelId) {
        const query = `
            SELECT s.*
            FROM sources s
            WHERE s.channelId = ?
            ORDER BY s.priority DESC, s.createdAt ASC
        `

        const rows = db.prepare(query).all(channelId)

        return serializeBigInt(rows.map(row => ({
            ...row,
            isActive: Boolean(row.isActive),
            isPrimary: Boolean(row.isPrimary)
        })))
    }

    // Create a new source
    static createSource({ channelId, type, port, ip, isActive = true, isPrimary = false, priority = 0 }) {
        // Check if channel exists
        const channelExists = db.prepare('SELECT id FROM channels WHERE id = ?').get(channelId)
        if (!channelExists) {
            throw new DatabaseError('Channel not found')
        }

        // Get current timestamp in ISO format
        const now = new Date().toISOString()

        const insertSource = db.prepare(`
            INSERT INTO sources (id, channelId, type, port, ip, isActive, isPrimary, priority, createdAt, updatedAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)

        // Generate CUID-like ID
        const sourceId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)

        insertSource.run(
            sourceId,
            channelId,
            type,
            port,
            ip,
            isActive ? 1 : 0,
            isPrimary ? 1 : 0,
            priority,
            now, // createdAt
            now  // updatedAt
        )

        return this.getSourceById(sourceId)
    }

    // Update source
    static updateSource(id, updates) {
        const existingSource = db.prepare('SELECT * FROM sources WHERE id = ?').get(id)
        if (!existingSource) {
            throw new DatabaseError('Source not found', 'P2025')
        }

        const channelId = existingSource.channelId
        const transaction = db.transaction(() => {
            // If isPrimary is being set to true, unset isPrimary on other sources in the same channel
            if (updates.isPrimary === true) {
                db.prepare('UPDATE sources SET isPrimary = 0 WHERE channelId = ? AND id != ?')
                    .run(channelId, id)
            }

            const allowedFields = ['type', 'port', 'ip', 'isActive', 'isPrimary', 'priority']
            const setClauses = []
            const params = { id }

            allowedFields.forEach(field => {
                if (updates[field] !== undefined) {
                    setClauses.push(`${field} = :${field}`)
                    if (field === 'isActive' || field === 'isPrimary') {
                        params[field] = updates[field] ? 1 : 0
                    } else {
                        params[field] = updates[field]
                    }
                }
            })

            if (setClauses.length === 0) {
                throw new DatabaseError('No valid fields to update')
            }

            // Get current timestamp in ISO format
            const now = new Date().toISOString()
            setClauses.push('updatedAt = :updatedAt')
            params.updatedAt = now

            const query = `UPDATE sources SET ${setClauses.join(', ')} WHERE id = :id`
            const result = db.prepare(query).run(params)

            if (result.changes === 0) {
                throw new DatabaseError('Source not found', 'P2025')
            }
        })

        transaction()
        return this.getSourceById(id)
    }

    // Delete source
    static deleteSource(id) {
        const result = db.prepare('DELETE FROM sources WHERE id = ?').run(id)

        if (result.changes === 0) {
            throw new DatabaseError('Source not found', 'P2025')
        }

        return { success: true }
    }

    // Get source count
    static getSourceCount(where = {}) {
        let whereClauses = []
        let params = {}

        if (where.channelId) {
            whereClauses.push('channelId = :channelId')
            params.channelId = where.channelId
        }

        if (where.isActive !== undefined) {
            whereClauses.push('isActive = :isActive')
            params.isActive = where.isActive ? 1 : 0
        }

        if (where.isPrimary !== undefined) {
            whereClauses.push('isPrimary = :isPrimary')
            params.isPrimary = where.isPrimary ? 1 : 0
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''
        const query = `SELECT COUNT(*) as count FROM sources ${whereClause}`

        return db.prepare(query).get(params)?.count || 0
    }
}

module.exports = SourceQueries
