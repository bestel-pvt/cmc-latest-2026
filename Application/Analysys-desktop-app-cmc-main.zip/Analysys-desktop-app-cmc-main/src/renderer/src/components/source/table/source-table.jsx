import DataTable from '@/components/ui/data-table/data-table'
import { useQuery } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { useSourceColumns } from './columns'
import { getAllSource } from '@/services/source/sourceApi'
import { useSearchParams } from 'react-router-dom'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useDebounce } from 'react-haiku'
import { Trash2 } from 'lucide-react'
import { SOURCE_TYPES } from '@/constants/channel'

const SourceTable = () => {
  const [searchParams, setSearchParams] = useSearchParams()

  // State from URL or defaults
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1)
  const [limit, setLimit] = useState(Number(searchParams.get('limit')) || 10)
  const [search, setSearch] = useState(searchParams.get('search') || '')
  const [isActive, setIsActive] = useState(searchParams.get('isActive') || 'all')
  const [isPriority, setIsPriority] = useState(searchParams.get('isPriority') || 'all')
  const [sort, setSort] = useState(searchParams.get('sort') || 'desc')
  const [type, setType] = useState(searchParams.get('type') || 'all')

  const debouncedSearch = useDebounce(search, 500)

  // Sync to URL
  useEffect(() => {
    const params = {
      page,
      limit,
      search: debouncedSearch || '',
      isActive,
      sort,
      type
    }
    Object.keys(params).forEach((key) => {
      if (params[key] === 'all' || params[key] === '') delete params[key]
    })
    setSearchParams(params)
  }, [page, limit, debouncedSearch, isActive, isPriority, sort, type])

  const { data, isPending } = useQuery({
    queryKey: ['sources', page, limit, debouncedSearch, isActive, isPriority, sort, type],
    queryFn: () =>
      getAllSource({
        page,
        limit,
        search: debouncedSearch,
        isActive,

        sort,
        type
      }),
    keepPreviousData: true
  })

  const sources = data?.data ?? []
  const columns = useSourceColumns()

  console.log(sources)

  const resetFilters = () => {
    setPage(1)
    setLimit(10)
    setSearch('')
    setIsActive('all')
    setIsPriority('all')
    setSort('desc')
    setType('all')
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex gap-4 flex-wrap">
        <Input
          placeholder="Search source..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value)
            setPage(1)
          }}
          className="w-64"
        />

        <Select
          value={isActive}
          onValueChange={(val) => {
            setIsActive(val)
            setPage(1)
          }}
        >
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Active Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="true">Active</SelectItem>
            <SelectItem value="false">Inactive</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={sort}
          onValueChange={(val) => {
            setSort(val)
            setPage(1)
          }}
        >
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Sort Order" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="desc">Newest First</SelectItem>
            <SelectItem value="asc">Oldest First</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={type}
          onValueChange={(val) => {
            setType(val)
            setPage(1)
          }}
        >
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            {SOURCE_TYPES.map((type) => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button onClick={resetFilters} size="icon">
          <Trash2 />
        </Button>
      </div>

      <DataTable
        columns={columns}
        data={sources}
        isPending={isPending}
        pagination={{
          page,
          limit,
          totalPages: data?.pagination?.totalPages || 1
        }}
        onPageChange={setPage}
        onLimitChange={(newLimit) => {
          setLimit(newLimit)
          setPage(1)
        }}
        isPagination
      />
    </div>
  )
}

export default SourceTable
