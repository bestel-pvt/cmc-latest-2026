const { Router } = require('express')
const {
    searchNews,
    getAllNewsChannels,
    getChannelSuggestions
} = require('../controllers/searchController.js')
const {
    getChannelById,
    getChannelsByCategory,
    getAvailableFilters
} = require('../services/searchService.js')

const router = Router()

/**
 * @route GET /api/search
 * @desc Search for news channels by keyword
 * @query {string} q - Search query
 * @query {number} limit - Maximum results (default: 10)
 * @access Public
 * @example /api/search?q=bbc&limit=5
 */
router.get('/', searchNews)

/**
 * @route GET /api/search/channels
 * @desc Get all available news channels
 * @query {number} limit - Maximum results (default: 50)
 * @access Public
 * @example /api/search/channels?limit=20
 */
router.get('/channels', getAllNewsChannels)

/**
 * @route GET /api/search/suggestions
 * @desc Get channel suggestions for autocomplete
 * @query {string} q - Partial search query
 * @query {number} limit - Maximum suggestions (default: 5)
 * @access Public
 * @example /api/search/suggestions?q=ar&limit=3
 */
router.get('/suggestions', getChannelSuggestions)

/**
 * @route GET /api/search/channel/:id
 * @desc Get specific channel by ID
 * @param {string} id - Channel ID
 * @access Public
 * @example /api/search/channel/bbc_news
 */
router.get('/channel/:id', async (req, res) => {
    try {
        const { id } = req.params
        const channel = await getChannelById(id)

        if (!channel) {
            return res.status(404).json({
                success: false,
                message: 'Channel not found'
            })
        }

        res.json({
            success: true,
            data: channel,
            message: 'Channel details retrieved successfully'
        })
    } catch (error) {
        console.error('Get channel error:', error)
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        })
    }
})

/**
 * @route GET /api/search/category/:category
 * @desc Get channels by category
 * @param {string} category - Category name (e.g., 'news')
 * @query {number} limit - Maximum results (default: 20)
 * @access Public
 * @example /api/search/category/news?limit=10
 */
router.get('/category/:category', async (req, res) => {
    try {
        const { category } = req.params
        const { limit = 20 } = req.query

        const channels = await getChannelsByCategory(category, parseInt(limit))

        res.json({
            success: true,
            data: channels,
            total: channels.length,
            category: category,
            message: `Channels in ${category} category`
        })
    } catch (error) {
        console.error('Get category error:', error)
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        })
    }
})

/**
 * @route GET /api/search/filters
 * @desc Get available filter options
 * @access Public
 * @example /api/search/filters
 */
router.get('/filters', async (req, res) => {
    try {
        const filters = await getAvailableFilters()

        res.json({
            success: true,
            data: filters,
            message: 'Available filters retrieved successfully'
        })
    } catch (error) {
        console.error('Get filters error:', error)
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        })
    }
})

module.exports = router
