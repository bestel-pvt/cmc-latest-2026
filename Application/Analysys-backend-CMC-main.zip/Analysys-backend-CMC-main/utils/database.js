const Database = require('better-sqlite3')
const path = require('path')
const fs = require('fs')
const DatabaseInitializer = require('./database-init')

const dbDir = path.join(process.cwd(), 'data')
const dbPath = path.join(dbDir, 'dev.db')

// Ensure directory exists
if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true })
}

// Initialize database if needed
const initializer = new DatabaseInitializer(dbPath)
initializer.initialize().catch(error => {
    console.error('Failed to initialize database:', error)
    process.exit(1)
})

// Open SQLite database from real filesystem
const db = new Database(dbPath)

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL')

// Enable foreign key constraints
db.pragma('foreign_keys = ON')

// Helper function to serialize BigInt values for JSON responses
function serializeBigInt(obj) {
    return JSON.parse(JSON.stringify(obj, (key, value) =>
        typeof value === 'bigint' ? value.toString() : value
    ))
}

// Custom error class for database operations
class DatabaseError extends Error {
    constructor(message, code) {
        super(message)
        this.name = 'DatabaseError'
        this.code = code
    }
}

// Export the database instance and utility functions
module.exports = {
    db,
    serializeBigInt,
    DatabaseError
}