CMC Video Wall - PAK NAVY

To run: double-click CMC-VideoWall.cmd

First launch shows the login screen. Sign in with your
CMC account credentials. The tool remembers you on
subsequent launches until you use the Logout button.

No install required. Copy this whole folder anywhere.

Powered by Analysys - for PAK NAVY.
