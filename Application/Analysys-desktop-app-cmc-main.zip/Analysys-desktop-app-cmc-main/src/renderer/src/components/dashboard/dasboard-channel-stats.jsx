import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Activity, Database, Server, TrendingUp } from 'lucide-react'
import { SkeletonLoader } from './dashboard-stats'

const DashboardChannelStats = ({ data, isPending = false }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Channels</CardTitle>
          <Server className="text-primary" />
        </CardHeader>
        <CardContent>
          <SkeletonLoader isPending={isPending}>
            <div className="text-2xl font-bold">{data?.length}</div>
          </SkeletonLoader>
          <p className="text-xs text-muted-foreground">Active streaming channels</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Online Channels</CardTitle>
          <Activity className="text-green-500" />
        </CardHeader>
        <CardContent>
          <SkeletonLoader isPending={isPending}>
            <div className="text-2xl font-bold text-green-600">
              {data?.filter((item) => !item?.streamStoppedAt)?.length}
            </div>
          </SkeletonLoader>
          <p className="text-xs text-muted-foreground">Currently streaming</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Data Transfer</CardTitle>
          <Database className="text-amber-500" />
        </CardHeader>
        <CardContent>
          <SkeletonLoader isPending={isPending}>
            <div className="text-2xl font-bold">
              {(
                data?.reduce((sum, item) => sum + parseInt(item?.totalBytes), 0) /
                (1024 * 1024 * 1024)
              )?.toFixed(1)}
              GB
            </div>
          </SkeletonLoader>
          <p className="text-xs text-muted-foreground">Across all channels</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Avg Performance</CardTitle>
          <TrendingUp className="text-red-500" />
        </CardHeader>
        <CardContent>
          <SkeletonLoader isPending={isPending}>
            <div className="text-2xl font-bold">
              {(
                data?.reduce((sum, item) => sum + item?.avgBytesPerSec, 0) /
                data?.length /
                1024
              ).toFixed(1)}
              KB/s
            </div>
          </SkeletonLoader>
          <p className="text-xs text-muted-foreground">Average throughput</p>
        </CardContent>
      </Card>
    </div>
  )
}

export default DashboardChannelStats
