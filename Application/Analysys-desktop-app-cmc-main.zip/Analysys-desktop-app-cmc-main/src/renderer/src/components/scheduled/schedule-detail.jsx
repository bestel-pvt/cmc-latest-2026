import { getInitials, getPriorityScheduleLabel } from '@/lib/utils'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '../ui/dialog'
import { DropdownMenuItem } from '../ui/dropdown-menu'
import { Avatar, AvatarFallback } from '../ui/avatar'

const ScheduleDetail = ({ details }) => {
  console.log('details: ', details)

  // Format date and time
  const formatDateTime = (dateString) => {
    const date = new Date(dateString)
    return {
      date: date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }),
      time: date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      })
    }
  }

  const formatDuration = (start, end) => {
    const startDate = new Date(start)
    const endDate = new Date(end)
    const durationMs = endDate - startDate
    const hours = Math.floor(durationMs / (1000 * 60 * 60))
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60))

    if (hours > 0) {
      return `${hours}h ${minutes}m`
    }
    return `${minutes}m`
  }

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'scheduled':
        return 'bg-blue-100 text-blue-800'
      case 'active':
        return 'bg-green-100 text-green-800'
      case 'completed':
        return 'bg-gray-100 text-gray-800'
      case 'cancelled':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const startDateTime = formatDateTime(details.scheduledStart)
  const endDateTime = formatDateTime(details.scheduledEnd)
  const duration = formatDuration(details.scheduledStart, details.scheduledEnd)

  return (
    <Dialog>
      <DialogTrigger asChild>
        <DropdownMenuItem onSelect={(e) => e.preventDefault()}>View schedule</DropdownMenuItem>
      </DialogTrigger>
      <DialogContent className=" max-w-4xl ">
        <DialogHeader>
          <DialogTitle className="space-y-2">
            <h5>{details.name}</h5>
            <div className="flex items-center gap-2 ">
              <span
                className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(details.status)}`}
              >
                {details.status.charAt(0).toUpperCase() + details.status.slice(1)}
              </span>
              {details.isRecurring && (
                <span className="px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                  Recurring
                </span>
              )}
            </div>
          </DialogTitle>
          {details.description && (
            <DialogDescription className="text-base">{details.description}</DialogDescription>
          )}
        </DialogHeader>

        <div className="space-y-6 mt- overflow-auto max-h-[80vh]">
          {/* Channel Information */}
          <div className="border rounded-lg p-4 bg-accent">
            <h3 className="font-semibold text-sm mb-2">CHANNEL</h3>
            <div className="flex items-center gap-3">
              <Avatar className="size-10">
                <AvatarFallback>{getInitials(details?.channel?.name)}</AvatarFallback>
              </Avatar>

              <div>
                <p className="font-medium">{details?.channel?.name}</p>
                <p className="text-sm text-muted-foreground">{details?.channel?.description}</p>
              </div>
            </div>
          </div>

          {/* Schedule Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Start Time */}
            <div className="border rounded-lg p-4">
              <h3 className="font-semibold text-sm mb-2">START TIME</h3>
              <p className="font-medium">{startDateTime.date}</p>
              <p className="text-lg font-bold text-primary">{startDateTime.time}</p>
            </div>

            {/* End Time */}
            <div className="border rounded-lg p-4">
              <h3 className="font-semibold text-sm mb-2">END TIME</h3>
              <p className="font-medium">{endDateTime.date}</p>
              <p className="text-lg font-bold text-primary">{endDateTime.time}</p>
            </div>
          </div>

          {/* Additional Details */}
          <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
            <div className="text-center p-3 bg-accent rounded-lg shadow">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Duration
              </p>
              <p className="text-lg font-bold">{duration}</p>
            </div>

            <div className="text-center p-3 bg-accent rounded-lg shadow">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Priority
              </p>
              <p className={`text font-bold`}>{getPriorityScheduleLabel(details.priority)}</p>
            </div>

            <div className="text-center p-3 bg-accent rounded-lg shadow">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Active
              </p>
              <p
                className={`text-lg font-bold ${details.isActive ? 'text-green-600' : 'text-red-600'}`}
              >
                {details?.isActive ? 'Yes' : 'No'}
              </p>
            </div>

            <div className="text-center p-3 bg-accent rounded-lg shadow">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Notifications
              </p>
              <p
                className={`font-bold ${details.notificationEnabled ? 'text-primary' : 'text-muted-foreground'}`}
              >
                {details.notificationEnabled ? 'On' : 'Off'}
              </p>
            </div>
          </div>

          {/* Recurrence Information */}
          {details.isRecurring && (
            <div className="border rounded-lg p-4 bg-purple-50 border-purple-200">
              <h3 className="font-semibold text-sm text-purple-700 mb-2">RECURRENCE PATTERN</h3>
              <div className="flex items-center gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Type</p>
                  <p className="font-medium text-purple-900 capitalize">{details.recurrenceType}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Rule</p>
                  <p className="font-mono text-sm text-purple-800">{details.recurrenceRule}</p>
                </div>
              </div>
            </div>
          )}

          {/* Timestamps */}
          <div className="border-t pt-4">
            <h3 className="font-semibold text-sm mb-3">METADATA</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Created</p>
                <p className="font-medium">
                  {formatDateTime(details.createdAt).date} at{' '}
                  {formatDateTime(details.createdAt).time}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Last Updated</p>
                <p className="font-medium">
                  {formatDateTime(details.updatedAt).date} at{' '}
                  {formatDateTime(details.updatedAt).time}
                </p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default ScheduleDetail
