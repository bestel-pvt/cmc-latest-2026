import Loader from '@/components/common/loader'
import ScheduleDetail from '@/components/scheduled/schedule-detail'
import { getScheduleRecording } from '@/services/scheduled-recordings/scheduledRecordingApi'
import { useQuery } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'

const ScheduleDetailPage = () => {
  const { id } = useParams()
  const { data, isPending } = useQuery({
    queryKey: ['schedule-recording', id],
    queryFn: () => getScheduleRecording(id),
    enabled: !!id
  })
  console.log(data)
  const schedule = data?.data

  if (isPending) {
    return <Loader name={'Schedule details'} />
  }

  return (
    <div>
      <ScheduleDetail details={schedule} />
    </div>
  )
}

export default ScheduleDetailPage
