export const SORTBY = [
  { name: 'Clip Name(a-z)', value: 'clipName' },
  { name: 'Created At', value: 'createdAt' },
  { name: 'Start Time', value: 'startTime' },
  { name: 'End Time', value: 'endTime' },
  { name: 'Status', value: 'status' }
]
export const STATUS = [
  { name: 'Processing', value: 'processing' },
  { name: 'Completed', value: 'completed' },
  { name: 'Failed', value: 'failed' }
]
