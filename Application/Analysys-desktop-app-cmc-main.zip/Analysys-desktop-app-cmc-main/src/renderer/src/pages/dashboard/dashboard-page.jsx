import Container from '@/components/common/dash-container'
import MetricsDashboard from '@/components/dashboard/metrics/dashboard-metrics'


const DashboardPage = () => {


  return (
    <Container>
      <MetricsDashboard />
    </Container>
  )
}

export default DashboardPage
