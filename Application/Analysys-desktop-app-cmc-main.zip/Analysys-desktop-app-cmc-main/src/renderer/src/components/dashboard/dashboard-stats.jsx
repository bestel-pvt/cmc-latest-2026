import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Clock, Network, Server, Signal, Tv } from 'lucide-react'
import { Skeleton } from '../ui/skeleton'

const DashboardStats = ({ summary, isPending = false }) => {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Channels</CardTitle>
          <Tv className="text-purple-500" />
        </CardHeader>
        <CardContent>
          <SkeletonLoader isPending={isPending}>
            <div className="text-2xl font-bold">{summary?.totalChannels || 0}</div>
          </SkeletonLoader>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Active Streams</CardTitle>
          <Signal className="text-green-500" />
        </CardHeader>
        <CardContent>
          <SkeletonLoader isPending={isPending}>
            <div className="text-2xl font-bold">{summary?.activeStreams || 0}</div>
          </SkeletonLoader>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Active Sources</CardTitle>
          <Network className="text-red-500" />
        </CardHeader>
        <CardContent>
          <SkeletonLoader isPending={isPending}>
            <div className="text-2xl font-bold">{summary?.activeSources || 0}</div>
          </SkeletonLoader>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Uptime (mins)</CardTitle>
          <Clock className="text-blue-500" />
        </CardHeader>
        <CardContent>
          <SkeletonLoader isPending={isPending}>
            <div className="text-2xl font-bold">{summary?.totalUptime || 0}</div>
          </SkeletonLoader>
        </CardContent>
      </Card>
    </div>
  )
}

export default DashboardStats

export const SkeletonLoader = ({ children, isPending = false }) => {
  return isPending ? <Skeleton className="w-1/2 h-8" /> : children
}
