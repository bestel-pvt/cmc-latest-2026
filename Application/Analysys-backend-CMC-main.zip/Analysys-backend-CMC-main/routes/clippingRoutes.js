const express = require('express')
const {
    createClip,
    getAllClips,
    getClipById,
    updateClip,
    deleteClip,
    getRecordingClips,
    serveClipFile
} = require('../controllers/clippingController.js')

const router = express.Router()

// POST /api/clips/recording/:recordingId - Create a new clip from recording
router.post('/recording/:recordingId', createClip)

// GET /api/clips - Get all clips with pagination and filters
router.get('/', getAllClips)

// GET /api/clips/recording/:recordingId - Get all clips for a specific recording
router.get('/recording/:recordingId', getRecordingClips)

// GET /api/clips/:id - Get clip by ID
router.get('/:id', getClipById)

// PUT /api/clips/:id - Update clip
router.put('/:id', updateClip)

// DELETE /api/clips/:id - Delete clip
router.delete('/:id', deleteClip)

// GET /api/clips/:id/file - Serve clip file
router.get('/:id/file', serveClipFile)

module.exports = router
