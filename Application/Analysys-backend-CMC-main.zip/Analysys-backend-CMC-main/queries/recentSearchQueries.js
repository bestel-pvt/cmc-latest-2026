const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')

class RecentSearchQueries {
    // Get recent searches with pagination
    static getRecentSearches({ page = 1, pageSize = 10, type, search = '' }) {
        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        if (type) {
            whereClauses.push('type = :type')
            params.type = type
        }

        if (search && search.trim() !== '') {
            whereClauses.push('(name LIKE :search OR query LIKE :search)')
            params.search = `%${search}%`
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Get total count
        const countQuery = `SELECT COUNT(*) as count FROM recent_searches ${whereClause}`
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Calculate pagination
        const take = parseInt(pageSize, 10) || 10
        const skip = (parseInt(page, 10) - 1) * take

        // Get recent searches
        const query = `
            SELECT *
            FROM recent_searches
            ${whereClause}
            ORDER BY updatedAt DESC
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        const rows = db.prepare(query).all(params)

        return {
            data: serializeBigInt(rows),
            pagination: {
                total: totalCount,
                page: parseInt(page, 10),
                pageSize: take,
                totalPages: Math.ceil(totalCount / take)
            }
        }
    }

    // Get recent search by ID
    static getRecentSearchById(id) {
        const query = 'SELECT * FROM recent_searches WHERE id = ?'
        const row = db.prepare(query).get(id)

        return row ? serializeBigInt(row) : null
    }

    // Find recent search by criteria
    static findRecentSearch(where) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            whereClauses.push(`${key} = :${key}`)
            params[key] = where[key]
        })

        const whereClause = `WHERE ${whereClauses.join(' AND ')}`
        const query = `SELECT * FROM recent_searches ${whereClause} ORDER BY updatedAt DESC LIMIT 1`

        const row = db.prepare(query).get(params)
        return row ? serializeBigInt(row) : null
    }

    // Create a new recent search
    static createRecentSearch({ name, type, query }) {
        const insertSearch = db.prepare(`
            INSERT INTO recent_searches (id, name, type, query, createdAt, updatedAt)
            VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
        `)

        // Generate CUID-like ID
        const searchId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)

        insertSearch.run(searchId, name, type, query)

        return this.getRecentSearchById(searchId)
    }

    // Update recent search
    static updateRecentSearch(id, updates) {
        const allowedFields = ['name', 'type', 'query']
        const setClauses = []
        const params = { id }

        allowedFields.forEach(field => {
            if (updates[field] !== undefined) {
                setClauses.push(`${field} = :${field}`)
                params[field] = updates[field]
            }
        })

        if (setClauses.length === 0) {
            throw new DatabaseError('No valid fields to update')
        }

        setClauses.push('updatedAt = datetime(\'now\')')

        const query = `UPDATE recent_searches SET ${setClauses.join(', ')} WHERE id = :id`
        const result = db.prepare(query).run(params)

        if (result.changes === 0) {
            throw new DatabaseError('Recent search not found', 'P2025')
        }

        return this.getRecentSearchById(id)
    }

    // Delete recent search
    static deleteRecentSearch(id) {
        const result = db.prepare('DELETE FROM recent_searches WHERE id = ?').run(id)

        if (result.changes === 0) {
            throw new DatabaseError('Recent search not found', 'P2025')
        }

        return { success: true }
    }

    // Delete many recent searches
    static deleteRecentSearches(where) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            whereClauses.push(`${key} = :${key}`)
            params[key] = where[key]
        })

        if (whereClauses.length === 0) {
            throw new DatabaseError('Where clause required for deleteMany operation')
        }

        const whereClause = `WHERE ${whereClauses.join(' AND ')}`
        const query = `DELETE FROM recent_searches ${whereClause}`

        const result = db.prepare(query).run(params)

        return { deletedCount: result.changes }
    }

    // Get recent search count
    static getRecentSearchCount(where = {}) {
        let whereClauses = []
        let params = {}

        if (where.type) {
            whereClauses.push('type = :type')
            params.type = where.type
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''
        const query = `SELECT COUNT(*) as count FROM recent_searches ${whereClause}`

        return db.prepare(query).get(params)?.count || 0
    }

    // Find many recent searches (for complex queries)
    static findRecentSearches(options = {}) {
        const {
            filters = {},
            orderBy = 'createdAt',
            orderDirection = 'DESC',
            limit = 10,
            offset = 0
        } = options

        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        Object.keys(filters).forEach(key => {
            if (key === 'search') {
                whereClauses.push('(name LIKE :search OR query LIKE :search)')
                params.search = `%${filters[key]}%`
            } else {
                whereClauses.push(`${key} = :${key}`)
                params[key] = filters[key]
            }
        })

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Build ORDER BY
        const orderByClause = `ORDER BY ${orderBy} ${orderDirection}`

        // Get total count
        const countQuery = `SELECT COUNT(*) as count FROM recent_searches ${whereClause}`
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Get recent searches
        const query = `
            SELECT *
            FROM recent_searches
            ${whereClause}
            ${orderByClause}
            LIMIT :limit OFFSET :offset
        `

        params.limit = limit
        params.offset = offset

        const rows = db.prepare(query).all(params)

        return {
            recentSearches: serializeBigInt(rows),
            total: totalCount
        }
    }
}

module.exports = RecentSearchQueries
