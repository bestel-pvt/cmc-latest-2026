import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '../ui/form'
import { useForm } from 'react-hook-form'
import { Switch } from '../ui/switch'
import { Input } from '../ui/input'
import { Textarea } from '../ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Button } from '../ui/button'
import { DatetimePicker } from '../ui/date-time-picker'

import { SCHEDULE_PRIORITY, SCHEDULE_RECURRENCE_TYPE } from '@/constants/recording'
import ChannelSelect from '../source/channel-select'
import { useNavigate } from 'react-router-dom'
import { zodResolver } from '@hookform/resolvers/zod'
import { ScheduledRecordingSchema } from '@/services/scheduled-recordings/schema'
import { Tooltip, TooltipContent, TooltipTrigger } from '../ui/tooltip'
import { Info } from 'lucide-react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { ToastError, ToastSuccess } from '@/lib/toast'
import {
  createScheduleRecording,
  updateScheduleRecording
} from '@/services/scheduled-recordings/scheduledRecordingApi'
import { useEffect } from 'react'

const ScheduleForm = ({ data }, props) => {
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const form = useForm({
    defaultValues: data || {
      channelId: '',
      name: '',
      description: '',
      scheduledStart: {},
      scheduledEnd: {},
      isRecurring: false,
      recurrenceType: undefined,
      recurrenceRule: undefined,
      priority: undefined,
      notificationEnabled: false
    },
    resolver: zodResolver(ScheduledRecordingSchema),
    mode: 'onSubmit'
  })

  const isRecurring = form.watch('isRecurring')
  const recurrenceType = form.watch('recurrenceType')
  const isCustom = recurrenceType === 'custom'

  useEffect(() => {
    if (!isRecurring) {
      form.setValue('recurrenceType', undefined)
      form.setValue('recurrenceRule', undefined)
    }
  }, [isRecurring, form])

  const mutationSchedule = useMutation({
    mutationFn: async (values) => {
      if (data?.id) {
        const updateValues = {
          name: values.name,
          description: values.description,
          scheduledStart: values.scheduledStart,
          scheduledEnd: values.scheduledEnd,
          isRecurring: values.isRecurring,
          recurrenceType: values.recurrenceType,
          recurrenceRule: values.recurrenceRule,
          notificationEnabled: values.notificationEnabled,
          priority: values.priority
        }
        return await updateScheduleRecording(data?.id, updateValues)
      } else {
        return await createScheduleRecording(values)
      }
    },
    onSuccess: (data) => {
      ToastSuccess(data?.message || 'Operation successful')
      queryClient.invalidateQueries(['schedule-recodings'])
      navigate(-1)
    },
    onError: (error) => {
      ToastError(error?.response?.data?.message || 'An error occurred')
    }
  })

  const onSubmit = async (values) => {
    console.log(values)
    await mutationSchedule.mutateAsync(values)
  }

  return (
    <div {...props}>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <ChannelSelect form={form} isDisabled={data?.id} />

          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Name</FormLabel>
                <FormControl>
                  <Input placeholder="" type="text" {...field} />
                </FormControl>

                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea placeholder="" className="resize-none" {...field} />
                </FormControl>

                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="scheduledStart"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Scheduled Start</FormLabel>
                  <DatetimePicker
                    {...field}
                    format={[
                      ['months', 'days', 'years'],
                      ['hours', 'minutes', 'am/pm']
                    ]}
                    className="w-full"
                  />

                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="scheduledEnd"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Scheduled End</FormLabel>
                  <DatetimePicker
                    {...field}
                    format={[
                      ['months', 'days', 'years'],
                      ['hours', 'minutes', 'am/pm']
                    ]}
                    className="w-full"
                  />
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="isRecurring"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                  <FormLabel>Recurring</FormLabel>
                  <FormDescription>
                    Enable to set up recurring recordings at regular intervals.
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={(checked) => {
                      console.log(checked)
                      field.onChange(checked)
                      if (!checked) {
                        form.setValue('recurrenceType', undefined)
                        form.setValue('recurrenceRule', undefined)
                        console.log(form.getValues())
                      }
                    }}
                  />
                </FormControl>
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="recurrenceType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Recurrence Type</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    disabled={!isRecurring}
                  >
                    <FormControl>
                      <SelectTrigger className="text-left w-full">
                        <SelectValue placeholder="Select a Recurrence Type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {SCHEDULE_RECURRENCE_TYPE?.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center-safe gap-2">
                            <type.icon />
                            <p className="font-semibold">
                              {type.label}{' '}
                              <span className="text-muted-foreground text-xs">
                                ({type.description})
                              </span>
                            </p>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="recurrenceRule"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-1">
                    Recurrence Rule
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="w-4 h-4 text-muted-foreground cursor-pointer" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-sm text-xs leading-relaxed space-y-2">
                        <p>
                          <strong>Custom Recurrence Rules (RRULE)</strong>
                        </p>
                        <p>
                          Format: <code>FREQ=...</code>; add modifiers like <code>INTERVAL</code>,{' '}
                          <code>BYDAY</code>, <code>UNTIL</code>.
                        </p>

                        <ul className="list-disc list-inside space-y-1">
                          <li>
                            <code>FREQ=DAILY</code> → every day
                          </li>
                          <li>
                            <code>FREQ=WEEKLY;BYDAY=MO,WE,FR</code> → Mon, Wed, Fri
                          </li>
                          <li>
                            <code>FREQ=MONTHLY;BYMONTHDAY=15</code> → 15th each month
                          </li>
                          <li>
                            <code>FREQ=YEARLY;BYMONTH=12;BYDAY=-1SU</code> → last Sun in Dec
                          </li>
                          <li>
                            <code>FREQ=DAILY;COUNT=10</code> → stop after 10 times
                          </li>
                          <li>
                            <code>FREQ=WEEKLY;UNTIL=20251231T000000Z</code> → until Dec 31, 2025
                          </li>
                        </ul>

                        <p className="mt-2">
                          Advanced: Use <code>INTERVAL</code> (e.g. every 2 weeks),{' '}
                          <code>BYMONTH</code> (specific months), <code>BYDAY</code> (days of week).
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </FormLabel>

                  <FormControl>
                    <Input
                      placeholder="e.g. FREQ=WEEKLY;BYDAY=MO"
                      disabled={!isRecurring || !isCustom}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="priority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Priority</FormLabel>
                <Select
                  onValueChange={(value) => field.onChange(Number(value))}
                  defaultValue={String(field.value)}
                >
                  <FormControl>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select a priority" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {SCHEDULE_PRIORITY?.map((priority) => (
                      <SelectItem key={priority.value} value={String(priority.value)}>
                        {priority.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="notificationEnabled"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                  <FormLabel>Enabled Notifications</FormLabel>
                  <FormDescription>
                    Enable to receive recording alerts and updates via notifications.
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch checked={field.value} onCheckedChange={field.onChange} />
                </FormControl>
              </FormItem>
            )}
          />
          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => navigate(-1)}>
              Cancel
            </Button>
            <Button type="submit">Save</Button>
          </div>
        </form>
      </Form>
    </div>
  )
}

export default ScheduleForm
