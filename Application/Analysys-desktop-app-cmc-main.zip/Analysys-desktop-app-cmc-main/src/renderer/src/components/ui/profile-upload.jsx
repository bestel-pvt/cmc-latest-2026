import { useId, useEffect, useState } from 'react'
import { ImageUpIcon } from 'lucide-react'
import { Label } from './label'
import { Avatar, AvatarFallback, AvatarImage } from './avatar'
import { uploadFile } from '@/services/uploads/uploadApi'
import { ToastError, ToastSuccess } from '@/lib/toast'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog'
import { Button } from './button'
import { Command, CommandInput, CommandEmpty, CommandGroup, CommandItem } from './command'
import { useDebounce } from 'react-haiku'
import { searchLogos } from '@/services/search/searchApi'
import { useQuery } from '@tanstack/react-query'

const ProfileUpload = ({ value, onChange, fallBack, className, id: propId }) => {
  console.log('check if updating correctly :', value)
  const generatedId = useId()
  const inputId = propId || `profile-image-input-${generatedId}`
  const [preview, setPreview] = useState(null)
  const [openDialog, setOpenDialog] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  const debouncedSearchQuery = useDebounce(searchQuery, 500)

  useEffect(() => {
    if (value instanceof File) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreview(reader.result)
      }
      reader.readAsDataURL(value)
    } else if (typeof value === 'string') {
      setPreview(value)
    } else {
      setPreview(null)
    }
  }, [value])

  const { data, isPending } = useQuery({
    queryKey: ['logo-searches', debouncedSearchQuery],
    queryFn: () => searchLogos(debouncedSearchQuery),
    enabled: !!debouncedSearchQuery
  })

  const logos = data?.data || []

  const handleImageChange = async (event) => {
    const file = event.target.files?.[0]
    if (!file) return

    try {
      onChange(file)
      const res = await uploadFile(file)
      onChange(res?.data?.url)
      ToastSuccess(res?.message)
      setOpenDialog(false)
    } catch (error) {
      console.error('Upload failed:', error)
      ToastError(error?.response?.data?.message)
    }
  }

  const handleLogoSelect = (logoUrl) => {
    console.log(logoUrl)
    onChange(logoUrl)
    setOpenDialog(false)
  }

  return (
    <div className="flex items-center justify-start ">
      <div className="relative">
        <Avatar className={`w-32 h-32 bg-primary/30 ${className}`}>
          <AvatarImage
            src={preview}
            alt="Profile Image"
            className="object-cover"
            crossOrigin="anonymous"
          />
          <AvatarFallback className="font-serif font-bold text-2xl text-primary ">
            {fallBack || 'U'}
          </AvatarFallback>
        </Avatar>

        <Dialog open={openDialog} onOpenChange={setOpenDialog}>
          <DialogTrigger asChild>
            <Label
              // htmlFor={inputId}
              className="absolute bottom-0 right-2 rounded-full bg-primary p-2 border-primary text-white cursor-pointer"
            >
              <ImageUpIcon className="size-5" />
            </Label>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>Upload Logo</DialogTitle>
            </DialogHeader>

            <div className="flex flex-col gap-4 pb-4">
              {/* Option 1: Upload from device */}
              <div>
                <Label htmlFor={inputId} className="font-medium mb-2 block">
                  Upload from device
                </Label>
                <input
                  id={inputId}
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  hidden
                />
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => document.getElementById(inputId).click()}
                >
                  <ImageUpIcon className="mr-2 h-4 w-4" />
                  Select File
                </Button>
              </div>

              {/* Divider with "OR" */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">OR</span>
                </div>
              </div>

              {/* Option 2: Search logos */}
              <div>
                <Label className="font-medium mb-2 block">Search logos</Label>
                <Command className="rounded-lg border shadow-md">
                  <CommandInput
                    placeholder="Search logos..."
                    value={searchQuery}
                    onValueChange={setSearchQuery}
                  />
                  {isPending && <CommandEmpty>Searching...</CommandEmpty>}
                  {!isPending && data.length === 0 && searchQuery && (
                    <CommandEmpty>No logos found</CommandEmpty>
                  )}
                  <CommandGroup className="max-h-96 overflow-y-auto">
                    {logos?.map((logo) => (
                      <CommandItem
                        key={logo.id}
                        value={logo.displayName}
                        onSelect={() => handleLogoSelect(logo.logoUrl)}
                        className="cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={logo.logoUrl}
                            alt={logo.name}
                            className="w-10 h-10 object-contain"
                          />
                          <span>{logo.displayName}</span>
                        </div>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </Command>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}

export default ProfileUpload
