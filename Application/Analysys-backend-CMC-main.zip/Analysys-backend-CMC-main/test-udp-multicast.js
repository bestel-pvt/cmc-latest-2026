const ffmpegStatic = require('ffmpeg-static')
const { spawn } = require('child_process')

async function testUdpMulticast() {
    console.log('🔬 Testing UDP multicast capability...')

    const ip = '127.0.0.1'
    const port = '4000'

    console.log(`\n📡 Testing UDP stream at ${ip}:${port}`)

    // Test 1: Basic UDP probe
    console.log('\n🔍 Test 1: Basic UDP stream probe...')
    await testUdpProbe(ip, port)

    // Test 2: Multiple concurrent UDP connections
    console.log('\n🔍 Test 2: Multiple concurrent UDP connections...')
    await testConcurrentUdpConnections(ip, port)
}

function testUdpProbe(ip, port) {
    return new Promise((resolve) => {
        const probeArgs = [
            '-f', 'mpegts',
            '-i', `udp://${ip}:${port}`,
            '-t', '3',
            '-f', 'null',
            '-'
        ]

        console.log(`Command: ${ffmpegStatic} ${probeArgs.join(' ')}`)

        const probeProcess = spawn(ffmpegStatic, probeArgs, {
            stdio: ['pipe', 'pipe', 'pipe'],
            windowsHide: true
        })

        let hasOutput = false
        let errorOutput = ''

        probeProcess.stderr.on('data', (data) => {
            const output = data.toString()
            errorOutput += output

            if (output.includes('Stream #') || output.includes('Input #')) {
                hasOutput = true
                console.log('✅ Stream detected:', output.trim())
            } else if (output.includes('error') || output.includes('Error')) {
                console.log('⚠️  Error:', output.trim())
            }
        })

        probeProcess.on('exit', (code) => {
            if (hasOutput) {
                console.log('✅ UDP probe successful - stream is accessible')
            } else {
                console.log('❌ UDP probe failed - no stream detected')
                if (errorOutput.includes('Connection refused')) {
                    console.log('   💡 Issue: Connection refused - check if UDP stream is running')
                } else if (errorOutput.includes('No route to host')) {
                    console.log('   💡 Issue: Network routing problem')
                } else {
                    console.log('   💡 Issue: Stream may not be multicast or not available')
                }
            }
            resolve()
        })

        probeProcess.on('error', (error) => {
            console.log('❌ Probe process error:', error.message)
            resolve()
        })

        // Timeout after 10 seconds
        setTimeout(() => {
            if (!probeProcess.killed) {
                probeProcess.kill('SIGTERM')
                console.log('⏱️  Probe timed out after 10 seconds')
                resolve()
            }
        }, 10000)
    })
}

function testConcurrentUdpConnections(ip, port) {
    return new Promise((resolve) => {
        console.log('Starting 2 concurrent UDP connections...')

        const connections = []
        const results = []

        for (let i = 0; i < 2; i++) {
            const args = [
                '-f', 'mpegts',
                '-i', `udp://${ip}:${port}`,
                '-t', '5',
                '-f', 'null',
                '-'
            ]

            console.log(`Connection ${i + 1}: ${ffmpegStatic} ${args.join(' ')}`)

            const process = spawn(ffmpegStatic, args, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            let hasStream = false

            process.stderr.on('data', (data) => {
                const output = data.toString()
                if (output.includes('Stream #') || output.includes('Input #')) {
                    hasStream = true
                } else if (output.includes('bind failed') || output.includes('Error number -10048')) {
                    console.log(`❌ Connection ${i + 1}: Port binding conflict`)
                }
            })

            process.on('exit', (code) => {
                const result = {
                    connection: i + 1,
                    success: hasStream && code === 0,
                    hasStream,
                    exitCode: code
                }
                results.push(result)

                if (result.success) {
                    console.log(`✅ Connection ${i + 1}: Successful`)
                } else if (result.hasStream) {
                    console.log(`⚠️  Connection ${i + 1}: Stream detected but process failed (code: ${code})`)
                } else {
                    console.log(`❌ Connection ${i + 1}: Failed (code: ${code})`)
                }

                if (results.length === 2) {
                    // All connections finished
                    const successCount = results.filter(r => r.success).length
                    console.log(`\n📊 Results: ${successCount}/2 connections successful`)

                    if (successCount === 2) {
                        console.log('✅ Multiple concurrent UDP connections work!')
                        console.log('   👍 Multicast is properly supported')
                    } else if (successCount === 1) {
                        console.log('⚠️  Only one connection worked')
                        console.log('   💡 This suggests port binding conflicts')
                        console.log('   💡 UDP stream might not be multicast or has binding issues')
                    } else {
                        console.log('❌ No connections worked')
                        console.log('   💡 UDP stream is not accessible or not running')
                    }

                    resolve()
                }
            })

            process.on('error', (error) => {
                console.log(`❌ Connection ${i + 1} process error:`, error.message)
            })

            connections.push(process)
        }

        // Timeout after 15 seconds
        setTimeout(() => {
            connections.forEach(proc => {
                if (!proc.killed) {
                    proc.kill('SIGTERM')
                }
            })

            if (results.length < 2) {
                console.log('⏱️  Test timed out')
                resolve()
            }
        }, 15000)
    })
}

// Run the test
if (require.main === module) {
    testUdpMulticast().then(() => {
        console.log('\n✅ UDP multicast test completed')
        process.exit(0)
    }).catch(error => {
        console.error('\n❌ UDP multicast test failed:', error)
        process.exit(1)
    })
}

module.exports = { testUdpMulticast }
