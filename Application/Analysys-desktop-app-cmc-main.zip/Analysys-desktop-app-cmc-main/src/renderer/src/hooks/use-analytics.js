import { useEffect, useState, useCallback } from 'react'

import socketService from '@/services/socket/socketService'
import { api } from '@/lib/axios-instance'

// ------------------------
// Overview Analytics Hook
// ------------------------
export const useOverviewAnalytics = () => {
  const [overviewData, setOverviewData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let mounted = true

    const fetchInitialData = async () => {
      try {
        setIsLoading(true)
        const res = await api.get('/analytics/overview')
        if (mounted) {
          setOverviewData(res.data)
          setError(null)
        }
      } catch (err) {
        if (mounted) {
          setError(err)
          console.error('Failed to fetch overview analytics:', err)
        }
      } finally {
        if (mounted) setIsLoading(false)
      }
    }

    fetchInitialData()

    const handleUpdate = (data) => {
      if (mounted) {
        setOverviewData(data)
        setError(null)
      }
    }

    socketService.subscribeToOverview(handleUpdate)

    return () => {
      mounted = false
      socketService.unsubscribeFromOverview(handleUpdate)
    }
  }, [])

  const refetch = useCallback(async () => {
    try {
      setIsLoading(true)
      const res = await api.get('/analytics/overview')
      setOverviewData(res.data)
      setError(null)
    } catch (err) {
      setError(err)
      console.error('Failed to refetch overview analytics:', err)
    } finally {
      setIsLoading(false)
    }
  }, [])

  return { data: overviewData, isLoading, error, refetch }
}

// ------------------------
// Channel Analytics Hook
// ------------------------
export const useChannelAnalytics = (channelId) => {
  const [channelData, setChannelData] = useState(null)
  const [events, setEvents] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!channelId) {
      setChannelData(null)
      setIsLoading(false)
      return
    }

    let mounted = true

    const fetchInitialData = async () => {
      try {
        setIsLoading(true)
        const res = await api.get(`/analytics/channels/${channelId}`)
        if (mounted) {
          setChannelData(res.data)
          setError(null)
        }
      } catch (err) {
        if (mounted) {
          setError(err)
          console.error(`Failed to fetch channel analytics for ${channelId}:`, err)
        }
      } finally {
        if (mounted) setIsLoading(false)
      }
    }

    fetchInitialData()

    // Handle all channel-related events
    const handleChannelUpdate = (data) => {
      if (mounted && data.channelId === channelId) {
        setChannelData(data)
      }
    }

    const handleChannelEvent = (event) => {
      if (mounted && event.channelId === channelId) {
        setEvents((prev) => [...prev, event])
      }
    }

    socketService.subscribeToChannel(channelId, (payload) => {
      // Distinguish between analytics & events
      if (payload?.data) {
        handleChannelUpdate(payload)
      } else {
        handleChannelEvent(payload)
      }
    })

    return () => {
      mounted = false
      socketService.unsubscribeFromChannel(channelId, handleChannelUpdate)
    }
  }, [channelId])

  const refetch = useCallback(async () => {
    if (!channelId) return
    try {
      setIsLoading(true)
      const res = await api.get(`/analytics/channels/${channelId}`)
      setChannelData(res.data)
      setError(null)
    } catch (err) {
      setError(err)
      console.error(`Failed to refetch channel analytics for ${channelId}:`, err)
    } finally {
      setIsLoading(false)
    }
  }, [channelId])

  return { data: channelData, events, isLoading, error, refetch }
}

// ------------------------
// Top Active Channels Hook
// ------------------------
export const useTopActiveChannels = () => {
  const [topActive, setTopActive] = useState([])
  const [error, setError] = useState(null)

  useEffect(() => {
    let mounted = true

    const handleUpdate = (data) => {
      if (mounted) {
        setTopActive(data)
        setError(null)
      }
    }

    socketService.subscribeToTopActive(handleUpdate)

    return () => {
      mounted = false
      socketService.unsubscribeFromTopActive(handleUpdate)
    }
  }, [])

  return { data: topActive, error }
}

// ------------------------
// Top Stable Sources Hook
// ------------------------
export const useTopStableSources = () => {
  const [topStable, setTopStable] = useState([])
  const [error, setError] = useState(null)

  useEffect(() => {
    let mounted = true

    const handleUpdate = (data) => {
      if (mounted) {
        setTopStable(data)
        setError(null)
      }
    }

    socketService.subscribeToTopStable(handleUpdate)

    return () => {
      mounted = false
      socketService.unsubscribeFromTopStable(handleUpdate)
    }
  }, [])

  return { data: topStable, error }
}

// ------------------------
// General Events Hook
// ------------------------
export const useAnalyticsEvents = (callback) => {
  const stableCallback = useCallback(callback, [callback])

  useEffect(() => {
    socketService.subscribeToEvents(stableCallback)
    return () => socketService.unsubscribeFromEvents(stableCallback)
  }, [stableCallback])
}

// ------------------------
// Socket Connection Status
// ------------------------
export const useSocketConnection = () => {
  const [isConnected, setIsConnected] = useState(false)

  useEffect(() => {
    socketService.connect()

    const checkConnection = () => {
      setIsConnected(socketService.isConnected)
    }

    checkConnection()
    const interval = setInterval(checkConnection, 1000)

    return () => clearInterval(interval)
  }, [])

  return isConnected
}

// ------------------------
// Real-time Metrics Hook
// ------------------------
export const useRealTimeMetrics = () => {
  const [metrics, setMetrics] = useState(null)
  const [error, setError] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    let loadingTimer

    const handleMetrics = (data) => {
      if (!mounted) return

      // Clear the loading timer
      clearTimeout(loadingTimer)
      setIsLoading(false)

      if (data?.error) {
        setError(data.error)
      } else {
        setMetrics(data)
        setError(null)
      }
    }

    // Set a timer to show loading state initially
    loadingTimer = setTimeout(() => {
      if (mounted && isLoading) {
        // Still loading after 1 second
      }
    }, 1000)

    socketService.subscribeToMetrics(handleMetrics)

    return () => {
      mounted = false
      clearTimeout(loadingTimer)
      socketService.unsubscribeFromMetrics(handleMetrics)
    }
  }, [])

  return { data: metrics, error, isLoading }
}
