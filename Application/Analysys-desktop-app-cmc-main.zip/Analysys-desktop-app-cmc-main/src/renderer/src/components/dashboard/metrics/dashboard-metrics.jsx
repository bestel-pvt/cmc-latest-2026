import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { useRealTimeMetrics } from '@/hooks/use-analytics'
import {
  Activity,
  Cpu,
  Database,
  Info,
  MemoryStick
} from 'lucide-react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  RadialBar,
  RadialBarChart,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  XAxis,
  YAxis
} from 'recharts'

// Custom tooltip component for charts
const CustomTooltip = ({ active, payload, label, unit = '', description = '' }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg p-3 shadow-md max-w-xs">
        <p className="text-sm text-muted-foreground font-medium">
          {new Date(label).toLocaleTimeString()}
        </p>
        <p className="font-bold text-lg">
          {payload[0].value}
          {unit}
        </p>
        {description && <p className="text-xs text-muted-foreground mt-1">{description}</p>}
      </div>
    )
  }
  return null
}

// Loading skeleton component
const MetricSkeleton = () => (
  <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
    {[...Array(4)].map((_, i) => (
      <Card key={i}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-4 rounded-full" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-7 w-16 mb-1" />
          <Skeleton className="h-3 w-32" />
        </CardContent>
      </Card>
    ))}
  </div>
)

// Enhanced storage visualization
const StorageVisualization = ({ data, isLoading }) => {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-4 w-60" />
        </CardHeader>
        <CardContent>
          <div className="h-80 flex items-center justify-center">
            <Skeleton className="h-64 w-64 rounded-full" />
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!data) {
    data = {
      recordings: { size: 0, formatted: '0 Bytes', percentage: 0 },
      clips: { size: 0, formatted: '0 Bytes', percentage: 0 },
      uploads: { size: 0, formatted: '0 Bytes', percentage: 0 }
    }
  }

  const { recordings, clips, uploads } = data
  const pieData = [
    {
      name: 'Recordings',
      value: recordings.percentage,
      size: recordings.formatted,
      color: '#8884d8',
      description: 'Video recordings stored on the system'
    },
    {
      name: 'Clips',
      value: clips.percentage,
      size: clips.formatted,
      color: '#82ca9d',
      description: 'Short video clips extracted from recordings'
    },
    {
      name: 'Uploads',
      value: uploads.percentage,
      size: uploads.formatted,
      color: '#ffc658',
      description: 'Content uploaded to external systems or cloud storage'
    }
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="flex items-center justify-between w-full ">
            <div className="flex items-center gap-4">
              <Database className="h-5 w-5" />
              Storage Breakdown
            </div>

            <Tooltip>
              <TooltipTrigger>
                <Info className="h-4 w-4 text-muted-foreground" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="font-semibold">Storage Breakdown</p>
                <p className="mt-2 text-sm">
                  Shows how your storage capacity is distributed across different content types:
                </p>
                <ul className="mt-2 text-xs space-y-1">
                  <li className="flex items-start">
                    <div className="w-3 h-3 rounded-full bg-[#8884d8] mt-1 mr-2"></div>
                    <span>
                      <strong>Recordings</strong>: Full-length video recordings stored on your
                      system
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-3 h-3 rounded-full bg-[#82ca9d] mt-1 mr-2"></div>
                    <span>
                      <strong>Clips</strong>: Short video segments extracted from recordings
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-3 h-3 rounded-full bg-[#ffc658] mt-1 mr-2"></div>
                    <span>
                      <strong>Uploads</strong>: Content synced to cloud or external services
                    </span>
                  </li>
                </ul>
                <p className="mt-2 text-xs ">
                  Monitor storage usage to prevent system slowdowns and ensure continuous recording
                  capability.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
        </CardTitle>
        <CardDescription>
          Distribution of storage usage across different content types
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <RechartsTooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload
                      return (
                        <div className="bg-background border rounded-lg p-3 shadow-md">
                          <p className="font-medium">{data.name}</p>
                          <p className="text-lg font-bold">{data.value}%</p>
                          <p className="text-sm">{data.size}</p>
                          <p className="text-xs text-muted-foreground mt-1">{data.description}</p>
                        </div>
                      )
                    }
                    return null
                  }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex flex-col justify-center space-y-4">
            {pieData.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color }} />
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-xs text-muted-foreground">{item.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold">{item.size}</p>
                  <p className="text-sm text-muted-foreground">{item.value}% of total</p>
                </div>
              </div>
            ))}

            <div className="mt-4 p-3 bg-muted rounded-lg">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Total Used</span>
                <span className="font-bold">
                  {recordings.size + clips.size + uploads.size > 0
                    ? `${((recordings.size + clips.size + uploads.size) / 1024 / 1024).toFixed(2)} MB`
                    : '0 Bytes'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Memory breakdown chart
const MemoryBreakdownChart = ({ data, isLoading }) => {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-4 w-60" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-80 w-full" />
        </CardContent>
      </Card>
    )
  }

  if (!data) {
    data = {
      rss: 0,
      heapTotal: 0,
      heapUsed: 0,
      external: 0,
      arrayBuffers: 0
    }
  }

  const chartData = [
    {
      name: 'RSS',
      value: data.rss,
      formatted: `${(data.rss / 1024 / 1024).toFixed(2)} MB`,
      color: '#8884d8'
    },
    {
      name: 'Heap Total',
      value: data.heapTotal,
      formatted: `${(data.heapTotal / 1024 / 1024).toFixed(2)} MB`,
      color: '#82ca9d'
    },
    {
      name: 'Heap Used',
      value: data.heapUsed,
      formatted: `${(data.heapUsed / 1024 / 1024).toFixed(2)} MB`,
      color: '#ff8042'
    },
    {
      name: 'External',
      value: data.external,
      formatted: `${(data.external / 1024 / 1024).toFixed(2)} MB`,
      color: '#ffc658'
    },
    {
      name: 'Array Buffers',
      value: data.arrayBuffers,
      formatted: `${(data.arrayBuffers / 1024 / 1024).toFixed(2)} MB`,
      color: '#0088FE'
    }
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <MemoryStick className="h-5 w-5" />
              Memory Breakdown
            </div>

            <Tooltip>
              <TooltipTrigger>
                <Info className="h-4 w-4 text-muted-foreground" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="font-semibold">Memory Breakdown</p>
                <p className="mt-2 text-sm">Shows how your system memory is allocated:</p>
                <ul className="mt-2 text-xs space-y-1">
                  <li>
                    <strong>RSS (Resident Set Size)</strong>: Total memory occupied by the process
                  </li>
                  <li>
                    <strong>Heap Total</strong>: Total memory allocated for the JavaScript heap
                  </li>
                  <li>
                    <strong>Heap Used</strong>: Currently used JavaScript heap memory
                  </li>
                  <li>
                    <strong>External</strong>: Memory used by C++ objects bound to JavaScript
                    objects
                  </li>
                  <li>
                    <strong>Array Buffers</strong>: Memory allocated for binary data storage
                  </li>
                </ul>
                <p className="mt-2 text-xs ">
                  High memory usage can impact system performance. Consider optimizing if usage
                  consistently exceeds 80%.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
        </CardTitle>
        <CardDescription>Detailed view of memory allocation and usage</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              layout="vertical"
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                type="number"
                tickFormatter={(value) => `${(value / 1024 / 1024).toFixed(0)} MB`}
              />
              <YAxis type="category" dataKey="name" width={100} />
              <RechartsTooltip
                formatter={(value) => [`${(value / 1024 / 1024).toFixed(2)} MB`, 'Size']}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload
                    return (
                      <div className="bg-background border rounded-lg p-3 shadow-md">
                        <p className="font-medium">{data.name}</p>
                        <p className="text-xs font-bold">{data.formatted}</p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Bar dataKey="value" barSize={30} radius={[0, 4, 4, 0]}>
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

// CPU usage breakdown chart
const CpuBreakdownChart = ({ data, isLoading }) => {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-4 w-60" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-80 w-full" />
        </CardContent>
      </Card>
    )
  }

  if (!data) {
    data = {
      user: 0,
      system: 0,
      usage: 0
    }
  }

  const total = data.user + data.system
  const chartData = [
    {
      name: 'User',
      value: data.user,
      // Convert microseconds to milliseconds for display
      formatted: `${(data.user / 1000).toFixed(0)} ms`,
      percentage: total > 0 ? Math.round((data.user / total) * 100) : 0,
      color: '#8884d8'
    },
    {
      name: 'System',
      value: data.system,
      formatted: `${(data.system / 1000).toFixed(0)} ms`,
      percentage: total > 0 ? Math.round((data.system / total) * 100) : 0,
      color: '#82ca9d'
    }
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <Cpu className="h-5 w-5" />
              CPU Usage Breakdown
            </div>

            <Tooltip>
              <TooltipTrigger>
                <Info className="h-4 w-4 text-muted-foreground" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="font-semibold">CPU Usage Breakdown</p>
                <p className="mt-2 text-sm">Shows how your CPU resources are being utilized:</p>
                <ul className="mt-2 text-xs space-y-1">
                  <li className="flex items-start">
                    <div className="w-3 h-3 rounded-full bg-[#8884d8] mt-1 mr-2"></div>
                    <span>
                      <strong>User</strong>: CPU time spent executing your application code
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-3 h-3 rounded-full bg-[#82ca9d] mt-1 mr-2"></div>
                    <span>
                      <strong>System</strong>: CPU time spent on operating system tasks
                    </span>
                  </li>
                </ul>
                <div className="mt-2 p-2 rounded-md bg-background text-black">
                  <p className="text-xs font-medium">Interpretation Guide:</p>
                  <ul className="text-xs mt-1 space-y-1">
                    <li>
                      • <span className="text-green-600">0-60%</span>: Normal operation
                    </li>
                    <li>
                      • <span className="text-yellow-600">60-80%</span>: High load - monitor closely
                    </li>
                    <li>
                      • <span className="text-red-600">80-100%</span>: Critical - may need
                      optimization
                    </li>
                  </ul>
                </div>
                <p className="mt-2 text-xs">
                  Sustained high CPU usage can cause system slowdowns and increased power
                  consumption.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
        </CardTitle>
        <CardDescription>
          Distribution of CPU time between user and system operations
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart
                innerRadius="20%"
                outerRadius="100%"
                data={[{ name: 'Usage', value: data.usage, fill: '#8884d8' }]}
                startAngle={180}
                endAngle={0}
              >
                <RadialBar minAngle={15} background dataKey="value" />
                <text
                  x="50%"
                  y="50%"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  className="text-2xl font-bold"
                >
                  {data.usage}%
                </text>
                <RechartsTooltip />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>

          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Total CPU Usage</span>
                <span className="font-bold">{data.usage}%</span>
              </div>
              <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full"
                  style={{ width: `${data.usage}%` }}
                />
              </div>
            </div>

            {chartData.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="font-medium">{item.name}</span>
                </div>
                <div className="text-right">
                  <p className="font-bold">{item.formatted}</p>
                  <p className="text-sm text-muted-foreground">{item.percentage}% of CPU time</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// System info component
const SystemInfo = ({ data, isLoading }) => {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-40" />
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-6 w-32" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!data) {
    data = {
      platform: 'Unknown',
      arch: 'Unknown',
      cpuCount: 0,
      uptime: 0,
      nodeVersion: 'Unknown'
    }
  }

  const formatUptime = (seconds) => {
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const mins = Math.floor((seconds % 3600) / 60)

    return `${days}d ${hours}h ${mins}m`
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          System Information
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Platform</p>
            <p className="font-medium">{data.platform}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Architecture</p>
            <p className="font-medium">{data.arch}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">CPU Cores</p>
            <p className="font-medium">{data.cpuCount}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Uptime</p>
            <p className="font-medium">{formatUptime(data.uptime)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Node.js Version</p>
            <p className="font-medium">{data.nodeVersion}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Load Average</p>
            <p className="font-medium">
              {data.loadAverage
                ? data.loadAverage.map((l) => l.toFixed(2)).join(', ')
                : '0.00, 0.00, 0.00'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Time series chart component
const TimeSeriesChart = ({
  data,
  title,
  unit,
  tooltip,
  color = '#8884d8',
  isLoading,
  description
}) => {
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-4 rounded-full" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-48 w-full" />
        </CardContent>
      </Card>
    )
  }

  const chartData =
    data ||
    Array(10)
      .fill(0)
      .map((_, i) => ({
        timestamp: Date.now() - (10 - i) * 1000,
        value: 0
      }))

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-semibold flex items-center gap-2">{title}</CardTitle>
        <Tooltip>
          <TooltipTrigger>
            <Info className="h-4 w-4 text-muted-foreground" />
          </TooltipTrigger>
          <TooltipContent className="max-w-xs">
            <p>{tooltip}</p>
            {description && <p className="mt-1">{description}</p>}
          </TooltipContent>
        </Tooltip>
      </CardHeader>
      <CardContent>
        <div className="h-[200px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.1)" />
              <XAxis
                dataKey="timestamp"
                tickFormatter={(value) => new Date(value).toLocaleTimeString()}
                fontSize={12}
              />
              <YAxis domain={[0, 100]} tickFormatter={(value) => `${value}${unit}`} fontSize={12} />
              <RechartsTooltip content={<CustomTooltip unit={unit} description={description} />} />
              <Area type="monotone" dataKey="value" stroke={color} fill={color} fillOpacity={0.3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

// System metrics component
const SystemMetrics = ({ performance, isLoading }) => {
  if (!performance) {
    performance = {
      current: {
        cpu: { usage: 0 },
        memory: { systemUsage: 0 },
        system: { loadAverage: [0, 0, 0] }
      },
      history: {
        cpuUsage: [],
        memoryUsage: [],
        systemLoad: []
      }
    }
  }

  return (
    <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
      <TimeSeriesChart
        data={performance.history.cpuUsage}
        title="CPU Usage"
        unit="%"
        tooltip="Percentage of CPU capacity being used by the system"
        description="Measures how much of the CPU's processing power is currently in use. High sustained usage may indicate performance bottlenecks."
        color="#8884d8"
        isLoading={isLoading}
      />
      <TimeSeriesChart
        data={performance.history.memoryUsage}
        title="Memory Usage"
        unit="%"
        tooltip="Percentage of system memory currently in use"
        description="Shows the proportion of RAM being utilized. Consistently high usage may lead to swapping and reduced performance."
        color="#82ca9d"
        isLoading={isLoading}
      />
      <TimeSeriesChart
        data={performance.history.systemLoad}
        title="System Load"
        unit=""
        tooltip="System load average over the last 1, 5, and 15 minutes"
        description="Represents the average number of processes waiting to run. Values above CPU core count indicate system overload."
        color="#ff8042"
        isLoading={isLoading}
      />
    </div>
  )
}

// Current metrics component
const CurrentMetrics = ({ metrics, isLoading }) => {
  if (isLoading) {
    return <MetricSkeleton />
  }

  if (!metrics) {
    metrics = {
      performance: {
        current: {
          cpu: { usage: 0 },
          memory: { systemUsage: 0, rss: 0, heapUsed: 0 },
          system: { loadAverage: [0, 0, 0], cpuCount: 0 }
        }
      },
      storage: {
        totalUsed: { formatted: '0 Bytes' },
        breakdown: {
          recordings: { formatted: '0 Bytes', percentage: 0 },
          clips: { formatted: '0 Bytes', percentage: 0 },
          uploads: { formatted: '0 Bytes', percentage: 0 }
        }
      }
    }
  }

  const { performance, storage } = metrics

  return (
    <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-semibold">CPU Usage</CardTitle>
          <Tooltip>
            <TooltipTrigger>
              <Info className="h-4 w-4 text-muted-foreground" />
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p>Current CPU utilization percentage</p>
              <p className="mt-1">
                Measures how much of the CPU&apos;s processing power is currently in use
              </p>
            </TooltipContent>
          </Tooltip>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{performance.current.cpu.usage}%</div>
          <p className="text-xs">{performance.current.system.cpuCount} cores</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-semibold">Memory Usage</CardTitle>
          <Tooltip>
            <TooltipTrigger>
              <Info className="h-4 w-4 text-muted-foreground" />
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p>Current system memory utilization percentage</p>
              <p className="mt-1 ">
                Shows the proportion of RAM being utilized by the application and system processes
              </p>
            </TooltipContent>
          </Tooltip>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{performance.current.memory.systemUsage}%</div>
          <p className="text-xs text-muted-foreground">
            Heap: {(performance.current.memory.heapUsed / 1024 / 1024).toFixed(1)} MB
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-semibold">Storage Used</CardTitle>
          <Tooltip>
            <TooltipTrigger>
              <Info className="h-4 w-4 text-muted-foreground" />
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p>Total storage space currently used</p>
              <p className="mt-1 ">
                Includes recordings, clips, and uploaded content. Monitor to prevent storage
                exhaustion.
              </p>
            </TooltipContent>
          </Tooltip>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{storage.totalUsed.formatted}</div>
          <p className="text-xs text-muted-foreground">
            Recordings: {storage.breakdown.recordings.formatted}
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-semibold">Active Processes</CardTitle>
          <Tooltip>
            <TooltipTrigger>
              <Info className="h-4 w-4 text-muted-foreground" />
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p>Number of currently active recordings and processing clips</p>
              <p className="mt-1 ">
                High numbers may indicate increased system load and resource usage
              </p>
            </TooltipContent>
          </Tooltip>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {metrics.performance?.active?.recordings || 0} Rec /{' '}
            {metrics.performance?.active?.processingClips || 0} Clip
          </div>
          <p className="text-xs text-muted-foreground">
            System load: {performance.current.system.loadAverage[0].toFixed(2)}
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

// Main dashboard component
const MetricsDashboard = () => {
  const { data: metrics, error, isLoading } = useRealTimeMetrics()

  return (
    <div className="">
      <Card className="min-h-[calc(100svh-80px)]">
        <CardHeader>
          <CardTitle>
            <div className="flex items-center justify-between space-y-2">
              <h4>System Metrics Dashboard</h4>
              <div className="flex items-center space-x-2">
                {metrics?.timestamp && (
                  <span className="text-sm text-muted-foreground">
                    Last updated: {new Date(metrics.timestamp).toLocaleTimeString()}
                  </span>
                )}
                {isLoading && (
                  <div className="flex items-center">
                    <div className="h-2 w-2 rounded-full bg-primary animate-ping mr-1" />
                    <span className="text-sm text-muted-foreground">Live</span>
                  </div>
                )}
              </div>
            </div>
          </CardTitle>
        </CardHeader>

        <CardContent>
          {error && (
            <Card className="border-destructive">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 text-destructive">
                  <Info className="h-5 w-5" />
                  <p>Error receiving metrics: {error}</p>
                </div>
              </CardContent>
            </Card>
          )}

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="storage">Storage</TabsTrigger>
              <TabsTrigger value="system">System Info</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <CurrentMetrics metrics={metrics} isLoading={isLoading} />
              <SystemMetrics performance={metrics?.performance} isLoading={isLoading} />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <StorageVisualization data={metrics?.storage?.breakdown} isLoading={isLoading} />
                <CpuBreakdownChart
                  data={metrics?.performance?.current?.cpu}
                  isLoading={isLoading}
                />
              </div>
            </TabsContent>
            <TabsContent value="performance" className="space-y-4">
              <SystemMetrics performance={metrics?.performance} isLoading={isLoading} />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <CpuBreakdownChart
                  data={metrics?.performance?.current?.cpu}
                  isLoading={isLoading}
                />
                <MemoryBreakdownChart
                  data={metrics?.performance?.current?.memory}
                  isLoading={isLoading}
                />
              </div>
            </TabsContent>
            <TabsContent value="storage" className="space-y-4">
              <CurrentMetrics metrics={metrics} isLoading={isLoading} />
              <StorageVisualization data={metrics?.storage?.breakdown} isLoading={isLoading} />
            </TabsContent>
            <TabsContent value="system" className="space-y-4">
              <SystemInfo data={metrics?.performance?.current?.system} isLoading={isLoading} />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <CpuBreakdownChart
                  data={metrics?.performance?.current?.cpu}
                  isLoading={isLoading}
                />
                <MemoryBreakdownChart
                  data={metrics?.performance?.current?.memory}
                  isLoading={isLoading}
                />
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

export default MetricsDashboard
