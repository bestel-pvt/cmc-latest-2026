const Database = require('better-sqlite3')
const path = require('path')
const fs = require('fs')

class DatabaseInitializer {
    constructor(dbPath) {
        this.dbPath = dbPath
        this.db = null
    }

    // Check if database file exists
    databaseExists() {
        return fs.existsSync(this.dbPath)
    }

    // Check if tables exist
    tablesExist() {
        try {
            this.db = new Database(this.dbPath)
            this.db.pragma('journal_mode = WAL')

            const tables = [
                'channels',
                'sources',
                'recordings',
                'clips',
                'recent_searches',
                'scheduled_recordings',
                'recording_conflicts',
                'scheduled_recording_executions',
                'process_states'
            ]

            for (const table of tables) {
                const result = this.db.prepare(`
                    SELECT name FROM sqlite_master
                    WHERE type='table' AND name=?
                `).get(table)

                if (!result) {
                    console.log(`Table '${table}' does not exist`)
                    return false
                }
            }

            console.log('All required tables exist')
            return true
        } catch (error) {
            console.error('Error checking tables:', error)
            return false
        } finally {
            if (this.db) {
                this.db.close()
                this.db = null
            }
        }
    }

    // Initialize database with all tables
    initializeDatabase() {
        console.log('Initializing database...')

        // Ensure directory exists
        const dbDir = path.dirname(this.dbPath)
        if (!fs.existsSync(dbDir)) {
            fs.mkdirSync(dbDir, { recursive: true })
        }

        this.db = new Database(this.dbPath)
        this.db.pragma('journal_mode = WAL')

        try {
            // Create tables in order (respecting foreign key constraints)
            this.createChannelsTable()
            this.createSourcesTable()
            this.createRecordingsTable()
            this.createClipsTable()
            this.createRecentSearchesTable()
            this.createScheduledRecordingsTable()
            this.createRecordingConflictsTable()
            this.createScheduledRecordingExecutionsTable()
            this.createProcessStatesTable()

            // Enable foreign key constraints
            this.db.pragma('foreign_keys = ON')

            console.log('Database initialized successfully!')
        } catch (error) {
            console.error('Error initializing database:', error)
            throw error
        } finally {
            if (this.db) {
                this.db.close()
                this.db = null
            }
        }
    }

    createChannelsTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS channels (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                isActive INTEGER DEFAULT 1,
                logo TEXT,
                isPriority INTEGER DEFAULT 0,
                channelStreamLink TEXT,
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now'))
            )
        `
        this.db.exec(sql)
        console.log('Created channels table')
    }

    createSourcesTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS sources (
                id TEXT PRIMARY KEY,
                channelId TEXT NOT NULL,
                type TEXT NOT NULL,
                port INTEGER NOT NULL,
                ip TEXT NOT NULL,
                isActive INTEGER DEFAULT 1,
                isPrimary INTEGER DEFAULT 0,
                priority INTEGER DEFAULT 0,
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (channelId) REFERENCES channels(id) ON DELETE CASCADE
            )
        `
        this.db.exec(sql)
        console.log('Created sources table')
    }

    createRecordingsTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS recordings (
                id TEXT PRIMARY KEY,
                channelId TEXT NOT NULL,
                fileName TEXT NOT NULL,
                filePath TEXT,
                fileSize INTEGER,
                duration REAL,
                format TEXT DEFAULT 'mp4',
                status TEXT DEFAULT 'recording',
                isActive INTEGER DEFAULT 0,
                sourceIp TEXT,
                sourcePort INTEGER,
                udpLink TEXT,
                startTime TEXT,
                endTime TEXT,
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (channelId) REFERENCES channels(id) ON DELETE CASCADE
            )
        `
        this.db.exec(sql)
        console.log('Created recordings table')
    }

    createClipsTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS clips (
                id TEXT PRIMARY KEY,
                recordingId TEXT NOT NULL,
                clipName TEXT NOT NULL,
                description TEXT,
                startTime REAL,
                endTime REAL,
                duration REAL,
                format TEXT,
                fileName TEXT,
                filePath TEXT,
                fileSize INTEGER,
                tags TEXT,
                status TEXT DEFAULT 'processing',
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (recordingId) REFERENCES recordings(id) ON DELETE CASCADE
            )
        `
        this.db.exec(sql)
        console.log('Created clips table')
    }

    createRecentSearchesTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS recent_searches (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                query TEXT NOT NULL,
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now'))
            )
        `
        this.db.exec(sql)
        console.log('Created recent_searches table')
    }

    createScheduledRecordingsTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS scheduled_recordings (
                id TEXT PRIMARY KEY,
                channelId TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                scheduledStart TEXT NOT NULL,
                scheduledEnd TEXT NOT NULL,
                duration REAL,
                isRecurring INTEGER DEFAULT 0,
                recurrenceType TEXT,
                recurrenceRule TEXT,
                priority INTEGER DEFAULT 1,
                status TEXT DEFAULT 'scheduled',
                isActive INTEGER DEFAULT 1,
                notificationEnabled INTEGER DEFAULT 1,
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (channelId) REFERENCES channels(id) ON DELETE CASCADE
            )
        `
        this.db.exec(sql)
        console.log('Created scheduled_recordings table')
    }

    createRecordingConflictsTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS recording_conflicts (
                id TEXT PRIMARY KEY,
                scheduledRecordingId1 TEXT NOT NULL,
                scheduledRecordingId2 TEXT NOT NULL,
                conflictType TEXT NOT NULL,
                conflictStart TEXT NOT NULL,
                conflictEnd TEXT NOT NULL,
                resolution TEXT,
                isResolved INTEGER DEFAULT 0,
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (scheduledRecordingId1) REFERENCES scheduled_recordings(id) ON DELETE CASCADE,
                FOREIGN KEY (scheduledRecordingId2) REFERENCES scheduled_recordings(id) ON DELETE CASCADE
            )
        `
        this.db.exec(sql)
        console.log('Created recording_conflicts table')
    }

    createScheduledRecordingExecutionsTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS scheduled_recording_executions (
                id TEXT PRIMARY KEY,
                scheduledRecordingId TEXT NOT NULL,
                recordingId TEXT,
                executionStart TEXT,
                executionEnd TEXT,
                status TEXT DEFAULT 'pending',
                failureReason TEXT,
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (scheduledRecordingId) REFERENCES scheduled_recordings(id) ON DELETE CASCADE,
                FOREIGN KEY (recordingId) REFERENCES recordings(id) ON DELETE SET NULL
            )
        `
        this.db.exec(sql)
        console.log('Created scheduled_recording_executions table')
    }

    createProcessStatesTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS process_states (
                id TEXT PRIMARY KEY,
                channelId TEXT NOT NULL,
                processType TEXT NOT NULL,
                status TEXT NOT NULL,
                httpPort INTEGER,
                udpLink TEXT,
                recordingId TEXT,
                startTime TEXT,
                metadata TEXT,
                createdAt TEXT DEFAULT (datetime('now')),
                updatedAt TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (channelId) REFERENCES channels(id) ON DELETE CASCADE
            )
        `
        this.db.exec(sql)
        console.log('Created process_states table')
    }

    // Main initialization method
    async initialize() {
        if (!this.databaseExists()) {
            console.log('Database file does not exist. Creating and initializing...')
            this.initializeDatabase()
        } else if (!this.tablesExist()) {
            console.log('Database exists but tables are missing. Initializing tables...')
            this.initializeDatabase()
        } else {
            console.log('Database and tables already exist. Skipping initialization.')
        }
    }
}

module.exports = DatabaseInitializer
