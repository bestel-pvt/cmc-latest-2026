import ChannelDetail from '@/components/channel/channel-detail'
import ChannelRecording from '@/components/channel/channel-recording'
import ChannelSourceAnalytics from '@/components/channel/channel-source-analystics'

import ChannelStats from '@/components/channel/channel-stats'
import RecordingTable from '@/components/channel/recording-table/recording-table'
import Container from '@/components/common/dash-container'
import Loader from '@/components/common/loader'
import { channelAnalytics, getChannel } from '@/services/channels/channelApi'
import { useQuery } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'

const ChannelDetailPage = () => {
  const { id } = useParams()
  const { data, isPending } = useQuery({
    queryKey: ['channel', id],
    queryFn: () => getChannel(id)
  })

  const { data: stats, isPending: isPendingStats } = useQuery({
    queryKey: ['channel-analytics', id],
    queryFn: () => channelAnalytics(id),
    enabled: !!id
  })

  console.log(stats)

  const channel = data

  if (isPending) {
    return <Loader name={'Channel details'} />
  }

  return (
    <Container>
      {/* <ChannelStats channelId={id} /> */}
      <ChannelDetail channel={channel} isPending={isPending} />
      {/* <ChannelSourceAnalytics id={id} /> */}

      <RecordingTable id={id} />
    </Container>
  )
}

export default ChannelDetailPage
