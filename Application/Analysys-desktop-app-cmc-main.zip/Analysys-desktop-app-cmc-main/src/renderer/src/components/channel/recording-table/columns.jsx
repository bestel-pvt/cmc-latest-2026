// import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { copyToClipboard, getInitials, getRecordingStatus } from '@/lib/utils'
import {
  deleteChannel,
  startChannelStream,
  stopChannelStream
} from '@/services/channels/channelApi'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { format } from 'date-fns'
import { Copy, MoreHorizontal, Pause, Play } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

export const useChannelRecordingColumns = () => {
  const queryClient = useQueryClient()
  const navigate = useNavigate()

  const mutationDelete = useMutation({
    mutationFn: async (id) => {
      return await deleteChannel(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel deleted successful!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.message)
    }
  })

  const mutationStartChannelStreaming = useMutation({
    mutationFn: async (id) => {
      return await startChannelStream(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel stream started successful!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.error)
    }
  })

  const mutationStopChannelStreaming = useMutation({
    mutationFn: async (id) => {
      return await stopChannelStream(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel stopped successful!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      console.log(error)
      ToastError(error?.response?.data?.error)
    }
  })

  return [
    {
      header: 'Sr. no.',
      size: 60,
      enableResizing: true,
      cell: ({ row, table }) => {
        const pagination = table.options.meta?.pagination
        const currentPage = pagination?.page || 1
        const pageSize = pagination?.limit || 10
        return (currentPage - 1) * pageSize + row.index + 1
      }
    },
    {
      accessorKey: 'fileName',
      header: 'File Name',
      size: 10,
      cell: ({ row }) => {
        const fileName = row.getValue('fileName')
        return (
          <div>
            <p className="max-w-2xs truncate">{fileName}</p>
          </div>
        )
      }
    },
    {
      accessorKey: 'status',
      header: 'Status',
      size: 120,
      cell: ({ cell }) => {
        const status = cell.getValue()
        return <div>{getRecordingStatus(status)}</div>
      }
    },
    {
      accessorKey: 'udpLink',
      header: 'Source Link',
      size: 120,
      cell: ({ row }) => {
        return (
          <div className="flex items-center gap-2">
            <code>{row.getValue('udpLink')}</code>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => copyToClipboard(row.getValue('udpLink'))}
            >
              <Copy />
            </Button>
          </div>
        )
      }
    },
    {
      accessorKey: 'fileSize',
      header: 'File Size',
      cell: ({ cell }) => {
        const size = cell.getValue()
        return size ? `${(size / 1024 / 1024).toFixed(2)} MB` : '0 B'
      }
    },
    {
      accessorKey: 'startTime',
      header: 'Start Time',
      size: 150,
      cell: ({ cell }) => {
        const date = cell.getValue()
        return date ? format(new Date(date), 'PPP, pp') : 'N/A'
      }
    },
    {
      accessorKey: 'endTime',
      header: 'End Time',
      size: 150,
      cell: ({ cell }) => {
        const date = cell.getValue()
        return date ? format(new Date(date), 'PPP, pp') : 'N/A'
      }
    },
    {
      accessorKey: 'duration',
      header: 'Duration',
      cell: ({ row }) => {
        const start = new Date(row.original.startTime)
        const end = new Date(row.original.endTime)
        const durationMs = end - start
        const minutes = Math.floor(durationMs / 60000)
        const seconds = ((durationMs % 60000) / 1000).toFixed(0)
        return `${minutes}:${seconds.padStart(2, '0')}`
      }
    },
    {
      id: 'actions',
      enableHiding: false,
      cell: ({ row }) => {
        const recording = row.original
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => copyToClipboard(recording.id)}>
                Copy recording ID
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate(`/recording/${recording?.id}`)}>
                View recording
              </DropdownMenuItem>
              {/* <DropdownMenuItem onClick={() => navigate(`/channel/edit/${channel?.id}`)}>
                Edit recording
              </DropdownMenuItem> */}
              {/* <Dialog>
                <DialogTrigger asChild>
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600">
                    Delete channel
                  </DropdownMenuItem>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Are you sure?</DialogTitle>
                    <DialogDescription>
                      This action cannot be undone. This will permanently delete the channel
                      <strong> {channel.name} </strong> and all its associated data.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button
                      variant="destructive"
                      onClick={() => mutationDelete.mutate(channel.id)}
                      loading={mutationDelete.isPending}
                    >
                      Confirm
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog> */}
            </DropdownMenuContent>
          </DropdownMenu>
        )
      }
    }
  ]
}
