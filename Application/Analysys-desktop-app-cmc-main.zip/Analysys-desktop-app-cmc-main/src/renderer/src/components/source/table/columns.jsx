import { Link, useNavigate } from 'react-router-dom'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { Button, buttonVariants } from '@/components/ui/button'
import { Copy, ExternalLink, MoreHorizontal } from 'lucide-react'
import { cn, copyToClipboard, getPriorityLabel } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { format } from 'date-fns'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { deleteSource } from '@/services/source/sourceApi'

export const useSourceColumns = () => {
  const queryClient = useQueryClient()
  const navigate = useNavigate()

  const mutationDelete = useMutation({
    mutationFn: async (id) => {
      return await deleteSource(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel deleted successful!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.message)
    }
  })

  return [
    {
      header: 'Sr. no.',
      size: 60,
      enableResizing: true,
      cell: ({ row, table }) => {
        const pagination = table.options.meta?.pagination
        const currentPage = pagination?.page || 1
        const pageSize = pagination?.limit || 10
        return (currentPage - 1) * pageSize + row.index + 1
      }
    },

    {
      accessorKey: 'type',
      header: 'Type',
      size: 120,
      enableResizing: true
    },
    {
      accessorKey: 'ipAddress',
      header: 'IP Address',
      size: 200, // Increased size to accommodate IP:port and button
      minSize: 150, // Minimum size to prevent shrinking too much
      maxSize: 250, // Maximum size to prevent expanding too much
      enableResizing: true,
      cell: ({ row }) => {
        const ip = row.original.ip
        const port = row.original.port
        return (
          <div className="font-mono flex items-center justify-between w-1/2 gap-4 ">
            <span className="">
              {ip}:{port}
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => {
                copyToClipboard(`${ip}:${port}`)
              }}
            >
              <Copy className="h-3 w-3" />
            </Button>
          </div>
        )
      }
    },
    {
      accessorKey: 'channel.name',
      header: 'Channel Name',
      size: 180,
      enableResizing: true,
      cell: ({ row }) => {
        const channel = row.original
        return (
          <Link
            className={cn(buttonVariants({ variant: 'link' }))}
            to={`/channel/${channel?.channelId}`}
          >
            {channel?.channel?.name} <ExternalLink />
          </Link>
        )
      }
    },
    {
      accessorKey: 'isActive',
      header: 'Status',
      size: 100,
      enableResizing: true,
      cell: ({ row }) => {
        const isActive = row.original.isActive
        return (
          <Badge variant={isActive ? 'default' : 'destructive'}>
            {isActive ? 'Active' : 'Inactive'}
          </Badge>
        )
      }
    },
    {
      accessorKey: 'isPrimary',
      header: 'Primary',
      size: 100,
      enableResizing: true,
      cell: ({ row }) => {
        const isPrimary = row.original.isPrimary
        return <Badge variant={isPrimary ? 'default' : 'outline'}>{isPrimary ? 'Yes' : 'No'}</Badge>
      }
    },
    {
      accessorKey: 'priority',
      header: 'Priority',
      size: 100,
      enableResizing: true,
      cell: ({ row }) => {
        const priority = row.original.priority
        return getPriorityLabel(priority)
      }
    },
    {
      accessorKey: 'createdAt',
      header: 'Creation Date',
      size: 150,
      cell: ({ cell }) => {
        const date = cell.getValue()
        return date ? format(new Date(date), 'PPP, pp') : '—'
      }
    },
    {
      id: 'actions',
      enableHiding: false,
      cell: ({ row }) => {
        const source = row.original
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => copyToClipboard(source.id)}>
                Copy source ID
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate(`/sources/${source.id}`)}>
                View source
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`/source/edit/${source.id}`)}>
                Edit source
              </DropdownMenuItem>
              <Dialog>
                <DialogTrigger asChild>
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600">
                    Delete source
                  </DropdownMenuItem>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Are you sure?</DialogTitle>
                    <DialogDescription>
                      This action cannot be undone. This will permanently delete the source
                      <strong> {source.name} </strong> and all its associated data.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button
                      variant="destructive"
                      onClick={() => mutationDelete.mutate(source.id)}
                      loading={mutationDelete.isPending}
                    >
                      Confirm
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </DropdownMenuContent>
          </DropdownMenu>
        )
      }
    }
  ]
}
