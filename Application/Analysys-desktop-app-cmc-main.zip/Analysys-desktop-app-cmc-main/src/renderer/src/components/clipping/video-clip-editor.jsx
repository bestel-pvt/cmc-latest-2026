import { useState, useRef, useEffect, useCallback } from 'react'
import { useForm } from 'react-hook-form'
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Scissors,
  Upload,
  Volume2,
  VolumeX,
  Minus,
  Plus
} from 'lucide-react'
import { toast, Toaster } from 'react-hot-toast'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../ui/form'
import { TagsInput } from '../ui/tags-input'
import { Textarea } from '../ui/textarea'

import { VIDEO_EXPORT_FORMATS, VIDEO_SPEED_OPTIONS } from '@/constants/recording'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { createClip } from '@/services/clipping/clipApi'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { zodResolver } from '@hookform/resolvers/zod'
import { ClipSchema } from '@/services/clipping/schema'

const VideoClipEditor = () => {
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const { id } = useParams()
  const { state } = useLocation()
  console.log(state.filePath)

  const [videoFile, setVideoFile] = useState(null)
  const [videoUrl, setVideoUrl] = useState('')
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(1)
  const [isMuted, setIsMuted] = useState(false)
  const [clipStart, setClipStart] = useState(0)
  const [clipEnd, setClipEnd] = useState(0)
  const [clips, setClips] = useState([])
  const [isDragging, setIsDragging] = useState(null)
  const [playbackRate, setPlaybackRate] = useState(1)
  console.log(id)

  const videoRef = useRef(null)
  const timelineRef = useRef(null)
  const fileInputRef = useRef(null)

  const form = useForm({
    defaultValues: {
      clipName: '',
      description: '',
      startTime: 0,
      endTime: 0,
      format: undefined,
      tags: []
    },
    mode: 'all',
    resolver: zodResolver(ClipSchema)
  })

  // const watchedValues = form.watch();

  useEffect(() => {
    if (state?.filePath) {
      const normalizedPath = state.filePath.replace(/\\/g, '/')
      setVideoFile(normalizedPath)
      setVideoUrl(normalizedPath)
    }
  }, [state?.filePath])

  // Handle file upload
  const handleFileUpload = useCallback((event) => {
    const file = event.target.files[0]
    if (!file) return

    if (!file.type.startsWith('video/')) {
      toast.error('Please select a valid video file')
      return
    }

    setVideoFile(file)
    const url = URL.createObjectURL(file)
    setVideoUrl(url)
    setClips([])
    setCurrentTime(0)
    setClipStart(0)
    setClipEnd(0)

    toast.success(`Loaded: ${file.name}`)
  }, [])

  // Video event handlers
  const handleVideoLoad = useCallback(() => {
    if (videoRef.current) {
      const dur = videoRef.current.duration
      setDuration(dur)
      setClipEnd(dur)
      form.setValue('endTime', Math.floor(dur))

      toast.success(`Video loaded: ${Math.floor(dur)}s duration`)
    }
  }, [form.setValue])

  const handleTimeUpdate = useCallback(() => {
    if (videoRef.current && !isDragging) {
      setCurrentTime(videoRef.current.currentTime)
    }
  }, [isDragging])

  // Playback controls
  const togglePlay = useCallback(() => {
    if (!videoRef.current) return

    if (isPlaying) {
      videoRef.current.pause()
    } else {
      videoRef.current.play()
    }
    setIsPlaying(!isPlaying)
  }, [isPlaying])

  const seekTo = useCallback(
    (time) => {
      if (videoRef.current) {
        videoRef.current.currentTime = Math.max(0, Math.min(time, duration))
        setCurrentTime(time)
      }
    },
    [duration]
  )

  const skipBackward = () => seekTo(currentTime - 10)
  const skipForward = () => seekTo(currentTime + 10)

  // Timeline Zoom
  const [zoom, setZoom] = useState(1)
  const [scrollOffset, setScrollOffset] = useState(0)

  const visibleDuration = duration / zoom
  const visibleStart = scrollOffset
  const visibleEnd = Math.min(duration, scrollOffset + visibleDuration)

  // Convert absolute time → percentage (relative to visible window)
  const getTimelinePercentage = (time) => {
    if (!duration) return 0
    const clamped = Math.max(visibleStart, Math.min(time, visibleEnd))
    return ((clamped - visibleStart) / visibleDuration) * 100
  }

  // Convert percentage → absolute time (relative to visible window)
  const getTimeFromPercentage = (percentage) => {
    return visibleStart + percentage * visibleDuration
  }

  // Handle scroll to update visible window
  const handleScroll = (e) => {
    const scrollLeft = e.target.scrollLeft
    const scrollWidth = e.target.scrollWidth
    const clientWidth = e.target.clientWidth

    const scrollRatio = scrollLeft / (scrollWidth - clientWidth)
    setScrollOffset(scrollRatio * (duration - visibleDuration))
  }

  // Timeline interaction
  const handleTimelineClick = useCallback(
    (event) => {
      if (!timelineRef.current || !duration) return

      const rect = timelineRef.current.getBoundingClientRect()
      const x = event.clientX - rect.left
      const percentage = x / rect.width
      const newTime = getTimeFromPercentage(percentage)

      seekTo(newTime)
    },
    [duration, seekTo, visibleStart, visibleDuration]
  )

  const handleTimelineDrag = useCallback(
    (event, type) => {
      if (!timelineRef.current || !duration) return

      const rect = timelineRef.current.getBoundingClientRect()
      const x = Math.max(0, Math.min(event.clientX - rect.left, rect.width))
      const percentage = x / rect.width

      // Compute time within *visible window* instead of whole duration
      let newTime = visibleStart + percentage * visibleDuration

      // Snap to 0.1s or per frame (use frameStep = 1/fps if known)
      newTime = Math.round(newTime * 10) / 10

      if (type === 'start') {
        const maxStart = clipEnd - 0.1
        const clampedStart = Math.max(0, Math.min(newTime, maxStart))
        setClipStart(clampedStart)
        form.setValue('startTime', clampedStart)
      } else if (type === 'end') {
        const minEnd = clipStart + 0.1
        const clampedEnd = Math.max(minEnd, Math.min(newTime, duration))
        setClipEnd(clampedEnd)
        form.setValue('endTime', clampedEnd)
      }
    },
    [duration, clipStart, clipEnd, form, visibleStart, visibleDuration]
  )

  useEffect(() => {
    const timelineEl = timelineRef.current
    if (!timelineEl) return

    const handleWheel = (e) => {
      if (!e.ctrlKey) return // only zoom when holding Ctrl
      e.preventDefault()

      const zoomFactor = e.deltaY < 0 ? 1.2 : 0.8 // scroll up = zoom in, down = zoom out
      setZoom((prev) => {
        const newZoom = Math.max(1, Math.min(prev * zoomFactor, 50)) // limit zoom 1x–50x

        // Keep the zoom centered on mouse cursor
        const rect = timelineEl.getBoundingClientRect()
        const mouseX = e.clientX - rect.left
        const mouseRatio = mouseX / rect.width
        const focusTime = getTimeFromPercentage(mouseRatio)

        const newVisibleDuration = duration / newZoom
        let newScrollOffset = focusTime - mouseRatio * newVisibleDuration
        newScrollOffset = Math.max(0, Math.min(newScrollOffset, duration - newVisibleDuration))

        setScrollOffset(newScrollOffset)
        return newZoom
      })
    }

    timelineEl.addEventListener('wheel', handleWheel, { passive: false })
    return () => timelineEl.removeEventListener('wheel', handleWheel)
  }, [duration, visibleDuration])

  // Mouse event handlers for dragging
  const handleMouseDown = useCallback((type) => {
    setIsDragging(type)
  }, [])

  const handleMouseMove = useCallback(
    (event) => {
      if (isDragging) {
        handleTimelineDrag(event, isDragging)
      }
    },
    [isDragging, handleTimelineDrag]
  )

  const handleMouseUp = useCallback(() => {
    setIsDragging(null)
  }, [])

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove)
      document.addEventListener('mouseup', handleMouseUp)
      return () => {
        document.removeEventListener('mousemove', handleMouseMove)
        document.removeEventListener('mouseup', handleMouseUp)
      }
    }
  }, [isDragging, handleMouseMove, handleMouseUp])

  // Volume and playback controls
  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const handleVolumeChange = (newVolume) => {
    if (videoRef.current) {
      videoRef.current.volume = newVolume
      setVolume(newVolume)
    }
  }

  const handlePlaybackRateChange = (rate) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = rate
      setPlaybackRate(rate)
      toast.success(`Playback speed: ${rate}x`)
    }
  }

  const loadClip = useCallback(
    (clip) => {
      setClipStart(clip.start)
      setClipEnd(clip.end)
      seekTo(clip.start)
      form.setValue('startTime', Math.floor(clip.start))
      form.setValue('endTime', Math.floor(clip.end))
      form.setValue('clipName', clip.name)
      toast.success(`Loaded clip: ${clip.name}`)
    },
    [seekTo, form.setValue]
  )

  // Utility functions
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    const ms = Math.floor((seconds % 1) * 100)
    return `${mins}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`
  }

  const mutationSchedule = useMutation({
    mutationFn: async (values) => {
      return await createClip(id, values)
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries(['clips'])
      ToastSuccess(data?.message || 'Clip created successfully')
      navigate('/clips')
    },
    onError: (error) => {
      ToastError(error?.response?.data?.message || 'An error occurred')
    }
  })

  const onSubmit = async (values) => {
    await mutationSchedule.mutateAsync(values)
  }

  return (
    <div className="w-full max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Video Clip Editor</h1>
      </div>

      {!videoUrl ? (
        <Alert>
          <Upload className="h-4 w-4" />
          <AlertDescription>
            Upload a video file to start editing. Supported formats: MP4, WebM, AVI, MOV
          </AlertDescription>
        </Alert>
      ) : (
        <div className="space-y-6">
          {/* Video Player */}
          <Card>
            <CardContent className="p-0 relative bg-black rounded-lg overflow-hidden aspect-video">
              <video
                ref={videoRef}
                src={videoUrl}
                className="w-full h-full object-contain"
                onLoadedMetadata={handleVideoLoad}
                onTimeUpdate={handleTimeUpdate}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onClick={togglePlay}
                muted={false}
              />

              {/* Video Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

              {/* Play/Pause Overlay */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                {!isPlaying && videoUrl && (
                  <div className="bg-black/50 rounded-full p-4 animate-pulse">
                    <Play size={48} className="text-white ml-1" />
                  </div>
                )}
              </div>

              {/* Time Display */}
              <div className="absolute top-4 left-4 bg-black/70 px-3 py-1 rounded text-sm font-mono text-white">
                {formatTime(currentTime)} / {formatTime(duration)}
              </div>

              {/* Playback Rate */}
              <div className="absolute top-4 right-4 bg-black/70 text-white px-3 py-1 rounded text-sm">
                {playbackRate}x
              </div>
            </CardContent>
          </Card>

          {/* Controls */}
          <Card>
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Button variant="outline" size="icon" onClick={skipBackward}>
                  <SkipBack size={20} />
                </Button>
                <Button size="icon" onClick={togglePlay} className="rounded-full h-12 w-12">
                  {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                </Button>
                <Button variant="outline" size="icon" onClick={skipForward}>
                  <SkipForward size={20} />
                </Button>
              </div>

              <div className="flex items-center gap-4">
                {/* Volume */}
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" onClick={toggleMute}>
                    {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                  </Button>
                  <Slider
                    value={[volume]}
                    min={0}
                    max={1}
                    step={0.1}
                    onValueChange={(value) => handleVolumeChange(value[0])}
                    className="w-20"
                  />
                </div>

                {/* Playback Rate */}
                <Select
                  value={playbackRate.toString()}
                  onValueChange={(value) => handlePlaybackRateChange(parseFloat(value))}
                >
                  <SelectTrigger className="w-20">
                    <SelectValue placeholder="Speed" />
                  </SelectTrigger>
                  <SelectContent>
                    {VIDEO_SPEED_OPTIONS?.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Scissors size={20} />
                Timeline Editor
              </CardTitle>
            </CardHeader>

            <CardContent className="space-y-4 select-none">
              {/* Zoom Controls */}
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setZoom((z) => Math.max(1, z / 2))}
                >
                  <Minus />
                </Button>
                <span className="text-sm">Zoom {zoom.toFixed(1)}x</span>
                <Button variant="outline" size="icon" onClick={() => setZoom((z) => z * 2)}>
                  <Plus />
                </Button>
              </div>

              {/* Timeline */}
              <div
                ref={timelineRef}
                className="relative h-20 bg-muted rounded-lg cursor-pointer overflow-x-scroll"
                onClick={handleTimelineClick}
                onScroll={handleScroll}
              >
                <div className="relative h-full" style={{ width: `${zoom * 100}%` }}>
                  {/* Timeline Background */}
                  <div className="absolute inset-0 bg-gradient-to-r from-muted via-muted-foreground/20 to-muted" />

                  {/* Time markers */}
                  <div className="absolute inset-0">
                    {Array.from({ length: Math.floor(duration / 10) + 1 }, (_, i) => {
                      const time = i * 10
                      return (
                        <div
                          key={i}
                          className="absolute top-0 bottom-0 w-px bg-muted-foreground/30"
                          style={{ left: `${getTimelinePercentage(time)}%` }}
                        >
                          <span className="absolute top-1 left-1 text-xs text-muted-foreground">
                            {time}s
                          </span>
                        </div>
                      )
                    })}
                  </div>

                  {/* Current Time Indicator */}
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-primary z-30"
                    style={{ left: `${getTimelinePercentage(currentTime)}%` }}
                  >
                    <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-primary rounded-full" />
                  </div>

                  {/* Clip Range */}
                  <div
                    className="absolute top-2 bottom-2 bg-primary/30 border-2 border-primary rounded z-20"
                    style={{
                      left: `${getTimelinePercentage(clipStart)}%`,
                      width: `${getTimelinePercentage(clipEnd) - getTimelinePercentage(clipStart)}%`
                    }}
                  >
                    {/* Start Handle */}
                    <div
                      className="absolute left-0 top-0 bottom-0 w-2 bg-primary cursor-ew-resize hover:bg-primary/90 z-10"
                      onMouseDown={() => handleMouseDown('start')}
                    >
                      <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-6 bg-background rounded" />
                    </div>

                    {/* End Handle */}
                    <div
                      className="absolute right-0 top-0 bottom-0 w-2 bg-primary cursor-ew-resize hover:bg-primary/90 z-10"
                      onMouseDown={() => handleMouseDown('end')}
                    >
                      <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-6 bg-background rounded">
                        <span className="opacity-0 hover:opacity-100 text-primary-foreground bg-primary p-1 rounded-full">
                          {clipEnd?.toFixed(1)}
                        </span>
                      </div>
                    </div>

                    {/* Clip Duration Display */}
                    <div className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-primary-foreground bg-primary/20 pointer-events-none">
                      {formatTime(clipEnd - clipStart)}
                    </div>
                  </div>

                  {/* Existing Clips */}
                  {clips.map((clip) => (
                    <div
                      key={clip.id}
                      className="absolute top-0 h-1 bg-green-500 z-10 cursor-pointer hover:h-2 transition-all"
                      style={{
                        left: `${getTimelinePercentage(clip.start)}%`,
                        width: `${getTimelinePercentage(clip.end) - getTimelinePercentage(clip.start)}%`
                      }}
                      onClick={(e) => {
                        e.stopPropagation()
                        loadClip(clip)
                      }}
                      title={`${clip.name} (${formatTime(clip.duration)})`}
                    />
                  ))}
                </div>
              </div>

              {/* Timeline Info */}
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Start: {formatTime(clipStart)}</span>
                <span>Duration: {formatTime(clipEnd - clipStart)}</span>
                <span>End: {formatTime(clipEnd)}</span>
              </div>
            </CardContent>
          </Card>

          {/* Clip Creation Form */}
          <Card>
            <CardHeader>
              <CardTitle>Create Clip</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="clipName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Clip Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Clip Name" type="" {...field} />
                          </FormControl>
                          {/* <FormDescription>This is your public display name.</FormDescription> */}
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="tags"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Enter Tags for clip</FormLabel>
                          <FormControl>
                            <TagsInput
                              value={field.value}
                              onValueChange={field.onChange}
                              placeholder="Enter your tags"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Description for the clip" {...field} />
                        </FormControl>
                        {/* <FormDescription>You can @mention other users and organizations.</FormDescription> */}
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="startTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Time</FormLabel>
                          <FormControl>
                            <Input placeholder="Start time" type="number" {...field} />
                          </FormControl>
                          {/* <FormDescription>This is your public display name.</FormDescription> */}
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="endTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Time</FormLabel>
                          <FormControl>
                            <Input placeholder="End time" type="number" {...field} />
                          </FormControl>
                          {/* <FormDescription>This is your public display name.</FormDescription> */}
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="format"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Clip Saving Formats</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select clip format" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {VIDEO_EXPORT_FORMATS.map((option) => (
                                <SelectItem key={option.value} value={option.value}>
                                  {option.label}{' '}
                                  <span className="text-xs text-muted-foreground">
                                    ({option.extension})
                                  </span>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>

                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex items-center justify-end gap-4">
                    <Button
                      variant="outline"
                      type="button"
                      onClick={() => {
                        setClipStart(currentTime)
                        form.setValue('startTime', Math.floor(currentTime))
                      }}
                    >
                      Set Start
                    </Button>

                    <Button
                      variant="outline"
                      type="button"
                      onClick={() => {
                        setClipEnd(currentTime)
                        form.setValue('endTime', Math.floor(currentTime))
                      }}
                    >
                      Set End
                    </Button>
                    <Button
                      type="submit"
                      className="flex items-center gap-2"
                      loading={form.formState.isSubmitting}
                    >
                      <Scissors size={18} />
                      Create Clip
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

export default VideoClipEditor
