const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')

class RecordingQueries {
    // Get all recordings with advanced pagination and filtering
    static getRecordings({
        page = 1,
        pageSize = 10,
        channelId,
        status,
        isActive = 'all',
        filters = {},
        orderBy = 'startTime',
        orderDirection = 'DESC',
        limit,
        offset,
        includeChannel = false
    }) {
        let whereClauses = []
        let params = {}

        // Handle legacy parameters
        if (channelId) {
            whereClauses.push('r.channelId = :channelId')
            params.channelId = channelId
        }

        if (status) {
            whereClauses.push('r.status = :status')
            params.status = status
        }

        if (isActive !== 'all') {
            whereClauses.push('r.isActive = :isActive')
            params.isActive = isActive === 'true' ? 1 : 0
        }

        // Handle advanced filters
        if (filters.status && filters.status !== '') {
            whereClauses.push('r.status = :filterStatus')
            params.filterStatus = filters.status
        }

        if (typeof filters.isActive !== 'undefined') {
            whereClauses.push('r.isActive = :filterIsActive')
            params.filterIsActive = filters.isActive ? 1 : 0
        }

        if (filters.format && filters.format !== '') {
            whereClauses.push('r.format = :format')
            params.format = filters.format
        }

        if (filters.channelId && filters.channelId !== '') {
            whereClauses.push('r.channelId = :filterChannelId')
            params.filterChannelId = filters.channelId
        }

        if (filters.channelName && filters.channelName !== '') {
            whereClauses.push('c.name LIKE :channelName')
            params.channelName = `%${filters.channelName}%`
        }

        if (filters.fileName && filters.fileName !== '') {
            whereClauses.push('r.fileName LIKE :fileName')
            params.fileName = `%${filters.fileName}%`
        }

        if (filters.sourceIp && filters.sourceIp !== '') {
            whereClauses.push('r.sourceIp = :sourceIp')
            params.sourceIp = filters.sourceIp
        }

        if (filters.sourcePort && filters.sourcePort !== '') {
            whereClauses.push('r.sourcePort = :sourcePort')
            params.sourcePort = filters.sourcePort
        }

        // Date range filters
        if (filters.startTimeFrom) {
            whereClauses.push('r.startTime >= :startTimeFrom')
            params.startTimeFrom = filters.startTimeFrom.toISOString()
        }

        if (filters.startTimeTo) {
            whereClauses.push('r.startTime <= :startTimeTo')
            params.startTimeTo = filters.startTimeTo.toISOString()
        }

        if (filters.endTimeFrom) {
            whereClauses.push('r.endTime >= :endTimeFrom')
            params.endTimeFrom = filters.endTimeFrom.toISOString()
        }

        if (filters.endTimeTo) {
            whereClauses.push('r.endTime <= :endTimeTo')
            params.endTimeTo = filters.endTimeTo.toISOString()
        }

        // Size and duration filters
        if (filters.minFileSize) {
            whereClauses.push('r.fileSize >= :minFileSize')
            params.minFileSize = filters.minFileSize
        }

        if (filters.maxFileSize) {
            whereClauses.push('r.fileSize <= :maxFileSize')
            params.maxFileSize = filters.maxFileSize
        }

        if (filters.minDuration) {
            whereClauses.push('r.duration >= :minDuration')
            params.minDuration = filters.minDuration
        }

        if (filters.maxDuration) {
            whereClauses.push('r.duration <= :maxDuration')
            params.maxDuration = filters.maxDuration
        }

        // Search functionality
        if (filters.search && filters.search !== '') {
            whereClauses.push('(r.fileName LIKE :search OR c.name LIKE :search)')
            params.search = `%${filters.search}%`
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Build ORDER BY clause
        const validOrderBy = ['fileName', 'startTime', 'endTime', 'status', 'fileSize', 'createdAt', 'updatedAt', 'duration', 'sourceIp', 'sourcePort', 'isActive']
        const sortField = validOrderBy.includes(orderBy) ? orderBy : 'startTime'
        const sortDirection = orderDirection.toUpperCase() === 'ASC' ? 'ASC' : 'DESC'
        const orderByClause = `ORDER BY r.${sortField} ${sortDirection}`

        // Get total count
        const countQuery = `
            SELECT COUNT(*) as count
            FROM recordings r
            LEFT JOIN channels c ON r.channelId = c.id
            ${whereClause}
        `
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Calculate pagination
        const take = limit || parseInt(pageSize, 10) || 10
        const skip = offset || (parseInt(page, 10) - 1) * take

        // Get recordings with channel info
        const selectFields = includeChannel
            ? `r.*, c.name as channelName, c.description as channelDescription`
            : `r.*`

        const joinClause = includeChannel
            ? `FROM recordings r LEFT JOIN channels c ON r.channelId = c.id`
            : `FROM recordings r`

        const query = `
            SELECT ${selectFields}
            ${joinClause}
            ${whereClause}
            ${orderByClause}
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        const rows = db.prepare(query).all(params)

        const recordings = rows.map(row => {
            const recording = {
                ...row,
                isActive: Boolean(row.isActive)
            }

            if (includeChannel) {
                recording.channelName = row.channelName
                recording.channelDescription = row.channelDescription
            }

            return recording
        })

        return {
            recordings: serializeBigInt(recordings),
            total: totalCount,
            page: parseInt(page, 10),
            pageSize: take,
            totalPages: Math.ceil(totalCount / take)
        }
    }

    // Get recording by ID
    static getRecordingById(id) {
        const query = `
            SELECT 
                r.*,
                c.name as channelName,
                c.description as channelDescription
            FROM recordings r
            LEFT JOIN channels c ON r.channelId = c.id
            WHERE r.id = ?
        `

        const row = db.prepare(query).get(id)
        if (!row) return null

        return serializeBigInt({
            ...row,
            isActive: Boolean(row.isActive),
            channel: {
                id: row.channelId,
                name: row.channelName,
                description: row.channelDescription
            }
        })
    }

    // Get recordings by channel ID
    static getRecordingsByChannelId(channelId) {
        const query = `
            SELECT r.*
            FROM recordings r
            WHERE r.channelId = ?
            ORDER BY r.startTime DESC
        `

        const rows = db.prepare(query).all(channelId)

        return serializeBigInt(rows.map(row => ({
            ...row,
            isActive: Boolean(row.isActive)
        })))
    }

    // Create a new recording
    static createRecording(recordingData) {
        const {
            channelId,
            fileName,
            filePath,
            fileSize,
            duration,
            format = 'mp4',
            status = 'recording',
            isActive = false,
            sourceIp,
            sourcePort,
            udpLink,
            startTime,
            endTime
        } = recordingData

        // Get current timestamp in ISO format
        const now = new Date().toISOString()

        const insertRecording = db.prepare(`
            INSERT INTO recordings (
                id, channelId, fileName, filePath, fileSize, duration, format,
                status, isActive, sourceIp, sourcePort, udpLink, startTime,
                endTime, createdAt, updatedAt
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)

        // Generate CUID-like ID
        const recordingId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)

        insertRecording.run(
            recordingId,
            channelId,
            fileName,
            filePath,
            fileSize,
            duration,
            format,
            status,
            isActive ? 1 : 0,
            sourceIp,
            sourcePort,
            udpLink,
            startTime || now,
            endTime,
            now, // createdAt
            now  // updatedAt
        )

        return this.getRecordingById(recordingId)
    }

    // Update recording
    static updateRecording(id, updates) {
        const allowedFields = [
            'fileName', 'filePath', 'fileSize', 'duration', 'format',
            'status', 'isActive', 'sourceIp', 'sourcePort', 'udpLink',
            'startTime', 'endTime'
        ]
        const setClauses = []
        const params = { id }

        allowedFields.forEach(field => {
            if (updates[field] !== undefined) {
                setClauses.push(`${field} = :${field}`)
                if (field === 'isActive') {
                    params[field] = updates[field] ? 1 : 0
                } else {
                    params[field] = updates[field]
                }
            }
        })

        if (setClauses.length === 0) {
            throw new DatabaseError('No valid fields to update')
        }

        // Get current timestamp in ISO format
        const now = new Date().toISOString()
        setClauses.push('updatedAt = :updatedAt')
        params.updatedAt = now

        const query = `UPDATE recordings SET ${setClauses.join(', ')} WHERE id = :id`
        const result = db.prepare(query).run(params)

        if (result.changes === 0) {
            throw new DatabaseError('Recording not found', 'P2025')
        }

        return this.getRecordingById(id)
    }

    // Delete recording
    static deleteRecording(id) {
        const result = db.prepare('DELETE FROM recordings WHERE id = ?').run(id)

        if (result.changes === 0) {
            throw new DatabaseError('Recording not found', 'P2025')
        }

        return { success: true }
    }

    // Find unique recording (used to check if already exists)
    static findUniqueRecording(where) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            whereClauses.push(`${key} = :${key}`)
            params[key] = where[key]
        })

        const whereClause = `WHERE ${whereClauses.join(' AND ')}`
        const query = `SELECT * FROM recordings ${whereClause} LIMIT 1`

        const row = db.prepare(query).get(params)
        if (!row) return null

        return serializeBigInt({
            ...row,
            isActive: Boolean(row.isActive)
        })
    }

    // Get recording count
    static getRecordingCount(where = {}) {
        let whereClauses = []
        let params = {}

        if (where.channelId) {
            whereClauses.push('channelId = :channelId')
            params.channelId = where.channelId
        }

        if (where.status) {
            whereClauses.push('status = :status')
            params.status = where.status
        }

        if (where.isActive !== undefined) {
            whereClauses.push('isActive = :isActive')
            params.isActive = where.isActive ? 1 : 0
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''
        const query = `SELECT COUNT(*) as count FROM recordings ${whereClause}`

        return db.prepare(query).get(params)?.count || 0
    }

    // Get recordings within date range
    static getRecordingsInRange(startDate, endDate) {
        const query = `
            SELECT r.*
            FROM recordings r
            WHERE r.startTime BETWEEN ? AND ?
            ORDER BY r.startTime DESC
        `

        const rows = db.prepare(query).all(startDate, endDate)

        return serializeBigInt(rows.map(row => ({
            ...row,
            isActive: Boolean(row.isActive)
        })))
    }

    // Get active recordings
    static getActiveRecordings() {
        const query = `
            SELECT 
                r.*,
                c.name as channelName
            FROM recordings r
            LEFT JOIN channels c ON r.channelId = c.id
            WHERE r.isActive = 1 AND r.status = 'recording'
            ORDER BY r.startTime DESC
        `

        const rows = db.prepare(query).all()

        return serializeBigInt(rows.map(row => ({
            ...row,
            isActive: Boolean(row.isActive),
            channelName: row.channelName
        })))
    }
}

module.exports = RecordingQueries
