import { TrendingUp } from 'lucide-react'
import { Pie, PieChart, ResponsiveContainer, Cell } from 'recharts'

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { useMemo } from 'react'

export function ChartPieDonut({ data = [], innerRadius = 50, maxWidth = 400, maxHeight = 600 }) {
  const chartConfig = useMemo(() => {
    return data.reduce((acc, item, idx) => {
      acc[item.name] = {
        label: item.name,
        color: item.color || `var(--chart-${idx + 1})`
      }
      return acc
    }, {})
  }, [data])

  const total = data.reduce((sum, d) => sum + (d.value || 0), 0)
  const hasData = total > 0

  return (
    <Card className="flex flex-col">
      <CardHeader className="items-center pb-0">
        <CardTitle>Stream Health Distribution</CardTitle>
        <CardDescription>Current health percentage</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 pb-0">
        {/* wrapper that actually constrains size and prevents overflow */}
        <div
          className="mx-auto w-full"
          style={{
            maxWidth,
            maxHeight,
            minHeight: 300,
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          <ChartContainer config={chartConfig} className="h-full w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
                <Pie
                  data={
                    hasData
                      ? data
                      : [
                          {
                            name: 'No data',
                            value: 1,
                            color: 'rgba(0,0,0,0.1)'
                          }
                        ]
                  }
                  dataKey="value"
                  nameKey="name"
                  innerRadius={innerRadius}
                  outerRadius="80%"
                  label={({ name, percent }) =>
                    hasData ? `${name}: ${(percent * 100).toFixed(0)}%` : 'No data available'
                  }
                  isAnimationActive={false}
                >
                  {(hasData ? data : [{ name: 'No data', value: 1, color: 'rgba(0,0,0,0.1)' }]).map(
                    (entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.color || `var(--chart-${index + 1})`}
                      />
                    )
                  )}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </ChartContainer>
        </div>
      </CardContent>
      <CardFooter className="flex-col gap-2 text-sm">
        <div className="flex items-center gap-2 leading-none font-medium">
          Current health distribution <TrendingUp className="h-4 w-4" />
        </div>
        <div className="text-muted-foreground leading-none">
          Showing percentage of each provider&apos;s health
        </div>
      </CardFooter>
    </Card>
  )
}
