import { XAxis, YAxis, CartesianGrid, LineChart, Line, Area, AreaChart } from 'recharts'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '../ui/button'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '../ui/chart'
import { chartConfig } from '@/lib/chart-config'
import { Info } from 'lucide-react'
import { Skeleton } from '../ui/skeleton'

const DashboardPerformance = ({ data, isPending = false }) => {
  if (isPending) {
    return <Skeleton className="h-96 w-full" />
  }

  const dataTransferChart = data.map((item, index) => ({
    name:
      item.channel.name.length > 12
        ? item.channel.name.substring(0, 10) + '...'
        : item.channel.name,
    fullName: item.channel.name,
    packets: parseInt(item.totalPackets),
    bytes: parseInt(item.totalBytes) / (1024 * 1024),
    packetsPerSec: item.avgPacketsPerSec,
    bytesPerSec: item.avgBytesPerSec / 1024,
    index
  }))

  return (
    <div>
      {/* Additional Performance Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Packet Rate Comparison */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <CardTitle>
                <h6>Packet Rate Performance</h6>
              </CardTitle>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="ghost">
                    {' '}
                    <Info />
                  </Button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-sm">
                    Average packets per second for each channel. Higher packet rates typically
                    indicate better streaming quality and more active data flow. Zero values may
                    indicate inactive or problematic streams.
                  </p>
                </TooltipContent>
              </Tooltip>
            </div>
            <CardDescription>Average packets per second across all channels</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="min-h-[300px]">
              <LineChart data={dataTransferChart}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                  height={80}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      formatter={(value) => [`${value} packets/sec`, 'Packet Rate']}
                      labelFormatter={(label) => {
                        const item = dataTransferChart.find((d) => d.name === label)
                        return (
                          <div className="space-y-1">
                            <p className="font-medium">{item?.fullName || label}</p>
                            <p className="text-xs text-muted-foreground">
                              Total Packets: {item?.packets.toLocaleString()}
                            </p>
                          </div>
                        )
                      }}
                    />
                  }
                />
                <Line
                  type="monotone"
                  dataKey="packetsPerSec"
                  stroke="var(--color-performance)"
                  strokeWidth={3}
                  dot={{ fill: 'var(--color-performance)', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Throughput Analysis */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <CardTitle>
                <h6>Throughput Analysis</h6>
              </CardTitle>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="ghost">
                    {' '}
                    <Info />
                  </Button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-sm">
                    Data throughput in KB/s for each channel. This measures the actual data delivery
                    rate and helps identify bandwidth bottlenecks. Consistent high throughput
                    indicates stable streaming quality.
                  </p>
                </TooltipContent>
              </Tooltip>
            </div>
            <CardDescription>Data throughput rates in KB/s by channel</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="min-h-[300px]">
              <AreaChart data={dataTransferChart}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                  height={80}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      formatter={(value) => [`${value.toFixed(1)} KB/s`, 'Throughput']}
                      labelFormatter={(label) => {
                        const item = dataTransferChart.find((d) => d.name === label)
                        return (
                          <div className="space-y-1">
                            <p className="font-medium">{item?.fullName || label}</p>
                            <p className="text-xs text-muted-foreground">
                              Data Transfer: {item?.bytes.toFixed(2)} MB
                            </p>
                          </div>
                        )
                      }}
                    />
                  }
                />
                <Area
                  type="monotone"
                  dataKey="bytesPerSec"
                  stroke="var(--chart-3)"
                  fill="var(--chart-3)"
                  fillOpacity={0.6}
                />
              </AreaChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default DashboardPerformance
