import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { cn, copyToClipboard, formatFileSize, getInitials } from '@/lib/utils'
import { format, formatDistanceToNow } from 'date-fns'
import { CheckCircle2, Clock, MoreHorizontal, XCircle } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { Button, buttonVariants } from '@/components/ui/button'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { deleteClip } from '@/services/clipping/clipApi'

const formatSeconds = (seconds) => {
  if (seconds == null) return '-'
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${String(mins).padStart(2, '0')}:${String(secs.toFixed(2)).padStart(5, '0')}`
}

export const useClipColumns = () => {
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const mutationDelete = useMutation({
    mutationFn: async (id) => {
      return await deleteClip(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel deleted successful!')
      queryClient.invalidateQueries(['clips'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.message)
    }
  })

  return [
    {
      header: 'Sr. no.',
      size: 60,
      cell: ({ row, table }) => {
        const pagination = table.options.meta?.pagination
        const currentPage = pagination?.page || 1
        const pageSize = pagination?.limit || 10
        return (currentPage - 1) * pageSize + row.index + 1
      }
    },
    {
      accessorKey: 'clipName',
      header: 'Clip Info',
      cell: ({ row }) => {
        const clip = row.original
        return (
          <div className="flex items-start gap-3">
            <Avatar className="size-11 rounded-xl">
              <AvatarFallback>{getInitials(clip?.clipName)}</AvatarFallback>
              <AvatarImage src={clip?.logo} alt={clip?.clipName} />
            </Avatar>
            <div className="min-w-0">
              <p className="font-semibold truncate">{clip?.clipName}</p>
              <small className="text-muted-foreground truncate block max-w-[220px]">
                {clip.description}
              </small>
            </div>
          </div>
        )
      }
    },
    {
      accessorKey: 'channelName',
      header: 'Channel',
      cell: ({ row }) => {
        const channel = row.original.recording.channel
        return (
          <Link
            to={`/channel/${channel?.id}`}
            className={cn(buttonVariants({ variant: 'link', size: 'sm' }))}
          >
            {channel?.name}
          </Link>
        )
      }
    },
    {
      id: 'timeRange',
      header: 'Time Range',
      cell: ({ row }) => {
        const { startTime, endTime } = row.original
        return (
          <span className="text-sm font-mono">
            {formatSeconds(startTime)} → {formatSeconds(endTime)}
          </span>
        )
      }
    },
    {
      accessorKey: 'fileSize',
      header: 'Size',
      cell: ({ row }) => (
        <span className="text-sm font-medium">{formatFileSize(row.original.fileSize)}</span>
      ),
      meta: { align: 'center' }
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => {
        const status = row.original.status
        let icon = <Clock className="size-4 text-yellow-600" />
        let color = 'bg-yellow-100 text-yellow-700'

        if (status === 'completed') {
          icon = <CheckCircle2 className="size-4 text-green-600" />
          color = 'bg-green-100 text-green-700'
        } else if (status === 'failed') {
          icon = <XCircle className="size-4 text-red-600" />
          color = 'bg-red-100 text-red-700'
        }

        return (
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${color}`}
          >
            {icon} {status}
          </span>
        )
      },
      meta: { align: 'center' }
    },
    {
      accessorKey: 'createdAt',
      header: 'Created',
      cell: ({ row }) => {
        const createdAt = row.original.createdAt
        return createdAt ? (
          <div className="flex flex-col text-sm">
            <span>{format(new Date(createdAt), 'PPP, p')}</span>
            <span className="text-muted-foreground text-xs">
              {formatDistanceToNow(new Date(createdAt), { addSuffix: true })}
            </span>
          </div>
        ) : (
          '-'
        )
      }
    },
    {
      id: 'actions',
      enableHiding: false,
      cell: ({ row }) => {
        const clip = row.original
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => copyToClipboard(clip.id)}>
                Copy clip ID
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate(`/recording/${clip?.recordingId}`)}>
                Open Recording
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate(`/clips/${clip?.id}`)}>
                View clip
              </DropdownMenuItem>
              {/* <DropdownMenuItem onClick={() => navigate(`/clips/edit/${clip?.id}`)}>
                Edit clip
              </DropdownMenuItem> */}
              <Dialog>
                <DialogTrigger asChild>
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600">
                    Delete clip
                  </DropdownMenuItem>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Are you sure?</DialogTitle>
                    <DialogDescription>
                      This action cannot be undone. This will permanently delete the clip
                      <strong> {clip.clipName} </strong> and all its associated data.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button
                      variant="destructive"
                      onClick={() => mutationDelete.mutate(clip.id)}
                      loading={mutationDelete.isPending}
                    >
                      Confirm
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </DropdownMenuContent>
          </DropdownMenu>
        )
      }
    }
  ]
}
