const { RecentSearchQueries } = require('../queries')
const { createRecentSearchSchema, updateRecentSearchSchema, idSchema } = require('../utils/validation.js')
const recentSearchService = require('../services/recentSearchService.js')

// Helper function to format validation errors
const formatValidationError = (error) => {
    const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
    }))
    return {
        error: 'Validation failed',
        details: errors
    }
}

// Get all recent searches with pagination, filtering, and search
const getRecentSearches = async (req, res) => {
    try {
        // Query params
        const {
            page = 1,
            pageSize = 10,
            search = '',
            type = 'all',
            sort = 'desc' // default sort order
        } = req.query;

        // Build filters object
        const filters = {};
        if (search && search.trim() !== '') {
            filters.search = search.trim();
        }
        if (type !== undefined && type !== 'all') {
            filters.type = type;
        }

        // Pagination
        const limit = parseInt(pageSize, 10) || 10;
        const offset = (parseInt(page, 10) - 1) * limit;

        // Determine sort order
        let orderBy = 'createdAt';
        let orderDirection = 'DESC';

        if (sort === 'asc') {
            orderBy = 'name';
            orderDirection = 'ASC';
        } else if (sort === 'dsc' || sort === 'desc') {
            orderBy = 'name';
            orderDirection = 'DESC';
        }

        // Fetch recent searches
        const result = await RecentSearchQueries.findRecentSearches({
            filters,
            orderBy,
            orderDirection,
            limit,
            offset
        });

        // Parse query strings back to JSON objects for response
        const formattedSearches = result.recentSearches.map(search => ({
            ...search,
            query: JSON.parse(search.query)
        }));

        res.json({
            data: formattedSearches,
            pagination: {
                total: result.total,
                page: parseInt(page, 10),
                pageSize: limit,
                totalPages: Math.ceil(result.total / limit)
            }
        });
    } catch (error) {
        console.log(error.message)
        res.status(500).json({ error: 'Failed to fetch recent searches' });
    }
}

// Get recent searches by type
const getRecentSearchesByType = async (req, res) => {
    try {
        const { type } = req.params;

        // Validate type
        if (!['channel', 'clip', 'recording'].includes(type)) {
            return res.status(400).json({
                error: 'Invalid type. Must be one of: channel, clip, recording'
            });
        }

        const {
            page = 1,
            pageSize = 10,
            search = '',
            sort = 'desc'
        } = req.query;

        // Build filters object
        const filters = { type };
        if (search && search.trim() !== '') {
            filters.search = search.trim();
        }

        // Pagination
        const limit = parseInt(pageSize, 10) || 10;
        const offset = (parseInt(page, 10) - 1) * limit;

        // Determine sort order
        let orderBy = 'createdAt';
        let orderDirection = 'DESC';

        if (sort === 'asc') {
            orderBy = 'name';
            orderDirection = 'ASC';
        } else if (sort === 'dsc' || sort === 'desc') {
            orderBy = 'name';
            orderDirection = 'DESC';
        }

        // Fetch recent searches
        const result = await RecentSearchQueries.findRecentSearches({
            filters,
            orderBy,
            orderDirection,
            limit,
            offset
        });

        // Parse query strings back to JSON objects for response
        const formattedSearches = result.recentSearches.map(search => ({
            ...search,
            query: JSON.parse(search.query)
        }));

        res.json({
            data: formattedSearches,
            pagination: {
                total: result.total,
                page: parseInt(page, 10),
                pageSize: limit,
                totalPages: Math.ceil(result.total / limit)
            }
        });
    } catch (error) {
        console.log(error.message)
        res.status(500).json({ error: 'Failed to fetch recent searches by type' });
    }
}

// Get recent search by ID
const getRecentSearchById = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const recentSearch = await RecentSearchQueries.getRecentSearchById(id)

        if (!recentSearch) {
            return res.status(404).json({ error: 'Recent search not found' })
        }

        // Parse query string back to JSON object for response
        const formattedSearch = {
            ...recentSearch,
            query: JSON.parse(recentSearch.query)
        };

        res.json(formattedSearch)
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch recent search' })
    }
}

// Create recent search
const createRecentSearch = async (req, res) => {
    try {
        const { error, value } = createRecentSearchSchema.validate(req.body)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { name, type, query } = value

        // Validate that query is valid JSON
        let parsedQuery;
        try {
            parsedQuery = JSON.parse(query);
        } catch (jsonError) {
            return res.status(400).json({
                error: 'Invalid query format. Query must be a valid JSON string'
            });
        }

        const recentSearch = await RecentSearchQueries.createRecentSearch({
            name,
            type,
            query // Store as JSON string
        })

        // Return with parsed query
        const formattedSearch = {
            ...recentSearch,
            query: parsedQuery
        };

        res.status(201).json(formattedSearch)
    } catch (error) {
        console.error('Create recent search error:', error)
        res.status(500).json({ error: 'Failed to create recent search' })
    }
}

// Update recent search
const updateRecentSearch = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.id)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const { error: bodyError, value } = updateRecentSearchSchema.validate(req.body)
        if (bodyError) {
            return res.status(400).json(formatValidationError(bodyError))
        }

        const { id } = req.params
        const { name, type, query } = value

        // Validate query if provided
        let parsedQuery;
        if (query) {
            try {
                parsedQuery = JSON.parse(query);
            } catch (jsonError) {
                return res.status(400).json({
                    error: 'Invalid query format. Query must be a valid JSON string'
                });
            }
        }

        const updateData = {};
        if (name) updateData.name = name;
        if (type) updateData.type = type;
        if (query) updateData.query = query;

        await RecentSearchQueries.updateRecentSearch(id, updateData)

        // Get updated search
        const recentSearch = await RecentSearchQueries.getRecentSearchById(id)

        // Return with parsed query
        const formattedSearch = {
            ...recentSearch,
            query: JSON.parse(recentSearch.query)
        };

        res.json(formattedSearch)
    } catch (error) {
        console.error('Update recent search error:', error)
        res.status(500).json({ error: 'Failed to update recent search' })
    }
}

// Delete recent search
const deleteRecentSearch = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params

        await RecentSearchQueries.deleteRecentSearch(id)

        return res.status(204).json({
            message: 'Recent search deleted successfully',
            success: true
        })
    } catch (error) {
        console.error('Delete recent search error:', error)
        res.status(500).json({ error: 'Failed to delete recent search' })
    }
}

// Delete all recent searches by type
const deleteRecentSearchesByType = async (req, res) => {
    try {
        const { type } = req.params;

        // Validate type
        if (!['channel', 'clip', 'recording'].includes(type)) {
            return res.status(400).json({
                error: 'Invalid type. Must be one of: channel, clip, recording'
            });
        }

        const result = await RecentSearchQueries.deleteRecentSearches({ type })
        const deletedCount = result.deletedCount

        res.json({
            success: true,
            message: `Deleted ${deletedCount} recent searches of type '${type}'`,
            deletedCount
        })
    } catch (error) {
        console.error('Delete recent searches by type error:', error)
        res.status(500).json({ error: 'Failed to delete recent searches by type' })
    }
}

// Create or update a recent search (smart save)
const saveRecentSearch = async (req, res) => {
    try {
        const { error, value } = createRecentSearchSchema.validate(req.body)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { name, type, query } = value

        // Validate that query is valid JSON
        let parsedQuery;
        try {
            parsedQuery = JSON.parse(query);
        } catch (jsonError) {
            return res.status(400).json({
                error: 'Invalid query format. Query must be a valid JSON string'
            });
        }

        // Validate query parameters based on type
        try {
            recentSearchService.validateQueryParams(type, parsedQuery);
        } catch (validationError) {
            return res.status(400).json({
                error: validationError.message
            });
        }

        // Create or update the search
        const recentSearch = await recentSearchService.createOrUpdate(name, type, parsedQuery);

        // Cleanup old searches (keep only latest 20 per type)
        await recentSearchService.cleanupOldSearches(type, 20);

        res.status(201).json(recentSearch)
    } catch (error) {
        console.error('Save recent search error:', error)
        res.status(500).json({ error: 'Failed to save recent search' })
    }
}

// Get search statistics
const getSearchStats = async (req, res) => {
    try {
        const stats = await recentSearchService.getSearchStats();
        res.json({
            success: true,
            stats
        });
    } catch (error) {
        console.error('Get search stats error:', error)
        res.status(500).json({ error: 'Failed to get search statistics' })
    }
}

module.exports = {
    getRecentSearches,
    getRecentSearchesByType,
    getRecentSearchById,
    createRecentSearch,
    updateRecentSearch,
    deleteRecentSearch,
    deleteRecentSearchesByType,
    saveRecentSearch,
    getSearchStats
}
