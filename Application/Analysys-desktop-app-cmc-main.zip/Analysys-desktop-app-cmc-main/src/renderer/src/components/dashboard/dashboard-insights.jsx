import { Alert, AlertDescription } from '@/components/ui/alert'
import { Activity, Zap, Clock } from 'lucide-react'
import { Skeleton } from '../ui/skeleton'

const DashboardInsights = ({ data, isPending = false }) => {
  if (isPending) {
    return <Skeleton className="h-96 w-full" />
  }
  return (
    <div>
      {/* Insights and Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Alert>
          <Zap className="h-4 w-4" />
          <AlertDescription>
            <strong>Performance Leader:</strong> Geo News shows the highest data transfer volume
            with 3.4GB and strong packet rates, indicating excellent streaming performance.
          </AlertDescription>
        </Alert>

        <Alert>
          <Clock className="h-4 w-4" />
          <AlertDescription>
            <strong>Reliability Concern:</strong> ARY Channels show significant downtime periods.
            Consider investigating network stability and implementing redundancy.
          </AlertDescription>
        </Alert>

        <Alert>
          <Activity className="h-4 w-4" />
          <AlertDescription>
            <strong>Current Status:</strong> Only 1 out of {data.length} channels is currently
            online. Immediate attention needed for offline channels.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  )
}

export default DashboardInsights
