const streamingService = require('./services/streamingService.js')
const recordingService = require('./services/recordingService.js')
const queries = require('./queries')

async function testConcurrentAccess() {
    console.log('🧪 Testing concurrent UDP access for streaming and recording...')

    // Define test channel ID at the beginning
    const testChannelId = 'cmeu6v9p70000uw28usmaeyxy' // Replace with your channel ID

    try {
        console.log(`\n📡 Step 1: Starting streaming for channel ${testChannelId}`)
        const streamResult = await streamingService.startStreaming(testChannelId)
        console.log('✅ Streaming started:', streamResult.message)
        console.log('🎥 Stream URL:', streamResult.data.httpUrl)

        // Wait a moment for streaming to establish
        console.log('\n⏳ Waiting 5 seconds for streaming to establish...')
        await new Promise(resolve => setTimeout(resolve, 5000))

        console.log(`\n📹 Step 2: Starting recording for channel ${testChannelId}`)
        const recordResult = await recordingService.startRecording(testChannelId)
        console.log('✅ Recording started:', recordResult.message)
        console.log('💾 Recording method:', recordResult.data.method)
        console.log('📄 Recording file:', recordResult.data.fileName)

        console.log('\n📊 Step 3: Checking status of both processes...')

        // Check streaming status
        const streamStatus = await streamingService.getStreamingStatus(testChannelId)
        console.log('🎭 Streaming status:', {
            isStreaming: streamStatus.isStreaming,
            duration: streamStatus.duration ? streamStatus.duration + ' seconds' : 'N/A'
        })

        // Check recording status with error handling
        let recordStatus
        try {
            recordStatus = await recordingService.getRecordingStatus(testChannelId)
            console.log('📹 Recording status:', {
                isRecording: recordStatus.isRecording,
                method: recordStatus.isRecording ? 'Active' : 'Inactive',
                duration: recordStatus.duration ? recordStatus.duration + ' seconds' : 'N/A'
            })
        } catch (recordError) {
            console.log('📹 Recording status: Not active or failed (' + recordError.message + ')')
            recordStatus = { isRecording: false }
        }

        if (!streamStatus.isStreaming) {
            throw new Error('Streaming failed to start properly')
        }

        // Only proceed with full test if both are working
        if (recordStatus.isRecording) {
            console.log('\n🕒 Both processes active - running for 30 seconds to test stability...')
            await new Promise(resolve => setTimeout(resolve, 30000))

            console.log('\n🛑 Step 4: Stopping recording...')
            const stopRecordResult = await recordingService.stopRecording(testChannelId)
            console.log('✅ Recording stopped:', stopRecordResult.message)
        } else {
            console.log('\n⚠️  Recording failed - testing streaming only...')
            console.log('🕒 Streaming test - running for 15 seconds...')
            await new Promise(resolve => setTimeout(resolve, 15000))
        }

        console.log('\n🛑 Step 5: Stopping streaming...')
        const stopStreamResult = await streamingService.stopStreaming(testChannelId)
        console.log('✅ Streaming stopped:', stopStreamResult.message)

        console.log('\n🎉 Test completed successfully!')
        if (recordStatus && recordStatus.isRecording) {
            console.log('✅ Both streaming and recording worked concurrently from single UDP source')
        } else {
            console.log('⚠️  Streaming worked, but recording had issues (likely UDP port conflicts)')
        }

    } catch (error) {
        console.error('\n❌ Test failed:', error.message)
        console.log('\n🔧 Troubleshooting tips:')
        console.log('1. Make sure the UDP stream is active on port 4000')
        console.log('2. Verify the channel exists and has a primary source')
        console.log('3. Check that FFmpeg can access the multicast stream')

        // Try to cleanup on error
        try {
            await recordingService.stopRecording(testChannelId)
            await streamingService.stopStreaming(testChannelId)
        } catch (cleanupError) {
            console.warn('Cleanup error:', cleanupError.message)
        }
    }
}

// Run the test
if (require.main === module) {
    testConcurrentAccess().then(() => {
        console.log('\n✅ Test script completed')
        process.exit(0)
    }).catch(error => {
        console.error('\n❌ Test script failed:', error)
        process.exit(1)
    })
}

module.exports = { testConcurrentAccess }
