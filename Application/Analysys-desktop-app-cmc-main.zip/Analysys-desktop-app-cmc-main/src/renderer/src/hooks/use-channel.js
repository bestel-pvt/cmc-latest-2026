import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  searchChannels,
  getAllChannels,
  getSuggestions,
  getFilters,
  getChannelById,
  getChannelsByCategory
} from '@/lib/services/searchService'

// Hook for searching channels
export const useChannelSearch = (query, limit = 20, enabled = true) => {
  return useQuery({
    queryKey: ['channels', 'search', query, limit],
    queryFn: () => searchChannels({ query, limit }),
    enabled: enabled && query.length > 0,
    staleTime: 2 * 60 * 1000,
    refetchOnWindowFocus: false
  })
}

// Hook for getting all channels
export const useAllChannels = (limit = 50) => {
  return useQuery({
    queryKey: ['channels', 'all', limit],
    queryFn: () => getAllChannels({ limit }),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false
  })
}

// Hook for getting suggestions
export const useSuggestions = (query, limit = 5, enabled = true) => {
  return useQuery({
    queryKey: ['channels', 'suggestions', query, limit],
    queryFn: () => getSuggestions({ query, limit }),
    enabled: enabled && query.length >= 2,
    staleTime: 30 * 1000, // 30 seconds
    refetchOnWindowFocus: false
  })
}

// Hook for getting filters
export const useFilters = () => {
  return useQuery({
    queryKey: ['channels', 'filters'],
    queryFn: getFilters,
    staleTime: 10 * 60 * 1000, // 10 minutes
    refetchOnWindowFocus: false
  })
}

// Hook for getting single channel by ID
export const useChannelById = (id, enabled = true) => {
  return useQuery({
    queryKey: ['channels', 'byId', id],
    queryFn: () => getChannelById(id),
    enabled: enabled && !!id,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false
  })
}

// Hook for getting channels by category
export const useChannelsByCategory = (category, limit = 20, enabled = true) => {
  return useQuery({
    queryKey: ['channels', 'category', category, limit],
    queryFn: () => getChannelsByCategory({ category, limit }),
    enabled: enabled && category !== 'all',
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false
  })
}

// Hook for prefetching channels (useful for hover states)
export const usePrefetchChannel = () => {
  const queryClient = useQueryClient()

  const prefetchChannel = (id) => {
    queryClient.prefetchQuery({
      queryKey: ['channels', 'byId', id],
      queryFn: () => getChannelById(id),
      staleTime: 5 * 60 * 1000
    })
  }

  return { prefetchChannel }
}
