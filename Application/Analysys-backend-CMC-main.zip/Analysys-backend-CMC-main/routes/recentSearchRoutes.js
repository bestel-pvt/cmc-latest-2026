const express = require('express')
const {
    getRecentSearches,
    getRecentSearchesByType,
    getRecentSearchById,
    createRecentSearch,
    updateRecentSearch,
    deleteRecentSearch,
    deleteRecentSearchesByType,
    saveRecentSearch,
    getSearchStats
} = require('../controllers/recentSearchController.js')

const router = express.Router()

// Get all recent searches with pagination and filtering
router.get('/', getRecentSearches)

// Get search statistics
router.get('/stats', getSearchStats)

// Get recent searches by type
router.get('/type/:type', getRecentSearchesByType)

// Get recent search by ID
router.get('/:id', getRecentSearchById)

// Create new recent search
router.post('/', createRecentSearch)

// Save recent search (create or update intelligently)
router.post('/save', saveRecentSearch)

// Update recent search
router.put('/:id', updateRecentSearch)

// Delete recent search by ID
router.delete('/:id', deleteRecentSearch)

// Delete all recent searches by type
router.delete('/type/:type', deleteRecentSearchesByType)

module.exports = router
