# CMC Backend Metrics API Documentation

This document provides comprehensive information about the metrics API endpoints and real-time socket integration for the CMC Backend system.

## Table of Contents

1. [Overview](#overview)
2. [API Endpoints](#api-endpoints)
3. [Socket.IO Integration](#socketio-integration)
4. [Data Structures](#data-structures)
5. [Frontend Integration Examples](#frontend-integration-examples)
6. [Error Handling](#error-handling)

---

## Overview

The CMC Backend now provides comprehensive metrics functionality including:
- **Clip Creation Metrics**: Statistics on frequently clipped content
- **Storage Utilization**: Real-time monitoring of system storage capacity
- **System Performance Metrics**: Real-time monitoring of recording and processing load

All metrics are available through REST API endpoints and real-time Socket.IO updates.

---

## API Endpoints

### Base URL
```
http://localhost:3000/api/metrics
```

### 1. Clip Creation Metrics

Get statistics on the most frequently clipped content.

**Endpoint:** `GET /api/metrics/clips`

**Query Parameters:**
- `dateFrom` (optional): ISO date string for filtering clips from this date
- `dateTo` (optional): ISO date string for filtering clips to this date  
- `limit` (optional): Number of top results to return (default: 10)

**Example Request:**
```bash
GET /api/metrics/clips?dateFrom=2025-01-01&dateTo=2025-12-31&limit=5
```

**Response:**
```json
{
  "success": true,
  "message": "Clip creation metrics retrieved successfully",
  "data": {
    "overview": {
      "totalClips": 145,
      "averageClipDuration": 32.5,
      "totalStorageUsed": "2.3 GB"
    },
    "groupedData": {
      "byRecording": [
        {
          "recordingId": "rec_123",
          "recordingName": "news_broadcast_2025_01_15.mp4",
          "channelName": "GEO News",
          "clipsCount": 8
        }
      ],
      "byChannel": [
        {
          "channelName": "GEO News",
          "clipsCount": 25,
          "totalDuration": 845.2,
          "channelId": "ch_456"
        }
      ],
      "byStatus": [
        {
          "status": "completed",
          "_count": { "id": 120 }
        },
        {
          "status": "failed",
          "_count": { "id": 5 }
        }
      ],
      "byFormat": [
        {
          "format": "mp4",
          "_count": { "id": 100 }
        },
        {
          "format": "mkv",
          "_count": { "id": 45 }
        }
      ],
      "byDay": [
        {
          "date": "2025-01-15",
          "clipsCount": 12,
          "totalDuration": 387.5
        }
      ]
    }
  }
}
```

### 2. Storage Utilization Metrics

Monitor system capacity and usage trends.

**Endpoint:** `GET /api/metrics/storage`

**Example Request:**
```bash
GET /api/metrics/storage
```

**Response:**
```json
{
  "success": true,
  "message": "Storage utilization metrics retrieved successfully",
  "data": {
    "totalUsed": {
      "size": 5368709120,
      "formatted": "5.00 GB"
    },
    "breakdown": {
      "recordings": {
        "size": 3221225472,
        "formatted": "3.00 GB",
        "percentage": 60
      },
      "clips": {
        "size": 1610612736,
        "formatted": "1.50 GB",
        "percentage": 30
      },
      "uploads": {
        "size": 536870912,
        "formatted": "512.00 MB",
        "percentage": 10
      }
    },
    "system": {
      "available": true
    },
    "timestamp": "2025-09-03T10:30:00.000Z"
  }
}
```

### 3. System Performance Metrics

Monitor recording and processing load.

**Endpoint:** `GET /api/metrics/performance`

**Example Request:**
```bash
GET /api/metrics/performance
```

**Response:**
```json
{
  "success": true,
  "message": "System performance metrics retrieved successfully",
  "data": {
    "current": {
      "cpu": {
        "user": 123456,
        "system": 78901,
        "usage": 202
      },
      "memory": {
        "rss": 134217728,
        "heapTotal": 67108864,
        "heapUsed": 33554432,
        "external": 8388608,
        "arrayBuffers": 4194304,
        "systemFree": 2147483648,
        "systemTotal": 8589934592,
        "systemUsage": 75
      },
      "system": {
        "loadAverage": [1.2, 1.1, 1.0],
        "platform": "win32",
        "arch": "x64",
        "cpuCount": 8,
        "uptime": 86400,
        "nodeVersion": "v18.17.0"
      }
    },
    "history": {
      "cpuUsage": [
        { "timestamp": 1693747800000, "value": 25 },
        { "timestamp": 1693747810000, "value": 30 }
      ],
      "memoryUsage": [
        { "timestamp": 1693747800000, "value": 72 },
        { "timestamp": 1693747810000, "value": 75 }
      ],
      "systemLoad": [
        { "timestamp": 1693747800000, "value": 1.1 },
        { "timestamp": 1693747810000, "value": 1.2 }
      ]
    },
    "active": {
      "recordings": 2,
      "processingClips": 1
    },
    "timestamp": "2025-09-03T10:30:00.000Z"
  }
}
```

### 4. All Metrics Combined

Get all metrics in a single request.

**Endpoint:** `GET /api/metrics/all`

**Query Parameters:** Same as clip metrics endpoint

**Example Request:**
```bash
GET /api/metrics/all
```

**Response:** Combined data from all three metric types.

### 5. Real-time Metrics

Get current metrics formatted for real-time updates.

**Endpoint:** `GET /api/metrics/realtime`

**Example Request:**
```bash
GET /api/metrics/realtime
```

**Response:** Optimized data structure for socket updates.

---

## Socket.IO Integration

The system provides real-time metrics updates through Socket.IO.

### Connection

**Server URL:** `http://localhost:3000`

**Namespace:** Default namespace (`/`)

### Events

#### Client → Server Events

1. **`metrics:request`** - Request immediate metrics update
   ```javascript
   socket.emit('metrics:request');
   ```

#### Server → Client Events

1. **`metrics:initial`** - Initial metrics data sent on connection
   ```javascript
   socket.on('metrics:initial', (data) => {
     console.log('Initial metrics:', data);
   });
   ```

2. **`metrics:update`** - Real-time metrics updates (broadcast every 30 seconds)
   ```javascript
   socket.on('metrics:update', (data) => {
     console.log('Updated metrics:', data);
   });
   ```

3. **`metrics:error`** - Error events
   ```javascript
   socket.on('metrics:error', (error) => {
     console.error('Metrics error:', error);
   });
   ```

---

## Data Structures

### Clip Metrics Data Structure
```typescript
interface ClipMetrics {
  overview: {
    totalClips: number;
    averageClipDuration: number;
    totalStorageUsed: string;
  };
  groupedData: {
    byRecording: RecordingClipStat[];
    byChannel: ChannelClipStat[];
    byStatus: StatusStat[];
    byFormat: FormatStat[];
    byDay: DailyStat[];
  };
}
```

### Storage Metrics Data Structure
```typescript
interface StorageMetrics {
  totalUsed: {
    size: number;
    formatted: string;
  };
  breakdown: {
    recordings: StorageBreakdown;
    clips: StorageBreakdown;
    uploads: StorageBreakdown;
  };
  system: {
    available: boolean;
  };
  timestamp: string;
}
```

### Performance Metrics Data Structure
```typescript
interface PerformanceMetrics {
  current: CurrentPerformance;
  history: {
    cpuUsage: TimeSeriesPoint[];
    memoryUsage: TimeSeriesPoint[];
    systemLoad: TimeSeriesPoint[];
  };
  active: {
    recordings: number;
    processingClips: number;
  };
  timestamp: string;
}
```

---

## Frontend Integration Examples

### React Integration

#### 1. HTTP API Integration

```javascript
import { useState, useEffect } from 'react';
import axios from 'axios';

function MetricsComponent() {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await axios.get('/api/metrics/all');
        setMetrics(response.data.data);
      } catch (error) {
        console.error('Error fetching metrics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMetrics();
    // Refresh every minute
    const interval = setInterval(fetchMetrics, 60000);
    return () => clearInterval(interval);
  }, []);

  if (loading) return <div>Loading metrics...</div>;

  return (
    <div>
      <h2>System Metrics</h2>
      {metrics && (
        <>
          <div>Total Clips: {metrics.clips.overview.totalClips}</div>
          <div>Storage Used: {metrics.storage.totalUsed.formatted}</div>
          <div>Active Recordings: {metrics.performance.active.recordings}</div>
        </>
      )}
    </div>
  );
}
```

#### 2. Socket.IO Real-time Integration

```javascript
import { useState, useEffect } from 'react';
import io from 'socket.io-client';

function RealTimeMetrics() {
  const [socket, setSocket] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    // Initialize socket connection
    const newSocket = io('http://localhost:3000');
    setSocket(newSocket);

    // Connection events
    newSocket.on('connect', () => {
      console.log('Connected to metrics socket');
      setConnected(true);
    });

    newSocket.on('disconnect', () => {
      console.log('Disconnected from metrics socket');
      setConnected(false);
    });

    // Metrics events
    newSocket.on('metrics:initial', (data) => {
      console.log('Received initial metrics:', data);
      setMetrics(data);
    });

    newSocket.on('metrics:update', (data) => {
      console.log('Received metrics update:', data);
      setMetrics(data);
    });

    newSocket.on('metrics:error', (error) => {
      console.error('Metrics error:', error);
    });

    return () => {
      newSocket.disconnect();
    };
  }, []);

  const requestMetricsUpdate = () => {
    if (socket) {
      socket.emit('metrics:request');
    }
  };

  return (
    <div>
      <h2>Real-Time Metrics</h2>
      <div>Status: {connected ? 'Connected' : 'Disconnected'}</div>
      <button onClick={requestMetricsUpdate}>Refresh Now</button>
      
      {metrics && (
        <div>
          <h3>Storage Utilization</h3>
          <div>Total: {metrics.storage?.totalUsed?.formatted}</div>
          
          <h3>Performance</h3>
          <div>Memory Usage: {metrics.performance?.current?.memory?.systemUsage}%</div>
          <div>Active Recordings: {metrics.performance?.active?.recordings}</div>
          <div>Processing Clips: {metrics.performance?.active?.processingClips}</div>
          
          <div>Last Updated: {metrics.timestamp}</div>
        </div>
      )}
    </div>
  );
}
```

#### 3. Chart Integration (with Chart.js)

```javascript
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

function PerformanceChart({ performanceData }) {
  const chartData = {
    labels: performanceData?.history?.memoryUsage?.map(point => 
      new Date(point.timestamp).toLocaleTimeString()
    ) || [],
    datasets: [
      {
        label: 'Memory Usage (%)',
        data: performanceData?.history?.memoryUsage?.map(point => point.value) || [],
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
      },
      {
        label: 'System Load',
        data: performanceData?.history?.systemLoad?.map(point => point.value) || [],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
      }
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'System Performance Over Time',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
      },
    },
  };

  return <Line data={chartData} options={options} />;
}
```

### Vue.js Integration

```javascript
// Vue 3 Composition API example
import { ref, onMounted, onUnmounted } from 'vue';
import io from 'socket.io-client';

export default {
  setup() {
    const metrics = ref(null);
    const socket = ref(null);
    const connected = ref(false);

    onMounted(() => {
      // Initialize socket
      socket.value = io('http://localhost:3000');
      
      socket.value.on('connect', () => {
        connected.value = true;
      });
      
      socket.value.on('disconnect', () => {
        connected.value = false;
      });
      
      socket.value.on('metrics:initial', (data) => {
        metrics.value = data;
      });
      
      socket.value.on('metrics:update', (data) => {
        metrics.value = data;
      });
    });

    onUnmounted(() => {
      if (socket.value) {
        socket.value.disconnect();
      }
    });

    return {
      metrics,
      connected
    };
  }
};
```

---

## Error Handling

### API Error Responses

All API endpoints return standardized error responses:

```json
{
  "success": false,
  "message": "Error description"
}
```

**HTTP Status Codes:**
- `200` - Success
- `400` - Bad Request (invalid parameters)
- `500` - Internal Server Error

### Socket Error Handling

```javascript
socket.on('metrics:error', (error) => {
  console.error('Metrics error:', error);
  // Handle error appropriately
  // e.g., show user notification, retry logic, etc.
});

socket.on('connect_error', (error) => {
  console.error('Socket connection error:', error);
});
```

### Best Practices

1. **Implement retry logic** for failed API calls
2. **Handle socket disconnections** gracefully
3. **Cache metrics data** to avoid UI flickering
4. **Debounce frequent updates** to prevent UI performance issues
5. **Show loading states** during data fetching
6. **Implement fallbacks** when real-time data is unavailable

---

## Notes

- Real-time metrics are broadcast every 30 seconds via Socket.IO
- Performance history maintains the last 100 data points (approximately 16 minutes)
- Storage calculations are performed recursively through directory structures
- All timestamps are in ISO 8601 format
- File sizes are automatically formatted with appropriate units (B, KB, MB, GB, TB)

For production deployment, ensure to:
- Configure proper CORS settings for Socket.IO
- Implement authentication/authorization for metrics endpoints
- Set up proper monitoring and alerting based on these metrics
- Consider implementing rate limiting for API endpoints
