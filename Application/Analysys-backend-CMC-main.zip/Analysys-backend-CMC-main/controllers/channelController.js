const queries = require('../queries')
const { generateChannelStreamLink } = require('../utils/helpers.js')
const { createChannelSchema, updateChannelSchema, idSchema } = require('../utils/validation.js')
const recordingService = require('../services/recordingService.js')

// Helper function to format validation errors
const formatValidationError = (error) => {
    const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
    }))
    return {
        error: 'Validation failed',
        details: errors
    }
}

// Get all channels with pagination, filtering, and search
const getChannels = async (req, res) => {
    try {
        // Query params
        const {
            page = 1,
            pageSize = 10,
            search = '',
            isActive = 'all',
            isPriority = 'all',
            sort = 'desc' // default sort order
        } = req.query;

        const result = queries.ChannelQueries.getChannels({
            page,
            pageSize,
            search,
            isActive,
            isPriority,
            sort
        })

        // Add active flags to each channel
        const streamingService = require('../services/streamingService.js')
        const recordingService = require('../services/recordingService.js')

        result.data = result.data.map(channel => ({
            ...channel,
            isAnyStreamActive: streamingService.hasActiveStream(channel.id),
            isAnyRecordingActive: recordingService.hasActiveRecording(channel.id)
        }))

        res.json(result);
    } catch (error) {
        console.log(error.message)
        res.status(500).json({ error: 'Failed to fetch channels' });
    }
}

// Get channel by ID
const getChannelById = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const channel = queries.ChannelQueries.getChannelById(id)

        if (!channel) {
            return res.status(404).json({ error: 'Channel not found' })
        }

        // Add active flags
        const streamingService = require('../services/streamingService.js')
        const recordingService = require('../services/recordingService.js')

        channel.isAnyStreamActive = streamingService.hasActiveStream(channel.id)
        channel.isAnyRecordingActive = recordingService.hasActiveRecording(channel.id)

        res.json(channel)
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch channel' })
    }
}

// Create channel with sources
const createChannel = async (req, res) => {
    try {
        const { error, value } = createChannelSchema.validate(req.body)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { name, description, isActive, logo, isPriority, sources } = value

        // Ensure only one source is marked primary: if multiple provided, keep the first and mark others as secondary
        let normalizedSources = Array.isArray(sources) ? sources.slice() : []
        const firstPrimaryIndex = normalizedSources.findIndex(s => s && s.isPrimary)
        if (firstPrimaryIndex !== -1) {
            normalizedSources = normalizedSources.map((s, idx) => ({
                ...s,
                isPrimary: idx === firstPrimaryIndex
            }))
        } else {
            // Ensure boolean defaults for isPrimary on each source when not specified
            normalizedSources = normalizedSources.map(s => ({
                ...s,
                isPrimary: s && s.isPrimary === true
            }))
        }

        const channelStreamLink = generateChannelStreamLink()

        const channel = queries.ChannelQueries.createChannel({
            name,
            description,
            isActive: isActive !== undefined ? isActive : true,
            logo,
            isPriority: isPriority !== undefined ? isPriority : false,
            channelStreamLink,
            sources: normalizedSources
        })

        // Add active flags
        const streamingService = require('../services/streamingService.js')
        const recordingService = require('../services/recordingService.js')

        channel.isAnyStreamActive = streamingService.hasActiveStream(channel.id)
        channel.isAnyRecordingActive = recordingService.hasActiveRecording(channel.id)

        res.status(201).json(channel)
    } catch (error) {
        console.error('Create channel error:', error)
        res.status(500).json({ error: 'Failed to create channel' })
    }
}

// Update channel
const updateChannel = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.id)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const { error: bodyError, value } = updateChannelSchema.validate(req.body)
        if (bodyError) {
            return res.status(400).json(formatValidationError(bodyError))
        }

        const { id } = req.params
        const { name, description, isActive, logo, isPriority } = value

        const updates = {}
        if (name) updates.name = name
        if (description !== undefined) updates.description = description
        if (isActive !== undefined) updates.isActive = isActive
        if (logo !== undefined) updates.logo = logo
        if (isPriority !== undefined) updates.isPriority = isPriority

        const channel = queries.ChannelQueries.updateChannel(id, updates)

        // Add active flags
        const streamingService = require('../services/streamingService.js')
        const recordingService = require('../services/recordingService.js')

        channel.isAnyStreamActive = streamingService.hasActiveStream(channel.id)
        channel.isAnyRecordingActive = recordingService.hasActiveRecording(channel.id)

        res.json(channel)
    } catch (error) {
        if (error.code === 'P2025') {
            return res.status(404).json({ error: 'Channel not found' })
        }
        console.error('Update channel error:', error)
        res.status(500).json({ error: 'Failed to update channel' })
    }
}

// Delete channel
const deleteChannel = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params

        queries.ChannelQueries.deleteChannel(id)

        return res.status(204).json({
            message: 'Channel deleted successfully',
            success: true
        })
    } catch (error) {
        if (error.code === 'P2025') {
            return res.status(404).json({ error: 'Channel not found' })
        }
        console.error('Delete channel error:', error)
        res.status(500).json({ error: 'Failed to delete channel' })
    }
}

// Start recording for a channel
const startRecording = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const result = await recordingService.startRecording(id)

        res.status(201).json(result)
    } catch (error) {
        console.error('Start recording error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to start recording'
        })
    }
}

// Stop recording for a channel
const stopRecording = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const result = await recordingService.stopRecording(id)

        res.json(result)
    } catch (error) {
        console.error('Stop recording error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to stop recording'
        })
    }
}

// Get recording status for a channel
const getRecordingStatus = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const status = await recordingService.getRecordingStatus(id)

        res.json({
            success: true,
            channelId: id,
            ...status
        })
    } catch (error) {
        console.error('Get recording status error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get recording status'
        })
    }
}

// Get all recordings for a channel
const getChannelRecordings = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const recordings = await recordingService.getAllRecordings(id)

        res.json({
            success: true,
            channelId: id,
            recordings
        })
    } catch (error) {
        console.error('Get channel recordings error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get channel recordings'
        })
    }
}

// Test UDP stream connection for a channel
const testChannelStream = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const result = await recordingService.testUdpStream(id)

        res.json({
            success: true,
            channelId: id,
            ...result
        })
    } catch (error) {
        console.error('Test stream error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to test stream'
        })
    }
}

module.exports = {
    getChannels,
    getChannelById,
    createChannel,
    updateChannel,
    deleteChannel,
    startRecording,
    stopRecording,
    getRecordingStatus,
    getChannelRecordings,
    testChannelStream
}
