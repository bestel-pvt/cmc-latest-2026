const StreamingDashboard = ({ data }) => {
  if (!data) {
    return <div>Loading ...</div>
  }

  return <div className=" space-y-4"></div>
}

export default StreamingDashboard
