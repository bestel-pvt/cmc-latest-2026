import Container from '@/components/common/dash-container'
import Loader from '@/components/common/loader'
import SourceDetail from '@/components/source/source-detail'

import { getSource } from '@/services/source/sourceApi'
import { useQuery } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'

const SourceDetailPage = () => {
  const { id } = useParams()
  const { data, isPending } = useQuery({
    queryKey: ['source', id],
    queryFn: () => getSource(id)
  })

  console.log(data)

  const source = data

  if (isPending) {
    return <Loader name={'Source details'} />
  }

  return (
    <Container>
      <SourceDetail source={source} isPending={isPending} />
    </Container>
  )
}

export default SourceDetailPage
