import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

// Toast
import { Toaster } from 'react-hot-toast'

// React Query
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { TooltipProvider } from './components/ui/tooltip'

const queryClient = new QueryClient()

createRoot(document.getElementById('root')).render(
  <>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster position="top-right" />
        <App />
      </TooltipProvider>
    </QueryClientProvider>
  </>
)
