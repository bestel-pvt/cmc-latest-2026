import ChannelForm from '@/components/channel/channel-form'
import { Card } from '@/components/ui/card'
import Container from '@/components/common/dash-container'
import { useQuery } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'
import { getChannel } from '@/services/channels/channelApi'
import Loader from '@/components/common/loader'

const ChannelEditPage = () => {
  const { id } = useParams()

  const { data, isPending } = useQuery({
    queryKey: ['channel', id],
    queryFn: () => getChannel(id)
  })

  const channel = data

  if (isPending) {
    return <Loader name={'Channel details'} />
  }

  return (
    <Container>
      <Card className="space-y-4 max-w-7xl p-4">
        <h5>Edit Channel</h5>
        <ChannelForm channelData={channel} />
      </Card>
    </Container>
  )
}

export default ChannelEditPage
