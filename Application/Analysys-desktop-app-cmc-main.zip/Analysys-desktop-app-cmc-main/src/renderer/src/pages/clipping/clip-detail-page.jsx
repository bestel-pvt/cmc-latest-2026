import ClipDetail from '@/components/clipping/clip-detail'
import Container from '@/components/common/dash-container'
import { getClip } from '@/services/clipping/clipApi'
import { useQuery } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'

const ClipDetailPage = () => {
  const { id } = useParams()
  const { data, isPending } = useQuery({
    queryKey: ['clip', id],
    queryFn: () => getClip(id),
    enabled: !!id
  })

  const clip = data?.clip

  return (
    <Container>
      <ClipDetail clipData={clip} isPending={isPending} />
    </Container>
  )
}

export default ClipDetailPage
