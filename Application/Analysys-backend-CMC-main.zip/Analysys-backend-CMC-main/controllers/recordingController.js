const recordingService = require('../services/recordingService.js')
const { RecordingQueries } = require('../queries')
const { idSchema } = require('../utils/validation.js')
const Joi = require('joi')
const fs = require('fs-extra')

// Query validation schema for pagination and filtering
const querySchema = Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(10),
    sortBy: Joi.string().valid('fileName', 'startTime', 'endTime', 'status', 'fileSize', 'createdAt').default('startTime'),
    sortOrder: Joi.string().valid('asc', 'desc').default('desc'),
    status: Joi.string().valid('recording', 'completed', 'failed', 'stopped').optional(),
    format: Joi.string().optional(),
    dateFrom: Joi.date().optional(),
    dateTo: Joi.date().optional()
})

// Comprehensive query validation schema for getAllRecordings
const getAllRecordingsQuerySchema = Joi.object({
    // Pagination
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(10),

    // Sorting
    sortBy: Joi.string().valid(
        'fileName', 'startTime', 'endTime', 'status', 'fileSize',
        'createdAt', 'updatedAt', 'duration', 'sourceIp', 'sourcePort', 'isActive'
    ).default('startTime'),
    sortOrder: Joi.string().valid('asc', 'desc').default('desc'),

    // Filtering
    status: Joi.string().valid('recording', 'completed', 'failed', 'stopped').allow('').optional(),
    isActive: Joi.boolean().optional(),
    format: Joi.string().allow('').optional(),
    channelId: Joi.string().allow('').optional(),
    channelName: Joi.string().allow('').optional(),
    fileName: Joi.string().allow('').optional(),
    sourceIp: Joi.string().allow('').optional(),
    sourcePort: Joi.number().integer().allow('').optional(),

    // Date range filtering
    dateFrom: Joi.date().allow('').optional(),
    dateTo: Joi.date().allow('').optional(),
    startTimeFrom: Joi.date().allow('').optional(),
    startTimeTo: Joi.date().allow('').optional(),
    endTimeFrom: Joi.date().allow('').optional(),
    endTimeTo: Joi.date().allow('').optional(),

    // Size and duration filtering
    minFileSize: Joi.number().integer().min(0).allow('').optional(),
    maxFileSize: Joi.number().integer().min(0).allow('').optional(),
    minDuration: Joi.number().integer().min(0).allow('').optional(),
    maxDuration: Joi.number().integer().min(0).allow('').optional(),

    // Search functionality
    search: Joi.string().allow('').optional() // Search in fileName, channelName, description
})

// Helper function to format validation errors
const formatValidationError = (error) => {
    const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
    }))
    return {
        error: 'Validation failed',
        details: errors
    }
}

// Start recording for a channel
const startRecording = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.channelId)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { channelId } = req.params
        const result = await recordingService.startRecording(channelId)

        res.json(result)
    } catch (error) {
        console.error('Start recording error:', error)

        let statusCode = 500
        if (error.message.includes('Channel not found')) {
            statusCode = 404
        } else if (error.message.includes('already being recorded') || error.message.includes('not active')) {
            statusCode = 400
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to start recording'
        })
    }
}

// Stop recording for a channel
const stopRecording = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.channelId)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { channelId } = req.params
        const result = await recordingService.stopRecording(channelId)

        res.json(result)
    } catch (error) {
        console.error('Stop recording error:', error)

        let statusCode = 500
        if (error.message.includes('No active recording')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to stop recording'
        })
    }
}

// Get recording status for a channel
const getRecordingStatus = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.channelId)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { channelId } = req.params
        const status = await recordingService.getRecordingStatus(channelId)

        res.json({
            success: true,
            ...status
        })
    } catch (error) {
        console.error('Get recording status error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get recording status'
        })
    }
}

// Get all recordings for a specific channel
const getChannelRecordings = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.channelId)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const { error: queryError, value } = querySchema.validate(req.query)
        if (queryError) {
            return res.status(400).json(formatValidationError(queryError))
        }

        const { channelId } = req.params
        const { page, limit, sortBy, sortOrder, status, format, dateFrom, dateTo } = value

        // Build filters object
        const filters = { channelId }

        if (typeof status !== 'undefined' && status !== '') {
            filters.status = status
        }

        if (typeof format !== 'undefined' && format !== '') {
            filters.format = format
        }

        const validDateFrom = typeof dateFrom !== 'undefined' && dateFrom !== '';
        const validDateTo = typeof dateTo !== 'undefined' && dateTo !== '';
        if (validDateFrom || validDateTo) {
            if (validDateFrom) {
                filters.startTimeFrom = new Date(dateFrom);
            }
            if (validDateTo) {
                filters.startTimeTo = new Date(dateTo);
            }
        }

        const offset = (page - 1) * limit

        // Get recordings with pagination and include channel info
        const result = await RecordingQueries.getRecordings({
            filters,
            orderBy: sortBy,
            orderDirection: sortOrder.toUpperCase(),
            limit: parseInt(limit),
            offset,
            includeChannel: true
        })

        // Format response without exposing file paths
        const formattedRecordings = result.recordings.map(recording => ({
            id: recording.id,
            channelId: recording.channelId,
            channelName: recording.channelName,
            fileName: recording.fileName,
            status: recording.status,
            isActive: recording.isActive,
            startTime: recording.startTime,
            endTime: recording.endTime,
            duration: recording.duration,
            fileSize: recording.fileSize,
            format: recording.format,
            sourceIp: recording.sourceIp,
            sourcePort: recording.sourcePort,
            udpLink: recording.udpLink,
            createdAt: recording.createdAt,
            updatedAt: recording.updatedAt
        }))

        res.json({
            success: true,
            recordings: formattedRecordings,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: result.total,
                pages: Math.ceil(result.total / limit)
            }
        })
    } catch (error) {
        console.error('Get channel recordings error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get channel recordings'
        })
    }
}

// Get active recordings
const getActiveRecordings = async (req, res) => {
    try {
        const activeRecordings = recordingService.getActiveRecordings()

        res.json({
            success: true,
            activeRecordings,
            count: activeRecordings.length
        })
    } catch (error) {
        console.error('Get active recordings error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get active recordings'
        })
    }
}

// Get all recordings
const getAllRecordings = async (req, res) => {
    try {
        const { error: queryError, value } = getAllRecordingsQuerySchema.validate(req.query)
        if (queryError) {
            return res.status(400).json(formatValidationError(queryError))
        }

        const {
            page,
            limit,
            sortBy,
            sortOrder,
            status,
            isActive,
            format,
            channelId,
            channelName,
            fileName,
            sourceIp,
            sourcePort,
            dateFrom,
            dateTo,
            startTimeFrom,
            startTimeTo,
            endTimeFrom,
            endTimeTo,
            minFileSize,
            maxFileSize,
            minDuration,
            maxDuration,
            search
        } = value

        // Build filters object
        const filters = {}

        // Status filter
        if (status && status !== '') {
            filters.status = status
        }

        // Active status filter
        if (typeof isActive !== 'undefined') {
            filters.isActive = isActive
        }

        // Format filter
        if (format && format !== '') {
            filters.format = format
        }

        // Channel ID filter
        if (channelId && channelId !== '') {
            filters.channelId = channelId
        }

        // Channel name filter
        if (channelName && channelName !== '') {
            filters.channelName = channelName
        }

        // Source IP filter
        if (sourceIp && sourceIp !== '') {
            filters.sourceIp = sourceIp
        }

        // Source Port filter
        if (sourcePort && sourcePort !== '') {
            filters.sourcePort = parseInt(sourcePort)
        }

        // File name filter (partial match)
        if (fileName && fileName !== '') {
            filters.fileName = fileName
        }

        // Date range filters
        if (dateFrom && dateFrom !== '') {
            filters.startTimeFrom = new Date(dateFrom)
        }
        if (dateTo && dateTo !== '') {
            filters.startTimeTo = new Date(dateTo)
        }

        // Start time range filters (override dateFrom/dateTo if specified)
        if (startTimeFrom && startTimeFrom !== '') {
            filters.startTimeFrom = new Date(startTimeFrom)
        }
        if (startTimeTo && startTimeTo !== '') {
            filters.startTimeTo = new Date(startTimeTo)
        }

        // End time range filters
        if (endTimeFrom && endTimeFrom !== '') {
            filters.endTimeFrom = new Date(endTimeFrom)
        }
        if (endTimeTo && endTimeTo !== '') {
            filters.endTimeTo = new Date(endTimeTo)
        }

        // File size range filters
        if (minFileSize && minFileSize !== '') {
            filters.minFileSize = parseInt(minFileSize)
        }
        if (maxFileSize && maxFileSize !== '') {
            filters.maxFileSize = parseInt(maxFileSize)
        }

        // Duration range filters
        if (minDuration && minDuration !== '') {
            filters.minDuration = parseInt(minDuration)
        }
        if (maxDuration && maxDuration !== '') {
            filters.maxDuration = parseInt(maxDuration)
        }

        // Search functionality (searches in fileName and channel name)
        if (search && search !== '') {
            filters.search = search
        }

        const offset = (page - 1) * limit

        // Get recordings with pagination and include channel info
        const result = await RecordingQueries.getRecordings({
            filters,
            orderBy: sortBy,
            orderDirection: sortOrder.toUpperCase(),
            limit: parseInt(limit),
            offset,
            includeChannel: true
        })

        // Format response without exposing file paths
        const formattedRecordings = result.recordings.map(recording => ({
            id: recording.id,
            channelId: recording.channelId,
            channelName: recording.channelName,
            channelDescription: recording.channelDescription,
            fileName: recording.fileName,
            status: recording.status,
            isActive: recording.isActive,
            format: recording.format,
            startTime: recording.startTime,
            endTime: recording.endTime,
            duration: recording.duration,
            fileSize: recording.fileSize,
            sourceIp: recording.sourceIp,
            sourcePort: recording.sourcePort,
            udpLink: recording.udpLink,
            createdAt: recording.createdAt,
            updatedAt: recording.updatedAt
        }))

        res.json({
            success: true,
            recordings: formattedRecordings,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: result.total,
                pages: Math.ceil(result.total / limit),
                hasNext: page * limit < result.total,
                hasPrev: page > 1
            },
            filters: {
                status,
                isActive,
                format,
                channelId,
                channelName,
                fileName,
                sourceIp,
                sourcePort,
                dateFrom,
                dateTo,
                startTimeFrom,
                startTimeTo,
                endTimeFrom,
                endTimeTo,
                minFileSize,
                maxFileSize,
                minDuration,
                maxDuration,
                search
            },
            sorting: {
                sortBy,
                sortOrder
            },
            count: formattedRecordings.length
        })
    } catch (error) {
        console.error('Get all recordings error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get recordings'
        })
    }
}

// Get recording by ID
const getRecordingById = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const recording = await RecordingQueries.getRecordingById(id, { includeChannel: true })

        if (!recording) {
            return res.status(404).json({
                success: false,
                error: 'Recording not found'
            })
        }

        res.json({
            success: true,
            recording
        })
    } catch (error) {
        console.error('Get recording by ID error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get recording'
        })
    }
}

// Delete recording
const deleteRecording = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params

        // Find the recording first
        const recording = await RecordingQueries.getRecordingById(id)

        if (!recording) {
            return res.status(404).json({
                success: false,
                error: 'Recording not found'
            })
        }

        // Delete file if it exists
        try {
            if (await fs.pathExists(recording.filePath)) {
                await fs.remove(recording.filePath)
            }
        } catch (fileError) {
            console.warn('Could not delete recording file:', fileError.message)
        }

        // Delete from database
        await RecordingQueries.deleteRecording(id)

        res.json({
            success: true,
            message: 'Recording deleted successfully'
        })

    } catch (error) {
        console.error('Delete recording error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to delete recording'
        })
    }
}

// Serve recording file securely
const serveRecordingFile = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params

        // Get recording details
        const recording = await RecordingQueries.getRecordingById(id, { includeChannel: true })

        if (!recording) {
            return res.status(404).json({
                success: false,
                error: 'Recording not found'
            })
        }

        if (!await fs.pathExists(recording.filePath)) {
            return res.status(404).json({
                success: false,
                error: 'Recording file not found'
            })
        }

        // Set appropriate headers for video streaming
        res.setHeader('Content-Type', recording.format === 'mp4' ? 'video/mp4' : 'video/x-matroska')
        res.setHeader('Content-Disposition', `inline; filename="${recording.fileName}"`)
        res.setHeader('Accept-Ranges', 'bytes')

        // Get file stats for content length
        const stats = await fs.stat(recording.filePath)
        const fileSize = stats.size

        // Handle range requests for video streaming
        const range = req.headers.range
        if (range) {
            const parts = range.replace(/bytes=/, "").split("-")
            const start = parseInt(parts[0], 10)
            const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1
            const chunksize = (end - start) + 1

            res.status(206)
            res.setHeader('Content-Range', `bytes ${start}-${end}/${fileSize}`)
            res.setHeader('Content-Length', chunksize)

            const stream = fs.createReadStream(recording.filePath, { start, end })
            stream.pipe(res)
        } else {
            res.setHeader('Content-Length', fileSize)
            const stream = fs.createReadStream(recording.filePath)
            stream.pipe(res)
        }

    } catch (error) {
        console.error('Serve recording file error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to serve recording file'
        })
    }
}

module.exports = {
    startRecording,
    stopRecording,
    getRecordingStatus,
    getChannelRecordings,
    getActiveRecordings,
    getAllRecordings,
    getRecordingById,
    deleteRecording,
    serveRecordingFile
}
