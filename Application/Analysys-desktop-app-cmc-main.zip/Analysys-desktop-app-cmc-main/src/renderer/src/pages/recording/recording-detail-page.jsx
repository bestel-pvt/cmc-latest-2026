import {
  ArrowLeft,
  Pen,
  Tags,
  Clock,
  Calendar,
  FileText,
  Wifi,
  HardDrive,
  Scissors
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'

import { format, parseISO } from 'date-fns'
import { useNavigate, useParams } from 'react-router-dom'
import Container from '@/components/common/dash-container'
import { Badge } from '@/components/ui/badge'

import { useQuery } from '@tanstack/react-query'
import { getRecording } from '@/services/recording/recordingApi'
import Loader from '@/components/common/loader'

import { useApiUrl } from '@/hooks/use-config'

const formatDuration = (seconds) => {
  if (!seconds) return 'N/A'
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${mins}m ${secs}s`
}

const formatFileSize = (bytes) => {
  if (bytes === null) return 'N/A'
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
  if (bytes === 0) return '0 Bytes'
  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10)
  return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i]
}

const RecordingDetailPage = () => {
  const { apiUrl, loading } = useApiUrl()
  const navigate = useNavigate()
  const { id } = useParams()
  const { data, isPending } = useQuery({
    queryKey: ['recording', id],
    queryFn: () => getRecording(id),
    enabled: !!id
  })

  const recording = data?.recording

  if (isPending || loading) {
    return <Loader name={'Recording details'} />
  }

  return (
    <Container>
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-start gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
                  <ArrowLeft />
                </Button>
                <div className="space-y-2">
                  <h3>{recording?.channel?.name}</h3>
                  <p className="text-muted-foreground font-medium text-wrap">
                    {recording?.fileName}
                  </p>
                </div>
              </div>
              <Button
                size="sm"
                onClick={() =>
                  navigate(`/clips/new/${recording?.id}`, {
                    state: { filePath: `${apiUrl}/recordings/${id}/file` }
                  })
                }
              >
                <Scissors />
                Create clip
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <video
              controls
              // src={buildFilePath(recording?.filePath)}
              src={`${apiUrl}/recordings/${id}/file`}
              className="w-full aspect-auto rounded-xl"
              autoPlay={false}
            >
              Your browser does not support the video tag.
            </video>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Recording Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <DetailItem
                icon={<FileText className="h-4 w-4" />}
                label="File Name"
                value={recording?.fileName}
              />

              <DetailItem
                icon={<HardDrive className="h-4 w-4" />}
                label="File Size"
                value={formatFileSize(recording?.fileSize)}
              />

              <DetailItem
                icon={<FileText className="h-4 w-4" />}
                label="Format"
                value={recording?.format?.toUpperCase()}
              />

              <DetailItem
                icon={<Clock className="h-4 w-4" />}
                label="Duration"
                value={formatDuration(recording?.duration)}
              />

              <DetailItem
                icon={<Calendar className="h-4 w-4" />}
                label="Created At"
                value={recording?.createdAt && format(parseISO(recording?.createdAt), 'PPPpp')}
              />

              <DetailItem
                icon={<Calendar className="h-4 w-4" />}
                label="Start Time"
                value={recording?.startTime && format(parseISO(recording?.startTime), 'PPPpp')}
              />

              <DetailItem
                icon={<Calendar className="h-4 w-4" />}
                label="End Time"
                value={recording?.endTime && format(parseISO(recording?.endTime), 'PPPpp')}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Connection Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <DetailItem
                icon={<Wifi className="h-4 w-4" />}
                label="UDP Link"
                value={recording?.udpLink}
                isLink
              />

              <DetailItem
                icon={<FileText className="h-4 w-4" />}
                label="Status"
                value={
                  <Badge variant={recording?.status === 'stopped' ? 'destructive' : 'default'}>
                    {recording?.status}
                  </Badge>
                }
              />

              {recording?.channel && (
                <>
                  <DetailItem
                    icon={<FileText className="h-4 w-4" />}
                    label="Channel"
                    value={recording?.channel?.name}
                  />

                  <DetailItem
                    icon={<FileText className="h-4 w-4" />}
                    label="Channel Description"
                    value={recording?.channel?.description}
                  />
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Metadata & Organization</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Custom Naming &amp; Tagging</p>
                <div className="mt-2 space-y-3">
                  <StorageFeature
                    icon={
                      <div className="w-5 h-5">
                        <Pen />
                      </div>
                    }
                    title="Custom Name"
                    description={recording.customName || 'No custom name provided.'}
                    enabled={!!recording.customName}
                  />
                  <StorageFeature
                    icon={<Tags />}
                    title="Tags"
                    description={
                      recording.tags && recording.tags.length > 0
                        ? `Tagged with: ${recording.tags.join(', ')}`
                        : 'No tags assigned.'
                    }
                    enabled={!!(recording.tags && recording.tags.length > 0)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">File Information</p>
                <div className="mt-2 space-y-3">
                  <StorageFeature
                    icon={<FileText />}
                    title="File Path"
                    description={recording?.filePath || 'No file path available'}
                    enabled={!!recording.filePath}
                  />
                  <StorageFeature
                    icon={<Calendar />}
                    title="Last Updated"
                    description={
                      recording.updatedAt
                        ? format(parseISO(recording.updatedAt), 'PPPpp')
                        : 'No update information available'
                    }
                    enabled={!!recording.updatedAt}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Container>
  )
}

// Reusable components
function StorageFeature({ icon, title, description, enabled }) {
  return (
    <div className="flex items-start gap-3">
      <div
        className={`p-2 rounded-lg ${
          enabled ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'
        }`}
      >
        {icon}
      </div>
      <div>
        <p className={`font-medium ${enabled ? '' : 'text-muted-foreground'}`}>{title}</p>
        <p
          className="text-sm text-muted-foreground truncate  line-clamp-1 max-w-80"
          title={description}
        >
          {description}
        </p>
      </div>
    </div>
  )
}

function DetailItem({ icon, label, value, isLink = false }) {
  if (!value) return null

  return (
    <div className="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
      <div className="flex items-center gap-2">
        <div className="text-muted-foreground">{icon}</div>
        <span className="text-sm font-medium">{label}:</span>
      </div>
      <div className="text-right">
        {isLink ? (
          <a
            href={value}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-blue-600 hover:underline"
          >
            {value}
          </a>
        ) : (
          <span className="text-sm truncate  line-clamp-1 max-w-80" title={value}>
            {value}
          </span>
        )}
      </div>
    </div>
  )
}

export default RecordingDetailPage
