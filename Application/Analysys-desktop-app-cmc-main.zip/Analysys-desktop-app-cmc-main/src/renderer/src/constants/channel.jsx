export const CATEGORIES = [
  { label: 'News', value: 'news' },
  { label: 'Sports', value: 'sports' },
  { label: 'Technology', value: 'technology' },
  { label: 'Business', value: 'business' },
  { label: 'Travel', value: 'travel' },
  { label: 'Entertainment', value: 'entertainment' },
  { label: 'Comedy', value: 'comedy' },
  { label: 'Movies', value: 'movies' },
  { label: 'Educational', value: 'educational' },
  { label: 'Music', value: 'music' },
  { label: 'Fashion', value: 'fashion' },
  { label: 'Food', value: 'food' },
  { label: 'Health & Fitness', value: 'health_fitness' },
  { label: 'Science', value: 'science' },
  { label: 'Art', value: 'art' },
  { label: 'Kids', value: 'kids' },
  { label: 'Gaming', value: 'gaming' },
  { label: 'Lifestyle', value: 'lifestyle' },
  { label: 'Automotive', value: 'automotive' },
  { label: 'Religion', value: 'religion' },
  { label: 'Politics', value: 'politics' },
  { label: 'Other', value: 'other' }
]

export const PRIORITY = [
  { label: 'Low (background)', value: 'low' },
  { label: 'Medium (default)', value: 'medium' },
  { label: 'High (preferred)', value: 'high' }
]

export const RECORDING_PATTERN = [
  { label: 'Daily', value: 'daily' },
  { label: 'Weekly', value: 'weekly' },
  { label: 'Custom', value: 'custom' }
]

export const SOURCE_PRIORITY = [
  { label: 'Low', value: 1 },
  { label: 'Medium', value: 2 },
  { label: 'High', value: 3 }
]

export const SOURCE_TYPES = [
  { value: 'PTCL', label: 'PTCL' },
  { value: 'SATELLITE', label: 'Satellite' },
  { value: 'NAYATEL', label: 'Nayatel' },
  { value: 'FIBER', label: 'Fiber' }
]
