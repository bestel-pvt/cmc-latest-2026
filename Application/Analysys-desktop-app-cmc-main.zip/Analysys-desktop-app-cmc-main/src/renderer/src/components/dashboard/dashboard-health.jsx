import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
// import { LineChart, BarChart, PieChart } from "@/components/ui/charts";
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell
} from '@/components/ui/table'
import ChartAreaStackedExpand from '../ui/charts/stack-line-chart'
import { ProviderHealthChart } from '../ui/charts/stack-bar-chart'
import { ChartPieDonut } from '../ui/charts/pie-donut'

const StreamHealthDashboard = () => {
  // Sample data
  const providers = [
    {
      id: 'ptcl',
      name: 'PTCL',
      currentHealth: 82,
      monthlyAvg: 78,
      bestHealth: 92,
      color: '#3b82f6'
    },
    {
      id: 'nayatel',
      name: 'Nayatel',
      currentHealth: 91,
      monthlyAvg: 89,
      bestHealth: 95,
      color: '#10b981'
    },
    {
      id: 'satellite',
      name: 'Satellite',
      currentHealth: 75,
      monthlyAvg: 72,
      bestHealth: 83,
      color: '#f59e0b'
    }
  ]

  const monthlyData = [
    { month: 'Jan', ptcl: 76, nayatel: 87, satellite: 70 },
    { month: 'Feb', ptcl: 78, nayatel: 88, satellite: 71 },
    { month: 'Mar', ptcl: 75, nayatel: 86, satellite: 69 },
    { month: 'Apr', ptcl: 79, nayatel: 89, satellite: 72 },
    { month: 'May', ptcl: 82, nayatel: 91, satellite: 75 },
    { month: 'Jun', ptcl: 80, nayatel: 90, satellite: 74 }
  ]

  const currentIssues = [
    { provider: 'PTCL', issue: 'Latency spikes', severity: 'medium', duration: '2h 15m' },
    { provider: 'Satellite', issue: 'Packet loss', severity: 'high', duration: '4h 30m' }
  ]

  return (
    <div className=" space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Stream Health Analysis</h1>
        <div className="flex space-x-2">
          <Badge variant="outline">Last updated: {new Date().toLocaleString()}</Badge>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        {providers.map((provider) => (
          <Card key={provider.id}>
            <CardHeader>
              <CardTitle>{provider.name}</CardTitle>
              <CardDescription>Stream health metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium mb-1">Current Health</p>
                  <div className="flex items-center space-x-2">
                    <Progress value={provider.currentHealth} className="h-2" />
                    <span className="text-sm font-medium">{provider.currentHealth}%</span>
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Monthly Average</p>
                  <p className="text-lg font-bold">{provider.monthlyAvg}%</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">All-time Best</p>
                  <p className="text-lg font-bold">{provider.bestHealth}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Section */}
      <Tabs defaultValue="trend">
        <TabsList>
          <TabsTrigger value="trend">Trend Analysis</TabsTrigger>
          <TabsTrigger value="comparison">Provider Comparison</TabsTrigger>
          <TabsTrigger value="distribution">Health Distribution</TabsTrigger>
        </TabsList>
        <TabsContent value="trend">
          <ChartAreaStackedExpand
            data={monthlyData}
            xAxis="month"
            yAxis={['ptcl', 'nayatel', 'satellite']}
            colors={['#3b82f6', '#10b981', '#f59e0b']}
            height={300}
          />
        </TabsContent>
        <TabsContent value="comparison">
          <ProviderHealthChart
            title="Provider Health Status"
            description="Current health scores compared to monthly averages"
            data={providers}
            footerText="Showing current health scores for major providers"
          />
        </TabsContent>
        <TabsContent value="distribution">
          <ChartPieDonut
            data={providers.map((p) => ({
              name: p.name,
              value: p.currentHealth,
              color: p.color
            }))}
            height={300}
            width={400}
          />
        </TabsContent>
      </Tabs>

      {/* Current Issues */}
      <Card>
        <CardHeader>
          <CardTitle>Current Issues</CardTitle>
          <CardDescription>Active problems affecting stream health</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Provider</TableHead>
                <TableHead>Issue</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Duration</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentIssues.map((issue, index) => (
                <TableRow key={index}>
                  <TableCell>{issue.provider}</TableCell>
                  <TableCell>{issue.issue}</TableCell>
                  <TableCell>
                    <Badge variant={issue.severity === 'high' ? 'destructive' : 'warning'}>
                      {issue.severity}
                    </Badge>
                  </TableCell>
                  <TableCell>{issue.duration}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Best Performer */}
      <Card>
        <CardHeader>
          <CardTitle>Best Performing Provider</CardTitle>
          <CardDescription>All-time health performance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <h4 className="font-bold">
                {providers.sort((a, b) => b.bestHealth - a.bestHealth)[0].name}
              </h4>
              <p className="text-muted-foreground">
                Achieved {providers.sort((a, b) => b.bestHealth - a.bestHealth)[0].bestHealth}%
                health score
              </p>
            </div>
            <Badge variant="success" className="">
              Best Overall
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default StreamHealthDashboard
