const { SourceQueries } = require('../queries')
const { createSourceSchema, updateSourceSchema, idSchema } = require('../utils/validation.js')

// Helper function to format validation errors
const formatValidationError = (error) => {
    const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
    }))
    return {
        error: 'Validation failed',
        details: errors
    }
}

// Get all sources with pagination, filtering, search, and sorting
const getSources = async (req, res) => {
    try {
        const {
            page = 1,
            pageSize = 10,
            search = '',
            type = 'all',
            isActive = 'all',
            isPrimary = 'all',
            sort = 'desc' // default sort order
        } = req.query;

        const result = SourceQueries.getSources({
            page,
            pageSize,
            search,
            type,
            isActive,
            isPrimary,
            sort
        })

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch sources' });
    }
}

// Get source by ID
const getSourceById = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const source = SourceQueries.getSourceById(id)

        if (!source) {
            return res.status(404).json({ error: 'Source not found' })
        }

        res.json(source)
    } catch (error) {
        console.error('Get source error:', error)
        res.status(500).json({ error: 'Failed to fetch source' })
    }
}

// Get sources by channel ID
const getSourcesByChannelId = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.channelId)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { channelId } = req.params
        const sources = SourceQueries.getSourcesByChannelId(channelId)
        res.json(sources)
    } catch (error) {
        console.error('Get sources by channel error:', error)
        res.status(500).json({ error: 'Failed to fetch sources for channel' })
    }
}

// Create source
const createSource = async (req, res) => {
    try {
        const { error, value } = createSourceSchema.validate(req.body)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { channelId, type, port, ip, isActive, isPrimary, priority } = value

        const source = SourceQueries.createSource({
            channelId,
            type,
            port,
            ip,
            isActive: isActive !== undefined ? isActive : true,
            isPrimary: isPrimary !== undefined ? isPrimary : false,
            priority: priority || 0
        })

        res.status(201).json(source)
    } catch (error) {
        console.error('Create source error:', error)
        res.status(500).json({ error: 'Failed to create source' })
    }
}

// Update source
const updateSource = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.id)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const { error: bodyError, value } = updateSourceSchema.validate(req.body)
        if (bodyError) {
            return res.status(400).json(formatValidationError(bodyError))
        }

        const { id } = req.params
        const { type, port, ip, isActive, isPrimary, priority } = value

        const updates = {}
        if (type) updates.type = type
        if (port) updates.port = port
        if (ip) updates.ip = ip
        if (isActive !== undefined) updates.isActive = isActive
        if (isPrimary !== undefined) updates.isPrimary = isPrimary
        if (priority !== undefined) updates.priority = priority

        const source = SourceQueries.updateSource(id, updates)

        res.json(source)
    } catch (error) {
        if (error.code === 'P2025') {
            return res.status(404).json({ error: 'Source not found' })
        }
        console.error('Update source error:', error)
        res.status(500).json({ error: 'Failed to update source' })
    }
}

// Delete source
const deleteSource = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params

        SourceQueries.deleteSource(id)

        res.status(204).send()
    } catch (error) {
        if (error.code === 'P2025') {
            return res.status(404).json({ error: 'Source not found' })
        }
        console.error('Delete source error:', error)
        res.status(500).json({ error: 'Failed to delete source' })
    }
}

module.exports = {
    getSources,
    getSourceById,
    getSourcesByChannelId,
    createSource,
    updateSource,
    deleteSource
}
