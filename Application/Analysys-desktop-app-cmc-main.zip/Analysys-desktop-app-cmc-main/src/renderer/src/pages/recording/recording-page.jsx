import Container from '@/components/common/dash-container'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import RecordingTable from '@/components/recording/table/recording-table'

const RecordingPage = () => {
  return (
    <Container>
      <Card>
        <CardHeader>
          <CardTitle>
            <h4>Recording List</h4>
          </CardTitle>
        </CardHeader>

        <CardContent>
          <RecordingTable />
        </CardContent>
      </Card>
    </Container>
  )
}

export default RecordingPage
