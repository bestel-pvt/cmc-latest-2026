'use client'

import { TrendingUp } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, LabelList, XAxis } from 'recharts'

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'

export const description = 'A bar chart with a label'

const chartData = [
  { content: 'January', clips: 186 },
  { content: 'February', clips: 305 },
  { content: 'March', clips: 237 },
  { content: 'April', clips: 73 },
  { content: 'May', clips: 209 },
  { content: 'June', clips: 214 }
]

const chartConfig = {
  clips: {
    label: 'Clips',
    color: 'var(--chart-1)'
  }
}

export function BarChartLabel({ data = [], xKey = 'content', yKey = 'clips', title, description }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title || 'Title of bar chart'}</CardTitle>
        <CardDescription>{description || 'January - June 2024'}</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig}>
          <BarChart
            accessibilityLayer
            data={data || chartData}
            margin={{
              top: 20
            }}
          >
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey={xKey || 'content'}
              tickLine={false}
              tickMargin={10}
              axisLine={false}
              // tickFormatter={(value) => value.slice(0, 3)}
            />
            <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
            <Bar dataKey={yKey || 'clip'} fill="var(--color-clips)" radius={8}>
              <LabelList position="top" offset={12} className="fill-foreground" fontSize={12} />
            </Bar>
          </BarChart>
        </ChartContainer>
      </CardContent>
      {/* <CardFooter className="flex-col items-start gap-2 text-sm">
                <div className="flex gap-2 leading-none font-medium">
                    Trending up by 5.2% this month <TrendingUp className="h-4 w-4" />
                </div>
                <div className="text-muted-foreground leading-none">
                    Showing total visitors for the last 6 months
                </div>
            </CardFooter> */}
    </Card>
  )
}
