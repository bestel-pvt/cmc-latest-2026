import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../ui/form'
import { useForm } from 'react-hook-form'
import { Input } from '../ui/input'
import { Checkbox } from '../ui/checkbox'
import { Button } from '../ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { SOURCE_PRIORITY, SOURCE_TYPES } from '@/constants/channel'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { createSource } from '@/services/source/sourceApi'
import { ToastError, ToastSuccess } from '@/lib/toast'

import { zodResolver } from '@hookform/resolvers/zod'
import { sourceCreateSchema } from '@/services/source/schema'
import ChannelSelect from './channel-select'
import { useNavigate } from 'react-router-dom'

const CreateSourceForm = ({ sourceData }) => {
  const navigate = useNavigate()
  const queryClient = useQueryClient()

  const form = useForm({
    defaultValues: sourceData || {
      channelId: '',
      ip: '',
      port: '',
      type: undefined,
      priority: '',
      isActive: false,
      isPrimary: false
    },
    mode: 'onSubmit',
    resolver: zodResolver(sourceCreateSchema)
  })

  const mutationUpdateSource = useMutation({
    mutationFn: async (values) => {
      return await createSource(values)
    },
    onSuccess: (data) => {
      navigate(-1)
      ToastSuccess(data?.message || 'Source created successful')
    },
    onError: (error) => {
      console.log(error)
      ToastError(error?.response?.data?.message || 'An error occurred')
    }
  })

  const onSubmit = async (values) => {
    console.log(values)
    mutationUpdateSource.mutate(values)
  }
  console.log(form.formState.errors)
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 ">
        <div className="grid grid-cols-1  md:grid-cols-2 gap-8">
          <ChannelSelect form={form} />
          <FormField
            control={form.control}
            name={`type`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>Source Type</FormLabel>
                <Select onValueChange={field.onChange} value={field.value} className="w-full">
                  <FormControl>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select source type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {SOURCE_TYPES.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="ip"
            render={({ field }) => (
              <FormItem>
                <FormLabel>IP Address</FormLabel>
                <FormControl>
                  <Input placeholder="192.168.1.100" type="" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="port"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Port Number</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="e.g. 5001" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name={`priority`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Priority</FormLabel>
              <Select
                onValueChange={(value) => field.onChange(Number(value))}
                value={field.value?.toString()}
              >
                <FormControl>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {SOURCE_PRIORITY.map((priority) => (
                    <SelectItem key={priority.value} value={priority.value.toString()}>
                      {priority.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="isActive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
              <FormControl>
                <Checkbox checked={field.value} onCheckedChange={field.onChange} />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel>Active Source</FormLabel>

                <FormMessage />
              </div>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="isPrimary"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
              <FormControl>
                <Checkbox checked={field.value} onCheckedChange={field.onChange} />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel>Primary Source</FormLabel>

                <FormMessage />
              </div>
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={() => navigate(-1)}>
            Cancel
          </Button>
          <Button type="submit">Save</Button>
        </div>
      </form>
    </Form>
  )
}

export default CreateSourceForm
