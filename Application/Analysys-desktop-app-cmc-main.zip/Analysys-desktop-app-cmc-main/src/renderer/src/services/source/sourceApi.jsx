import { api } from '@/lib/axios-instance'

export const getAllSource = async ({
  page = 1,
  limit = 10,
  search = '',
  isActive = 'all',
  sort = 'desc',
  type = 'all'
}) => {
  const response = await api.get('/sources', {
    params: {
      page,
      pageSize: limit,
      search,
      isActive,
      sort,
      type
    }
  })
  return response?.data
}

export const getSource = async (id) => {
  const response = await api.get(`/sources/${id}`)
  return response?.data
}

export const createSource = async (data) => {
  const response = await api.post(`/sources/`, data)
  return response?.data
}

export const updateSource = async (id, data) => {
  console.log(id)
  const response = await api.put(`/sources/${id}`, data)
  return response?.data
}
export const deleteSource = async (id) => {
  const response = await api.delete(`/sources/${id}`)
  return response?.data
}

export const getSourceHealth = async (id) => {
  const response = await api.get(`/sources/${id}/health`)
  return response?.data
}
export const connectivitySourceTest = async (id) => {
  const response = await api.post(`/sources/${id}/test`)
  return response?.data
}
