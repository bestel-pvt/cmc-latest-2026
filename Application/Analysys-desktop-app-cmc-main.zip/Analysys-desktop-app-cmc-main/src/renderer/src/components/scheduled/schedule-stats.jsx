import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table'
import { format } from 'date-fns'

const ScheduledStats = () => {
  const data = {
    totalScheduled: 1,
    activeRecordings: 0,
    upcomingToday: 0,
    upcomingWeek: 0,
    unresolvedConflicts: 0,
    recentExecutions: [
      {
        id: 'cmey5woc80001dk1glf2ou522',
        channelId: 'cmeu6v9p70000uw28usmaeyxy',
        name: 'Weekly Sports Show',
        description: '',
        scheduledStart: '2024-01-16T20:00:00.000Z',
        scheduledEnd: '2024-01-16T21:30:00.000Z',
        duration: null,
        isRecurring: true,
        recurrenceType: 'weekly',
        recurrenceRule: 'FREQ=WEEKLY;BYDAY=TU',
        priority: 3,
        status: 'scheduled',
        isActive: true,
        notificationEnabled: false,
        createdAt: '2025-08-30T11:12:15.416Z',
        updatedAt: '2025-08-30T11:16:05.742Z',
        channel: {
          id: 'cmeu6v9p70000uw28usmaeyxy',
          name: 'GEO News',
          description: "Pakistan's leading news channel"
        },
        executions: []
      }
    ]
  }

  // Get status badge variant
  const getStatusVariant = (status) => {
    switch (status) {
      case 'scheduled':
        return 'secondary'
      case 'recording':
        return 'destructive'
      case 'completed':
        return 'default'
      default:
        return 'outline'
    }
  }

  return (
    <div className="">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Recording Dashboard</h1>
        <p className="text-gray-600">Monitor and manage your scheduled recordings</p>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Scheduled</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalScheduled}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Recordings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.activeRecordings}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.upcomingToday}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Week</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.upcomingWeek}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unresolved Conflicts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.unresolvedConflicts}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recent Executions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.recentExecutions?.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* <Card>
        <CardHeader>
          <CardTitle>Recent Executions</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Channel</TableHead>
                <TableHead>Scheduled Start</TableHead>
                <TableHead>Scheduled End</TableHead>
                <TableHead>Recurrence</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.recentExecutions.map((execution) => (
                <TableRow key={execution.id}>
                  <TableCell className="font-medium">{execution.name}</TableCell>
                  <TableCell>{execution.channel.name}</TableCell>
                  <TableCell>{format(new Date(execution.scheduledStart), 'PPP, pp')}</TableCell>
                  <TableCell>{format(new Date(execution.scheduledEnd), 'PPP ,pp')}</TableCell>
                  <TableCell>
                    {execution.isRecurring ? (
                      <Badge variant="outline" className="capitalize">
                        {execution.recurrenceType}
                      </Badge>
                    ) : (
                      <span>One-time</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">Level {execution.priority}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(execution.status)} className="capitalize">
                      {execution.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card> */}
    </div>
  )
}

export default ScheduledStats
