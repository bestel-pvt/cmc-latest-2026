import { RouterProvider } from 'react-router-dom'
import { router } from './router'
import { useEffect } from 'react'
import socketService from './services/socket/socketService'

function App() {
  useEffect(() => {
    // Connect when app mounts
    socketService.connect()

    // Disconnect when app unmounts
    return () => {
      socketService.disconnect()
    }
  }, [])

  return (
    <>
      <RouterProvider router={router} />
    </>
  )
}

export default App
