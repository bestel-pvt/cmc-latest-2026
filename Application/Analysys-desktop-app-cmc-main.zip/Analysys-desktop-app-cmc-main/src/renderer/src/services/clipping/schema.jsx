import { z } from 'zod'

export const searchSchema = z.object({
  name: z.string().min(6, 'String must contain at least 6 character(s)')
})

export const ClipSchema = z
  .object({
    clipName: z
      .string()
      .min(1, 'Clip name is required')
      .max(100, 'Clip name must be 100 characters or less'),

    description: z
      .string()
      .min(1, 'Description is required')
      .max(500, 'Description must be 500 characters or less'),

    startTime: z.coerce
      .number({
        invalid_type_error: 'Start time must be a number',
        required_error: 'Start time is required'
      })
      .nonnegative('Start time cannot be negative'),

    endTime: z.coerce
      .number({
        invalid_type_error: 'End time must be a number',
        required_error: 'End time is required'
      })
      .nonnegative('End time cannot be negative'),

    format: z
      .string()
      .min(1, 'Format is required')
      .refine(
        (format) => ['mp4', 'mov', 'avi', 'mkv', 'webm'].includes(format.toLowerCase()),
        'Format must be one of: mp4, mov, avi, mkv, webm'
      ),

    tags: z
      .array(z.string())
      .min(1, 'At least one tag is required')
      .max(10, 'Maximum 10 tags allowed')
      .refine(
        (tags) => tags.every((tag) => /^[a-zA-Z0-9-]+$/.test(tag)),
        'Tags can only contain letters, numbers, and hyphens'
      )
      .refine(
        (tags) => tags.every((tag) => tag.length >= 2 && tag.length <= 50),
        'Each tag must be between 2 and 50 characters'
      )
  })
  .refine((data) => data.endTime > data.startTime, {
    message: 'End time must be greater than start time',
    path: ['endTime']
  })
  .refine((data) => data.endTime - data.startTime <= 3600, {
    message: 'Clip duration cannot exceed 1 hour',
    path: ['endTime']
  })
