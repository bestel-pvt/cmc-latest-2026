import { useState } from 'react'
import { format, formatDistanceToNow } from 'date-fns'
import { Copy, Check, Play, Tag, FileText, ChevronLeft, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { copyToClipboard, formatFileSize, getInitials } from '@/lib/utils'
import { useNavigate } from 'react-router-dom'
import { Avatar, AvatarFallback } from '../ui/avatar'
import { useQuery } from '@tanstack/react-query'
import { serverClip } from '@/services/clipping/clipApi'
import Loader from '../common/loader'
import { useApiUrl } from '@/hooks/use-config'

const ClipDetail = ({ clipData, isPending = false }) => {
  const { apiUrl, loading } = useApiUrl()
  const { data, isPending: clipIsPending } = useQuery({
    queryKey: ['clip-file', clipData?.id],
    queryFn: () => serverClip(clipData?.id),
    enabled: !!clipData?.id
  })

  console.log('Clip detail comp : ', clipData)

  const [copiedField, setCopiedField] = useState(null)
  const navigate = useNavigate()

  const handleCopy = (value, field) => {
    copyToClipboard(value, field)
    setCopiedField(field)
    setTimeout(() => setCopiedField(null), 1500)
  }

  const formatDuration = (start, end) => `${end - start} sec`

  if (isPending || loading) return <Loader name={'clip details'} />

  return (
    <div className="space-y-8">
      {/* Header */}

      {/* Main Card */}
      <Card>
        <CardHeader className="pb-4 border-b space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button onClick={() => navigate(-1)} size="icon" variant="outline">
                <ChevronLeft />
              </Button>
              <h4>Clip Details</h4>
            </div>
          </div>

          <div className="flex justify-between items-start">
            <div>
              <CardTitle>
                <h5>{clipData?.clipName}</h5>
              </CardTitle>
              <p className="text-muted-foreground">{clipData?.description}</p>
            </div>
            <Badge variant="success" className="capitalize">
              {clipData?.status}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-8">
          {/* Source Information (Channel + Connection) */}

          <video
            controls
            // src={buildFilePath(recording?.filePath)}
            src={`${apiUrl}/clips/${clipData?.id}/file`}
            className="w-full h-full aspect-auto rounded-xl"
            autoPlay={false}
          >
            Your browser does not support the video tag.
          </video>

          {/* <video
            controls
           
            className="w-full aspect-video rounded-xl"
          >
            Your browser does not support the video tag.
          </video> */}

          <Section title="Source Information" icon={<User />}>
            <div className="flex items-center gap-3 pb-4 border-b">
              <Avatar className="size-12">
                <AvatarFallback>{getInitials(clipData?.channelName)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{clipData?.channelName}</p>
                <p className="text-sm text-muted-foreground">Source Channel</p>
              </div>
            </div>

            <div className="space-y-3 pt-4">
              <CopyRow
                label="UDP Link"
                value={clipData?.channelStreamUrl}
                copied={copiedField === 'udpLink'}
                onCopy={() => handleCopy(clipData?.channelStreamUrl, 'udpLink')}
              />
              <InfoRow label="Source URL" value={clipData?.channelStreamUrl} />
            </div>
          </Section>

          {/* Clip Metadata (Info + Timeline + Tags) */}
          <Section title="Clip Metadata" icon={<FileText />}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <InfoRow
                  label="Duration"
                  value={formatDuration(clipData?.startTime, clipData?.endTime)}
                />
                <InfoRow label="Format" value={clipData?.format.toUpperCase()} />
                <InfoRow label="File Size" value={formatFileSize(clipData?.fileSize)} />
              </div>

              <div className="space-y-3">
                <InfoRow
                  label="Created"
                  value={format(new Date(clipData?.createdAt), 'MMM d, yyyy h:mm a')}
                />
                <InfoRow
                  label="Updated"
                  value={formatDistanceToNow(new Date(clipData?.updatedAt), {
                    addSuffix: true
                  })}
                />
              </div>
            </div>

            {/* Tags */}
            <div className="pt-4 border-t">
              <p className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2">
                <Tag className="size-4" /> Tags
              </p>
              <div className="flex flex-wrap gap-2">
                {clipData?.tags.map((tag, i) => (
                  <Badge key={i} variant="outline" className="px-3 py-0.5 text-sm">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </Section>

          {/* File Info (kept separate) */}
          <Section title="File Information">
            <CopyRow
              label="Clip File Name"
              value={clipData?.fileName}
              copied={copiedField === 'clipFileName'}
              onCopy={() => handleCopy(clipData?.fileName, 'clipFileName')}
            />
            <CopyRow
              label="Recording File Name"
              value={clipData?.recordingFileName}
              copied={copiedField === 'recordingFileName'}
              onCopy={() => handleCopy(clipData?.recordingFileName, 'recordingFileName')}
            />
            <CopyRow
              label="Clip ID"
              value={clipData?.id}
              copied={copiedField === 'clipId'}
              onCopy={() => handleCopy(clipData?.id, 'clipId')}
            />
          </Section>
        </CardContent>
      </Card>
    </div>
  )
}

/* ---------------- Reusable Components ---------------- */

const Section = ({ title, icon, children }) => (
  <div className="space-y-3">
    <h6 className=" font-semibold flex items-center gap-2 text-muted-foreground">
      {icon}
      {title}
    </h6>
    <div className="border rounded-lg p-4 space-y-4 bg-card">{children}</div>
  </div>
)

const InfoRow = ({ label, value }) => (
  <div className="flex justify-between text-sm">
    <span className="text-muted-foreground">{label}</span>
    <span className="font-medium">{value}</span>
  </div>
)

const CopyRow = ({ label, value, copied, onCopy }) => (
  <div className="flex justify-between items-center text-sm">
    <span className="text-muted-foreground">{label}</span>
    <div className="flex items-center max-w-[70%]">
      <span className="font-mono text-sm truncate mr-2" title={value}>
        {value}
      </span>
      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onCopy}>
        {copied ? <Check className="h-4 w-4 text-green-600" /> : <Copy />}
      </Button>
    </div>
  </div>
)

export default ClipDetail
