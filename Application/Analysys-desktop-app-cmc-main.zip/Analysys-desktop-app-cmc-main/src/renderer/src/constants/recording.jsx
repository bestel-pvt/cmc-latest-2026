import { Calendar, CalendarDays, Clock, Settings } from 'lucide-react'

export const VIDEO_EXPORT_FORMATS = [
  { value: 'mp4', label: 'MP4 (H.264)', extension: '.mp4' },
  { value: 'mkv', label: 'Matroska (MKV)', extension: '.mkv' }
  // { value: "h265", label: "H.265/HEVC", extension: ".mp4" },
  // { value: "mov", label: "QuickTime (MOV)", extension: ".mov" },
  // { value: "avi", label: "AVI", extension: ".avi" },
  // { value: "webm", label: "WebM", extension: ".webm" },
  // { value: "gif", label: "Animated GIF", extension: ".gif" },
  // { value: "prores", label: "ProRes", extension: ".mov" },
]

export const VIDEO_SPEED_OPTIONS = [
  { value: '0.25', label: '0.25x' },
  { value: '0.5', label: '0.5x' },
  { value: '0.75', label: '0.75x' },
  { value: '1', label: '1x (Normal)' },
  { value: '1.25', label: '1.25x' },
  { value: '1.5', label: '1.5x' },
  { value: '1.75', label: '1.75x' },
  { value: '2', label: '2x' }
]

export const RECORDING_STATUS = [
  { label: 'Recording', value: 'recording' },
  { label: 'Completed', value: 'completed' },
  { label: 'Failed', value: 'failed' },
  { label: 'Stopped', value: 'stopped' }
]

export const SCHEDULE_PRIORITY = [
  { label: 'Very Low', value: 1 },
  { label: 'Low', value: 2 },
  { label: 'Medium', value: 3 },
  { label: 'High', value: 4 },
  { label: 'Very High', value: 5 }
]

export const SCHEDULE_RECURRENCE_TYPE = [
  {
    label: 'Daily',
    value: 'daily',
    description: 'Repeats every day',
    icon: Clock
  },
  {
    label: 'Weekly',
    value: 'weekly',
    description: 'Repeats every week',
    icon: Calendar
  },
  {
    label: 'Monthly',
    value: 'monthly',
    description: 'Repeats every month',
    icon: CalendarDays
  },
  {
    label: 'Custom',
    value: 'custom',
    description: 'Custom recurrence pattern',
    icon: Settings
  }
]

export const SCHEDULE_STATUS = [
  { label: 'Scheduled', value: 'scheduled' },
  { label: 'Active', value: 'active' },
  { label: 'Completed', value: 'completed' },
  { label: 'Failed', value: 'failed' },
  { label: 'Cancelled', value: 'cancelled' }
]
