const express = require('express')
const {
    startStreaming,
    stopStreaming,
    getStreamingStatus,
    getActiveStreams,
    getAllChannelStreams
} = require('../controllers/streamingController.js')

const router = express.Router()

// Start streaming for a specific channel
router.post('/:channelId/start', startStreaming)

// Stop streaming for a specific channel
router.post('/:channelId/stop', stopStreaming)

// Get streaming status for a specific channel
router.get('/:channelId/status', getStreamingStatus)

// Get all active streams
router.get('/active', getActiveStreams)

// Get all channels with their streaming information
router.get('/channels', getAllChannelStreams)

module.exports = router
