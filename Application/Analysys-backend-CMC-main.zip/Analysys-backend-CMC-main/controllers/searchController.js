const { searchChannels, getAllChannels } = require('../services/searchService.js')

/**
 * Search for news channels by keyword
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const searchNews = async (req, res) => {
    try {
        const { q, limit = 10 } = req.query

        // If no query provided, return all channels
        if (!q) {
            const allChannels = await getAllChannels(parseInt(limit))
            return res.json({
                success: true,
                data: allChannels,
                total: allChannels.length,
                query: '',
                message: 'All available channels'
            })
        }

        // Search for channels matching the query
        const results = await searchChannels(q.trim(), parseInt(limit), req)

        res.json({
            success: true,
            data: results,
            total: results.length,
            query: q.trim(),
            message: results.length > 0
                ? `Found ${results.length} channel(s) matching "${q}"`
                : `No channels found matching "${q}"`
        })

    } catch (error) {
        console.error('Search error:', error)
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        })
    }
}

/**
 * Get all available news channels
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getAllNewsChannels = async (req, res) => {
    try {
        const { limit = 50 } = req.query
        const channels = await getAllChannels(parseInt(limit))

        res.json({
            success: true,
            data: channels,
            total: channels.length,
            message: 'All available news channels'
        })

    } catch (error) {
        console.error('Get all channels error:', error)
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        })
    }
}

/**
 * Get channel suggestions based on partial keyword
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const getChannelSuggestions = async (req, res) => {
    try {
        const { q, limit = 5 } = req.query

        if (!q) {
            return res.json({
                success: true,
                data: [],
                message: 'No query provided for suggestions'
            })
        }

        const suggestions = await searchChannels(q.trim(), parseInt(limit))

        res.json({
            success: true,
            data: suggestions.map(channel => ({
                id: channel.id,
                name: channel.name,
                displayName: channel.displayName
            })),
            total: suggestions.length,
            query: q.trim()
        })

    } catch (error) {
        console.error('Suggestions error:', error)
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        })
    }
}

module.exports = {
    searchNews,
    getAllNewsChannels,
    getChannelSuggestions
}
