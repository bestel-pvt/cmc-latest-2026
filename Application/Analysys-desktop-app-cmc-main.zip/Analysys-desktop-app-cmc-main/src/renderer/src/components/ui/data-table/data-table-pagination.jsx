import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'

const DataTablePagination = ({ pagination, onPageChange, onLimitChange }) => {
  const { page, totalPages, limit } = pagination

  return (
    <div className="flex items-center justify-between py-4">
      {/* Left side: Rows per page */}
      {/* <div className="flex items-center space-x-2">
                <p className="text-sm font-medium">Rows per page</p>
                <Select
                    value={String(limit)}
                    onValueChange={(value) => {
                        onLimitChange(Number(value));
                    }}
                >
                    <SelectTrigger className="h-8 w-[70px]">
                        <SelectValue placeholder={limit} />
                    </SelectTrigger>
                    <SelectContent side="top">
                        {[10, 20, 25, 30, 40, 50].map((size) => (
                            <SelectItem key={size} value={String(size)}>
                                {size}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div> */}

      {/* Middle: Page info */}
      <div className="text-sm text-muted-foreground">
        Page {page} of {totalPages}
      </div>

      {/* Right side: Pagination buttons */}
      <div className="flex items-center space-x-2">
        <Button variant="outline" size="icon" onClick={() => onPageChange(1)} disabled={page === 1}>
          <ChevronsLeft />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={() => onPageChange(page - 1)}
          disabled={page === 1}
        >
          <ChevronLeft />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={() => onPageChange(page + 1)}
          disabled={page === totalPages}
        >
          <ChevronRight />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={() => onPageChange(totalPages)}
          disabled={page === totalPages}
        >
          <ChevronsRight />
        </Button>
      </div>
    </div>
  )
}

export default DataTablePagination
