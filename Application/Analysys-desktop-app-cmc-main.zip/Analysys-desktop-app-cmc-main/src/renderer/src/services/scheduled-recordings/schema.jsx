import { z } from 'zod'

export const ScheduledRecordingSchema = z
  .object({
    channelId: z.string().min(1, 'Channel ID is required'),
    name: z
      .string()
      .min(1, 'Recording name is required')
      .max(255, 'Recording name cannot exceed 255 characters'),
    description: z
      .string()
      .max(1000, 'Description cannot exceed 1000 characters')
      .optional()
      .or(z.literal('')),
    scheduledStart: z.coerce.date({
      required_error: 'Scheduled start time is required',
      invalid_type_error: 'Scheduled start must be a valid date'
    }),
    scheduledEnd: z.coerce
      .date({
        invalid_type_error: 'Scheduled end must be a valid date'
      })
      .optional(),
    isRecurring: z.boolean().default(false),
    recurrenceType: z.enum(['daily', 'weekly', 'monthly', 'custom']).optional(),
    recurrenceRule: z.string().optional(),
    priority: z.coerce
      .number({
        invalid_type_error: 'Priority must be a number'
      })
      .int('Priority must be an integer')
      .min(1, 'Priority must be at least 1')
      .max(5, 'Priority cannot exceed 5')
      .default(1),
    notificationEnabled: z.boolean().default(true)
  })
  .superRefine((data, ctx) => {
    // ensure end > start
    if (data.scheduledEnd && data.scheduledEnd <= data.scheduledStart) {
      ctx.addIssue({
        code: 'custom',
        message: 'Scheduled end must be after scheduled start time',
        path: ['scheduledEnd']
      })
    }

    // recurrence validation - require type when recurring is true
    if (data.isRecurring && !data.recurrenceType) {
      ctx.addIssue({
        code: 'custom',
        message: 'Recurrence type is required when isRecurring is true',
        path: ['recurrenceType']
      })
    }

    // recurrence validation - require rule when type is custom
    if (data.recurrenceType === 'custom' && !data.recurrenceRule) {
      ctx.addIssue({
        code: 'custom',
        message: 'Recurrence rule is required when recurrence type is custom',
        path: ['recurrenceRule']
      })
    }

    // recurrence validation - forbid rule when type is not custom
    if (data.recurrenceType !== 'custom' && data.recurrenceRule) {
      ctx.addIssue({
        code: 'custom',
        message: 'Recurrence rule is only allowed when recurrence type is custom',
        path: ['recurrenceRule']
      })
    }

    // recurrence validation - forbid type when recurring is false
    if (!data.isRecurring && data.recurrenceType) {
      ctx.addIssue({
        code: 'custom',
        message: 'Recurrence type is only allowed when isRecurring is true',
        path: ['recurrenceType']
      })
    }
  })
