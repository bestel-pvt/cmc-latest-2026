import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  Area,
  AreaChart
} from 'recharts'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '../ui/button'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '../ui/chart'
import { Info } from 'lucide-react'
import { Badge } from '../ui/badge'
import { chartConfig } from '@/lib/chart-config'
import { formatNumberShort, getHoursSince } from '@/lib/utils'
import { Skeleton } from '../ui/skeleton'

const DashboardCharts = ({ data, isPending = false }) => {
  if (isPending) {
    return <Skeleton className="h-96 w-full" />
  }

  const uptimeData = data?.map((item, index) => ({
    name:
      item.channel.name.length > 15
        ? item.channel.name.substring(0, 12) + '...'
        : item.channel.name,
    fullName: item.channel.name,
    uptime: item.totalUptime,
    downtime: item.totalDowntime,
    uptimePercentage:
      item.totalUptime + item.totalDowntime > 0
        ? ((item.totalUptime / (item.totalUptime + item.totalDowntime)) * 100).toFixed(2)
        : 0,
    index
  }))

  const performanceData = data?.map((item, index) => ({
    name: item.channel.name,
    packetsPerSec: item.avgPacketsPerSec,
    bytesPerSec: item.avgBytesPerSec / 1024,
    switchCount: item.switchCount,
    isPriority: item.channel.isPriority,
    index
  }))

  const timelineData = data?.map((item, index) => ({
    name:
      item.channel.name.length > 12
        ? item.channel.name.substring(0, 10) + '...'
        : item.channel.name,
    fullName: item.channel.name,
    createdAt: getHoursSince(item.createdAt),
    lastUpdated: getHoursSince(item.updatedAt),
    isOnline: !item.streamStoppedAt,
    index
  }))

  const dataTransferChart = data?.map((item, index) => ({
    name:
      item.channel.name.length > 12
        ? item.channel.name.substring(0, 10) + '...'
        : item.channel.name,
    fullName: item.channel.name,
    packets: parseInt(item.totalPackets),
    bytes: parseInt(item.totalBytes) / (1024 * 1024),
    packetsPerSec: item.avgPacketsPerSec,
    bytesPerSec: item.avgBytesPerSec / 1024,
    index
  }))

  const statusData = [
    {
      name: 'Online',
      value: data?.filter((item) => !item.streamStoppedAt).length,
      fill: 'var(--chart-1)'
    },
    {
      name: 'Offline',
      value: data?.filter((item) => item.streamStoppedAt).length,
      fill: 'var(--chart-2)'
    }
  ]

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
      {/* Uptime vs Downtime Chart */}
      <Card className="col-span-1">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>
              <h6>Channel Uptime Analysis</h6>
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs ">
                <p className="text-sm">
                  This chart compares uptime vs downtime for each channel in seconds. Higher uptime
                  indicates better channel reliability and stability. Channels with high downtime
                  may need infrastructure improvements.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription>
            Compares uptime vs downtime for each channel to identify reliability issues
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer height={'100%'} width={'100%'}>
            <ChartContainer config={chartConfig} className="min-h-[300px]">
              <BarChart data={uptimeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                  height={80}
                />
                <YAxis
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => formatNumberShort(value)}
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      formatter={(value, name) => [
                        typeof value === 'number' ? value.toLocaleString() : value,
                        name === 'uptime' ? ' Uptime (sec)' : ' Downtime (sec)'
                      ]}
                      labelFormatter={(label) => {
                        const item = uptimeData.find((d) => d.name === label)
                        return (
                          <div className="space-y-1">
                            <p className="font-medium">{item?.fullName || label}</p>
                            <p className="text-xs text-muted-foreground">
                              Uptime Percentage: {item?.uptimePercentage}%
                            </p>
                          </div>
                        )
                      }}
                    />
                  }
                />
                <Bar dataKey="uptime" fill="var(--chart-5)" name="uptime" />
                <Bar dataKey="downtime" fill="var(--chart-4)" name="downtime" />
              </BarChart>
            </ChartContainer>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Channel Status Distribution */}
      <Card className="col-span-1">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>
              <h6>Channel Status Distribution</h6>
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="text-sm">
                  Real-time status overview of all streaming channels. Online channels are actively
                  streaming content, while offline channels may require attention or maintenance.
                  Aim for maximum online channels.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription>
            Real-time status of all streaming channels (online vs offline)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer height={'100%'} width={'100%'}>
            <ChartContainer config={chartConfig} className="min-h-[300px]">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value, percent }) =>
                    `${name}: ${value} (${(percent * 100).toFixed(0)}%)`
                  }
                  outerRadius={100}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <ChartTooltip
                  indicator="line"
                  content={
                    <ChartTooltipContent
                      formatter={(value, name) => [`${value} Channel(s) `, name]}
                    />
                  }
                />
              </PieChart>
            </ChartContainer>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Data Transfer Volume */}
      <Card className="col-span-1">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>
              <h6>Data Transfer Volume</h6>
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="text-sm">
                  Shows total data transferred by each channel in megabytes. Higher values indicate
                  more active streaming or higher quality content. Use this to monitor bandwidth
                  usage and content delivery performance.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription>Total data transferred by each channel in megabytes</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer height={'100%'} width={'100%'}>
            <ChartContainer config={chartConfig} className="min-h-[300px]">
              <BarChart data={dataTransferChart}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                  height={80}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      formatter={(value) => [`${value.toFixed(2)} MB`, 'Data Transfer']}
                      labelFormatter={(label) => {
                        const item = dataTransferChart.find((d) => d.name === label)
                        return (
                          <div className="space-y-1">
                            <p className="font-medium">{item?.fullName || label}</p>
                            <p className="text-xs text-muted-foreground">
                              Total Packets: {item?.packets.toLocaleString()}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Avg Rate: {item?.bytesPerSec.toFixed(1)} KB/s
                            </p>
                          </div>
                        )
                      }}
                    />
                  }
                />
                <Bar dataKey="bytes" fill="var(--color-bytes)" />
              </BarChart>
            </ChartContainer>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Performance Scatter Chart */}
      <Card className="">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>
              <h6>Performance Correlation</h6>
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="text-sm">
                  Scatter plot showing the relationship between packet rate (x-axis) and data
                  throughput (y-axis). Points in the upper-right indicate better performance. Use
                  this to identify high-performing vs problematic channels.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription>Relationship between packet rate and data throughput</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer height={'100%'} width={'100%'}>
            <ChartContainer config={chartConfig} className="min-h-[300px]">
              <ScatterChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="packetsPerSec" name="Packets/sec" tick={{ fontSize: 12 }} />
                <YAxis dataKey="bytesPerSec" name="KB/sec" tick={{ fontSize: 12 }} />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      formatter={(value, name) => [
                        value,
                        name === 'packetsPerSec' ? 'Packets/sec' : 'KB/sec'
                      ]}
                      labelFormatter={(_, payload) => {
                        if (payload && payload.length > 0) {
                          const data = payload[0].payload
                          return (
                            <div className="space-y-1">
                              <p className="font-medium">{data.name}</p>
                              <p className="text-xs text-muted-foreground">
                                Switch Count: {data.switchCount}
                              </p>
                              {data.isPriority && (
                                <Badge variant="secondary" className="text-xs">
                                  Priority Channel
                                </Badge>
                              )}
                            </div>
                          )
                        }
                        return null
                      }}
                    />
                  }
                />
                <Scatter dataKey="bytesPerSec" fill="var(--color-performance)" />
              </ScatterChart>
            </ChartContainer>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Timeline Chart */}
      <Card className="col-span-1 lg:col-span-2">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CardTitle>
              <h6>Channel Activity Timeline</h6>
            </CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost">
                  {' '}
                  <Info />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p className="text-sm">
                  Shows when channels were created and last updated (hours ago). This timeline helps
                  identify recent channel activity and maintenance patterns. Lower values indicate
                  more recent activity.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription>Channel creation and last update timeline (hours ago)</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer height={'100%'} width={'100%'}>
            <ChartContainer config={chartConfig} className="min-h-[350px]">
              <AreaChart data={timelineData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                  height={100}
                />
                <YAxis
                  tick={{ fontSize: 12 }}
                  label={{
                    value: 'Hours Ago',
                    angle: -90,
                    position: 'insideLeft'
                  }}
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      formatter={(value, name) => [
                        `${value} hours ago`,
                        name === 'createdAt' ? 'Created' : 'Last Updated'
                      ]}
                      labelFormatter={(label) => {
                        const item = timelineData.find((d) => d.name === label)
                        return (
                          <div className="space-y-1">
                            <p className="font-medium">{item?.fullName || label}</p>
                            <p className="text-xs text-muted-foreground">
                              Status: {item?.isOnline ? 'Online' : 'Offline'}
                            </p>
                          </div>
                        )
                      }}
                    />
                  }
                />
                <Area
                  type="monotone"
                  dataKey="createdAt"
                  stroke="var(--color-timeline)"
                  fill="var(--color-timeline)"
                  fillOpacity={0.3}
                  name="createdAt"
                />
                <Area
                  type="monotone"
                  dataKey="lastUpdated"
                  stroke="var(--chart-2)"
                  fill="var(--chart-2)"
                  fillOpacity={0.3}
                  name="lastUpdated"
                />
              </AreaChart>
            </ChartContainer>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}

export default DashboardCharts
