
const fs = require('fs-extra')
const path = require('path')
const { spawn } = require('child_process')
const queries = require('../queries')
const { generateUdpLink, generateRecordingFileName } = require('../utils/helpers.js')
const metricsService = require('./metricsService.js')
const { recordingsDir, ffmpegStatic, streamsDir } = require('../utils/path.js')
const { ProcessStateQueries } = require('../queries')


// Store active recording processes
const activeRecordings = new Map()

class RecordingService {
    constructor() {
        this.recordingsDir = recordingsDir
        this.processStates = new Map() // Store process state IDs
        this.ensureRecordingsDirectory()
        this.recoverActiveRecordings() // Recover recordings on startup
    }

    // Helper method to convert relative path to absolute path
    getAbsolutePath(relativePath) {
        if (path.isAbsolute(relativePath)) {
            return relativePath // Already absolute (backward compatibility)
        }
        return path.join(recordingsDir, '..', relativePath)
    }

    async ensureRecordingsDirectory() {
        try {
            await fs.ensureDir(this.recordingsDir)
        } catch (error) {
            console.error('Failed to create recordings directory:', error)
            throw new Error('Failed to initialize recordings directory')
        }
    }

    // Recover active recordings after system restart
    async recoverActiveRecordings() {
        try {
            console.log('🔄 Checking for active recordings to recover...')

            const activeStates = ProcessStateQueries.getActiveProcessStates()
            const recordingStates = activeStates.filter(state => state.processType === 'recording')

            if (recordingStates.length === 0) {
                console.log('✅ No active recordings to recover')
                return
            }

            console.log(`🎥 Found ${recordingStates.length} active recordings to recover`)

            for (const state of recordingStates) {
                try {
                    console.log(`🔄 Recovering recording for channel ${state.channelId}...`)

                    // Get channel details
                    const channel = await queries.ChannelQueries.getChannelById(state.channelId)

                    if (!channel || !channel.isActive) {
                        console.log(`⚠️ Channel ${state.channelId} is not active, marking state as stopped`)
                        ProcessStateQueries.updateProcessState(state.id, { status: 'stopped' })

                        // Update recording status if exists
                        if (state.recordingId) {
                            await queries.RecordingQueries.updateRecording(state.recordingId, {
                                status: 'failed',
                                endTime: new Date().toISOString()
                            })
                        }
                        continue
                    }

                    // Restart the recording
                    await this.startRecording(state.channelId)
                    console.log(`✅ Successfully recovered recording for channel ${state.channelId}`)

                } catch (error) {
                    console.error(`❌ Failed to recover recording for channel ${state.channelId}:`, error.message)
                    // Mark as failed in database
                    ProcessStateQueries.updateProcessState(state.id, { status: 'failed' })

                    // Update recording status if exists
                    if (state.recordingId) {
                        try {
                            await queries.RecordingQueries.updateRecording(state.recordingId, {
                                status: 'failed',
                                endTime: new Date().toISOString()
                            })
                        } catch (recError) {
                            console.error(`Failed to update recording ${state.recordingId}:`, recError)
                        }
                    }
                }
            }

            console.log('✅ Recording recovery process completed')
        } catch (error) {
            console.error('❌ Error during recording recovery:', error)
        }
    }

    async validateUdpStream(ip, port, timeoutMs = 5000) {
        return new Promise((resolve) => {
            console.log(`Validating UDP stream at ${ip}:${port}`)

            // Quick validation: Try to probe the UDP stream using multicast subscription
            const probeArgs = [
                '-f', 'mpegts',
                '-i', `udp://${ip}:${port}?timeout=5000000`,
                '-t', '1', // Only analyze for 1 second
                '-f', 'null',
                '-'
            ]

            const probeProcess = spawn(ffmpegStatic, probeArgs, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            let streamFound = false
            const timeout = setTimeout(() => {
                if (!probeProcess.killed) {
                    probeProcess.kill('SIGTERM')
                }
                resolve({
                    valid: streamFound,
                    message: streamFound ? 'Stream detected' : 'Validation timeout - stream may still be valid'
                })
            }, timeoutMs)

            probeProcess.stderr.on('data', (data) => {
                const output = data.toString()
                if (output.includes('Stream #') || output.includes('Input #') || output.includes('Video:') || output.includes('Audio:')) {
                    streamFound = true
                    console.log(`UDP stream validation: Stream detected at ${ip}:${port}`)
                }
            })

            probeProcess.on('exit', (code) => {
                clearTimeout(timeout)
                resolve({
                    valid: streamFound || code === 0,
                    message: streamFound ? 'Stream validated successfully' : 'No stream detected'
                })
            })

            probeProcess.on('error', (error) => {
                clearTimeout(timeout)
                console.warn(`Stream validation error for ${ip}:${port}:`, error.message)
                resolve({
                    valid: false,
                    message: 'Validation failed - but recording may still work'
                })
            })
        })
    }

    async startRecording(channelId) {
        try {
            // Check if channel is already being recorded
            if (activeRecordings.has(channelId)) {
                throw new Error('Channel is already being recorded')
            }

            // Get channel with primary source
            const channel = await queries.ChannelQueries.getChannelById(channelId)

            if (!channel) {
                throw new Error('Channel not found')
            }

            if (!channel.isActive) {
                throw new Error('Channel is not active')
            }

            const primarySource = channel.sources && channel.sources.length > 0 ? channel.sources.find(source => source.isPrimary) : null
            if (!primarySource) {
                throw new Error('No primary source found for this channel')
            }

            // Check if streaming is active for this channel
            const streamingService = require('./streamingService.js')
            const isStreaming = streamingService.hasActiveStream(channelId)

            // Generate UDP link from primary source
            const udpLink = generateUdpLink(primarySource.ip, primarySource.port)
            console.log(`Generated UDP link: ${udpLink}`)

            // Generate unique filename
            const fileName = generateRecordingFileName(channel.name, channel.id)
            const absoluteFilePath = path.join(this.recordingsDir, fileName)
            // Store relative path in database for portability
            const relativeFilePath = path.join('data', 'recordings', fileName)

            // Create recording record in database
            const recording = await queries.RecordingQueries.createRecording({
                channelId: channel.id,
                fileName,
                filePath: relativeFilePath,
                sourceIp: primarySource.ip,
                sourcePort: primarySource.port,
                udpLink,
                status: 'recording',
                isActive: true // Set recording as active
            })

            let ffmpegProcess

            // ALWAYS try direct UDP recording first for better reliability
            // UDP multicast allows multiple clients (streaming + recording) simultaneously
            console.log(`Attempting direct UDP recording for channel ${channelId}`)

            // Validate the UDP stream before starting recording
            const validation = await this.validateUdpStream(primarySource.ip, primarySource.port)
            console.log(`Stream validation result: ${validation.message}`)

            try {
                ffmpegProcess = this.createDirectUdpRecordingProcess(udpLink, absoluteFilePath, recording.id)
                console.log(`Using direct UDP recording for channel ${channelId}`)
            } catch (udpError) {
                console.log(`Direct UDP recording failed: ${udpError.message}`)

                if (isStreaming) {
                    // Fallback to HLS only if UDP fails AND streaming is active
                    console.log(`Falling back to HLS-to-MP4 recording for channel ${channelId}`)
                    ffmpegProcess = this.createHlsRecordingProcess(channelId, absoluteFilePath, recording.id)
                } else {
                    throw udpError
                }
            }

            // Persist process state to database for recovery
            const processState = ProcessStateQueries.createProcessState({
                channelId: channel.id,
                processType: 'recording',
                status: 'active',
                recordingId: recording.id,
                udpLink: udpLink,
                startTime: new Date().toISOString(),
                metadata: {
                    channelName: channel.name,
                    fileName: fileName,
                    sourceIp: primarySource.ip,
                    sourcePort: primarySource.port,
                    method: ffmpegProcess === undefined ? 'hls' : 'udp'
                }
            })

            // Store the active recording
            activeRecordings.set(channelId, {
                recordingId: recording.id,
                process: ffmpegProcess,
                startTime: new Date(),
                method: ffmpegProcess === undefined ? 'hls' : 'udp',
                stateId: processState.id
            })

            // Store state ID for later cleanup
            this.processStates.set(channelId, processState.id)

            // Update metrics service
            metricsService.updateActiveRecordings(activeRecordings.size)

            return {
                success: true,
                recordingId: recording.id,
                message: 'Recording started successfully',
                data: {
                    channelId: channel.id,
                    channelName: channel.name,
                    udpLink,
                    fileName,
                    status: 'recording',
                    method: ffmpegProcess === undefined ? 'hls' : 'udp'
                }
            }

        } catch (error) {
            console.error('Start recording error:', error)
            throw error
        }
    }

    // Create HLS-to-MP4 recording process (when streaming is active)
    createHlsRecordingProcess(channelId, outputPath, recordingId) {
        console.log(`Starting continuous HLS-to-MP4 recording for channel ${channelId}`)

        const streamsDir = path.join(streamsDir, 'streams')
        const playlistPath = path.join(streamsDir, `stream_${channelId}.m3u8`)

        console.log(`Reading HLS playlist from: ${playlistPath}`)

        // Wait for playlist to be created and have segments
        const waitForPlaylist = () => {
            return new Promise((resolve, reject) => {
                let attempts = 0
                const maxAttempts = 30 // 30 seconds

                const checkInterval = setInterval(() => {
                    attempts++

                    if (fs.existsSync(playlistPath)) {
                        try {
                            const playlistContent = fs.readFileSync(playlistPath, 'utf8')
                            if (playlistContent.includes('.ts')) {
                                clearInterval(checkInterval)
                                console.log(`HLS playlist ready for recording ${recordingId}`)
                                resolve()
                                return
                            }
                        } catch (error) {
                            console.log(`Playlist check attempt ${attempts}: ${error.message}`)
                        }
                    }

                    if (attempts >= maxAttempts) {
                        clearInterval(checkInterval)
                        reject(new Error('HLS playlist not ready after 30 seconds'))
                    }
                }, 1000)
            })
        }

        return waitForPlaylist().then(() => {
            // FFmpeg command to continuously read from HLS playlist
            // Key improvements for longer recordings and better handling
            const ffmpegArgs = [
                // Input handling for live HLS
                '-re', // Read at native frame rate
                '-f', 'hls',
                '-live_start_index', '0', // Start from beginning of live playlist
                '-i', playlistPath,

                // Improved stream handling
                '-fflags', '+genpts+discardcorrupt+igndts+flush_packets',
                '-avoid_negative_ts', 'make_zero',
                '-copyts', // Copy timestamps to maintain continuity
                '-start_at_zero',

                // Codec settings
                '-c:v', 'copy',
                '-c:a', 'copy',

                // Output format settings for continuous recording
                '-f', 'mp4',
                '-movflags', '+faststart+frag_keyframe+empty_moov+default_base_moof',
                '-max_muxing_queue_size', '8192',
                '-max_interleave_delta', '0',

                // Timeout settings
                '-timeout', '30000000', // 30 seconds timeout
                '-reconnect', '1',
                '-reconnect_streamed', '1',
                '-reconnect_delay_max', '5',

                '-y', // Overwrite output file if it exists
                outputPath
            ]

            console.log(`FFmpeg HLS recording command: ${ffmpegStatic} ${ffmpegArgs.join(' ')}`)

            // Spawn FFmpeg process
            const ffmpegProcess = spawn(ffmpegStatic, ffmpegArgs, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            // Track recording start
            let recordingStarted = false
            let lastProgressTime = 0
            let progressTimeout = null

            // Handle stdout for progress information
            ffmpegProcess.stdout.on('data', (data) => {
                const output = data.toString()
                if (output.includes('frame=') && !recordingStarted) {
                    recordingStarted = true
                    console.log(`HLS recording ${recordingId} started successfully`)
                }
            })

            // Handle stderr for progress and error information
            ffmpegProcess.stderr.on('data', (data) => {
                const output = data.toString()

                // Log important progress information
                if (output.includes('frame=') || output.includes('time=')) {
                    const timeMatch = output.match(/time=(\d{2}:\d{2}:\d{2}.\d{2})/)
                    if (timeMatch) {
                        const currentTimeStr = timeMatch[1]
                        const [hours, minutes, seconds] = currentTimeStr.split(':')
                        const totalSeconds = parseInt(hours) * 3600 + parseInt(minutes) * 60 + parseFloat(seconds)

                        // Log progress every 30 seconds
                        if (totalSeconds - lastProgressTime >= 30) {
                            console.log(`HLS recording ${recordingId} progress: ${currentTimeStr}`)
                            lastProgressTime = totalSeconds
                        }
                    }

                    if (!recordingStarted) {
                        recordingStarted = true
                        console.log(`HLS recording ${recordingId} started successfully`)
                    }
                }

                // Log connection and stream information
                if (output.includes('Opening') || output.includes('Input')) {
                    console.log(`HLS recording ${recordingId} info: ${output.trim()}`)
                }

                // Handle specific HLS issues gracefully
                if (output.includes('No such file or directory') && output.includes('.ts')) {
                    console.log(`HLS recording ${recordingId}: Segment file not found - normal for live HLS`)
                } else if (output.includes('error') && !output.includes('Last message repeated')) {
                    console.warn(`HLS recording ${recordingId} error: ${output.trim()}`)
                }
            })

            // Handle process exit
            ffmpegProcess.on('exit', async (code, signal) => {
                if (progressTimeout) {
                    clearTimeout(progressTimeout)
                }

                console.log(`HLS recording ${recordingId} process exited with code ${code}, signal: ${signal}`)

                if (code === 0) {
                    console.log(`HLS recording ${recordingId} completed successfully`)
                    await this.handleRecordingEnd(recordingId, outputPath, 'completed')
                } else if (signal === 'SIGTERM' || signal === 'SIGINT') {
                    console.log(`HLS recording ${recordingId} was stopped by user`)
                    await this.handleRecordingEnd(recordingId, outputPath, 'stopped')
                } else {
                    console.error(`HLS recording ${recordingId} failed with exit code ${code}`)
                    await this.handleRecordingEnd(recordingId, outputPath, 'failed')
                }
            })

            // Handle process errors
            ffmpegProcess.on('error', async (error) => {
                console.error(`HLS recording ${recordingId} process error:`, error)
                await this.handleRecordingEnd(recordingId, outputPath, 'failed')
            })

            // Set a longer timeout for HLS recording
            progressTimeout = setTimeout(() => {
                if (!recordingStarted) {
                    console.log(`HLS recording ${recordingId} didn't start within timeout, marking as failed`)
                    ffmpegProcess.kill('SIGTERM')
                }
            }, 60000) // 60 second timeout for HLS

            return ffmpegProcess
        }).catch(error => {
            console.error(`Failed to start HLS recording for ${recordingId}:`, error)
            throw error
        })
    }

    // Create direct UDP recording process (when no streaming is active)

    // Create direct UDP recording process (when no streaming is active)
    createDirectUdpRecordingProcess(udpLink, outputPath, recordingId) {
        console.log(`Starting UDP stream recording as multicast client: ${udpLink}`)

        // Extract IP and port from UDP link
        const urlMatch = udpLink.match(/udp:\/\/([^:]+):(\d+)/)
        if (!urlMatch) {
            throw new Error(`Invalid UDP link format: ${udpLink}`)
        }

        const [, ip, port] = urlMatch

        // Create the FFmpeg command for multicast client recording
        // Use multicast subscription approach to avoid port binding conflicts
        // This allows multiple FFmpeg processes to receive the same multicast stream
        const ffmpegArgs = [
            '-f', 'mpegts',
            // Use pure multicast client mode - no port binding
            '-i', `udp://${ip}:${port}?fifo_size=1000000&overrun_nonfatal=1`,
            '-analyzeduration', '2000000',
            '-probesize', '5000000',
            '-fflags', '+genpts+discardcorrupt',
            '-avoid_negative_ts', 'make_zero',
            '-c:v', 'copy',
            '-c:a', 'copy',
            '-f', 'mp4',
            '-movflags', '+faststart+frag_keyframe',
            '-max_muxing_queue_size', '2048',
            '-y', // Overwrite output file if it exists
            outputPath
        ]

        console.log(`FFmpeg command: ${ffmpegStatic} ${ffmpegArgs.join(' ')}`)

        // Spawn FFmpeg process
        const ffmpegProcess = spawn(ffmpegStatic, ffmpegArgs, {
            stdio: ['pipe', 'pipe', 'pipe'],
            windowsHide: true
        })

        // Track recording start
        let recordingStarted = false
        let progressTimeout = null

        // Handle stdout for progress information
        ffmpegProcess.stdout.on('data', (data) => {
            const output = data.toString()
            // FFmpeg progress info usually goes to stderr, but capture stdout too
            if (output.includes('frame=') && !recordingStarted) {
                recordingStarted = true
                console.log(`Recording ${recordingId} started successfully`)
            }
        })

        // Handle stderr for progress and error information
        ffmpegProcess.stderr.on('data', (data) => {
            const output = data.toString()

            // Log important progress information
            if (output.includes('frame=') || output.includes('time=')) {
                const timeMatch = output.match(/time=(\d{2}:\d{2}:\d{2}.\d{2})/);
                if (timeMatch) {
                    console.log(`Recording ${recordingId} progress: ${timeMatch[1]}`)
                }

                if (!recordingStarted) {
                    recordingStarted = true
                    console.log(`UDP multicast recording ${recordingId} started successfully`)
                }
            }

            // Log connection and stream information
            if (output.includes('Opening') || output.includes('Stream') || output.includes('Input')) {
                console.log(`Recording ${recordingId} info: ${output.trim()}`)
            }

            // Log errors but don't necessarily fail on warnings
            if (output.includes('error') || output.includes('Error') || output.includes('ERROR')) {
                console.warn(`Recording ${recordingId} warning/error: ${output.trim()}`)
            }
        })

        // Handle process exit
        ffmpegProcess.on('exit', async (code, signal) => {
            if (progressTimeout) {
                clearTimeout(progressTimeout)
            }

            console.log(`Recording ${recordingId} process exited with code ${code}, signal: ${signal}`)

            // Wait a bit for FFmpeg to fully flush and close the file
            // This prevents 0-byte file issues
            await new Promise(resolve => setTimeout(resolve, 2000))

            if (code === 0) {
                console.log(`Recording ${recordingId} completed successfully`)
                await this.handleRecordingEnd(recordingId, outputPath, 'completed')
            } else if (signal === 'SIGTERM' || signal === 'SIGINT') {
                console.log(`Recording ${recordingId} was stopped by user`)
                await this.handleRecordingEnd(recordingId, outputPath, 'stopped')
            } else {
                console.error(`Recording ${recordingId} failed with exit code ${code}`)

                // Try alternative approach if the main one fails
                if (!recordingStarted) {
                    console.log(`Primary method failed, trying alternative approach for ${recordingId}`)
                    this.tryAlternativeUdpApproach(ip, port, outputPath, recordingId)
                    return // Don't mark as failed yet
                }

                await this.handleRecordingEnd(recordingId, outputPath, 'failed')
            }
        })

        // Handle process errors
        ffmpegProcess.on('error', async (error) => {
            console.error(`Recording ${recordingId} process error:`, error)

            if (!recordingStarted) {
                console.log(`Process error occurred, trying alternative approach for ${recordingId}`)
                this.tryAlternativeUdpApproach(ip, port, outputPath, recordingId)
                return // Don't mark as failed yet
            }

            await this.handleRecordingEnd(recordingId, outputPath, 'failed')
        })

        // Set a timeout to detect if recording never starts
        progressTimeout = setTimeout(() => {
            if (!recordingStarted) {
                console.log(`Recording ${recordingId} didn't start within timeout, trying alternative`)
                ffmpegProcess.kill('SIGTERM')
                this.tryAlternativeUdpApproach(ip, port, outputPath, recordingId)
            }
        }, 15000) // 15 second timeout

        return ffmpegProcess
    }

    async tryAlternativeUdpApproach(ip, port, outputPath, recordingId) {
        try {
            console.log(`Trying alternative UDP multicast approach for ${recordingId}`)

            // Alternative approach: Use different multicast subscription parameters
            // Remove all port binding parameters to allow pure multicast subscription
            const altArgs = [
                '-f', 'mpegts',
                '-i', `udp://${ip}:${port}?fifo_size=2000000&overrun_nonfatal=1`,
                '-thread_queue_size', '4096',
                '-analyzeduration', '3000000',
                '-probesize', '10000000',
                '-fflags', '+genpts+discardcorrupt+nobuffer',
                '-flags', 'low_delay',
                '-avoid_negative_ts', 'make_zero',
                '-c:v', 'copy',
                '-c:a', 'copy',
                '-f', 'mp4',
                '-movflags', '+faststart+frag_keyframe+empty_moov',
                '-max_muxing_queue_size', '4096',
                '-y',
                outputPath.replace('.mp4', '_alt.mp4')
            ]

            console.log(`Alternative FFmpeg: ${ffmpegStatic} ${altArgs.join(' ')}`)

            const altProcess = spawn(ffmpegStatic, altArgs, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            let altStarted = false

            altProcess.stderr.on('data', (data) => {
                const output = data.toString()

                if (output.includes('frame=') || output.includes('time=')) {
                    if (!altStarted) {
                        altStarted = true
                        console.log(`Alternative recording ${recordingId} started successfully`)
                    }

                    const timeMatch = output.match(/time=(\d{2}:\d{2}:\d{2}.\d{2})/);
                    if (timeMatch) {
                        console.log(`Alternative recording ${recordingId} progress: ${timeMatch[1]}`)
                    }
                }

                if (output.includes('Opening') || output.includes('Stream')) {
                    console.log(`Alternative ${recordingId} info: ${output.trim()}`)
                }
            })

            altProcess.on('exit', async (code, signal) => {
                if (code === 0) {
                    console.log(`Alternative recording ${recordingId} completed`)
                    await this.handleRecordingEnd(recordingId, outputPath.replace('.mp4', '_alt.mp4'), 'completed')
                } else if (signal === 'SIGTERM' || signal === 'SIGINT') {
                    await this.handleRecordingEnd(recordingId, outputPath.replace('.mp4', '_alt.mp4'), 'stopped')
                } else {
                    console.log(`Alternative also failed, trying final fallback for ${recordingId}`)
                    this.tryPipeApproach(ip, port, outputPath, recordingId)
                }
            })

            altProcess.on('error', (error) => {
                console.error(`Alternative process error for ${recordingId}:`, error)
                this.tryPipeApproach(ip, port, outputPath, recordingId)
            })

            // Store the alternative process in activeRecordings
            const channelId = this.findChannelIdByRecordingId(recordingId)
            if (channelId) {
                const recording = activeRecordings.get(channelId)
                if (recording) {
                    recording.process = altProcess
                }
            }

        } catch (error) {
            console.error(`Alternative approach setup failed for ${recordingId}:`, error)
            this.tryPipeApproach(ip, port, outputPath, recordingId)
        }
    }

    async tryPipeApproach(ip, port, outputPath, recordingId) {
        try {
            console.log(`Trying final multicast client approach for ${recordingId}`)

            // Final approach: Simplest multicast subscription with minimal parameters
            // This maintains multicast client behavior while avoiding all socket binding options
            const basicArgs = [
                '-f', 'mpegts',
                '-i', `udp://${ip}:${port}`,
                '-t', '3600', // Max 1 hour recording to prevent runaway
                '-c', 'copy',
                '-f', 'mp4',
                '-movflags', '+faststart',
                '-y',
                outputPath.replace('.mp4', '_basic.mp4')
            ]

            console.log(`Basic FFmpeg: ${ffmpegStatic} ${basicArgs.join(' ')}`)

            const basicProcess = spawn(ffmpegStatic, basicArgs, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            let basicStarted = false

            basicProcess.stderr.on('data', (data) => {
                const output = data.toString()

                if (output.includes('frame=')) {
                    if (!basicStarted) {
                        basicStarted = true
                        console.log(`Basic recording ${recordingId} started`)
                    }
                }
            })

            basicProcess.on('exit', async (code, signal) => {
                if (code === 0 || signal === 'SIGTERM') {
                    const status = signal === 'SIGTERM' ? 'stopped' : 'completed'
                    await this.handleRecordingEnd(recordingId, outputPath.replace('.mp4', '_basic.mp4'), status)
                } else {
                    console.error(`All recording methods failed for ${recordingId}`)
                    await this.handleRecordingEnd(recordingId, outputPath, 'failed')
                }
            })

            basicProcess.on('error', async (error) => {
                console.error(`Basic approach failed for ${recordingId}:`, error)
                await this.handleRecordingEnd(recordingId, outputPath, 'failed')
            })

            // Store the basic process
            const channelId = this.findChannelIdByRecordingId(recordingId)
            if (channelId) {
                const recording = activeRecordings.get(channelId)
                if (recording) {
                    recording.process = basicProcess
                }
            }

        } catch (error) {
            console.error(`Final approach setup failed for ${recordingId}:`, error)
            await this.handleRecordingEnd(recordingId, outputPath, 'failed')
        }
    }

    // Get media duration (in seconds) by probing the file with ffmpeg and parsing the Duration line
    getMediaDuration(filePath, timeoutMs = 5000) {
        return new Promise((resolve) => {
            try {
                const args = ['-i', filePath]
                const proc = spawn(ffmpegStatic, args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true })

                let stderr = ''

                proc.stderr.on('data', (data) => {
                    stderr += data.toString()
                })

                const timer = setTimeout(() => {
                    try {
                        proc.kill('SIGTERM')
                    } catch (e) { }
                    // Try to parse whatever we have
                    const match = stderr.match(/Duration:\s*(\d{2}:\d{2}:\d{2}\.\d+)/)
                    if (match) {
                        const parts = match[1].split(':')
                        const hours = parseInt(parts[0], 10)
                        const minutes = parseInt(parts[1], 10)
                        const seconds = parseFloat(parts[2])
                        const total = Math.round(hours * 3600 + minutes * 60 + seconds)
                        resolve(total)
                    } else {
                        resolve(null)
                    }
                }, timeoutMs)

                proc.on('exit', (code) => {
                    clearTimeout(timer)
                    const match = stderr.match(/Duration:\s*(\d{2}:\d{2}:\d{2}\.\d+)/)
                    if (match) {
                        const parts = match[1].split(':')
                        const hours = parseInt(parts[0], 10)
                        const minutes = parseInt(parts[1], 10)
                        const seconds = parseFloat(parts[2])
                        const total = Math.round(hours * 3600 + minutes * 60 + seconds)
                        resolve(total)
                    } else {
                        resolve(null)
                    }
                })

                proc.on('error', (err) => {
                    clearTimeout(timer)
                    resolve(null)
                })
            } catch (err) {
                resolve(null)
            }
        })
    }

    findChannelIdByRecordingId(recordingId) {
        for (const [channelId, recording] of activeRecordings.entries()) {
            if (recording.recordingId === recordingId) {
                return channelId
            }
        }
        return null
    }

    async handleRecordingEnd(recordingId, absoluteFilePath, status) {
        try {
            // Update recording status in database
            let fileSize = 0
            let duration = null

            // If the file exists on disk (regardless of status), try to read its size
            try {
                const absPath = path.isAbsolute(absoluteFilePath) ? absoluteFilePath : this.getAbsolutePath(absoluteFilePath)
                if (await fs.pathExists(absPath)) {
                    const stats = await fs.stat(absPath)
                    fileSize = stats.size
                }
            } catch (fsErr) {
                console.warn(`Could not determine file size for recording ${recordingId}: ${fsErr.message}`)
            }

            // Determine endTime and duration (use DB startTime if available)
            const endTimeISO = new Date().toISOString()

            try {
                const existing = queries.RecordingQueries.getRecordingById(recordingId)
                if (existing && existing.startTime) {
                    const start = new Date(existing.startTime)
                    const end = new Date(endTimeISO)
                    const diffMs = end - start
                    if (!Number.isNaN(diffMs) && diffMs >= 0) {
                        // Duration in seconds (rounded)
                        duration = Math.round(diffMs / 1000)
                    }
                }
            } catch (qErr) {
                console.warn(`Could not compute duration for recording ${recordingId}: ${qErr.message}`)
            }

            // If duration is still null, try to probe the media file with ffmpeg to get an accurate duration
            if ((duration === null || duration === 0) && fileSize > 0) {
                try {
                    const absPath = path.isAbsolute(absoluteFilePath) ? absoluteFilePath : this.getAbsolutePath(absoluteFilePath)
                    const probed = await this.getMediaDuration(absPath, 5000)
                    if (probed !== null) {
                        duration = probed
                    }
                } catch (probeErr) {
                    console.warn(`FFmpeg probe failed for recording ${recordingId}: ${probeErr.message}`)
                }
            }

            const updatedRecording = queries.RecordingQueries.updateRecording(recordingId, {
                status,
                endTime: endTimeISO,
                fileSize,
                duration,
                isActive: false // Set recording as inactive when it ends
            })

            // Find and remove from active recordings
            for (const [channelId, recording] of activeRecordings.entries()) {
                if (recording.recordingId === recordingId) {
                    // Update process state in database
                    if (recording.stateId) {
                        try {
                            ProcessStateQueries.updateProcessState(recording.stateId, {
                                status: status === 'completed' ? 'stopped' : 'failed'
                            })
                        } catch (error) {
                            console.error(`Failed to update process state for recording ${recordingId}:`, error)
                        }
                    }

                    activeRecordings.delete(channelId)
                    this.processStates.delete(channelId)
                    break
                }
            }

            // Update metrics service
            metricsService.updateActiveRecordings(activeRecordings.size)

            console.log(`Recording ${recordingId} ended with status: ${status}`)

        } catch (error) {
            console.error(`Failed to handle recording end for ${recordingId}:`, error)
        }
    }

    async stopRecording(channelId) {
        try {
            const activeRecording = activeRecordings.get(channelId)

            if (!activeRecording) {
                throw new Error('No active recording found for this channel')
            }

            // Update process state in database
            if (activeRecording.stateId) {
                try {
                    ProcessStateQueries.updateProcessState(activeRecording.stateId, {
                        status: 'stopped'
                    })
                } catch (error) {
                    console.error(`Failed to update process state for channel ${channelId}:`, error)
                }
            }

            // Kill the FFmpeg process gracefully
            if (activeRecording.process) {
                console.log(`Stopping recording ${activeRecording.recordingId} for channel ${channelId}`)

                // Send SIGTERM for graceful shutdown
                activeRecording.process.kill('SIGTERM')

                // Fallback: Force kill after 5 seconds if process doesn't respond
                setTimeout(() => {
                    if (activeRecording.process && !activeRecording.process.killed) {
                        console.log(`Force killing recording ${activeRecording.recordingId}`)
                        activeRecording.process.kill('SIGKILL')
                    }
                }, 5000)
            }

            // Update database - the handleRecordingEnd will be called by the process exit handler
            // But we can update the status immediately to indicate stop was requested
            queries.RecordingQueries.updateRecording(activeRecording.recordingId, {
                status: 'stopping',
                isActive: false // Set as inactive when stop is requested
            })

            // Update metrics immediately
            activeRecordings.delete(channelId)
            metricsService.updateActiveRecordings(activeRecordings.size)

            return {
                success: true,
                recordingId: activeRecording.recordingId,
                message: 'Recording stop requested successfully'
            }

        } catch (error) {
            console.error('Stop recording error:', error)
            throw error
        }
    }

    async getRecordingStatus(channelId) {
        try {
            const activeRecording = activeRecordings.get(channelId)

            if (!activeRecording) {
                return {
                    isRecording: false,
                    message: 'No active recording found for this channel'
                }
            }

            // Get recording details from database
            const recording = queries.RecordingQueries.getRecordingById(activeRecording.recordingId)

            return {
                isRecording: true,
                recordingId: recording.id,
                channelName: recording.channel.name,
                startTime: recording.startTime,
                duration: Math.floor((new Date() - new Date(recording.startTime)) / 1000),
                status: recording.status,
                fileName: recording.fileName,
                udpLink: recording.udpLink
            }

        } catch (error) {
            console.error('Get recording status error:', error)
            throw error
        }
    }

    async getChannelRecordings(channelId) {
        try {
            const recordings = queries.RecordingQueries.getRecordingsByChannelId(channelId)

            return recordings.map(recording => ({
                id: recording.id,
                fileName: recording.fileName,
                status: recording.status,
                startTime: recording.startTime,
                endTime: recording.endTime,
                duration: recording.duration,
                fileSize: recording.fileSize,
                channelName: recording.channel?.name || '',
                udpLink: recording.udpLink
            }))

        } catch (error) {
            console.error('Get channel recordings error:', error)
            throw error
        }
    }

    getActiveRecordings() {
        const active = []
        for (const [channelId, recording] of activeRecordings.entries()) {
            active.push({
                channelId,
                recordingId: recording.recordingId,
                startTime: recording.startTime
            })
        }
        return active
    }

    async getAllRecordings() {
        try {
            const recordings = queries.RecordingQueries.getRecordings({})

            return recordings.data.map(recording => ({
                id: recording.id,
                channelId: recording.channelId,
                channelName: recording.channel?.name || '',
                fileName: recording.fileName,
                filePath: recording.filePath,
                status: recording.status,
                startTime: recording.startTime,
                endTime: recording.endTime,
                duration: recording.duration,
                fileSize: recording.fileSize,
                sourceIp: recording.sourceIp,
                sourcePort: recording.sourcePort,
                udpLink: recording.udpLink,
                createdAt: recording.createdAt,
                updatedAt: recording.updatedAt
            }))
        } catch (error) {
            console.error('Get all recordings error:', error)
            throw error
        }
    }

    async getRecordingById(recordingId) {
        try {
            const recording = queries.RecordingQueries.getRecordingById(recordingId)

            if (!recording) {
                return null
            }

            return {
                id: recording.id,
                channelId: recording.channelId,
                channelName: recording.channel?.name || '',
                fileName: recording.fileName,
                filePath: recording.filePath,
                status: recording.status,
                startTime: recording.startTime,
                endTime: recording.endTime,
                duration: recording.duration,
                fileSize: recording.fileSize,
                sourceIp: recording.sourceIp,
                sourcePort: recording.sourcePort,
                udpLink: recording.udpLink,
                createdAt: recording.createdAt,
                updatedAt: recording.updatedAt
            }
        } catch (error) {
            console.error('Get recording by ID error:', error)
            throw error
        }
    }

    async deleteRecording(recordingId) {
        try {
            // Get the recording first to check if it exists and get file path
            const recording = queries.RecordingQueries.getRecordingById(recordingId)

            if (!recording) {
                throw new Error('Recording not found')
            }

            // Check if this recording is currently active
            for (const [channelId, activeRecording] of activeRecordings.entries()) {
                if (activeRecording.recordingId === recordingId) {
                    throw new Error('Cannot delete an active recording. Stop the recording first.')
                }
            }

            // Delete the file if it exists
            try {
                const absolutePath = this.getAbsolutePath(recording.filePath)
                if (await fs.pathExists(absolutePath)) {
                    await fs.remove(absolutePath)
                    console.log(`Deleted recording file: ${absolutePath}`)
                }
            } catch (fileError) {
                console.warn('Could not delete recording file:', fileError.message)
                // Continue with database deletion even if file deletion fails
            }

            // Delete from database
            queries.RecordingQueries.deleteRecording(recordingId)

            return {
                success: true,
                message: 'Recording deleted successfully',
                recordingId: recordingId
            }

        } catch (error) {
            console.error('Delete recording error:', error)
            throw error
        }
    }

    hasActiveRecording(channelId) {
        return activeRecordings.has(channelId)
    }
}

module.exports = new RecordingService()
