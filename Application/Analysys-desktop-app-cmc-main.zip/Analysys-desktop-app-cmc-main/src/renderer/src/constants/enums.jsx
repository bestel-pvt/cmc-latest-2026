export const sources = [
  { label: 'PTCL', value: 'ptcl' },
  { label: 'Satellite', value: 'satellite' },
  { label: 'Nayatel', value: 'nayatel' }
]

export const sourceValues = sources.map((source) => source.value)
