const scheduledRecordingService = require('../services/scheduledRecordingService.js')
const {
    createScheduledRecordingSchema,
    updateScheduledRecordingSchema,
    scheduledRecordingQuerySchema,
    conflictResolutionSchema,
    idSchema
} = require('../utils/validation.js')

// Helper function to format validation errors
const formatValidationError = (error) => {
    const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
    }))
    return {
        error: 'Validation failed',
        details: errors
    }
}

// Create a new scheduled recording
const createScheduledRecording = async (req, res) => {
    try {
        const { error, value } = createScheduledRecordingSchema.validate(req.body)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const scheduledRecording = await scheduledRecordingService.createScheduledRecording(value)

        res.status(201).json({
            success: true,
            data: scheduledRecording,
            message: 'Scheduled recording created successfully'
        })
    } catch (error) {
        console.error('Create scheduled recording error:', error)

        let statusCode = 500
        if (error.message.includes('Channel not found')) {
            statusCode = 404
        } else if (error.message.includes('not found')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to create scheduled recording'
        })
    }
}

// Get all scheduled recordings with filtering and pagination
const getScheduledRecordings = async (req, res) => {
    try {
        const { error, value } = scheduledRecordingQuerySchema.validate(req.query)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const result = await scheduledRecordingService.getAllScheduledRecordings(value)

        res.json({
            success: true,
            data: result.scheduledRecordings,
            pagination: result.pagination,
            filters: value
        })
    } catch (error) {
        console.error('Get scheduled recordings error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get scheduled recordings'
        })
    }
}

// Get scheduled recording by ID
const getScheduledRecordingById = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const scheduledRecording = await scheduledRecordingService.getScheduledRecordingById(id)

        res.json({
            success: true,
            data: scheduledRecording
        })
    } catch (error) {
        console.error('Get scheduled recording by ID error:', error)

        let statusCode = 500
        if (error.message.includes('not found')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to get scheduled recording'
        })
    }
}

// Update scheduled recording
const updateScheduledRecording = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.id)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const { error: bodyError, value } = updateScheduledRecordingSchema.validate(req.body)
        if (bodyError) {
            return res.status(400).json(formatValidationError(bodyError))
        }

        const { id } = req.params
        const scheduledRecording = await scheduledRecordingService.updateScheduledRecording(id, value)

        res.json({
            success: true,
            data: scheduledRecording,
            message: 'Scheduled recording updated successfully'
        })
    } catch (error) {
        console.error('Update scheduled recording error:', error)

        let statusCode = 500
        if (error.message.includes('not found')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to update scheduled recording'
        })
    }
}

// Delete scheduled recording
const deleteScheduledRecording = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const result = await scheduledRecordingService.deleteScheduledRecording(id)

        res.json({
            success: true,
            message: result.message
        })
    } catch (error) {
        console.error('Delete scheduled recording error:', error)

        let statusCode = 500
        if (error.message.includes('not found')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to delete scheduled recording'
        })
    }
}

// Get upcoming scheduled recordings (next 24 hours)
const getUpcomingRecordings = async (req, res) => {
    try {
        const now = new Date()
        const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000)

        const result = await scheduledRecordingService.getAllScheduledRecordings({
            dateFrom: now,
            dateTo: tomorrow,
            status: 'scheduled',
            sortBy: 'scheduledStart',
            sortOrder: 'asc',
            limit: 50
        })

        res.json({
            success: true,
            data: result.scheduledRecordings,
            count: result.scheduledRecordings.length,
            message: 'Upcoming recordings for next 24 hours'
        })
    } catch (error) {
        console.error('Get upcoming recordings error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get upcoming recordings'
        })
    }
}

// Get active scheduled recordings (currently running)
const getActiveScheduledRecordings = async (req, res) => {
    try {
        const result = await scheduledRecordingService.getAllScheduledRecordings({
            status: 'active',
            sortBy: 'scheduledStart',
            sortOrder: 'desc',
            limit: 50
        })

        res.json({
            success: true,
            data: result.scheduledRecordings,
            count: result.scheduledRecordings.length,
            message: 'Currently active scheduled recordings'
        })
    } catch (error) {
        console.error('Get active scheduled recordings error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get active scheduled recordings'
        })
    }
}

// Get scheduled recordings for a specific channel
const getChannelScheduledRecordings = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.channelId)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const { error: queryError, value } = scheduledRecordingQuerySchema.validate(req.query)
        if (queryError) {
            return res.status(400).json(formatValidationError(queryError))
        }

        const { channelId } = req.params
        const result = await scheduledRecordingService.getAllScheduledRecordings({
            ...value,
            channelId
        })

        res.json({
            success: true,
            channelId,
            data: result.scheduledRecordings,
            pagination: result.pagination,
            filters: { ...value, channelId }
        })
    } catch (error) {
        console.error('Get channel scheduled recordings error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get channel scheduled recordings'
        })
    }
}

// Cancel a scheduled recording
const cancelScheduledRecording = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.id)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { id } = req.params
        const scheduledRecording = await scheduledRecordingService.updateScheduledRecording(id, {
            status: 'cancelled',
            isActive: false
        })

        res.json({
            success: true,
            data: scheduledRecording,
            message: 'Scheduled recording cancelled successfully'
        })
    } catch (error) {
        console.error('Cancel scheduled recording error:', error)

        let statusCode = 500
        if (error.message.includes('not found')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to cancel scheduled recording'
        })
    }
}

// Get recording conflicts
const getConflicts = async (req, res) => {
    try {
        const { page = 1, limit = 10, isResolved } = req.query

        const filters = {
            page: parseInt(page),
            limit: parseInt(limit)
        }

        if (isResolved !== undefined) {
            filters.isResolved = isResolved === 'true'
        }

        const result = await scheduledRecordingService.getConflicts(filters)

        res.json({
            success: true,
            data: result.conflicts,
            pagination: result.pagination,
            filters
        })
    } catch (error) {
        console.error('Get conflicts error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get conflicts'
        })
    }
}

// Resolve a recording conflict
const resolveConflict = async (req, res) => {
    try {
        const { error: idError } = idSchema.validate(req.params.id)
        if (idError) {
            return res.status(400).json(formatValidationError(idError))
        }

        const { error: bodyError, value } = conflictResolutionSchema.validate(req.body)
        if (bodyError) {
            return res.status(400).json(formatValidationError(bodyError))
        }

        const { id } = req.params
        const { resolution, winningScheduleId } = value

        const result = await scheduledRecordingService.resolveConflict(id, resolution, winningScheduleId)

        res.json({
            success: true,
            message: result.message
        })
    } catch (error) {
        console.error('Resolve conflict error:', error)

        let statusCode = 500
        if (error.message.includes('not found')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to resolve conflict'
        })
    }
}

// Get schedule statistics/dashboard data
const getScheduleStats = async (req, res) => {
    try {
        const now = new Date()
        const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000)
        const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)

        const [
            totalScheduled,
            activeRecordings,
            upcomingToday,
            upcomingWeek,
            conflicts,
            recentExecutions
        ] = await Promise.all([
            scheduledRecordingService.getAllScheduledRecordings({
                isActive: true,
                limit: 1
            }),
            scheduledRecordingService.getAllScheduledRecordings({
                status: 'active',
                limit: 1
            }),
            scheduledRecordingService.getAllScheduledRecordings({
                dateFrom: now,
                dateTo: tomorrow,
                status: 'scheduled',
                limit: 1
            }),
            scheduledRecordingService.getAllScheduledRecordings({
                dateFrom: now,
                dateTo: weekFromNow,
                status: 'scheduled',
                limit: 1
            }),
            scheduledRecordingService.getConflicts({
                isResolved: false,
                limit: 1
            }),
            scheduledRecordingService.getAllScheduledRecordings({
                sortBy: 'updatedAt',
                sortOrder: 'desc',
                limit: 5
            })
        ])

        res.json({
            success: true,
            data: {
                totalScheduled: totalScheduled.pagination.total,
                activeRecordings: activeRecordings.pagination.total,
                upcomingToday: upcomingToday.pagination.total,
                upcomingWeek: upcomingWeek.pagination.total,
                unresolvedConflicts: conflicts.pagination.total,
                recentExecutions: recentExecutions.scheduledRecordings.slice(0, 5)
            }
        })
    } catch (error) {
        console.error('Get schedule stats error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get schedule statistics'
        })
    }
}

module.exports = {
    createScheduledRecording,
    getScheduledRecordings,
    getScheduledRecordingById,
    updateScheduledRecording,
    deleteScheduledRecording,
    getUpcomingRecordings,
    getActiveScheduledRecordings,
    getChannelScheduledRecordings,
    cancelScheduledRecording,
    getConflicts,
    resolveConflict,
    getScheduleStats
}
