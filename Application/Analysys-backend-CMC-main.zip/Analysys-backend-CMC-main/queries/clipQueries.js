const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')

class ClipQueries {
    // Get all clips with pagination and filtering
    static getClips({ page = 1, pageSize = 10, recordingId, status, search = '' }) {
        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        if (recordingId) {
            whereClauses.push('c.recordingId = :recordingId')
            params.recordingId = recordingId
        }

        if (status) {
            whereClauses.push('c.status = :status')
            params.status = status
        }

        if (search && search.trim() !== '') {
            whereClauses.push('(c.clipName LIKE :search OR c.description LIKE :search OR c.tags LIKE :search)')
            params.search = `%${search}%`
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Get total count
        const countQuery = `
            SELECT COUNT(*) as count 
            FROM clips c
            LEFT JOIN recordings r ON c.recordingId = r.id
            LEFT JOIN channels ch ON r.channelId = ch.id
            ${whereClause}
        `
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Calculate pagination
        const take = parseInt(pageSize, 10) || 10
        const skip = (parseInt(page, 10) - 1) * take

        // Get clips with recording and channel info
        const query = `
            SELECT 
                c.*,
                r.fileName as recordingFileName,
                r.channelId,
                r.filePath as recordingFilePath,
                r.fileSize as recordingFileSize,
                r.duration as recordingDuration,
                r.status as recordingStatus,
                r.createdAt as recordingCreatedAt,
                ch.name as channelName,
                ch.description as channelDescription,
                ch.logo as channelLogo,
                ch.channelStreamLink as channelStreamUrl,
                ch.isActive as channelIsActive
            FROM clips c
            LEFT JOIN recordings r ON c.recordingId = r.id
            LEFT JOIN channels ch ON r.channelId = ch.id
            ${whereClause}
            ORDER BY c.createdAt DESC
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        const rows = db.prepare(query).all(params)

        const clips = rows.map(row => ({
            ...row,
            recording: {
                id: row.recordingId,
                fileName: row.recordingFileName,
                filePath: row.recordingFilePath,
                fileSize: row.recordingFileSize,
                duration: row.recordingDuration,
                status: row.recordingStatus,
                createdAt: row.recordingCreatedAt,
                channelId: row.channelId,
                channel: {
                    id: row.channelId,
                    name: row.channelName,
                    description: row.channelDescription,
                    logo: row.channelLogo,
                    streamUrl: row.channelStreamUrl,
                    isActive: Boolean(row.channelIsActive)
                }
            }
        }))

        return {
            data: serializeBigInt(clips),
            pagination: {
                total: totalCount,
                page: parseInt(page, 10),
                pageSize: take,
                totalPages: Math.ceil(totalCount / take)
            }
        }
    }

    // Get clip by ID
    static getClipById(id) {
        const query = `
            SELECT 
                c.*,
                r.fileName as recordingFileName,
                r.channelId,
                r.filePath as recordingFilePath,
                r.fileSize as recordingFileSize,
                r.duration as recordingDuration,
                r.status as recordingStatus,
                r.createdAt as recordingCreatedAt,
                ch.name as channelName,
                ch.description as channelDescription,
                ch.logo as channelLogo,
                ch.channelStreamLink as channelStreamUrl,
                ch.isActive as channelIsActive
            FROM clips c
            LEFT JOIN recordings r ON c.recordingId = r.id
            LEFT JOIN channels ch ON r.channelId = ch.id
            WHERE c.id = ?
        `

        const row = db.prepare(query).get(id)
        if (!row) return null

        return serializeBigInt({
            ...row,
            recording: {
                id: row.recordingId,
                fileName: row.recordingFileName,
                filePath: row.recordingFilePath,
                fileSize: row.recordingFileSize,
                duration: row.recordingDuration,
                status: row.recordingStatus,
                createdAt: row.recordingCreatedAt,
                channelId: row.channelId,
                channel: {
                    id: row.channelId,
                    name: row.channelName,
                    description: row.channelDescription,
                    logo: row.channelLogo,
                    streamUrl: row.channelStreamUrl,
                    isActive: Boolean(row.channelIsActive)
                }
            }
        })
    }

    // Get clips by recording ID
    static getClipsByRecordingId(recordingId) {
        const query = `
            SELECT c.*
            FROM clips c
            WHERE c.recordingId = ?
            ORDER BY c.startTime ASC
        `

        const rows = db.prepare(query).all(recordingId)

        return serializeBigInt(rows)
    }

    // Create a new clip
    static createClip(clipData) {
        const {
            recordingId,
            clipName,
            description,
            startTime,
            endTime,
            duration,
            format,
            fileName,
            filePath,
            fileSize,
            tags,
            status = 'processing'
        } = clipData

        // Get current timestamp in ISO format
        const now = new Date().toISOString()

        const insertClip = db.prepare(`
            INSERT INTO clips (
                id, recordingId, clipName, description, startTime, endTime,
                duration, format, fileName, filePath, fileSize, tags,
                status, createdAt, updatedAt
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)

        // Generate CUID-like ID
        const clipId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)

        insertClip.run(
            clipId,
            recordingId,
            clipName,
            description,
            startTime,
            endTime,
            duration,
            format,
            fileName,
            filePath,
            fileSize,
            tags, // Already a JSON string
            status,
            now, // createdAt
            now  // updatedAt
        )

        return this.getClipById(clipId)
    }

    // Update clip
    static updateClip(id, updates) {
        const allowedFields = [
            'clipName', 'description', 'startTime', 'endTime', 'duration',
            'format', 'fileName', 'filePath', 'fileSize', 'tags', 'status'
        ]
        const setClauses = []
        const params = { id }

        allowedFields.forEach(field => {
            if (updates[field] !== undefined) {
                setClauses.push(`${field} = :${field}`)
                params[field] = updates[field]
            }
        })

        if (setClauses.length === 0) {
            throw new DatabaseError('No valid fields to update')
        }

        // Get current timestamp in ISO format
        const now = new Date().toISOString()
        setClauses.push('updatedAt = :updatedAt')
        params.updatedAt = now

        const query = `UPDATE clips SET ${setClauses.join(', ')} WHERE id = :id`
        const result = db.prepare(query).run(params)

        if (result.changes === 0) {
            throw new DatabaseError('Clip not found', 'P2025')
        }

        return this.getClipById(id)
    }

    // Delete clip
    static deleteClip(id) {
        const result = db.prepare('DELETE FROM clips WHERE id = ?').run(id)

        if (result.changes === 0) {
            throw new DatabaseError('Clip not found', 'P2025')
        }

        return { success: true }
    }

    // Find unique clip
    static findUniqueClip(where) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            whereClauses.push(`${key} = :${key}`)
            params[key] = where[key]
        })

        const whereClause = `WHERE ${whereClauses.join(' AND ')}`
        const query = `SELECT * FROM clips ${whereClause} LIMIT 1`

        const row = db.prepare(query).get(params)
        if (!row) return null

        return serializeBigInt(row)
    }

    // Get clip count
    static getClipCount(where = {}) {
        let whereClauses = []
        let params = {}

        if (where.recordingId) {
            whereClauses.push('recordingId = :recordingId')
            params.recordingId = where.recordingId
        }

        if (where.status) {
            whereClauses.push('status = :status')
            params.status = where.status
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''
        const query = `SELECT COUNT(*) as count FROM clips ${whereClause}`

        return db.prepare(query).get(params)?.count || 0
    }

    // Group clips by a field (for metrics)
    static groupClipsBy(field, where = {}) {
        // Validate field to prevent SQL injection
        const allowedFields = ['status', 'format', 'recordingId', 'createdAt']
        if (!allowedFields.includes(field)) {
            throw new Error(`Invalid field: ${field}`)
        }

        let whereClauses = []
        let params = {}

        // Build WHERE clause
        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                whereClauses.push(`${key} = :${key}`)
                params[key] = where[key]
            }
        })

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        const query = `
            SELECT ${field}, COUNT(*) as _count, SUM(duration) as _sum
            FROM clips
            ${whereClause}
            GROUP BY ${field}
            ORDER BY _count DESC
        `

        const rows = db.prepare(query).all(params)

        return serializeBigInt(rows)
    }

    // Get clips within date range
    static getClipsInRange(startDate, endDate, where = {}) {
        let whereClauses = ['c.createdAt BETWEEN :startDate AND :endDate']
        let params = { startDate, endDate }

        // Add additional where conditions
        Object.keys(where).forEach(key => {
            whereClauses.push(`c.${key} = :${key}`)
            params[key] = where[key]
        })

        const whereClause = `WHERE ${whereClauses.join(' AND ')}`

        const query = `
            SELECT c.*
            FROM clips c
            ${whereClause}
            ORDER BY c.createdAt DESC
        `

        const rows = db.prepare(query).all(params)

        return serializeBigInt(rows)
    }

    // Get clip aggregates (for metrics)
    static getClipAggregates(where = {}) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                whereClauses.push(`${key} = :${key}`)
                params[key] = where[key]
            }
        })

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        const query = `
            SELECT 
                COUNT(*) as _count,
                SUM(duration) as _sum,
                AVG(duration) as _avg,
                MIN(duration) as _min,
                MAX(duration) as _max
            FROM clips
            ${whereClause}
        `

        const result = db.prepare(query).get(params)

        return serializeBigInt(result)
    }

    // Find clips for search functionality
    static findClipsMany(options = {}) {
        const {
            where = {},
            include = {},
            skip = 0,
            take = 10,
            orderBy = { createdAt: 'desc' }
        } = options

        let whereClauses = []
        let params = {}
        let joins = []

        // Build WHERE clauses
        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                if (key === 'OR' && Array.isArray(where[key])) {
                    // Handle OR conditions for search
                    const orClauses = where[key].map((condition, index) => {
                        const orClause = Object.keys(condition).map(field => {
                            // Validate field to prevent SQL injection
                            const allowedFields = ['clipName', 'description', 'tags', 'status', 'recordingId']
                            if (allowedFields.includes(field) && condition[field].contains) {
                                const paramKey = `or_${index}_${field}`
                                params[paramKey] = `%${condition[field].contains}%`
                                return `c.${field} LIKE :${paramKey}`
                            }
                            return null
                        }).filter(Boolean)
                        return orClause.length > 0 ? `(${orClause.join(' OR ')})` : null
                    }).filter(Boolean)

                    if (orClauses.length > 0) {
                        whereClauses.push(`(${orClauses.join(' OR ')})`)
                    }
                } else if (key === 'createdAtFrom') {
                    whereClauses.push('c.createdAt >= :createdAtFrom')
                    params.createdAtFrom = where[key].toISOString()
                } else if (key === 'createdAtTo') {
                    whereClauses.push('c.createdAt <= :createdAtTo')
                    params.createdAtTo = where[key].toISOString()
                } else if (key === 'search') {
                    // General search in clipName and description
                    whereClauses.push('(c.clipName LIKE :search OR c.description LIKE :search)')
                    params.search = `%${where[key]}%`
                } else if (key === 'channelName') {
                    // Channel name filter
                    whereClauses.push('ch.name LIKE :channelName')
                    params.channelName = `%${where[key]}%`
                } else if (key === 'tags') {
                    // Tags filter (partial match)
                    whereClauses.push('c.tags LIKE :tags')
                    params.tags = `%${where[key]}%`
                } else {
                    // Validate key to prevent SQL injection
                    const allowedKeys = ['clipName', 'description', 'status', 'recordingId', 'format', 'createdAt']
                    if (allowedKeys.includes(key)) {
                        whereClauses.push(`c.${key} = :${key}`)
                        params[key] = where[key]
                    }
                }
            }
        })

        // Handle includes
        if (include.recording || where.channelName) {
            joins.push('LEFT JOIN recordings r ON c.recordingId = r.id')
            if ((include.recording && include.recording.include && include.recording.include.channel) || where.channelName) {
                joins.push('LEFT JOIN channels ch ON r.channelId = ch.id')
            }
        }

        const joinClause = joins.join(' ')
        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Build ORDER BY
        let orderByClause = 'ORDER BY c.createdAt DESC'
        if (orderBy) {
            const orderField = Object.keys(orderBy)[0]
            // Validate order field to prevent SQL injection
            const allowedOrderFields = ['clipName', 'createdAt', 'startTime', 'endTime', 'status', 'duration', 'fileSize']
            if (allowedOrderFields.includes(orderField)) {
                const orderDirection = orderBy[orderField].toUpperCase()
                orderByClause = `ORDER BY c.${orderField} ${orderDirection}`
            }
        }

        const query = `
            SELECT
                c.*
                ${include.recording || where.channelName ? ', r.fileName as recordingFileName, r.channelId, r.filePath as recordingFilePath, r.fileSize as recordingFileSize, r.duration as recordingDuration, r.status as recordingStatus, r.createdAt as recordingCreatedAt' : ''}
                ${(include.recording && include.recording.include && include.recording.include.channel) || where.channelName ? ', ch.name as channelName, ch.description as channelDescription, ch.logo as channelLogo, ch.channelStreamLink as channelStreamUrl, ch.isActive as channelIsActive' : ''}
            FROM clips c
            ${joinClause}
            ${whereClause}
            ${orderByClause}
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        // Get total count
        const countQuery = `
            SELECT COUNT(*) as count
            FROM clips c
            ${joinClause}
            ${whereClause}
        `
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        const rows = db.prepare(query).all(params)

        const clips = rows.map(row => {
            const clip = { ...row }
            if (include.recording || where.channelName) {
                clip.recording = {
                    id: row.recordingId,
                    fileName: row.recordingFileName,
                    filePath: row.recordingFilePath,
                    fileSize: row.recordingFileSize,
                    duration: row.recordingDuration,
                    status: row.recordingStatus,
                    createdAt: row.recordingCreatedAt,
                    channelId: row.channelId
                }
                if ((include.recording && include.recording.include && include.recording.include.channel) || where.channelName) {
                    clip.recording.channel = {
                        id: row.channelId,
                        name: row.channelName,
                        description: row.channelDescription,
                        logo: row.channelLogo,
                        streamUrl: row.channelStreamUrl,
                        isActive: Boolean(row.channelIsActive)
                    }
                }
            }
            return clip
        })

        return {
            clips: serializeBigInt(clips),
            total: totalCount
        }
    }
}

module.exports = ClipQueries
