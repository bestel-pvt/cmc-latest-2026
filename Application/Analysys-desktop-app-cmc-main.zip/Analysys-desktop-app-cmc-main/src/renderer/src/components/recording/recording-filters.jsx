import { format } from 'date-fns'
import { CalendarIcon, Search, X, Filter } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'
import { useDebounce } from 'react-haiku'
import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { RECORDING_STATUS, VIDEO_EXPORT_FORMATS } from '@/constants/recording'
import TimeInput from '../ui/time-input'

const RecordingFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [openFilter, setOpenFilter] = useState(false)

  // Filter states
  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    status: searchParams.get('status') || '',
    format: searchParams.get('format') || '',
    channelId: searchParams.get('channelId') || '',
    channelName: searchParams.get('channelName') || '',
    fileName: searchParams.get('fileName') || '',
    sourceIp: searchParams.get('sourceIp') || '',
    sourcePort: searchParams.get('sourcePort') || '',
    dateFrom: searchParams.get('dateFrom') || '',
    dateTo: searchParams.get('dateTo') || '',
    startTimeFrom: searchParams.get('startTimeFrom') || '',
    startTimeTo: searchParams.get('startTimeTo') || '',
    endTimeFrom: searchParams.get('endTimeFrom') || '',
    endTimeTo: searchParams.get('endTimeTo') || '',
    minFileSize: searchParams.get('minFileSize') || '',
    maxFileSize: searchParams.get('maxFileSize') || '',
    minDuration: searchParams.get('minDuration') || '',
    maxDuration: searchParams.get('maxDuration') || ''
  })

  // Debounced filters
  const debouncedFilters = useDebounce(filters, 1000)

  // Date states for calendar pickers
  const [dateFromCalendar, setDateFromCalendar] = useState(
    filters.dateFrom ? new Date(filters.dateFrom) : undefined
  )
  const [dateToCalendar, setDateToCalendar] = useState(
    filters.dateTo ? new Date(filters.dateTo) : undefined
  )

  // Update URL when debounced filters change
  useEffect(() => {
    const params = new URLSearchParams(searchParams)

    Object.entries(debouncedFilters).forEach(([key, value]) => {
      if (value && value.trim() !== '') {
        params.set(key, value)
      } else {
        params.delete(key)
      }
    })

    // Reset page to 1 when filters change
    if (params.toString() !== searchParams.toString()) {
      params.set('page', '1')
      setSearchParams(params, { replace: true })
    }
  }, [debouncedFilters, searchParams, setSearchParams])

  // Handle filter changes
  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value
    }))
  }

  // Handle date changes
  const handleDateChange = (key, date, setCalendarState) => {
    const dateValue = date ? format(date, 'yyyy-MM-dd') : ''
    setCalendarState(date)
    handleFilterChange(key, dateValue)
  }

  // Handle time changes
  const handleTimeChange = (key, value) => {
    // Validate time format (HH:mm)
    if (value === '' || /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(value)) {
      handleFilterChange(key, value)
    }
  }

  // Check if any filters are active
  const hasActiveFilters = useMemo(() => {
    return Object.values(filters).some((value) => value && value.trim() !== '')
  }, [filters])

  // Clear all filters
  const clearAllFilters = () => {
    const clearedFilters = Object.keys(filters).reduce(
      (acc, key) => ({
        ...acc,
        [key]: ''
      }),
      {}
    )

    setFilters(clearedFilters)
    setDateFromCalendar(undefined)
    setDateToCalendar(undefined)

    // Clear URL params except page and limit
    const params = new URLSearchParams()
    if (searchParams.get('page')) params.set('page', searchParams.get('page'))
    if (searchParams.get('limit')) params.set('limit', searchParams.get('limit'))
    setSearchParams(params, { replace: true })
  }

  // Get active filter count
  const activeFilterCount = useMemo(() => {
    return Object.values(filters).filter((value) => value && value.trim() !== '').length
  }, [filters])

  return (
    <div className="mb-6">
      <div className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setOpenFilter(!openFilter)}>
              <Filter /> Filters
            </Button>
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-2">
                {activeFilterCount} active
              </Badge>
            )}
          </div>
          {hasActiveFilters && (
            <Button
              variant="outline"
              size="sm"
              onClick={clearAllFilters}
              className="flex items-center gap-2"
            >
              <X />
              Clear Filters
            </Button>
          )}
        </div>
      </div>
      {/* Filter Card  */}
      {openFilter && (
        <div className="space-y-6">
          {/* Search */}
          <div className="space-y-2">
            <Label htmlFor="search">Search</Label>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                id="search"
                placeholder="Search recordings..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                className="pl-8"
              />
            </div>
          </div>

          <Separator />

          {/* Basic Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="channelId">Channel ID</Label>
              <Input
                id="channelId"
                placeholder="Enter channel ID"
                value={filters.channelId}
                onChange={(e) => handleFilterChange('channelId', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="channelName">Channel Name</Label>
              <Input
                id="channelName"
                placeholder="Enter channel name"
                value={filters.channelName}
                onChange={(e) => handleFilterChange('channelName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={filters.status}
                onValueChange={(value) => handleFilterChange('status', value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {RECORDING_STATUS.map((status) => (
                    <SelectItem key={status.value} value={status.value}>
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 ">
              <Label htmlFor="format">Format</Label>
              <Select
                value={filters.format}
                onValueChange={(value) => handleFilterChange('format', value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  {VIDEO_EXPORT_FORMATS.map((format) => (
                    <SelectItem key={format.value} value={format.value}>
                      {format.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Separator />

          {/* File and Source Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fileName">File Name</Label>
              <Input
                id="fileName"
                placeholder="Enter file name"
                value={filters.fileName}
                onChange={(e) => handleFilterChange('fileName', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sourceIp">Source IP</Label>
              <Input
                id="sourceIp"
                placeholder="192.168.1.1"
                value={filters.sourceIp}
                onChange={(e) => handleFilterChange('sourceIp', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sourcePort">Source Port</Label>
              <Input
                id="sourcePort"
                placeholder="8080"
                type="number"
                value={filters.sourcePort}
                onChange={(e) => handleFilterChange('sourcePort', e.target.value)}
              />
            </div>
          </div>

          <Separator />

          {/* Date Filters */}
          <div>
            <h6 className="text-base ">Date Range</h6>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="space-y-2">
                <Label htmlFor="dateFrom">From Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !dateFromCalendar && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateFromCalendar ? format(dateFromCalendar, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      captionLayout="dropdown"
                      selected={dateFromCalendar}
                      onSelect={(date) => handleDateChange('dateFrom', date, setDateFromCalendar)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dateTo">To Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !dateToCalendar && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateToCalendar ? format(dateToCalendar, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      captionLayout="dropdown"
                      selected={dateToCalendar}
                      onSelect={(date) => handleDateChange('dateTo', date, setDateToCalendar)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>

          <Separator />

          {/* Time Filters */}
          <div>
            <h6 className="text-base">Time Ranges</h6>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              {/* Start Time */}
              <div className="space-y-3">
                <Label className="text-sm font-semibold">Start Time</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label htmlFor="startTimeFrom" className="text-xs">
                      From
                    </Label>
                    <TimeInput
                      id="startTimeFrom"
                      value={filters.startTimeFrom}
                      onChange={(e) => handleTimeChange('startTimeFrom', e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="startTimeTo" className="text-xs">
                      To
                    </Label>
                    <TimeInput
                      id="startTimeTo"
                      type="time"
                      value={filters.startTimeTo}
                      onChange={(e) => handleTimeChange('startTimeTo', e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* End Time */}
              <div className="space-y-3">
                <Label className="text-sm font-semibold">End Time</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label htmlFor="endTimeFrom" className="text-xs">
                      From
                    </Label>
                    <TimeInput
                      id="endTimeFrom"
                      type="time"
                      value={filters.endTimeFrom}
                      onChange={(e) => handleTimeChange('endTimeFrom', e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="endTimeTo" className="text-xs">
                      To
                    </Label>
                    <TimeInput
                      id="endTimeTo"
                      type="time"
                      value={filters.endTimeTo}
                      onChange={(e) => handleTimeChange('endTimeTo', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Size and Duration Filters */}
          <div>
            <h6 className="text-base ">Size & Duration</h6>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-2">
              {/* File Size */}
              <div className="space-y-3">
                <Label className="text-sm font-semibold">File Size (MB)</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label htmlFor="minFileSize" className="text-xs">
                      Min
                    </Label>
                    <Input
                      id="minFileSize"
                      type="number"
                      placeholder="0"
                      min="0"
                      value={filters.minFileSize}
                      onChange={(e) => handleFilterChange('minFileSize', e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="maxFileSize" className="text-xs">
                      Max
                    </Label>
                    <Input
                      id="maxFileSize"
                      type="number"
                      placeholder="1000"
                      min="0"
                      value={filters.maxFileSize}
                      onChange={(e) => handleFilterChange('maxFileSize', e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Duration */}
              <div className="space-y-3">
                <Label className="text-sm font-semibold">Duration (minutes)</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <Label htmlFor="minDuration" className="text-xs">
                      Min
                    </Label>
                    <Input
                      id="minDuration"
                      type="number"
                      placeholder="0"
                      min="0"
                      value={filters.minDuration}
                      onChange={(e) => handleFilterChange('minDuration', e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="maxDuration" className="text-xs">
                      Max
                    </Label>
                    <Input
                      id="maxDuration"
                      type="number"
                      placeholder="60"
                      min="0"
                      value={filters.maxDuration}
                      onChange={(e) => handleFilterChange('maxDuration', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default RecordingFilters
