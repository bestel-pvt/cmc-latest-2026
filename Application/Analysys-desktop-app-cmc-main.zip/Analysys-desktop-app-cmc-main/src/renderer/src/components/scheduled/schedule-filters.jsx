import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { format } from 'date-fns'
import { CalendarIcon, Filter, Search, X } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'
import { useDebounce } from 'react-haiku'
import { SCHEDULE_STATUS } from '@/constants/recording'
import TimeInput from '@/components/ui/time-input'

const ScheduleFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [openFilter, setOpenFilter] = useState(false)

  // Filters
  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    channelId: searchParams.get('channelId') || '',
    status: searchParams.get('status') || '',
    isRecurring: searchParams.get('isRecurring') || '',
    isActive: searchParams.get('isActive') || '',
    priority: searchParams.get('priority') || '',
    dateFrom: searchParams.get('dateFrom') || '',
    dateTo: searchParams.get('dateTo') || '',
    startTime: searchParams.get('startTime') || '',
    endTime: searchParams.get('endTime') || ''
  })

  const debouncedFilters = useDebounce(filters, 800)

  // Calendar states
  const [dateFromCalendar, setDateFromCalendar] = useState(
    filters.dateFrom ? new Date(filters.dateFrom) : undefined
  )
  const [dateToCalendar, setDateToCalendar] = useState(
    filters.dateTo ? new Date(filters.dateTo) : undefined
  )

  // Sync URL
  useEffect(() => {
    const params = new URLSearchParams(searchParams)

    Object.entries(debouncedFilters).forEach(([key, value]) => {
      if (value && value.trim() !== '') {
        params.set(key, value)
      } else {
        params.delete(key)
      }
    })

    if (params.toString() !== searchParams.toString()) {
      params.set('page', '1')
      setSearchParams(params, { replace: true })
    }
  }, [debouncedFilters, searchParams, setSearchParams])

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const handleDateChange = (key, date, setCalendarState) => {
    const dateValue = date ? format(date, 'yyyy-MM-dd') : ''
    setCalendarState(date)
    handleFilterChange(key, dateValue)
  }

  const hasActiveFilters = useMemo(() => {
    return Object.values(filters).some((v) => v && v.trim() !== '')
  }, [filters])

  const activeFilterCount = useMemo(() => {
    return Object.values(filters).filter((v) => v && v.trim() !== '').length
  }, [filters])

  const clearAllFilters = () => {
    const cleared = Object.keys(filters).reduce((acc, k) => ({ ...acc, [k]: '' }), {})
    setFilters(cleared)
    setDateFromCalendar(undefined)
    setDateToCalendar(undefined)

    const params = new URLSearchParams()
    if (searchParams.get('page')) params.set('page', searchParams.get('page'))
    if (searchParams.get('limit')) params.set('limit', searchParams.get('limit'))
    setSearchParams(params, { replace: true })
  }

  return (
    <div className="mb-6">
      {/* Header buttons */}
      <div className="pb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setOpenFilter(!openFilter)}>
            <Filter /> Filters
          </Button>
          {activeFilterCount > 0 && <Badge variant="secondary">{activeFilterCount} active</Badge>}
        </div>
        {hasActiveFilters && (
          <Button variant="outline" size="sm" onClick={clearAllFilters} className="flex gap-2">
            <X /> Clear
          </Button>
        )}
      </div>

      {/* Filters Card */}
      {openFilter && (
        <div className="space-y-6">
          {/* Search */}
          <div className="space-y-2">
            <Label htmlFor="search">Search</Label>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                id="search"
                placeholder="Search schedules..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                className="pl-8"
              />
            </div>
          </div>

          <Separator />

          {/* Basic filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="channelId">Channel ID</Label>
              <Input
                id="channelId"
                value={filters.channelId}
                onChange={(e) => handleFilterChange('channelId', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={filters.status} onValueChange={(v) => handleFilterChange('status', v)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {SCHEDULE_STATUS.map((s) => (
                    <SelectItem key={s.value} value={s.value}>
                      {s.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Recurring</Label>
              <Select
                value={filters.isRecurring}
                onValueChange={(v) => handleFilterChange('isRecurring', v)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Any" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="true">Yes</SelectItem>
                  <SelectItem value="false">No</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Active</Label>
              <Select
                value={filters.isActive}
                onValueChange={(v) => handleFilterChange('isActive', v)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Any" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="true">Active</SelectItem>
                  <SelectItem value="false">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Separator />

          {/* Date range */}
          <div>
            <h6 className="text-base">Date Range</h6>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="space-y-2">
                <Label>From</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start',
                        !dateFromCalendar && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateFromCalendar ? format(dateFromCalendar, 'PPP') : 'Pick date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent>
                    <Calendar
                      mode="single"
                      captionLayout="dropdown"
                      selected={dateFromCalendar}
                      onSelect={(d) => handleDateChange('dateFrom', d, setDateFromCalendar)}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label>To</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start',
                        !dateToCalendar && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateToCalendar ? format(dateToCalendar, 'PPP') : 'Pick date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent>
                    <Calendar
                      mode="single"
                      captionLayout="dropdown"
                      selected={dateToCalendar}
                      onSelect={(d) => handleDateChange('dateTo', d, setDateToCalendar)}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>

          <Separator />

          {/* Time filters */}
          <div>
            <h6 className="text-base">Time Range</h6>
            <div className="grid grid-cols-2 gap-4 mt-2">
              <div className="space-y-2">
                <Label>Start Time</Label>
                <TimeInput
                  value={filters.startTime}
                  onChange={(e) => handleFilterChange('startTime', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>End Time</Label>
                <TimeInput
                  value={filters.endTime}
                  onChange={(e) => handleFilterChange('endTime', e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ScheduleFilters
