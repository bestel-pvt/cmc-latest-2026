// Query classes for raw SQL database operations
const ChannelQueries = require('./channelQueries')
const SourceQueries = require('./sourceQueries')
const RecordingQueries = require('./recordingQueries')
const ClipQueries = require('./clipQueries')
const RecentSearchQueries = require('./recentSearchQueries')
const ScheduledRecordingQueries = require('./scheduledRecordingQueries')
const ScheduledRecordingExecutionQueries = require('./scheduledRecordingExecutionQueries')
const RecordingConflictQueries = require('./recordingConflictQueries')
const ProcessStateQueries = require('./processStateQueries')

module.exports = {
    ChannelQueries,
    SourceQueries,
    RecordingQueries,
    ClipQueries,
    RecentSearchQueries,
    ScheduledRecordingQueries,
    ScheduledRecordingExecutionQueries,
    RecordingConflictQueries,
    ProcessStateQueries
}
