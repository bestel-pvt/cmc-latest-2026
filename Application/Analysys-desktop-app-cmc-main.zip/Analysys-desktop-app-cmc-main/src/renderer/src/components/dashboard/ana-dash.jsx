import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell
} from '@/components/ui/table'
import { BarChartLabel } from '../ui/charts/bar-chart'
import { ChartPieLegend } from '../ui/charts/pie-chart'
import { format } from 'date-fns'
import StreamHealthDashboard from './dashboard-health'

// Sample data objects
const clipMetrics = {
  title: 'Clip Creation Metrics',
  data: [
    { content: 'React Hooks Guide', clips: 245 },
    { content: 'CSS Grid Tutorial', clips: 189 },
    { content: 'TypeScript Basics', clips: 156 },
    { content: 'Next.js Optimization', clips: 132 },
    { content: 'UI Design Principles', clips: 98 }
  ],
  description: 'Most frequently clipped content this month'
}

const storageData = {
  title: 'Storage Utilization',
  used: 75, // percentage
  total: '500GB',
  trend: 'up', // or "down"
  trendValue: '12%',
  description: 'System capacity overview'
}

const activityLogs = {
  title: 'Recent User Activity',
  logs: [
    { user: 'alice@example.com', action: 'Created clip', time: '2023-11-15 09:23' },
    { user: 'bob@example.com', action: 'Deleted clip', time: '2023-11-15 08:47' },
    { user: 'charlie@example.com', action: 'Logged in', time: '2023-11-15 08:12' },
    { user: 'dana@example.com', action: 'Shared clip', time: '2023-11-15 07:35' }
  ],
  description: 'Last 24 hours of system access'
}

const trendingTopics = {
  title: 'Trending Content Types',
  data: [
    { type: 'Tutorials', percentage: 45 },
    { type: 'Documentation', percentage: 30 },
    { type: 'Code Samples', percentage: 15 },
    { type: 'Articles', percentage: 10 }
  ],
  description: 'Content type distribution'
}

const performanceMetrics = {
  title: 'System Performance',
  metrics: [
    { name: 'Recording Load', value: 68, unit: '%' },
    { name: 'Processing Time', value: 2.3, unit: 's' },
    { name: 'API Response', value: 320, unit: 'ms' }
  ],
  description: 'Current system health'
}

export function AnalyticsDashboard() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Analytics Dashboard</h1>

      {/* Top Row - Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard title="Total Clips" value="1,245" change="+12%" description="This month" />
        <MetricCard title="Active Users" value="328" change="+5%" description="Daily average" />
        <MetricCard
          title="Storage Used"
          value={storageData.used + '%'}
          change={storageData.trendValue}
          description={`of ${storageData.total}`}
        />
        <MetricCard
          title="Avg. Load"
          value={performanceMetrics.metrics[0].value + performanceMetrics.metrics[0].unit}
          change="-3%"
          description="Recording system"
        />
      </div>

      <StreamHealthDashboard />

      {/* Middle Row - Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Clip Metrics */}

        <BarChartLabel
          data={clipMetrics.data}
          xKey="content"
          yKey="clips"
          title={clipMetrics.title}
          description={clipMetrics.description}
          className="h-[300px]"
        />

        {/* Trending Topics */}

        <ChartPieLegend
          data={trendingTopics.data}
          title={trendingTopics.title}
          description={trendingTopics.description}
          nameKey="type"
          valueKey="percentage"
          className="h-[300px]"
        />
      </div>

      {/* Bottom Row - Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Activity Logs */}
        <Card>
          <CardHeader>
            <CardTitle>{activityLogs.title}</CardTitle>
            <p className="text-sm text-muted-foreground">{activityLogs.description}</p>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead className="text-right">Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activityLogs.logs.map((log, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{log.user}</TableCell>
                    <TableCell>{log.action}</TableCell>
                    <TableCell className="text-right">
                      {format(new Date(log.time), 'PPP, pp')}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Performance Metrics */}
        <Card>
          <CardHeader>
            <CardTitle>{performanceMetrics.title}</CardTitle>
            <p className="text-sm text-muted-foreground">{performanceMetrics.description}</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {performanceMetrics.metrics.map((metric, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">{metric.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {index === 1 ? 'Average time' : 'Current utilization'}
                    </p>
                  </div>
                  <div className="font-bold">
                    {metric.value}
                    {metric.unit}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Reusable metric card component
function MetricCard({ title, value, change, description }) {
  const isPositive = change.startsWith('+')

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground flex items-center">
          <span className={isPositive ? 'text-green-500' : 'text-red-500'}>{change}</span>
          <span className="ml-1">{description}</span>
        </p>
      </CardContent>
    </Card>
  )
}
