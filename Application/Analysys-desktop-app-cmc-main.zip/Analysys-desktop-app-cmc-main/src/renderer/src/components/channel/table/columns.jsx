// import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { copyToClipboard, getInitials } from '@/lib/utils'
import {
  deleteChannel,
  startChannelRecording,
  startChannelStream,
  stopChannelRecording,
  stopChannelStream
} from '@/services/channels/channelApi'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { format } from 'date-fns'
import { Copy, MoreHorizontal, Pause, Play } from 'lucide-react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export const useChannelColumns = () => {
  const queryClient = useQueryClient()
  const navigate = useNavigate()

  const [streamingLoadingId, setStreamingLoadingId] = useState(null)
  const [recordingLoadingId, setRecordingLoadingId] = useState(null)

  const mutationDelete = useMutation({
    mutationFn: async (id) => {
      return await deleteChannel(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel deleted successful!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.message)
    }
  })

  // Streamings
  const mutationStartChannelStreaming = useMutation({
    mutationFn: async (id) => {
      setStreamingLoadingId(id)
      return await startChannelStream(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel stream started successfully!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.error)
    },
    onSettled: () => {
      setStreamingLoadingId(null)
    }
  })

  const mutationStopChannelStreaming = useMutation({
    mutationFn: async (id) => {
      setStreamingLoadingId(id)
      return await stopChannelStream(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel stream stopped successfully!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.error)
    },
    onSettled: () => {
      setStreamingLoadingId(null)
    }
  })

  // Recordings

  const mutationStartChannelRecording = useMutation({
    mutationFn: async (id) => {
      setRecordingLoadingId(id)
      return await startChannelRecording(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel recording started successfully!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.error)
    },
    onSettled: () => {
      setRecordingLoadingId(null)
    }
  })

  const mutationStopChannelRecording = useMutation({
    mutationFn: async (id) => {
      setRecordingLoadingId(id)
      return await stopChannelRecording(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Channel recording stopped successfully!')
      queryClient.invalidateQueries(['channels'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.error)
    },
    onSettled: () => {
      setRecordingLoadingId(null)
    }
  })

  return [
    {
      header: 'Sr. no.',
      size: 60,
      enableResizing: true,
      cell: ({ row, table }) => {
        const pagination = table.options.meta?.pagination
        const currentPage = pagination?.page || 1
        const pageSize = pagination?.limit || 10
        return (currentPage - 1) * pageSize + row.index + 1
      }
    },
    {
      accessorKey: 'name',
      header: 'Channel Name',
      cell: ({ row }) => {
        const channel = row.original

        return (
          <div className="flex items-start gap-4">
            <Avatar className="size-11">
              <AvatarFallback>{getInitials(channel?.name)}</AvatarFallback>
              <AvatarImage src={channel.logo} alt={channel?.name} />
            </Avatar>
            <div>
              <p className="font-semibold" title={channel?.name}>
                {channel?.name}
              </p>
              <small
                className="text-muted-foreground max-w-sm truncate overflow-hidden line-clamp-1"
                title={channel.description}
              >
                {channel.description}
              </small>
            </div>
          </div>
        )
      }
    },
    {
      accessorKey: 'isActive',
      header: 'Status',
      size: 120,
      cell: ({ cell }) => {
        const isActive = cell.getValue()
        return isActive ? (
          <div className="flex items-center gap-3">
            <span className="relative flex size-3">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-500 opacity-75"></span>
              <span className="relative inline-flex size-3 rounded-full bg-green-500"></span>
            </span>
            Active
          </div>
        ) : (
          <p className="text-destructive">Inactive</p>
        )
      }
    },

    {
      accessorKey: 'sources',
      header: 'Sources',
      size: 150,
      cell: ({ cell }) => {
        const sources = cell.getValue()
        return sources?.length ? sources.map((src) => src.type).join(', ') : '—'
      }
    },
    {
      accessorKey: 'isAnyStreamActive',
      header: 'Streaming',
      size: 120,
      cell: ({ row }) => {
        const channel = row.original
        const isStreaming = row.getValue('isAnyStreamActive')

        return (
          <Button
            variant={isStreaming ? 'destructive' : ''}
            size="icon"
            onClick={() => {
              if (isStreaming) {
                mutationStopChannelStreaming.mutate(channel.id)
              } else {
                mutationStartChannelStreaming.mutate(channel.id)
              }
            }}
            loading={
              streamingLoadingId === channel.id &&
              (mutationStartChannelStreaming.isPending || mutationStopChannelStreaming.isPending)
            }
          >
            {isStreaming ? <Pause /> : <Play />}
          </Button>
        )
      }
    },
    {
      accessorKey: 'isAnyRecordingActive',
      header: 'Recording',
      size: 120,
      cell: ({ row }) => {
        const channel = row.original
        const isRecording = row.getValue('isAnyRecordingActive')

        return (
          <Button
            variant={isRecording ? 'destructive' : ''}
            size="icon"
            onClick={() => {
              if (isRecording) {
                mutationStopChannelRecording.mutate(channel.id)
              } else {
                mutationStartChannelRecording.mutate(channel.id)
              }
            }}
            loading={
              recordingLoadingId === channel.id &&
              (mutationStartChannelRecording.isPending || mutationStopChannelRecording.isPending)
            }
          >
            {isRecording ? <Pause /> : <Play />}
          </Button>
        )
      }
    },
    {
      accessorKey: 'createdAt',
      header: 'Creation Date',
      size: 150,
      cell: ({ cell }) => {
        const date = cell.getValue()
        return date ? format(new Date(date), 'PPP, pp') : '—'
      }
    },
    {
      id: 'actions',
      enableHiding: false,
      cell: ({ row }) => {
        const channel = row.original
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => copyToClipboard(channel.id)}>
                Copy channel ID
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate(`/channel/${channel?.id}`)}>
                View channel
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`/channel/edit/${channel?.id}`)}>
                Edit channel
              </DropdownMenuItem>
              <Dialog>
                <DialogTrigger asChild>
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600">
                    Delete channel
                  </DropdownMenuItem>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Are you sure?</DialogTitle>
                    <DialogDescription>
                      This action cannot be undone. This will permanently delete the channel
                      <strong> {channel.name} </strong> and all its associated data.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button
                      variant="destructive"
                      onClick={() => mutationDelete.mutate(channel.id)}
                      loading={mutationDelete.isPending}
                    >
                      Confirm
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </DropdownMenuContent>
          </DropdownMenu>
        )
      }
    }
  ]
}
