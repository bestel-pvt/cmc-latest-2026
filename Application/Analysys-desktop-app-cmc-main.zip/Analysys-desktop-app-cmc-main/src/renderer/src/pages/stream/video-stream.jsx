import { useState, useEffect, useMemo, useRef, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { AspectRatio } from '@/components/ui/aspect-ratio'
import { Maximize, ChevronLeft, ChevronRight, GripVertical } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { getAllStrems } from '@/services/streams/streamApi'
import Hls from 'hls.js'

// Dnd-kit imports
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay
} from '@dnd-kit/core'
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  rectSortingStrategy
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import Loader from '@/components/common/loader'

// Local storage key for channel order
const CHANNEL_ORDER_KEY = 'videoWallChannelOrder'

function parseLayout(layout) {
  const [colsStr, rowsStr] = layout.split('x')
  const cols = parseInt(colsStr, 10) || 4
  const rows = parseInt(rowsStr, 10) || 4
  return { cols, rows }
}

// HLS Video Player Component
const HlsVideoPlayer = ({ src, title, isStreaming }) => {
  const videoRef = useRef(null)

  useEffect(() => {
    let hls = null

    if (src && videoRef.current) {
      if (Hls.isSupported()) {
        hls = new Hls({
          autoStartLoad: true,
          startPosition: -1,
          capLevelToPlayerSize: true,
          debug: false
        })
        hls.loadSource(src)
        hls.attachMedia(videoRef.current)
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          videoRef.current.play().catch(console.error)
        })
      } else if (videoRef.current.canPlayType('application/vnd.apple.mpegurl')) {
        // Native HLS support (Safari)
        videoRef.current.src = src
        videoRef.current.addEventListener('loadedmetadata', () => {
          videoRef.current.play().catch(console.error)
        })
      }
    }

    return () => {
      if (hls) {
        hls.destroy()
      }
    }
  }, [src])

  if (!src || !isStreaming) {
    return (
      <div className="w-full h-full bg-gray-800 flex flex-col items-center justify-center text-gray-500">
        <div className="text-lg">Offline</div>
        <div className="text-sm mt-2 text-center px-2">{title}</div>
      </div>
    )
  }

  return (
    <video
      ref={videoRef}
      className="w-full h-full object-cover"
      muted
      autoPlay
      playsInline
      controls={false}
    />
  )
}

// Draggable Video Card Component
const DraggableVideoCard = ({ channel, isDragging, isFullscreen = false, ...props }) => {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({
    id: channel?.id
  })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1
  }

  return (
    <div ref={setNodeRef} style={style} {...attributes} className="relative">
      {!isFullscreen && (
        <div
          {...listeners}
          className="absolute top-2 left-2 z-10 cursor-grab bg-black/50 rounded p-1 hover:bg-black/70"
        >
          <GripVertical className="h-4 w-4 text-white" />
        </div>
      )}
      <AspectRatio ratio={16 / 9}>
        <HlsVideoPlayer
          src={channel?.httpUrl}
          title={channel?.title}
          isStreaming={channel?.isStreaming}
        />
      </AspectRatio>
    </div>
  )
}

// Fullscreen Wall Component
const FullscreenWall = ({
  channels,
  layout,
  currentSlide,
  totalSlides,
  onExitFullscreen,
  onReorderChannels,
  onChangeSlide,
  isFullscreen = false
}) => {
  const [activeId, setActiveId] = useState(null)
  const [isDraggingNearEdge, setIsDraggingNearEdge] = useState(null) // 'left' or 'right'
  const edgeScrollTimeoutRef = useRef(null)

  const { cols, rows } = useMemo(() => parseLayout(layout), [layout])
  const videosPerSlide = cols * rows

  // Get channels for current slide
  const currentChannels = useMemo(() => {
    const startIndex = currentSlide * videosPerSlide
    const endIndex = startIndex + videosPerSlide
    const slideChannels = channels?.slice(startIndex, endIndex)

    // Pad with empty slots if needed
    while (slideChannels.length < videosPerSlide) {
      slideChannels.push({
        id: `empty-${slideChannels.length}`,
        title: 'Empty Slot',
        isStreaming: false,
        httpUrl: null
      })
    }

    return slideChannels
  }, [channels, currentSlide, videosPerSlide])

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8
      }
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates
    })
  )

  const handleDragStart = (event) => {
    setActiveId(event.active.id)
    setIsDraggingNearEdge(null)
  }

  const handleDragMove = (event) => {
    if (!event.active.rect.current.translated) return

    const { left, right, width } = event.active.rect.current.translated
    const screenWidth = window.innerWidth
    const edgeThreshold = 100 // pixels from edge to trigger slide change

    // Check if dragging near left edge and can go to previous slide
    if (left < edgeThreshold && currentSlide > 0) {
      setIsDraggingNearEdge('left')

      // Change slide after a short delay
      if (edgeScrollTimeoutRef.current) {
        clearTimeout(edgeScrollTimeoutRef.current)
      }
      edgeScrollTimeoutRef.current = setTimeout(() => {
        onChangeSlide(currentSlide - 1)
        setIsDraggingNearEdge(null)
      }, 500)
    }
    // Check if dragging near right edge and can go to next slide
    else if (right > screenWidth - edgeThreshold && currentSlide < totalSlides - 1) {
      setIsDraggingNearEdge('right')

      // Change slide after a short delay
      if (edgeScrollTimeoutRef.current) {
        clearTimeout(edgeScrollTimeoutRef.current)
      }
      edgeScrollTimeoutRef.current = setTimeout(() => {
        onChangeSlide(currentSlide + 1)
        setIsDraggingNearEdge(null)
      }, 500)
    } else {
      setIsDraggingNearEdge(null)
      if (edgeScrollTimeoutRef.current) {
        clearTimeout(edgeScrollTimeoutRef.current)
      }
    }
  }

  const handleDragEnd = (event) => {
    const { active, over } = event

    // Clear any pending slide change
    if (edgeScrollTimeoutRef.current) {
      clearTimeout(edgeScrollTimeoutRef.current)
      edgeScrollTimeoutRef.current = null
    }

    if (active.id !== over?.id && over?.id && over.id !== 'empty-slot') {
      // Find the global indices of the dragged item and the target
      const activeIndex = channels?.findIndex((ch) => ch.id === active.id)
      const overIndex = channels?.findIndex((ch) => ch.id === over.id)

      if (activeIndex !== -1 && overIndex !== -1) {
        onReorderChannels(activeIndex, overIndex)
      }
    }

    setActiveId(null)
    setIsDraggingNearEdge(null)
  }

  const handleDragCancel = () => {
    if (edgeScrollTimeoutRef.current) {
      clearTimeout(edgeScrollTimeoutRef.current)
      edgeScrollTimeoutRef.current = null
    }
    setActiveId(null)
    setIsDraggingNearEdge(null)
  }

  const gridStyle = {
    gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`
  }

  return (
    <div className="fixed inset-0 bg-black z-50 p-4">
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragMove={handleDragMove}
        onDragEnd={handleDragEnd}
        onDragCancel={handleDragCancel}
      >
        <div className="w-full h-full grid" style={gridStyle}>
          <SortableContext
            items={currentChannels.map((channel) => channel.id)}
            strategy={rectSortingStrategy}
          >
            {currentChannels.map((channel) => (
              <DraggableVideoCard
                key={channel.id}
                channel={channel}
                isFullscreen={isFullscreen}
                isDragging={activeId === channel.id}
              />
            ))}
          </SortableContext>
        </div>

        {/* Edge scrolling indicators */}
        {isDraggingNearEdge === 'left' && (
          <div className="absolute left-0 top-0 bottom-0 w-32 flex items-center justify-center bg-blue-500/30">
            <ChevronLeft className="h-12 w-12 text-white" />
          </div>
        )}
        {isDraggingNearEdge === 'right' && (
          <div className="absolute right-0 top-0 bottom-0 w-32 flex items-center justify-center bg-blue-500/30">
            <ChevronRight className="h-12 w-12 text-white" />
          </div>
        )}

        <DragOverlay>
          {activeId ? (
            <div className="w-40 h-24 bg-gray-800 opacity-80 border-2 border-dashed border-blue-500">
              <div className="w-full h-full flex items-center justify-center text-white">
                Moving...
              </div>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>
    </div>
  )
}

export function VideoWall() {
  const { data, isLoading } = useQuery({
    queryKey: ['all-active-stream'],
    queryFn: getAllStrems
  })

  const [layout, setLayout] = useState('4x4')
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [currentSlide, setCurrentSlide] = useState(0)
  const [channelsOrder, setChannelsOrder] = useState([])
  const [activeId, setActiveId] = useState(null)

  // Use actual channels from API response
  const channels = useMemo(() => {
    if (!data?.channels) return []

    return data.channels.map((channel) => ({
      id: channel.channelId,
      title: channel.channelName,
      description: channel.description,
      isStreaming: channel.isStreaming,
      httpUrl: channel.httpUrl,
      thumbnail: `https://placehold.co/400x225/333/white?text=${encodeURIComponent(channel.channelName)}`
    }))
  }, [data])

  // Load channel order from localStorage on initial load
  useEffect(() => {
    try {
      const savedOrder = localStorage.getItem(CHANNEL_ORDER_KEY)
      if (savedOrder) {
        const parsedOrder = JSON.parse(savedOrder)
        setChannelsOrder(parsedOrder)
      }
    } catch (error) {
      console.error('Failed to load channel order from localStorage:', error)
    }
  }, [])

  // Initialize or update channels order when channels change
  useEffect(() => {
    if (channels.length > 0) {
      // Only initialize if we don't have an order yet or if the channel count changed
      if (channelsOrder.length === 0 || channelsOrder.length !== channels.length) {
        const newOrder = channels.map((channel) => channel.id)
        setChannelsOrder(newOrder)

        // Save to localStorage
        try {
          localStorage.setItem(CHANNEL_ORDER_KEY, JSON.stringify(newOrder))
        } catch (error) {
          console.error('Failed to save channel order to localStorage:', error)
        }
      }
    }
  }, [channels, channelsOrder])

  // Save channel order to localStorage whenever it changes
  useEffect(() => {
    if (channelsOrder.length > 0) {
      try {
        localStorage.setItem(CHANNEL_ORDER_KEY, JSON.stringify(channelsOrder))
      } catch (error) {
        console.error('Failed to save channel order to localStorage:', error)
      }
    }
  }, [channelsOrder])

  // Get ordered channels based on channelsOrder
  const orderedChannels = useMemo(() => {
    if (channelsOrder.length === 0) return channels

    return channelsOrder
      .map((id) => channels.find((channel) => channel.id === id))
      .filter((channel) => channel !== undefined)
  }, [channels, channelsOrder])

  const { cols, rows } = useMemo(() => parseLayout(layout), [layout])
  const videosPerSlide = cols * rows

  // Calculate total slides needed
  const totalSlides = useMemo(
    () => Math.ceil(orderedChannels.length / videosPerSlide),
    [orderedChannels.length, videosPerSlide]
  )

  // Get channels for current slide
  const currentChannels = useMemo(() => {
    const startIndex = currentSlide * videosPerSlide
    const endIndex = startIndex + videosPerSlide
    const slideChannels = orderedChannels.slice(startIndex, endIndex)

    // Pad with empty slots if needed
    while (slideChannels.length < videosPerSlide) {
      slideChannels.push({
        id: `empty-${slideChannels.length}`,
        title: 'Empty Slot',
        isStreaming: false,
        httpUrl: null
      })
    }

    return slideChannels
  }, [orderedChannels, currentSlide, videosPerSlide])

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8
      }
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates
    })
  )

  const handleDragStart = (event) => {
    setActiveId(event.active.id)
  }

  const handleDragEnd = (event) => {
    const { active, over } = event

    if (active.id !== over?.id && over?.id && over.id !== 'empty-slot') {
      // Find the global indices of the dragged item and the target
      const activeIndex = orderedChannels.findIndex((ch) => ch.id === active.id)
      const overIndex = orderedChannels.findIndex((ch) => ch.id === over.id)

      if (activeIndex !== -1 && overIndex !== -1) {
        // Update the global channel order
        setChannelsOrder((items) => {
          const oldIndex = items.indexOf(active.id)
          const newIndex = items.indexOf(over.id)

          return arrayMove(items, oldIndex, newIndex)
        })
      }
    }

    setActiveId(null)
  }

  const handleDragCancel = () => {
    setActiveId(null)
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement
        .requestFullscreen()
        .then(() => setIsFullscreen(true))
        .catch((err) => console.error('Fullscreen error:', err))
    } else {
      document
        .exitFullscreen()
        .then(() => setIsFullscreen(false))
        .catch(() => {})
    }
  }

  const exitFullscreen = () => {
    document
      .exitFullscreen()
      .then(() => setIsFullscreen(false))
      .catch(() => {})
  }

  const handleReorderChannels = useCallback((fromIndex, toIndex) => {
    setChannelsOrder((items) => {
      return arrayMove(items, fromIndex, toIndex)
    })
  }, [])

  const handleChangeSlide = useCallback((newSlide) => {
    setCurrentSlide(newSlide)
  }, [])

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key.toLowerCase() === 'f') {
        e.preventDefault()
        toggleFullscreen()
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault()
        setCurrentSlide((prev) => (prev > 0 ? prev - 1 : totalSlides - 1))
      } else if (e.key === 'ArrowRight') {
        e.preventDefault()
        setCurrentSlide((prev) => (prev < totalSlides - 1 ? prev + 1 : 0))
      } else if (e.key === 'Escape' && isFullscreen) {
        e.preventDefault()
        exitFullscreen()
      }
    }

    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener('keydown', handleKeyDown)
    document.addEventListener('fullscreenchange', handleFullscreenChange)

    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.removeEventListener('fullscreenchange', handleFullscreenChange)
    }
  }, [totalSlides, isFullscreen])

  const gridStyle = {
    gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`
  }

  if (isLoading) {
    return (
      <Card>
        <Loader name="Streams" />
      </Card>
    )
  }

  if (isFullscreen) {
    return (
      <FullscreenWall
        channels={orderedChannels}
        layout={layout}
        currentSlide={currentSlide}
        totalSlides={totalSlides}
        onExitFullscreen={exitFullscreen}
        onReorderChannels={handleReorderChannels}
        onChangeSlide={handleChangeSlide}
        isFullscreen={isFullscreen}
      />
    )
  }

  const Wall = (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onDragCancel={handleDragCancel}
    >
      <div className="w-full grid" style={gridStyle}>
        <SortableContext
          items={currentChannels.map((channel) => channel.id)}
          strategy={rectSortingStrategy}
        >
          {currentChannels.map((channel) => (
            <DraggableVideoCard
              key={channel.id}
              channel={channel}
              isDragging={activeId === channel.id}
            />
          ))}
        </SortableContext>
      </div>
      <DragOverlay>
        {activeId ? (
          <div className="w-40 h-24 bg-gray-800 opacity-80 border-2 border-dashed border-blue-500">
            <div className="w-full h-full flex items-center justify-center text-white">
              Moving...
            </div>
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  )

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row justify-between items-center">
        <CardTitle className="flex flex-1 flex-wrap justify-between gap-3">
          <h4>Video Wall Display</h4>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Layout:</span>
              <ToggleGroup
                type="single"
                variant="outline"
                value={layout}
                onValueChange={(v) => {
                  if (v) {
                    setLayout(v)
                    setCurrentSlide(0) // Reset to first slide when layout changes
                  }
                }}
              >
                <ToggleGroupItem value="2x2" aria-label="2x2 layout">
                  2×2
                </ToggleGroupItem>
                <ToggleGroupItem value="4x4" aria-label="4x4 layout">
                  4x4
                </ToggleGroupItem>
                <ToggleGroupItem value="5x5" aria-label="5x5 layout">
                  5x5
                </ToggleGroupItem>
                <ToggleGroupItem value="6x6" aria-label="6x6 layout">
                  6x6
                </ToggleGroupItem>
              </ToggleGroup>
            </div>

            <Button
              variant="outline"
              onClick={toggleFullscreen}
              className="flex items-center gap-2"
            >
              <Maximize className="h-4 w-4" />
              Fullscreen (F)
            </Button>
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent>
        <div className="relative">
          {Wall}

          {totalSlides > 1 && (
            <>
              <Button
                variant="secondary"
                size="icon"
                className="absolute -left-4 top-1/2 transform -translate-y-1/2 bg-background/80 hover:bg-background"
                onClick={() => setCurrentSlide((prev) => (prev > 0 ? prev - 1 : totalSlides - 1))}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>

              <Button
                variant="secondary"
                size="icon"
                className="absolute -right-4 top-1/2 transform -translate-y-1/2 bg-background/80 hover:bg-background"
                onClick={() => setCurrentSlide((prev) => (prev < totalSlides - 1 ? prev + 1 : 0))}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>

              <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex items-center gap-1 bg-background/80 px-2 py-1 rounded-md">
                {Array.from({ length: totalSlides }).map((_, i) => (
                  <button
                    key={i}
                    className={`w-2 h-2 rounded-full ${i === currentSlide ? 'bg-primary' : 'bg-muted-foreground'}`}
                    onClick={() => setCurrentSlide(i)}
                    aria-label={`Go to slide ${i + 1}`}
                  />
                ))}
              </div>

              <div className="absolute top-2 right-2 bg-background/80 px-2 py-1 rounded-md text-sm">
                Slide {currentSlide + 1} of {totalSlides}
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
