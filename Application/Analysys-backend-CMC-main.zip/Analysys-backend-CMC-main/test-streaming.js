#!/usr/bin/env node

// Simple test script to check streaming functionality
const fetch = require('node-fetch')

const API_BASE = 'http://localhost:3000/api/streaming'
const TEST_CHANNEL_ID = 'cmenweeai0000uwm0ougwvpf0' // Replace with your actual channel ID

async function testStreaming() {
    console.log('🚀 Testing Streaming API...\n')

    try {
        // 1. Start streaming
        console.log('1. Starting stream...')
        const startResponse = await fetch(`${API_BASE}/${TEST_CHANNEL_ID}/start`, {
            method: 'POST'
        })
        const startData = await startResponse.json()

        if (startData.success) {
            console.log('✅ Stream started successfully!')
            console.log(`   Channel: ${startData.data.channelName}`)
            console.log(`   HLS URL: ${startData.data.httpUrl}`)
            console.log(`   UDP Source: ${startData.data.udpLink}`)
            console.log(`   HTTP Port: ${startData.data.httpPort}`)

            const hlsUrl = startData.data.httpUrl

            // 2. Wait a moment for stream to initialize
            console.log('\n2. Waiting 10 seconds for stream to initialize...')
            await new Promise(resolve => setTimeout(resolve, 10000))

            // 3. Check if playlist exists
            console.log('\n3. Checking HLS playlist...')
            try {
                const playlistResponse = await fetch(hlsUrl)
                if (playlistResponse.ok) {
                    const playlistContent = await playlistResponse.text()
                    console.log('✅ HLS playlist is accessible!')
                    console.log('   Playlist content preview:')
                    console.log('   ' + playlistContent.split('\n').slice(0, 10).join('\n   '))
                    if (playlistContent.split('\n').length > 3) {
                        console.log('   ... (playlist has content)')
                    }

                    // Check for segments
                    const segments = playlistContent.match(/stream_.*\.ts/g)
                    if (segments) {
                        console.log(`   Found ${segments.length} segments in playlist`)

                        // Try to fetch first segment
                        console.log('\n4. Testing segment access...')
                        const segmentUrl = hlsUrl.replace('/playlist.m3u8', `/${segments[0]}`)
                        const segmentResponse = await fetch(segmentUrl)

                        if (segmentResponse.ok) {
                            console.log(`✅ Segments are accessible! (${segmentResponse.headers.get('content-length')} bytes)`)
                        } else {
                            console.log(`❌ Segment not accessible: ${segmentResponse.status}`)
                        }
                    } else {
                        console.log('   No segments found in playlist yet')
                    }
                } else {
                    console.log(`❌ HLS playlist not accessible: ${playlistResponse.status}`)
                }
            } catch (error) {
                console.log(`❌ Error accessing playlist: ${error.message}`)
            }

            // 4. Get stream status
            console.log('\n5. Checking stream status...')
            const statusResponse = await fetch(`${API_BASE}/${TEST_CHANNEL_ID}/status`)
            const statusData = await statusResponse.json()

            if (statusData.success && statusData.isStreaming) {
                console.log('✅ Stream status: ACTIVE')
                console.log(`   Duration: ${statusData.duration} seconds`)
            } else {
                console.log('❌ Stream status: NOT ACTIVE')
            }

            // 5. Stop streaming
            console.log('\n6. Stopping stream...')
            const stopResponse = await fetch(`${API_BASE}/${TEST_CHANNEL_ID}/stop`, {
                method: 'POST'
            })
            const stopData = await stopResponse.json()

            if (stopData.success) {
                console.log('✅ Stream stopped successfully!')
            } else {
                console.log(`❌ Failed to stop stream: ${stopData.error}`)
            }

        } else {
            console.log(`❌ Failed to start stream: ${startData.error}`)
        }

    } catch (error) {
        console.error(`❌ Test failed: ${error.message}`)
    }

    console.log('\n🏁 Test completed!')
}

// Run test if this file is executed directly
if (process.argv[1].endsWith('test-streaming.js')) {
    testStreaming()
}

module.exports = testStreaming
