const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')

class ChannelQueries {
    // Get all channels with pagination, filtering, and search
    static getChannels({ page = 1, pageSize = 10, search = '', isActive = 'all', isPriority = 'all', sort = 'desc' }) {
        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        if (search && search.trim() !== '') {
            whereClauses.push('(c.name LIKE :search OR c.description LIKE :search)')
            params.search = `%${search}%`
        }

        if (isActive !== 'all') {
            whereClauses.push('c.isActive = :isActive')
            params.isActive = isActive === 'true' ? 1 : 0
        }

        if (isPriority !== 'all') {
            whereClauses.push('c.isPriority = :isPriority')
            params.isPriority = isPriority === 'true' ? 1 : 0
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Build ORDER BY clause
        let orderBy
        if (sort === 'asc') {
            orderBy = 'ORDER BY c.name ASC'
        } else if (sort === 'dsc' || sort === 'desc') {
            orderBy = 'ORDER BY c.name DESC'
        } else {
            orderBy = 'ORDER BY c.createdAt DESC'
        }

        // Get total count
        const countQuery = `SELECT COUNT(*) as count FROM channels c ${whereClause}`
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Calculate pagination
        const take = parseInt(pageSize, 10) || 10
        const skip = (parseInt(page, 10) - 1) * take

        // Get channels with sources
        const query = `
            SELECT 
                c.*,
                GROUP_CONCAT(
                    json_object(
                        'id', s.id,
                        'channelId', s.channelId,
                        'type', s.type,
                        'port', s.port,
                        'ip', s.ip,
                        'isActive', s.isActive,
                        'isPrimary', s.isPrimary,
                        'priority', s.priority,
                        'createdAt', s.createdAt,
                        'updatedAt', s.updatedAt
                    )
                ) as sourcesJson
            FROM channels c
            LEFT JOIN sources s ON c.id = s.channelId
            ${whereClause}
            GROUP BY c.id
            ${orderBy}
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        const rows = db.prepare(query).all(params)

        // Parse sources JSON
        const channels = rows.map(row => ({
            ...row,
            isActive: Boolean(row.isActive),
            isPriority: Boolean(row.isPriority),
            sources: row.sourcesJson ? JSON.parse(`[${row.sourcesJson}]`).map(source => ({
                ...source,
                isActive: Boolean(source.isActive),
                isPrimary: Boolean(source.isPrimary)
            })) : []
        }))

        return {
            data: serializeBigInt(channels),
            pagination: {
                total: totalCount,
                page: parseInt(page, 10),
                pageSize: take,
                totalPages: Math.ceil(totalCount / take)
            }
        }
    }

    // Get channel by ID with sources
    static getChannelById(id) {
        const query = `
            SELECT 
                c.*,
                GROUP_CONCAT(
                    json_object(
                        'id', s.id,
                        'channelId', s.channelId,
                        'type', s.type,
                        'port', s.port,
                        'ip', s.ip,
                        'isActive', s.isActive,
                        'isPrimary', s.isPrimary,
                        'priority', s.priority,
                        'createdAt', s.createdAt,
                        'updatedAt', s.updatedAt
                    )
                ) as sourcesJson
            FROM channels c
            LEFT JOIN sources s ON c.id = s.channelId
            WHERE c.id = ?
            GROUP BY c.id
        `

        const row = db.prepare(query).get(id)
        if (!row) return null

        return serializeBigInt({
            ...row,
            isActive: Boolean(row.isActive),
            isPriority: Boolean(row.isPriority),
            sources: row.sourcesJson ? JSON.parse(`[${row.sourcesJson}]`).map(source => ({
                ...source,
                isActive: Boolean(source.isActive),
                isPrimary: Boolean(source.isPrimary)
            })) : []
        })
    }

    // Create a new channel with sources
    static createChannel({ name, description, isActive = true, logo, isPriority = false, channelStreamLink, sources = [] }) {
        const transaction = db.transaction(() => {
            // Get current timestamp in ISO format
            const now = new Date().toISOString()

            // Insert channel
            const insertChannel = db.prepare(`
                INSERT INTO channels (id, name, description, isActive, logo, isPriority, channelStreamLink, createdAt, updatedAt)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `)

            // Generate CUID-like ID
            const channelId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)

            insertChannel.run(channelId, name, description || null, isActive ? 1 : 0, logo || null, isPriority ? 1 : 0, channelStreamLink, now, now)

            // Insert sources if provided
            if (sources && sources.length > 0) {
                const insertSource = db.prepare(`
                    INSERT INTO sources (id, channelId, type, port, ip, isActive, isPrimary, priority, createdAt, updatedAt)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `)

                sources.forEach(source => {
                    const sourceId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)
                    insertSource.run(
                        sourceId,
                        channelId,
                        source.type,
                        source.port,
                        source.ip,
                        source.isActive !== undefined ? (source.isActive ? 1 : 0) : 1,
                        source.isPrimary ? 1 : 0,
                        source.priority || 0,
                        now,
                        now
                    )
                })
            }

            return channelId
        })

        const channelId = transaction()
        return this.getChannelById(channelId)
    }

    // Update channel
    static updateChannel(id, updates) {
        const allowedFields = ['name', 'description', 'isActive', 'logo', 'isPriority']
        const setClauses = []
        const params = { id }

        allowedFields.forEach(field => {
            if (updates[field] !== undefined) {
                setClauses.push(`${field} = :${field}`)
                if (field === 'isActive' || field === 'isPriority') {
                    params[field] = updates[field] ? 1 : 0
                } else {
                    params[field] = updates[field]
                }
            }
        })

        if (setClauses.length === 0) {
            throw new DatabaseError('No valid fields to update')
        }

        // Get current timestamp in ISO format
        const now = new Date().toISOString()
        setClauses.push('updatedAt = :updatedAt')
        params.updatedAt = now

        const query = `UPDATE channels SET ${setClauses.join(', ')} WHERE id = :id`
        const result = db.prepare(query).run(params)

        if (result.changes === 0) {
            throw new DatabaseError('Channel not found', 'P2025')
        }

        return this.getChannelById(id)
    }

    // Delete channel (cascading deletes handled by foreign key constraints)
    static deleteChannel(id) {
        const result = db.prepare('DELETE FROM channels WHERE id = ?').run(id)

        if (result.changes === 0) {
            throw new DatabaseError('Channel not found', 'P2025')
        }

        return { success: true }
    }

    // Get channel count
    static getChannelCount(where = {}) {
        let whereClauses = []
        let params = {}

        if (where.isActive !== undefined) {
            whereClauses.push('isActive = :isActive')
            params.isActive = where.isActive ? 1 : 0
        }

        if (where.isPriority !== undefined) {
            whereClauses.push('isPriority = :isPriority')
            params.isPriority = where.isPriority ? 1 : 0
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''
        const query = `SELECT COUNT(*) as count FROM channels ${whereClause}`

        return db.prepare(query).get(params)?.count || 0
    }
}

module.exports = ChannelQueries
