import { api } from '@/lib/axios-instance'

export const getAllClips = async (options = {}) => {
  const {
    page = 1,
    limit = 10,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    recordingId,
    status,
    tags,
    channelName,
    dateFrom,
    dateTo,
    clipName,
    search
  } = options

  // Build params object, only include non-empty values
  const queryParams = {
    page,
    limit,
    sortBy,
    sortOrder
  }

  // Add optional filters only if they have values
  if (recordingId) queryParams.recordingId = recordingId
  if (status) queryParams.status = status
  if (tags) queryParams.tags = tags
  if (channelName) queryParams.channelName = channelName
  if (dateFrom) queryParams.dateFrom = dateFrom
  if (dateTo) queryParams.dateTo = dateTo
  if (clipName) queryParams.clipName = clipName
  if (search) queryParams.search = search

  const response = await api.get('/clips', {
    params: queryParams
  })

  return response?.data
}

export const getClip = async (id) => {
  const response = await api.get(`/clips/${id}`)
  return response?.data
}

export const deleteClip = async (id) => {
  const response = await api.delete(`/clips/${id}`)
  return response?.data
}

export const serverClip = async (id) => {
  const response = await api.get(`/clips/${id}/file`)
  return response?.data
}

export const createClip = async (id, data) => {
  const response = await api.post(`/clips/recording/${id}`, data)
  return response?.data
}
