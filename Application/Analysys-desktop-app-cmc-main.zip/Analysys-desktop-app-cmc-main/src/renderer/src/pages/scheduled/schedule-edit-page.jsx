import Container from '@/components/common/dash-container'
import Loader from '@/components/common/loader'
import ScheduleForm from '@/components/scheduled/schedule-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { getScheduleRecording } from '@/services/scheduled-recordings/scheduledRecordingApi'
import { useQuery } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'

const ScheduleEditPage = () => {
  const { id } = useParams()
  console.log(id)

  const { data, isPending } = useQuery({
    queryKey: ['schedule-recording', id],
    queryFn: () => getScheduleRecording(id),
    enabled: !!id
  })

  console.log(data)
  const schedule = data?.data

  if (isPending) {
    return <Loader name="Schedule details" />
  }

  return (
    <Container>
      <Card>
        <CardHeader>
          <CardTitle>
            <h4>Edit Recording Schedule</h4>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScheduleForm data={schedule} className="max-w-3xl" />
        </CardContent>
      </Card>
    </Container>
  )
}

export default ScheduleEditPage
