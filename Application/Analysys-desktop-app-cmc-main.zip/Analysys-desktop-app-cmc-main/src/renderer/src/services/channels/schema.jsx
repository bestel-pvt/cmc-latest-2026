import { z } from 'zod'

const sourceSchema = z.object({
  type: z.string().min(1, 'Source type is required'),
  ip: z.ipv4().min(1, 'IP address is required'),
  port: z.coerce.number().min(1, 'Port is required').max(9999),
  isPrimary: z.boolean().default(false),
  priority: z.coerce
    .number()
    .min(1, 'Priority must be at least 1')
    .max(3, 'Priority cannot exceed 3')
})

export const channelSchema = z.object({
  logo: z.string().optional(),
  name: z.string().min(1, 'Channel name is required'),
  description: z.string().optional(),
  isActive: z.boolean().default(true),
  isPriority: z.boolean().default(false),
  sources: z.array(sourceSchema).min(1, 'At least one source is required')
})
