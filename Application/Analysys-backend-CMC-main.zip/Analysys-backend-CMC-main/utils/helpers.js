const { randomBytes } = require('crypto')

// Generate unique channel stream link
function generateChannelStreamLink() {
    const baseIP = '127.0.0.1'
    const port = Math.floor(Math.random() * (9999 - 9000 + 1)) + 9000
    return `udp://${baseIP}:${port}`
}

// Generate UDP link from IP and port
function generateUdpLink(ip, port) {
    if (!ip || !port) {
        throw new Error('IP and port are required to generate UDP link')
    }
    return `udp://${ip}:${port}`
}

// Generate unique filename for recording
function generateRecordingFileName(channelName, channelId) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
    const sanitizedChannelName = channelName.replace(/[^a-zA-Z0-9]/g, '_')
    return `recording_${sanitizedChannelName}_${channelId}_${timestamp}.mp4`
}

module.exports = {
    generateChannelStreamLink,
    generateUdpLink,
    generateRecordingFileName
}
