import {
  deleteRecentSearch,
  getRecentSearches,
  getRecentSearchesByType
} from '@/services/search/searchApi'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '../ui/dialog'

import { ArrowUpLeft, Loader, Search, Trash2 } from 'lucide-react'
import { Button } from '../ui/button'
import toast from 'react-hot-toast'
import { useMemo, useState } from 'react'
import { useDebounce } from 'react-haiku'
import { Input } from '../ui/input'
import { format } from 'date-fns'

const SaveSearches = ({ type = null, open = false, setOpen, onApply }) => {
  const queryClient = useQueryClient()

  const { data, isPending } = useQuery({
    queryKey: ['saved-searches'],
    queryFn: () => (type ? getRecentSearchesByType(type) : getRecentSearches()),
    retry: 1,
    enabled: !!open
  })

  const recentSearches = data?.data
  const [query, setQuery] = useState('')

  const debouncedQuery = useDebounce(query, 300)

  // filter the list only after debounce
  const filtered = useMemo(() => {
    if (!debouncedQuery) return recentSearches
    return recentSearches.filter((item) =>
      item.name.toLowerCase().includes(debouncedQuery.toLowerCase())
    )
  }, [debouncedQuery, recentSearches])

  const mutationDelete = useMutation({
    mutationFn: async (id) => {
      return await deleteRecentSearch(id)
    },
    onSuccess: (data) => {
      queryClient?.invalidateQueries(['saved-searches'])
      toast.success(data?.message || 'Recent search deleted successfully!')
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || 'An error occurred')
    }
  })

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" onClick={() => setOpen(!open)}>
          Open Search
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Saved Searches</DialogTitle>
          <DialogDescription asChild>
            <div className="space-y-2 w-full min-h-[50vh]">
              <div className="relative py-2">
                <Input
                  placeholder="Search..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="pl-8"
                />
                <Search className="size-4 absolute top-1/2 -translate-y-1/2 left-2" />
              </div>
              <div className="flex flex-col gap-2 max-h-[60vh] overflow-auto py-4">
                {isPending ? (
                  <div className="min-h-[50vh] flex flex-col gap-2 items-center justify-center">
                    <Loader className="animate-spin" />
                    <p>Loading...</p>
                  </div>
                ) : filtered?.length > 0 ? (
                  filtered?.map((s) => (
                    <div
                      key={s.id}
                      className="flex items-center justify-between p-3 border rounded"
                    >
                      <div className="flex flex-col flex-1 gap-2">
                        <p className="font-semibold">{s.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(s.createdAt), 'PPP ,pp')}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            try {
                              const parsed = s.query
                              onApply(parsed)
                              setOpen(false)
                            } catch (err) {
                              console.error('Invalid query JSON', err)
                            }
                          }}
                          aria-label="Apply"
                        >
                          <ArrowUpLeft />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-destructive hover:text-destructive"
                          onClick={() => mutationDelete.mutateAsync(s?.id)}
                          aria-label="Delete"
                        >
                          <Trash2 />
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-muted-foreground py-12 text-center">No save search yet.</div>
                )}
              </div>
            </div>
          </DialogDescription>
        </DialogHeader>
      </DialogContent>
    </Dialog>
  )
}

export default SaveSearches
