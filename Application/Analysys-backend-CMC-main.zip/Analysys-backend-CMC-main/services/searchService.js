// News channels database with logos and metadata
const newsChannels = [
    {
        id: '24_news',
        name: '24_news',
        displayName: '24 News HD',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/24_news.png',
        keywords: ['24', 'news', 'hd', 'pakistan', 'urdu', 'breaking']
    },
    {
        id: '92_news',
        name: '92_news',
        displayName: '92 News HD Plus',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/92_news.png',
        keywords: ['92', 'news', 'hd', 'plus', 'pakistan', 'urdu', 'breaking']
    },
    {
        id: '365_news',
        name: '365_news',
        displayName: '365 News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/365_news.png',
        keywords: ['365', 'news', 'pakistan', 'urdu', 'daily']
    },
    {
        id: 'aaj_news',
        name: 'aaj_news',
        displayName: 'Aaj News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/aaj_news.png',
        keywords: ['aaj', 'news', 'pakistan', 'urdu', 'today']
    },
    {
        id: 'abbtak_news',
        name: 'abbtak_news',
        displayName: 'Abb Takk News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/abbtak_news.png',
        keywords: ['abb', 'takk', 'abbtakk', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'abn_news',
        name: 'abn_news',
        displayName: 'ABN News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/abn_news.png',
        keywords: ['abn', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'aik_news',
        name: 'aik_news',
        displayName: 'Aik News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/aik_news.png',
        keywords: ['aik', 'news', 'pakistan', 'urdu', 'one']
    },
    {
        id: 'aljazeera_news',
        name: 'aljazeera_news',
        displayName: 'Al Jazeera',
        description: 'International news channel',
        category: 'news',
        country: 'qatar',
        language: 'english',
        logo: '/news_logos/aljazeera_news.png',
        keywords: ['aljazeera', 'al', 'jazeera', 'news', 'international', 'english', 'qatar', 'middle east']
    },
    {
        id: 'ary_news',
        name: 'ary_news',
        displayName: 'ARY News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/ary_news.png',
        keywords: ['ary', 'news', 'pakistan', 'urdu', 'breaking']
    },
    {
        id: 'bbc_news',
        name: 'bbc_news',
        displayName: 'BBC News',
        description: 'British news channel',
        category: 'news',
        country: 'uk',
        language: 'english',
        logo: '/news_logos/bbc_news.png',
        keywords: ['bbc', 'news', 'british', 'uk', 'english', 'international', 'world']
    },
    {
        id: 'bol_news',
        name: 'bol_news',
        displayName: 'BOL News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/bol_news.png',
        keywords: ['bol', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'capital_news',
        name: 'capital_news',
        displayName: 'Capital TV',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/capital_news.png',
        keywords: ['capital', 'tv', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'city_21_news',
        name: 'city_21_news',
        displayName: 'City 21',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/city_21_news.png',
        keywords: ['city', '21', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'city_42_news',
        name: 'city_42_news',
        displayName: 'City 42',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/city_42_news.png',
        keywords: ['city', '42', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'cnn',
        name: 'cnn',
        displayName: 'CNN',
        description: 'American news channel',
        category: 'news',
        country: 'usa',
        language: 'english',
        logo: '/news_logos/cnn.png',
        keywords: ['cnn', 'news', 'american', 'usa', 'english', 'international', 'breaking']
    },
    {
        id: 'dawn_news',
        name: 'dawn_news',
        displayName: 'Dawn News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/dawn_news.png',
        keywords: ['dawn', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'dunya_news',
        name: 'dunya_news',
        displayName: 'Dunya News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/dunya_news.png',
        keywords: ['dunya', 'news', 'pakistan', 'urdu', 'world']
    },
    {
        id: 'express_news',
        name: 'express_news',
        displayName: 'Express News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/express_news.png',
        keywords: ['express', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'geo_news',
        name: 'geo_news',
        displayName: 'Geo News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/geo_news.png',
        keywords: ['geo', 'news', 'pakistan', 'urdu', 'jang']
    },
    {
        id: 'gnn_news',
        name: 'gnn_news',
        displayName: 'GNN News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/gnn_news.png',
        keywords: ['gnn', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'gtv_news',
        name: 'gtv_news',
        displayName: 'GTV News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/gtv_news.png',
        keywords: ['gtv', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'hum_news',
        name: 'hum_news',
        displayName: 'Hum News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/hum_news.png',
        keywords: ['hum', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'india_today',
        name: 'india_today',
        displayName: 'India Today',
        description: 'Indian news channel',
        category: 'news',
        country: 'india',
        language: 'english',
        logo: '/news_logos/india_today.png',
        keywords: ['india', 'today', 'news', 'indian', 'english']
    },
    {
        id: 'k_21_news',
        name: 'k_21_news',
        displayName: 'K21 News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/k_21_news.png',
        keywords: ['k21', 'k', '21', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'ndtv',
        name: 'ndtv',
        displayName: 'NDTV',
        description: 'Indian news channel',
        category: 'news',
        country: 'india',
        language: 'english',
        logo: '/news_logos/ndtv.png',
        keywords: ['ndtv', 'news', 'indian', 'india', 'english']
    },
    {
        id: 'neo_news',
        name: 'neo_news',
        displayName: 'Neo News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/neo_news.png',
        keywords: ['neo', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'news_one',
        name: 'news_one',
        displayName: 'News One',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/news_one.png',
        keywords: ['news', 'one', 'newsone', 'pakistan', 'urdu']
    },
    {
        id: 'ptv_news',
        name: 'ptv_news',
        displayName: 'PTV News',
        description: 'Pakistani state news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/ptv_news.png',
        keywords: ['ptv', 'news', 'pakistan', 'urdu', 'state', 'television']
    },
    {
        id: 'ptv_world',
        name: 'ptv_world',
        displayName: 'PTV World',
        description: 'Pakistani international news channel',
        category: 'news',
        country: 'pakistan',
        language: 'english',
        logo: '/news_logos/ptv_world.png',
        keywords: ['ptv', 'world', 'pakistan', 'english', 'international']
    },
    {
        id: 'public_news',
        name: 'public_news',
        displayName: 'Public News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/public_news.png',
        keywords: ['public', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'sama_news',
        name: 'sama_news',
        displayName: 'Sama News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/sama_news.png',
        keywords: ['sama', 'news', 'pakistan', 'urdu']
    },
    {
        id: 'suno_news',
        name: 'suno_news',
        displayName: 'Suno News',
        description: 'Pakistani news channel',
        category: 'news',
        country: 'pakistan',
        language: 'urdu',
        logo: '/news_logos/suno_news.png',
        keywords: ['suno', 'news', 'pakistan', 'urdu', 'listen']
    }
]

/**
 * Search channels by keyword with fuzzy matching
 * @param {string} query - Search query
 * @param {number} limit - Maximum results to return
 * @returns {Array} Array of matching channels
 */
const searchChannels = async (query, limit = 10, req) => {
    if (!query) {
        return newsChannels.slice(0, limit)
    }

    const searchTerm = query.toLowerCase().trim()
    const results = []

    newsChannels.forEach(channel => {
        let score = 0
        let matchType = 'none'

        // Exact match in name or display name (highest priority)
        if (channel.name.toLowerCase() === searchTerm ||
            channel.displayName.toLowerCase() === searchTerm) {
            score = 100
            matchType = 'exact'
        }
        // Starts with match in name or display name
        else if (channel.name.toLowerCase().startsWith(searchTerm) ||
            channel.displayName.toLowerCase().startsWith(searchTerm)) {
            score = 90
            matchType = 'starts_with'
        }
        // Contains match in name or display name
        else if (channel.name.toLowerCase().includes(searchTerm) ||
            channel.displayName.toLowerCase().includes(searchTerm)) {
            score = 80
            matchType = 'contains_name'
        }
        // Keyword match
        else if (channel.keywords.some(keyword => keyword.toLowerCase().includes(searchTerm))) {
            score = 70
            matchType = 'keyword'
        }
        // Category, country, or language match
        else if (channel.category.toLowerCase().includes(searchTerm) ||
            channel.country.toLowerCase().includes(searchTerm) ||
            channel.language.toLowerCase().includes(searchTerm)) {
            score = 60
            matchType = 'metadata'
        }
        // Description match (lowest priority)
        else if (channel.description.toLowerCase().includes(searchTerm)) {
            score = 50
            matchType = 'description'
        }

        if (score > 0) {
            results.push({
                ...channel,
                matchScore: score,
                matchType: matchType
            })
        }
    })

    // Sort by match score (highest first) and return limited results
    return results
        .sort((a, b) => b.matchScore - a.matchScore)
        .slice(0, limit)
        .map(({ matchScore, matchType, ...channel }) => ({
            ...channel,
            // Add full URL for logo (assuming your server serves static files)
            // `${req.protocol}://${req.get('host')}`
            // logoUrl: `${process.env.BASE_URL || 'http://localhost:3000'}${channel.logo}`,
            logoUrl: `${req.protocol}://${req.get('host')}${channel.logo}`,
            relevanceScore: matchScore
        }))
}

/**
 * Get all channels with optional filtering
 * @param {number} limit - Maximum results to return
 * @param {string} category - Filter by category
 * @param {string} country - Filter by country
 * @param {string} language - Filter by language
 * @returns {Array} Array of channels
 */
const getAllChannels = async (limit = 50, category = null, country = null, language = null) => {
    let filteredChannels = [...newsChannels]

    // Apply filters
    if (category) {
        filteredChannels = filteredChannels.filter(channel =>
            channel.category.toLowerCase() === category.toLowerCase())
    }

    if (country) {
        filteredChannels = filteredChannels.filter(channel =>
            channel.country.toLowerCase() === country.toLowerCase())
    }

    if (language) {
        filteredChannels = filteredChannels.filter(channel =>
            channel.language.toLowerCase() === language.toLowerCase())
    }

    // Sort alphabetically by display name
    filteredChannels.sort((a, b) => a.displayName.localeCompare(b.displayName))

    return filteredChannels
        .slice(0, limit)
        .map(channel => ({
            ...channel,
            logoUrl: `${process.env.BASE_URL || 'http://localhost:3000'}${channel.logo}`
        }))
}

/**
 * Get channel by ID
 * @param {string} channelId - Channel ID
 * @returns {Object|null} Channel object or null if not found
 */
const getChannelById = async (channelId) => {
    const channel = newsChannels.find(ch => ch.id === channelId)

    if (!channel) {
        return null
    }

    return {
        ...channel,
        logoUrl: `${process.env.BASE_URL || 'http://localhost:3000'}${channel.logo}`
    }
}

/**
 * Get channels by category
 * @param {string} category - Category name
 * @param {number} limit - Maximum results to return
 * @returns {Array} Array of channels
 */
const getChannelsByCategory = async (category, limit = 20) => {
    return newsChannels
        .filter(channel => channel.category.toLowerCase() === category.toLowerCase())
        .slice(0, limit)
        .map(channel => ({
            ...channel,
            logoUrl: `${process.env.BASE_URL || 'http://localhost:3000'}${channel.logo}`
        }))
}

/**
 * Get available categories, countries, and languages
 * @returns {Object} Available filters
 */
const getAvailableFilters = async () => {
    const categories = [...new Set(newsChannels.map(ch => ch.category))]
    const countries = [...new Set(newsChannels.map(ch => ch.country))]
    const languages = [...new Set(newsChannels.map(ch => ch.language))]

    return {
        categories,
        countries,
        languages,
        totalChannels: newsChannels.length
    }
}

module.exports = {
    searchChannels,
    getAllChannels,
    getChannelById,
    getChannelsByCategory,
    getAvailableFilters
}
