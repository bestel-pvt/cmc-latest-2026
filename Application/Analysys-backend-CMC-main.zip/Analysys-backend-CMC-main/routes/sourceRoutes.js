const express = require('express')
const {
    getSources,
    getSourceById,
    getSourcesByChannelId,
    createSource,
    updateSource,
    deleteSource
} = require('../controllers/sourceController.js')

const router = express.Router()

// GET /api/sources - Get all sources with pagination and filters
router.get('/', getSources)

// GET /api/sources/channel/:channelId - Get sources by channel ID (must come before /:id)
router.get('/channel/:channelId', getSourcesByChannelId)

// GET /api/sources/:id - Get source by ID
router.get('/:id', getSourceById)

// POST /api/sources - Create new source
router.post('/', createSource)

// PUT /api/sources/:id - Update source
router.put('/:id', updateSource)

// DELETE /api/sources/:id - Delete source
router.delete('/:id', deleteSource)

module.exports = router
