import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import Container from '@/components/common/dash-container'
import { useQuery } from '@tanstack/react-query'
import { Link as RouterLink, useParams } from 'react-router-dom'
import { getSource } from '@/services/source/sourceApi'
import SourceForm from '@/components/source/source-form'
import { Badge } from '@/components/ui/badge'
import { Copy, Link, Server } from 'lucide-react'
import { cn, copyToClipboard, getPriorityLabel } from '@/lib/utils'
import { Button, buttonVariants } from '@/components/ui/button'
import Loader from '@/components/common/loader'

const SourceEditPage = () => {
  const { id } = useParams()
  const { data, isPending } = useQuery({
    queryKey: ['source', id],
    queryFn: () => getSource(id)
  })

  const source = data

  if (isPending) {
    return <Loader name={'Source details'} />
  }

  return (
    <Container>
      <Card className="space-y-4 p-4">
        <h5>Edit Source</h5>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="border  p-6 rounded-xl shadow bg-white order-2 lg:order-1">
            <SourceForm sourceData={source} />
          </div>

          {/* Channel Info Card */}
          <div className="space-y-4 order-1 lg:order-2">
            {/* Header Card */}
            <Card>
              <CardHeader className="flex flex-row items-start gap-4">
                <div className="space-y-1 flex-1">
                  <div className="flex justify-between items-start">
                    <div className="space-y-4">
                      <h1 className="text-2xl font-bold">{source?.type}</h1>
                      <p className="font-semibold">
                        For channel:{' '}
                        <RouterLink
                          className={cn(buttonVariants({ variant: 'link' }))}
                          to={`/channel/${source?.channelId}`}
                        >
                          {source?.channel?.name}
                        </RouterLink>
                      </p>
                    </div>
                    <Badge variant={source?.isActive ? 'default' : 'destructive'}>
                      {source?.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Source Details Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="h-5 w-5" />
                    Source Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Type</h3>
                      <p className="font-medium">{source?.type}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Primary Source</h3>
                      <Badge variant={source?.isPrimary ? 'default' : 'outline'}>
                        {source?.isPrimary ? 'Yes' : 'No'}
                      </Badge>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Priority</h3>
                      <p className="font-medium">{getPriorityLabel(source?.priority)}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                      <Badge variant={source?.isActive ? 'default' : 'destructive'}>
                        {source?.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  </div>

                  <div className="pt-2">
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Connection</h3>
                    <div className="flex items-center gap-2">
                      <code className="text-sm bg-muted rounded px-3 py-2 flex-1 truncate">
                        {source?.ip}:{source?.port}
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => copyToClipboard(`${source?.ip}:${source?.port}`)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Channel Info Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Link className="h-5 w-5" />
                    Channel Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Channel Name</h3>
                      <p className="font-medium">{source?.channel?.name}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Channel Status</h3>
                      <Badge variant={source?.channel?.isActive ? 'default' : 'destructive'}>
                        {source?.channel?.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                    <div className="col-span-2">
                      <h3 className="text-sm font-medium text-muted-foreground">Channel ID</h3>
                      <p className="font-mono text-sm truncate">{source?.channelId}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </Card>
    </Container>
  )
}

export default SourceEditPage
