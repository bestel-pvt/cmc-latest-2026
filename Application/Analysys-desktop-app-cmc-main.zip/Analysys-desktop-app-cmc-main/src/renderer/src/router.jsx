import { createBrowserRouter, createHashRouter } from 'react-router-dom'

import ErrorPage from './pages/error/error-page'
import NotFoundPage from './pages/error/not-found'
import DashboardLayout from './layout/dashboard-layout'
import DashboardPage from './pages/dashboard/dashboard-page'
// Dashboard Home page
import { AnalyticsDashboard } from './components/dashboard/ana-dash'

//Channel page
import ChannelPage from './pages/channel/channel-page'
import ChannelAddPage from './pages/channel/channel-add-page'
import ChannelEditPage from './pages/channel/channel-edit-page'
import ChannelDetailPage from './pages/channel/channel-detail-page'
// Recording
import RecordingPage from './pages/recording/recording-page'
import RecordingDetailPage from './pages/recording/recording-detail-page'
// Video Wall
import { VideoWall } from './pages/stream/video-stream'

// Searches
import SearchPage from './pages/search/search-page'
import SourcePage from './pages/source/source-page'
import SourceDetailPage from './pages/source/source-detail-page'
import SourceEditPage from './pages/source/source-edit-page'
import SourceAddPage from './pages/source/source-add-page'
import OverallAnalytics from './pages/analytics/overall-analytics'
import ClippingPage from './pages/clipping/clipping-page'
import ClipDetailPage from './pages/clipping/clip-detail-page'
import VideoClipEditor from './components/clipping/video-clip-editor'
import ScheduledPage from './pages/scheduled/scheduled-page'
import ScheduleAddPage from './pages/scheduled/schedule-add-page'
import ScheduleEditPage from './pages/scheduled/schedule-edit-page'
import ScheduleDetailPage from './pages/scheduled/schedule-detail-page'
import ApiSettings from './pages/settings/api-settings'

export const router = createHashRouter([
  {
    path: '/',
    element: <DashboardLayout />,
    errorElement: <ErrorPage />,
    children: [
      {
        index: true,
        path: '/',
        element: <DashboardPage />
      },
      {
        path: '/overall-analytics',
        element: <OverallAnalytics />
      },

      // Channels
      {
        path: '/channel',
        element: <ChannelPage />
      },
      {
        path: '/channel/new',
        element: <ChannelAddPage />
      },
      {
        path: '/channel/edit/:id',
        element: <ChannelEditPage />
      },
      {
        path: '/channel/:id',
        element: <ChannelDetailPage />
      },
      // Sources
      {
        path: '/sources',
        element: <SourcePage />
      },
      {
        path: '/sources/new',
        element: <SourceAddPage />
      },
      {
        path: '/sources/:id',
        element: <SourceDetailPage />
      },
      {
        path: '/source/edit/:id',
        element: <SourceEditPage />
      },
      // Recordings
      {
        path: '/recordings',
        element: <RecordingPage />
      },
      {
        path: '/recording/:id',
        element: <RecordingDetailPage />
      },

      // Clippings

      {
        path: '/clips/new/:id',
        element: <VideoClipEditor />
      },
      {
        path: '/clips',
        element: <ClippingPage />
      },
      {
        path: '/clips/:id',
        element: <ClipDetailPage />
      },

      // Scheduled Recordings
      {
        path: '/scheduled-recordings',
        element: <ScheduledPage />
      },
      {
        path: '/scheduled-recordings/new',
        element: <ScheduleAddPage />
      },
      {
        path: '/scheduled-recordings/edit/:id',
        element: <ScheduleEditPage />
      },
      // {
      //   path: '/scheduled-recordings/:id',
      //   element: <ScheduleDetailPage />
      // },

      // Video Wall
      {
        path: '/streams',
        element: <VideoWall />
      },
      // Search Functionality
      {
        path: '/search',
        element: <SearchPage />
      },
      {
        path: '/settings',
        element: <ApiSettings />
      }
    ]
  },
  {
    path: '*',
    element: <NotFoundPage />
  }
])
