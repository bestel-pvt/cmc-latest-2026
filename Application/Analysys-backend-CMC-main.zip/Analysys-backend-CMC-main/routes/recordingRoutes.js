const express = require('express')
const {
    getAllRecordings,
    getRecordingById,
    deleteRecording,
    startRecording,
    stopRecording,
    getRecordingStatus,
    getChannelRecordings,
    getActiveRecordings,
    serveRecordingFile
} = require('../controllers/recordingController.js')

const router = express.Router()

// GET /api/recordings - Get all recordings
router.get('/', getAllRecordings)

// GET /api/recordings/active - Get active recordings
router.get('/active', getActiveRecordings)

// POST /api/recordings/start/:channelId - Start recording for a channel
router.post('/start/:channelId', startRecording)

// POST /api/recordings/stop/:channelId - Stop recording for a channel
router.post('/stop/:channelId', stopRecording)

// GET /api/recordings/status/:channelId - Get recording status for a channel
router.get('/status/:channelId', getRecordingStatus)

// GET /api/recordings/channel/:channelId - Get all recordings for a channel
router.get('/channel/:channelId', getChannelRecordings)

// GET /api/recordings/:id - Get recording by ID
router.get('/:id', getRecordingById)

// GET /api/recordings/:id/file - Serve recording file
router.get('/:id/file', serveRecordingFile)

// DELETE /api/recordings/:id - Delete recording
router.delete('/:id', deleteRecording)

module.exports = router
