import Container from '@/components/common/dash-container'
import SourceTable from '@/components/source/table/source-table'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { Link } from 'react-router-dom'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const SourcePage = () => {
  return (
    <Container>
      <Card>
        <CardHeader>
          <CardTitle>
            <div className="flex items-center justify-between">
              <h4>Source List</h4>
              <Link
                to="/sources/new"
                className={cn(
                  buttonVariants({
                    variant: 'default',
                    size: 'sm'
                  })
                )}
              >
                Create Source
              </Link>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <SourceTable />
        </CardContent>
      </Card>
    </Container>
  )
}

export default SourcePage
