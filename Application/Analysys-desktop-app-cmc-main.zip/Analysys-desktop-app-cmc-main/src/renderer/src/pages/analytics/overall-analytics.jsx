import Container from '@/components/common/dash-container'
import DashboardChannelStats from '@/components/dashboard/dasboard-channel-stats'
import Dashboardchannels from '@/components/dashboard/dashboard-channels'
import DashboardCharts from '@/components/dashboard/dashboard-charts'
import DashboardInsights from '@/components/dashboard/dashboard-insights'
import DasboardOverview from '@/components/dashboard/dashboard-overview'
import DashboardPerformance from '@/components/dashboard/dashboard-performance'
import { useRealtimeAnalytics } from '@/hooks/use-test'

const OverallAnalytics = () => {
  const { loadingOverview, overviewData } = useRealtimeAnalytics()
  console.log(overviewData)
  const topChannels = overviewData?.topChannels

  return (
    <Container>
      {/* Overview Section */}
      <div className="">
        <h3>Channels Statistics</h3>
        <p className="text-muted-foreground">
          A quick snapshot of your top-performing channels and their key metrics.
        </p>
      </div>
      <DashboardChannelStats data={topChannels} isPending={loadingOverview} />

      {/* Overview Trends */}
      <div className="">
        <h5>Overview</h5>
        <p className="text-muted-foreground">
          Track overall performance trends and engagement metrics at a glance.
        </p>
      </div>
      <DasboardOverview data={topChannels} isPending={loadingOverview} />
      <Dashboardchannels data={topChannels} isPending={loadingOverview} />

      {/* Performance Section */}
      <div className="">
        <h5>Performance</h5>
        <p className="text-muted-foreground">
          Dive deeper into detailed performance analytics across all channels.
        </p>
      </div>
      <DashboardPerformance data={topChannels} isPending={loadingOverview} />

      {/* Insights Section */}
      <div className="">
        <h5>Insights</h5>
        <p className="text-muted-foreground">
          Get actionable insights to optimize growth and audience engagement.
        </p>
      </div>
      <DashboardInsights data={topChannels} isPending={loadingOverview} />

      {/* Charts Section */}
      <div className="">
        <h5>Charts & Visuals</h5>
        <p className="text-muted-foreground">
          Visualize trends, comparisons, and growth patterns over time.
        </p>
      </div>
      <DashboardCharts data={topChannels} isPending={loadingOverview} />
    </Container>
  )
}

export default OverallAnalytics
