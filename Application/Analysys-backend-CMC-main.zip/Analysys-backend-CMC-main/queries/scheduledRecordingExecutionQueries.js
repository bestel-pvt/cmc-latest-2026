const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')

class ScheduledRecordingExecutionQueries {
    // Get scheduled recording executions with pagination and filtering
    static getScheduledRecordingExecutions({ page = 1, pageSize = 10, scheduledRecordingId, status }) {
        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        if (scheduledRecordingId) {
            whereClauses.push('sre.scheduledRecordingId = :scheduledRecordingId')
            params.scheduledRecordingId = scheduledRecordingId
        }

        if (status) {
            whereClauses.push('sre.status = :status')
            params.status = status
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Get total count
        const countQuery = `
            SELECT COUNT(*) as count 
            FROM scheduled_recording_executions sre
            ${whereClause}
        `
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Calculate pagination
        const take = parseInt(pageSize, 10) || 10
        const skip = (parseInt(page, 10) - 1) * take

        // Get executions
        const query = `
            SELECT 
                sre.*,
                sr.name as scheduledRecordingName,
                r.fileName as recordingFileName
            FROM scheduled_recording_executions sre
            LEFT JOIN scheduled_recordings sr ON sre.scheduledRecordingId = sr.id
            LEFT JOIN recordings r ON sre.recordingId = r.id
            ${whereClause}
            ORDER BY sre.executionStart DESC
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        const rows = db.prepare(query).all(params)

        const executions = rows.map(row => ({
            ...row,
            scheduledRecording: {
                name: row.scheduledRecordingName
            },
            recording: row.recordingFileName ? {
                fileName: row.recordingFileName
            } : null
        }))

        return {
            data: serializeBigInt(executions),
            pagination: {
                total: totalCount,
                page: parseInt(page, 10),
                pageSize: take,
                totalPages: Math.ceil(totalCount / take)
            }
        }
    }

    // Get execution by ID
    static getScheduledRecordingExecutionById(id) {
        const query = `
            SELECT 
                sre.*,
                sr.name as scheduledRecordingName,
                r.fileName as recordingFileName
            FROM scheduled_recording_executions sre
            LEFT JOIN scheduled_recordings sr ON sre.scheduledRecordingId = sr.id
            LEFT JOIN recordings r ON sre.recordingId = r.id
            WHERE sre.id = ?
        `

        const row = db.prepare(query).get(id)
        if (!row) return null

        return serializeBigInt({
            ...row,
            scheduledRecording: {
                name: row.scheduledRecordingName
            },
            recording: row.recordingFileName ? {
                fileName: row.recordingFileName
            } : null
        })
    }

    // Create a new execution
    static createScheduledRecordingExecution(data) {
        const {
            scheduledRecordingId,
            recordingId,
            executionStart,
            executionEnd,
            status = 'pending',
            failureReason
        } = data

        // Convert dates to ISO strings for SQLite binding
        const startTime = executionStart instanceof Date ? executionStart.toISOString() : executionStart
        const endTime = executionEnd instanceof Date ? executionEnd.toISOString() : executionEnd

        const insertExecution = db.prepare(`
            INSERT INTO scheduled_recording_executions (
                id, scheduledRecordingId, recordingId, executionStart, executionEnd,
                status, failureReason, createdAt, updatedAt
            ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `)

        // Generate CUID-like ID
        const executionId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)

        insertExecution.run(
            executionId,
            scheduledRecordingId,
            recordingId,
            startTime,
            endTime,
            status,
            failureReason
        )

        return this.getScheduledRecordingExecutionById(executionId)
    }

    // Update execution
    static updateScheduledRecordingExecution(id, updates) {
        const allowedFields = ['recordingId', 'executionStart', 'executionEnd', 'status', 'failureReason']
        const setClauses = []
        const params = { id }

        allowedFields.forEach(field => {
            if (updates[field] !== undefined) {
                setClauses.push(`${field} = :${field}`)
                if (field === 'executionStart' || field === 'executionEnd') {
                    params[field] = updates[field] instanceof Date ? updates[field].toISOString() : updates[field]
                } else {
                    params[field] = updates[field]
                }
            }
        })

        if (setClauses.length === 0) {
            throw new DatabaseError('No valid fields to update')
        }

        setClauses.push('updatedAt = datetime(\'now\')')

        const query = `UPDATE scheduled_recording_executions SET ${setClauses.join(', ')} WHERE id = :id`
        const result = db.prepare(query).run(params)

        if (result.changes === 0) {
            throw new DatabaseError('Scheduled recording execution not found', 'P2025')
        }

        return this.getScheduledRecordingExecutionById(id)
    }

    // Delete execution
    static deleteScheduledRecordingExecution(id) {
        const result = db.prepare('DELETE FROM scheduled_recording_executions WHERE id = ?').run(id)

        if (result.changes === 0) {
            throw new DatabaseError('Scheduled recording execution not found', 'P2025')
        }

        return { success: true }
    }

    // Find executions by criteria
    static findScheduledRecordingExecutions(options = {}) {
        const {
            where = {},
            include = {},
            skip = 0,
            take = 10,
            orderBy = { executionStart: 'desc' }
        } = options

        let whereClauses = []
        let params = {}
        let joins = []

        // Build WHERE clauses
        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                if (typeof where[key] === 'object' && where[key].lte) {
                    whereClauses.push(`sre.${key} <= :${key}`)
                    params[key] = where[key].lte instanceof Date ? where[key].lte.toISOString() : where[key].lte
                } else if (typeof where[key] === 'object' && where[key].gte) {
                    whereClauses.push(`sre.${key} >= :${key}`)
                    params[key] = where[key].gte instanceof Date ? where[key].gte.toISOString() : where[key].gte
                } else {
                    whereClauses.push(`sre.${key} = :${key}`)
                    params[key] = where[key]
                }
            }
        })

        // Handle includes
        if (include.scheduledRecording) {
            joins.push('LEFT JOIN scheduled_recordings sr ON sre.scheduledRecordingId = sr.id')
            if (include.scheduledRecording.include && include.scheduledRecording.include.channel) {
                joins.push('LEFT JOIN channels c ON sr.channelId = c.id')
            }
        }
        if (include.recording) {
            joins.push('LEFT JOIN recordings r ON sre.recordingId = r.id')
        }

        const joinClause = joins.join(' ')
        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Build ORDER BY
        let orderByClause = 'ORDER BY sre.executionStart DESC'
        if (orderBy) {
            const orderField = Object.keys(orderBy)[0]
            const orderDirection = orderBy[orderField].toUpperCase()
            orderByClause = `ORDER BY sre.${orderField} ${orderDirection}`
        }

        const query = `
            SELECT 
                sre.*
                ${include.scheduledRecording ? ', sr.name as scheduledRecordingName, sr.channelId as channelId' : ''}
                ${include.scheduledRecording && include.scheduledRecording.include && include.scheduledRecording.include.channel ? ', c.name as channelName, c.id as channelId' : ''}
                ${include.recording ? ', r.fileName as recordingFileName' : ''}
            FROM scheduled_recording_executions sre
            ${joinClause}
            ${whereClause}
            ${orderByClause}
            LIMIT ${take} OFFSET ${skip}
        `

        const rows = db.prepare(query).all(params)

        return serializeBigInt(rows.map(row => {
            const execution = { ...row }
            if (include.scheduledRecording) {
                execution.scheduledRecording = {
                    name: row.scheduledRecordingName,
                    channelId: row.channelId
                }
                if (include.scheduledRecording.include && include.scheduledRecording.include.channel) {
                    execution.scheduledRecording.channel = {
                        id: row.channelId,
                        name: row.channelName
                    }
                }
            }
            if (include.recording && row.recordingFileName) {
                execution.recording = {
                    fileName: row.recordingFileName
                }
            }
            return execution
        }))
    }

    // Get execution count
    static getScheduledRecordingExecutionCount(where = {}) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                if (typeof where[key] === 'object' && where[key].lte) {
                    whereClauses.push(`${key} <= :${key}`)
                    params[key] = where[key].lte instanceof Date ? where[key].lte.toISOString() : where[key].lte
                } else if (typeof where[key] === 'object' && where[key].gte) {
                    whereClauses.push(`${key} >= :${key}`)
                    params[key] = where[key].gte instanceof Date ? where[key].gte.toISOString() : where[key].gte
                } else {
                    whereClauses.push(`${key} = :${key}`)
                    params[key] = where[key]
                }
            }
        })

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''
        const query = `SELECT COUNT(*) as count FROM scheduled_recording_executions ${whereClause}`

        return db.prepare(query).get(params)?.count || 0
    }

    // Find unique execution
    static findUniqueScheduledRecordingExecution(where) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            whereClauses.push(`${key} = :${key}`)
            params[key] = where[key]
        })

        const whereClause = `WHERE ${whereClauses.join(' AND ')}`
        const query = `SELECT * FROM scheduled_recording_executions ${whereClause} LIMIT 1`

        const row = db.prepare(query).get(params)
        if (!row) return null

        return serializeBigInt(row)
    }
}

module.exports = ScheduledRecordingExecutionQueries
