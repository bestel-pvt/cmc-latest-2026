# Streaming and Recording Improvements

## Summary of Changes

### ✅ Core Issues Resolved

1. **UDP Multicast Support**: Both streaming and recording can now access the same UDP source simultaneously as multicast clients
2. **HLS File Locking**: Fixed permission denied errors when HLS segments are deleted while recording is reading them
3. **Recording Duration**: Improved HLS recording to capture full duration instead of stopping after 10-20 seconds
4. **Safe Cleanup**: Added intelligent cleanup that respects active recordings

### 🔧 Technical Improvements

#### Streaming Service Enhancements
- **Increased HLS segment buffer**: From 6 to 10 segments (20 seconds buffer)
- **Added delete threshold**: Prevents immediate deletion of segments being read by recording
- **Safe cleanup functionality**: Checks for active recordings before cleanup
- **Retry mechanism**: For handling file locks gracefully
- **Enhanced error filtering**: Reduces noise from common H.264 decoder warnings
- **Better stream handling**: Added error detection flags for corrupted streams

#### Recording Service Enhancements
- **UDP-first approach**: Always tries direct UDP recording first for better reliability
- **Improved multicast parameters**: Removed port binding parameters to avoid conflicts
- **Enhanced HLS recording**: Waits for playlist availability and handles live streams better
- **Better error handling**: More robust fallback mechanisms
- **Simplified UDP parameters**: Removed timeout and buffer parameters that cause binding issues

### 🎯 Key Features

#### 1. Concurrent Access Support
```javascript
// Both processes can now access UDP stream simultaneously
const streamResult = await streamingService.startStreaming(channelId)
const recordResult = await recordingService.startRecording(channelId)
// Both will work as multicast clients
```

#### 2. Smart Method Selection
- **Primary**: Direct UDP recording (preferred for reliability)
- **Fallback**: HLS-to-MP4 recording (only if UDP fails)
- **Conflict Resolution**: Safe cleanup prevents file locking issues

#### 3. Improved FFmpeg Parameters

**For Streaming (HLS generation):**
```bash
-hls_list_size 10              # Keep more segments
-hls_delete_threshold 3        # Delay segment deletion
-hls_flags delete_segments+independent_segments
-err_detect ignore_err         # Ignore decoder errors for corrupted streams
-fflags +genpts+discardcorrupt+nobuffer+igndts
```

**For UDP Recording:**
```bash
-i udp://ip:port?fifo_size=1000000&overrun_nonfatal=1  # Simple multicast
# Removed: timeout, buffer_size, localport parameters that cause binding conflicts
```

**For HLS Recording:**
```bash
-live_start_index 0            # Start from beginning
-reconnect 1                   # Auto-reconnect
-copyts                        # Maintain timestamp continuity
```

### 📊 Testing

**Test concurrent access:**
```bash
node test-concurrent-access.js
```

**Test UDP multicast capability:**
```bash
node test-udp-multicast.js
```

The concurrent test will:
1. Start streaming for a channel
2. Start recording for the same channel
3. Run both for 30 seconds (if recording works)
4. Stop both processes
5. Verify both worked correctly

The UDP multicast test will:
1. Test basic UDP stream accessibility
2. Test multiple concurrent UDP connections
3. Diagnose port binding conflicts
4. Provide troubleshooting information

### 🚀 Benefits

1. **Reliability**: Direct UDP recording is more stable than HLS-based recording
2. **Efficiency**: No intermediate HLS files needed for recording in most cases
3. **Scalability**: Multiple clients can access the same UDP stream
4. **Robustness**: Better error handling and recovery mechanisms
5. **Performance**: Reduced file I/O conflicts and better resource usage

### 🔍 Troubleshooting

If you encounter issues:

1. **Check UDP stream**: Ensure multicast stream is active on the expected port
2. **Test UDP multicast**: Run `node test-udp-multicast.js` to diagnose connection issues
3. **Port binding conflicts**: Error -10048 indicates the port is already bound - this is common with non-multicast streams
4. **H.264 decode errors**: These are usually non-critical for streaming but indicate stream quality issues
5. **Verify channel**: Make sure channel exists and has primary source configured
6. **Test connectivity**: Use FFmpeg directly to test UDP access
7. **Check logs**: Look for specific error messages in the console output

**Common Issues:**
- **"bind failed: Error number -10048"**: UDP port is already in use, stream may not support true multicast
- **"decode_slice_header error"**: H.264 stream has corruption, but streaming should still work
- **"No stream detected"**: UDP stream is not accessible or not running
- **Recording fails but streaming works**: Port binding conflict - stream doesn't support multiple connections

### 📝 Usage Notes

- **Preferred workflow**: Start streaming first, then recording (but both orders work)
- **File cleanup**: HLS files are cleaned up safely without affecting active recordings  
- **Resource usage**: UDP recording uses less resources than HLS recording
- **Compatibility**: Works with both unicast and multicast UDP streams

The system now handles the exact scenario in your logs - streaming and recording can run simultaneously from UDP port 4000 without conflicts.
