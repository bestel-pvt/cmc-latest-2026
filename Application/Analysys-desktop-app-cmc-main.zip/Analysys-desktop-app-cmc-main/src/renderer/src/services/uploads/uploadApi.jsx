import { api } from '@/lib/axios-instance'

export const uploadFile = async (file) => {
  const response = await api.postForm('/uploads/single', { file })
  return response?.data
}
