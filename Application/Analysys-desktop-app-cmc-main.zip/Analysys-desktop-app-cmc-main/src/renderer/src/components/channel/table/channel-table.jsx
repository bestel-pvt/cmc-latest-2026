import DataTable from '@/components/ui/data-table/data-table'
import { useChannelColumns } from './columns'
import { useQuery } from '@tanstack/react-query'
import { getAllChannels } from '@/services/channels/channelApi'
import { useState, useEffect } from 'react'
import { useDebounce } from 'react-haiku'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { useSearchParams } from 'react-router-dom' // or next/navigation for Next.js
import { Button } from '@/components/ui/button'
import { Trash2 } from 'lucide-react'

const ChannelTable = () => {
  const [searchParams, setSearchParams] = useSearchParams()

  // Initialize from URL
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1)
  const [limit, setLimit] = useState(Number(searchParams.get('limit')) || 10)
  const [search, setSearch] = useState(searchParams.get('search'))
  const [isActive, setIsActive] = useState(searchParams.get('isActive') || undefined)
  const [isPriority, setIsPriority] = useState(searchParams.get('isPriority') || undefined)

  // Debounce search value
  const debouncedSearch = useDebounce(search, 500)

  // Sync state to URL params
  useEffect(() => {
    const params = {
      page,
      limit,
      search: debouncedSearch || '',
      isActive: isActive || '',
      isPriority: isPriority || ''
    }
    // Remove empty filters from URL
    Object.keys(params).forEach((key) => params[key] === '' && delete params[key])
    setSearchParams(params)
  }, [page, limit, debouncedSearch, isActive, isPriority])

  const { data, isPending } = useQuery({
    queryKey: ['channels', page, limit, debouncedSearch, isActive, isPriority],
    queryFn: () =>
      getAllChannels({
        page,
        limit,
        search: debouncedSearch,
        isActive,
        isPriority
      }),
    keepPreviousData: true
  })

  const columns = useChannelColumns()
  const channel = data?.data

  console.log(channel)

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex gap-4 flex-wrap">
          <Input
            placeholder="Search channels..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value)
              setPage(1)
            }}
            className="w-64"
          />
          <Select
            value={isActive}
            onValueChange={(val) => {
              setIsActive(val)
              setPage(1)
            }}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Active Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="true">Active</SelectItem>
              <SelectItem value="false">Inactive</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={isPriority}
            onValueChange={(val) => {
              setIsPriority(val)
              setPage(1)
            }}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="true">Priority</SelectItem>
              <SelectItem value="false">Non-Priority</SelectItem>
            </SelectContent>
          </Select>
          <Button
            onClick={() => {
              setSearchParams({})

              // Reset all filter states
              setPage(1)
              setLimit(10)
              setSearch('')
              setIsActive(undefined)
              setIsPriority(undefined)
            }}
            size="icon"
          >
            <Trash2 />
          </Button>
        </div>

        {/* <div className="flex items-center gap-4">
          <Button
            varaint=""
            size="sm"
            onClick={() => {
              mutationStartChannelStreaming.mutate()
            }}
          >
            <Play />
            Start All Stream
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => {
              mutationStopChannelStreaming.mutate()
            }}
          >
            <Pause /> Stop All Streams
          </Button>
        </div> */}
      </div>

      {/* Table */}
      <DataTable
        columns={columns}
        data={channel || []}
        isPending={isPending}
        isPagination
        pagination={{
          page,
          limit,
          totalPages: data?.pagination?.totalPages || 1
        }}
        onPageChange={setPage}
        onLimitChange={(newLimit) => {
          setLimit(newLimit)
          setPage(1)
        }}
      />
    </div>
  )
}

export default ChannelTable
