const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')

class RecordingConflictQueries {
    // Get recording conflicts with pagination and filtering
    static getRecordingConflicts({ page = 1, pageSize = 10, isResolved = 'all', conflictType }) {
        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        if (isResolved !== 'all') {
            whereClauses.push('rc.isResolved = :isResolved')
            params.isResolved = isResolved === 'true' ? 1 : 0
        }

        if (conflictType) {
            whereClauses.push('rc.conflictType = :conflictType')
            params.conflictType = conflictType
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Get total count
        const countQuery = `
            SELECT COUNT(*) as count 
            FROM recording_conflicts rc
            ${whereClause}
        `
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Calculate pagination
        const take = parseInt(pageSize, 10) || 10
        const skip = (parseInt(page, 10) - 1) * take

        // Get conflicts
        const query = `
            SELECT 
                rc.*
            FROM recording_conflicts rc
            ${whereClause}
            ORDER BY rc.createdAt DESC
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        const rows = db.prepare(query).all(params)

        const conflicts = rows.map(row => ({
            ...row,
            isResolved: Boolean(row.isResolved)
        }))

        return {
            data: serializeBigInt(conflicts),
            pagination: {
                total: totalCount,
                page: parseInt(page, 10),
                pageSize: take,
                totalPages: Math.ceil(totalCount / take)
            }
        }
    }

    // Get conflict by ID
    static getRecordingConflictById(id) {
        const query = 'SELECT * FROM recording_conflicts WHERE id = ?'

        const row = db.prepare(query).get(id)
        if (!row) return null

        return serializeBigInt({
            ...row,
            isResolved: Boolean(row.isResolved)
        })
    }

    // Create a new conflict
    static createRecordingConflict(data) {
        const {
            scheduledRecordingId1,
            scheduledRecordingId2,
            conflictType,
            conflictStart,
            conflictEnd,
            resolution,
            isResolved = false
        } = data

        const insertConflict = db.prepare(`
            INSERT INTO recording_conflicts (
                id, scheduledRecordingId1, scheduledRecordingId2, conflictType,
                conflictStart, conflictEnd, resolution, isResolved, createdAt, updatedAt
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `)

        // Generate CUID-like ID
        const conflictId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)

        insertConflict.run(
            conflictId,
            scheduledRecordingId1,
            scheduledRecordingId2,
            conflictType,
            conflictStart,
            conflictEnd,
            resolution,
            isResolved ? 1 : 0
        )

        return this.getRecordingConflictById(conflictId)
    }

    // Update conflict
    static updateRecordingConflict(id, updates) {
        const allowedFields = [
            'scheduledRecordingId1', 'scheduledRecordingId2', 'conflictType',
            'conflictStart', 'conflictEnd', 'resolution', 'isResolved'
        ]
        const setClauses = []
        const params = { id }

        allowedFields.forEach(field => {
            if (updates[field] !== undefined) {
                setClauses.push(`${field} = :${field}`)
                if (field === 'isResolved') {
                    params[field] = updates[field] ? 1 : 0
                } else {
                    params[field] = updates[field]
                }
            }
        })

        if (setClauses.length === 0) {
            throw new DatabaseError('No valid fields to update')
        }

        setClauses.push('updatedAt = datetime(\'now\')')

        const query = `UPDATE recording_conflicts SET ${setClauses.join(', ')} WHERE id = :id`
        const result = db.prepare(query).run(params)

        if (result.changes === 0) {
            throw new DatabaseError('Recording conflict not found', 'P2025')
        }

        return this.getRecordingConflictById(id)
    }

    // Delete conflict
    static deleteRecordingConflict(id) {
        const result = db.prepare('DELETE FROM recording_conflicts WHERE id = ?').run(id)

        if (result.changes === 0) {
            throw new DatabaseError('Recording conflict not found', 'P2025')
        }

        return { success: true }
    }

    // Find conflicts by criteria
    static findRecordingConflicts(options = {}) {
        const {
            where = {},
            skip = 0,
            take = 10,
            orderBy = { createdAt: 'desc' }
        } = options

        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                if (typeof where[key] === 'object' && where[key].lte) {
                    whereClauses.push(`${key} <= :${key}`)
                    params[key] = where[key].lte
                } else if (typeof where[key] === 'object' && where[key].gte) {
                    whereClauses.push(`${key} >= :${key}`)
                    params[key] = where[key].gte
                } else if (typeof where[key] === 'object' && where[key].in && Array.isArray(where[key].in)) {
                    const placeholders = where[key].in.map((_, index) => `:${key}_${index}`).join(', ')
                    whereClauses.push(`${key} IN (${placeholders})`)
                    where[key].in.forEach((value, index) => {
                        params[`${key}_${index}`] = value
                    })
                } else {
                    whereClauses.push(`${key} = :${key}`)
                    if (key === 'isResolved') {
                        params[key] = where[key] ? 1 : 0
                    } else {
                        params[key] = where[key]
                    }
                }
            }
        })

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Build ORDER BY
        let orderByClause = 'ORDER BY createdAt DESC'
        if (orderBy) {
            const orderField = Object.keys(orderBy)[0]
            const orderDirection = orderBy[orderField].toUpperCase()
            orderByClause = `ORDER BY ${orderField} ${orderDirection}`
        }

        const query = `
            SELECT *
            FROM recording_conflicts
            ${whereClause}
            ${orderByClause}
            LIMIT ${take} OFFSET ${skip}
        `

        const rows = db.prepare(query).all(params)

        return serializeBigInt(rows.map(row => ({
            ...row,
            isResolved: Boolean(row.isResolved)
        })))
    }

    // Get conflict count
    static getRecordingConflictCount(where = {}) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                if (typeof where[key] === 'object' && where[key].lte) {
                    whereClauses.push(`${key} <= :${key}`)
                    params[key] = where[key].lte
                } else if (typeof where[key] === 'object' && where[key].gte) {
                    whereClauses.push(`${key} >= :${key}`)
                    params[key] = where[key].gte
                } else if (typeof where[key] === 'object' && where[key].in && Array.isArray(where[key].in)) {
                    const placeholders = where[key].in.map((_, index) => `:${key}_${index}`).join(', ')
                    whereClauses.push(`${key} IN (${placeholders})`)
                    where[key].in.forEach((value, index) => {
                        params[`${key}_${index}`] = value
                    })
                } else {
                    whereClauses.push(`${key} = :${key}`)
                    if (key === 'isResolved') {
                        params[key] = where[key] ? 1 : 0
                    } else {
                        params[key] = where[key]
                    }
                }
            }
        })

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''
        const query = `SELECT COUNT(*) as count FROM recording_conflicts ${whereClause}`

        return db.prepare(query).get(params)?.count || 0
    }

    // Find unique conflict
    static findUniqueRecordingConflict(where) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            whereClauses.push(`${key} = :${key}`)
            params[key] = where[key]
        })

        const whereClause = `WHERE ${whereClauses.join(' AND ')}`
        const query = `SELECT * FROM recording_conflicts ${whereClause} LIMIT 1`

        const row = db.prepare(query).get(params)
        if (!row) return null

        return serializeBigInt({
            ...row,
            isResolved: Boolean(row.isResolved)
        })
    }
}

module.exports = RecordingConflictQueries
