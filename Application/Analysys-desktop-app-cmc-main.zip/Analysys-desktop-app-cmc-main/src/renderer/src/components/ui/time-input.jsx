import { Input } from './input'
import { cn } from '@/lib/utils'

const TimeInput = ({ defaultValue = '12:30:00', step = '1', className }, props) => {
  return (
    <Input
      type="time"
      step={step}
      defaultValue={defaultValue}
      className={`bg-background appearance-none [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-calendar-picker-indicator]:appearance-none ${className}`}
      {...props}
    />
  )
}

export default TimeInput
