import { Button } from '@/components/ui/button'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter
} from '@/components/ui/card'
import { AlertTriangle } from 'lucide-react'

import { useRouteError, isRouteErrorResponse, Link } from 'react-router-dom'

const ErrorPage = () => {
  const error = useRouteError()

  let errorTitle = 'Something went wrong'
  let errorMessage = 'An unexpected error occurred'
  let errorStatus = null

  if (isRouteErrorResponse(error)) {
    errorStatus = error.status
    errorTitle = `${error.status} - ${error.statusText || 'Error'}`
    errorMessage =
      error.data?.message || "The page you're looking for doesn't exist or has been moved."
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted p-4">
      <Card className="w-full max-w-md border border-destructive/20">
        <CardHeader className="space-y-1">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <CardTitle className="text-2xl">{errorTitle}</CardTitle>
          </div>
          <CardDescription className="text-base">Oops! We encountered a problem</CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <p className="text-muted-foreground">{errorMessage}</p>

          {errorStatus === 404 && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">You might want to:</p>
              <ul className="list-disc pl-5 text-sm space-y-1 text-muted-foreground">
                <li>Check the URL for typos</li>
                <li>Go back to the previous page</li>
                <li>Return to the homepage</li>
              </ul>
            </div>
          )}
        </CardContent>

        <CardFooter className="flex flex-col gap-2">
          <Button asChild variant="outline" className="w-full">
            <Link to="/">Go to Homepage</Link>
          </Button>
          <Button
            variant="ghost"
            className="w-full text-destructive hover:text-destructive"
            onClick={() => window.location.reload()}
          >
            Try Again
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

export default ErrorPage
