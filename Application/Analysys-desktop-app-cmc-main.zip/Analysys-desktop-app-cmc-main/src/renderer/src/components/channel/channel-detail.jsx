import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ChevronLeft, Copy, Server } from 'lucide-react'
import { format } from 'date-fns'
import { useRef, useState } from 'react'
import { copyToClipboard, getInitials, getPriorityLabel } from '@/lib/utils'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'
import { Separator } from '../ui/separator'
import { useNavigate } from 'react-router-dom'

const ChannelDetail = ({ channel }) => {
  const navigate = useNavigate()
  const [watch, setWatch] = useState(false)

  const containerRef = useRef(null)

  const url = 'udp://127.0.0.1:4000'

  console.log(channel)

  return (
    <div className="space-y-4">
      {/* Channel Header Card */}
      <Card>
        <CardHeader className="flex flex-col  items-start gap-4">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => navigate('/channel')}>
              <ChevronLeft />
            </Button>
            <h4>Channel Details</h4>
          </div>
          <Separator />
          <div className="flex flex-row items-start gap-4 w-full">
            <Avatar className="size-24 border rounded-md">
              <AvatarFallback className="rounded-md">{getInitials(channel?.name)}</AvatarFallback>
              <AvatarImage src={channel.logo} alt={channel?.name} className="object-contain" />
            </Avatar>
            <div className="space-y-1 flex-1">
              <div className="flex justify-between items-start">
                <h5>{channel?.name}</h5>
                <Badge variant={channel?.isActive ? 'default' : 'destructive'}>
                  {channel?.isActive ? 'Active' : 'Inactive'}
                </Badge>
              </div>
              <p className="text-muted-foreground">{channel?.description}</p>
              {channel?.channelStreamLink && (
                <div className="flex items-center gap-4">
                  <p className="text-sm font-mono text-muted-foreground">
                    {channel.channelStreamLink}
                  </p>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => copyToClipboard(channel.channelStreamLink)}
                  >
                    <Copy />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Channel Details Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Channel Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Priority</h3>
                <p className="font-medium">{channel?.isPriority ? 'High' : 'Normal'}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Created</h3>
                <p className="font-medium">{format(new Date(channel?.createdAt), 'PPP, p')}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Last Updated</h3>
                <p className="font-medium">{format(new Date(channel?.updatedAt), 'PPP, p')}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">ID</h3>
                <p className="font-mono text-sm">{channel?.id}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sources Card */}
        <Card>
          <CardHeader>
            <CardTitle>Sources</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {channel?.sources?.map((source) => (
              <div key={source.id} className="border rounded-lg p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Type</h3>
                    <p className="font-medium">{source.type}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                    <Badge variant={source.isActive ? 'default' : 'destructive'}>
                      {source.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">IP Address</h3>
                    <p className="font-mono text-sm">{source.ip}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Port</h3>
                    <p className="font-mono text-sm">{source.port}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Primary</h3>
                    <p className="font-medium">{source.isPrimary ? 'Yes' : 'No'}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Priority</h3>
                    <p className="font-medium">{getPriorityLabel(source.priority)}</p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
      {/* Watch Button and Video Player
      <div className="flex justify-center">
        <Button size="lg" onClick={() => setWatch(!watch)} className="gap-2">
          <Play className="h-5 w-5" />
          {watch ? 'Hide Video' : 'Watch Channel'}
        </Button>
      </div> */}
      {watch && (
        <>
          <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
          <Card className="p-4">
            <video
              controls
              src={'http://localhost:8080/stream.ts'}
              className="w-full aspect-video rounded-xl"
              autoPlay
            >
              Your browser does not support the video tag.
            </video>
          </Card>
        </>
      )}
    </div>
  )
}

export default ChannelDetail
