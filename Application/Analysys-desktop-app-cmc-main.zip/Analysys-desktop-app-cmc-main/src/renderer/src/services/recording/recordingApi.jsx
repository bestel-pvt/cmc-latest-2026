import { api } from '@/lib/axios-instance'

export const getAllRecordings = async (params = {}) => {
  const {
    page = 1,
    limit = 10,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    status,
    format,
    channelId,
    channelName,
    fileName,
    sourceIp,
    sourcePort,
    dateFrom,
    dateTo,
    startTimeFrom,
    startTimeTo,
    endTimeFrom,
    endTimeTo,
    minFileSize,
    maxFileSize,
    minDuration,
    maxDuration,
    search
  } = params

  // Build params object, only include non-empty values
  const queryParams = {
    page,
    limit,
    sortBy,
    sortOrder
  }

  // Add optional filters only if they have values
  if (status) queryParams.status = status
  if (format) queryParams.format = format
  if (channelId) queryParams.channelId = channelId
  if (channelName) queryParams.channelName = channelName
  if (fileName) queryParams.fileName = fileName
  if (sourceIp) queryParams.sourceIp = sourceIp
  if (sourcePort) queryParams.sourcePort = sourcePort
  if (dateFrom) queryParams.dateFrom = dateFrom
  if (dateTo) queryParams.dateTo = dateTo
  if (startTimeFrom) queryParams.startTimeFrom = startTimeFrom
  if (startTimeTo) queryParams.startTimeTo = startTimeTo
  if (endTimeFrom) queryParams.endTimeFrom = endTimeFrom
  if (endTimeTo) queryParams.endTimeTo = endTimeTo
  if (minFileSize) queryParams.minFileSize = minFileSize
  if (maxFileSize) queryParams.maxFileSize = maxFileSize
  if (minDuration) queryParams.minDuration = minDuration
  if (maxDuration) queryParams.maxDuration = maxDuration
  if (search) queryParams.search = search

  const response = await api.get('/recordings', { params: queryParams })

  return response?.data
}

export const getRecording = async (id) => {
  const response = await api.get(`/recordings/${id}`)
  return response?.data
}

export const getRecordingFile = async (id) => {
  const response = await api.get(`/api/recordings/${id}/file`)
  return response?.data
}
