'use client'

import { TrendingUp, TrendingDown } from 'lucide-react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  LabelList,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Cell
} from 'recharts'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { useMemo } from 'react'

export function ProviderHealthChart({
  title,
  description,
  data = [],
  footerText,
  maxWidth = 600,
  maxHeight = 500
}) {
  // Transform the data for the chart (ensure fallback values)
  const chartData =
    Array.isArray(data) && data.length > 0
      ? data.map((provider) => ({
          name: provider.name,
          currentHealth: provider.currentHealth ?? 0,
          monthlyAvg: provider.monthlyAvg ?? 0,
          bestHealth: provider.bestHealth ?? 0,
          color: provider.color || 'var(--chart-1)',
          id: provider.id
        }))
      : [
          {
            name: 'No data',
            currentHealth: 0,
            monthlyAvg: 0,
            bestHealth: 0,
            color: 'rgba(0,0,0,0.1)',
            id: 'none'
          }
        ]

  // Calculate overall trend safely
  const totalMonthly = data.reduce((sum, provider) => sum + (provider.monthlyAvg || 0), 0)
  const totalChange = data.reduce(
    (sum, provider) => sum + ((provider.currentHealth || 0) - (provider.monthlyAvg || 0)),
    0
  )
  const isTrendingUp = totalChange >= 0
  const trendPercentage =
    totalMonthly > 0 ? Math.abs((totalChange / totalMonthly) * 100).toFixed(1) : '0.0'

  // Build chart config for any wrappers/legends (optional)
  const chartConfig = useMemo(() => {
    return chartData.reduce((config, provider) => {
      config[provider.id] = {
        label: provider.name,
        color: provider.color
      }
      return config
    }, {})
  }, [chartData])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div
          className="mx-auto w-full"
          style={{
            maxWidth,
            maxHeight,
            minHeight: 180,
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          <ChartContainer config={chartConfig}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{
                  top: 16,
                  right: 20,
                  left: 20,
                  bottom: 16
                }}
                layout="vertical"
              >
                <CartesianGrid horizontal={false} />
                <YAxis
                  dataKey="name"
                  type="category"
                  tickLine={false}
                  axisLine={false}
                  width={100}
                />
                <XAxis
                  type="number"
                  domain={[0, 100]}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => `${v}%`}
                />
                <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
                <Bar
                  dataKey="currentHealth"
                  radius={[0, 4, 4, 0]}
                  isAnimationActive={false}
                  name="Current Health"
                  label={false}
                >
                  {chartData.map((entry, idx) => (
                    <Cell key={`cell-${idx}`} fill={entry.color} />
                  ))}
                  <LabelList
                    dataKey="currentHealth"
                    position="right"
                    offset={10}
                    className="fill-foreground"
                    fontSize={12}
                    formatter={(value) => `${value}%`}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </div>
      </CardContent>
      <CardContent className="flex-col items-start justify-center gap-2 text-sm pt-0">
        <div className="flex gap-2 justify-center leading-none font-medium">
          {isTrendingUp ? (
            <>
              Trending up by {trendPercentage}% this month <TrendingUp className="h-4 w-4" />
            </>
          ) : (
            <>
              Trending down by {trendPercentage}% this month <TrendingDown className="h-4 w-4" />
            </>
          )}
        </div>
        {footerText && (
          <div className="text-muted-foreground leading-none text-center">{footerText}</div>
        )}
      </CardContent>
    </Card>
  )
}
