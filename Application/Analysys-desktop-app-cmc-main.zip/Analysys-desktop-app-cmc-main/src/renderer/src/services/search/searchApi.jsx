import { api } from '@/lib/axios-instance'

// Search channels with optional query and limit
export const searchLogos = async (query = '', limit = 1000) => {
  const response = await api.get('/search', {
    params: { q: query, limit }
  })
  return response?.data
}

// Get all channels
export const getAllChannels = async ({ limit = 50 }) => {
  const response = await api.get('/search/channels', {
    params: { limit }
  })
  return response?.data
}

// Get channel by ID
export const getChannelById = async (id) => {
  const response = await api.get(`/search/channel/${id}`)
  return response?.data
}

// Get suggestions for autocomplete
export const getSuggestions = async ({ query, limit = 5 }) => {
  const response = await api.get('/search/suggestions', {
    params: { q: query, limit }
  })
  return response?.data
}

// Get channels by category
export const getChannelsByCategory = async ({ category, limit = 20 }) => {
  const response = await api.get(`/search/category/${category}`, {
    params: { limit }
  })
  return response?.data
}

// Get available filters
export const getFilters = async () => {
  const response = await api.get('/search/filters')
  return response?.data
}

// Saved Searches
export const getRecentSearches = async (pageSize = 100000) => {
  const response = await api.get(`/recent-searches`, {
    params: {
      pageSize
    }
  })
  return response?.data
}

export const getRecentSearchesByType = async (type, pageSize = 100000) => {
  const response = await api.get(`/recent-searches/type/${type}`, {
    params: {
      pageSize
    }
  })
  return response?.data
}

export const createAndupdateSearch = async (data) => {
  const response = await api.post('/recent-searches/', data)
  return response?.data
}

export const deleteRecentSearch = async (id) => {
  const response = await api.delete(`/recent-searches/${id}`)
  return response?.data
}
