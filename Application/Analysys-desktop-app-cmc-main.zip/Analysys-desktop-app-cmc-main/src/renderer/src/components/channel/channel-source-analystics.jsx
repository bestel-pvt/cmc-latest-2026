import { format, formatDistanceToNow, parseISO, subSeconds } from 'date-fns'
import {
  Activity,
  Satellite,
  Wifi,
  ArrowUp,
  ArrowDown,
  HardDrive,
  Circle,
  AlertCircle
} from 'lucide-react'

import { useQuery } from '@tanstack/react-query'
import { channelSourceAnalytics } from '@/services/channels/channelApi'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Badge } from '../ui/badge'
import { Progress } from '../ui/progress'
import { getPriorityLabel } from '@/lib/utils'

const ChannelSourceAnalytics = ({ id }) => {
  const { data, isPending } = useQuery({
    queryKey: ['channel-sources', id],
    queryFn: () => channelSourceAnalytics(id),
    enabled: !!id
  })

  const sources = data?.data
  console.log('Source Ans ', sources)
  if (isPending) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Source Analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8 text-muted-foreground">
            <AlertCircle className="w-5 h-5 " />
            No analytics data available
          </div>
        </CardContent>
      </Card>
    )
  }

  const formatBytes = (bytes) => {
    if (!bytes) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const getSourceIcon = (type) => {
    switch (type) {
      case 'SATELLITE':
        return <Satellite className="w-5 h-5" />
      case 'PTCL':
        return <Wifi className="w-5 h-5" />
      default:
        return <HardDrive className="w-5 h-5" />
    }
  }

  const getStatusIndicator = (isActive) => {
    return isActive ? (
      <Circle className="w-3 h-3 fill-green-500 text-green-500" />
    ) : (
      <Circle className="w-3 h-3 fill-red-500 text-red-500" />
    )
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'Never'
    try {
      return formatDistanceToNow(parseISO(dateString), { addSuffix: true })
    } catch {
      return 'Invalid date'
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Activity className="w-5 h-5" />
          Source Analytics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sources?.map((source) => (
            <div key={source.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  {getSourceIcon(source.source?.type)}
                  <span className="font-medium">{source.source?.type || 'Unknown Source'}</span>
                  {getStatusIndicator(source.isCurrentlyActive)}
                  {source.source?.isPrimary && <Badge variant="secondary">Primary</Badge>}
                </div>
                <Badge variant="outline">
                  Priority: {getPriorityLabel(source.source?.priority)}
                </Badge>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <ArrowUp className="w-4 h-4 mr-1" />
                    Packets
                  </div>
                  <div className="font-medium">{Number(source.totalPackets) || 0}</div>
                  <div className="text-sm text-muted-foreground">
                    {source.avgPacketsPerSec
                      ? `${source.avgPacketsPerSec.toFixed(1)}/sec`
                      : '0/sec'}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <ArrowDown className="w-4 h-4 mr-1" />
                    Data
                  </div>
                  <div className="font-medium">{formatBytes(Number(source?.totalBytes) || 0)}</div>
                  <div className="text-sm text-muted-foreground">
                    {source.avgBytesPerSec
                      ? `${formatBytes(source.avgBytesPerSec)}/sec`
                      : '0 Bytes/sec'}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Health Status</span>
                  <span>
                    {source.healthyPeriods || 0} healthy / {source.unhealthyPeriods || 0} unhealthy
                  </span>
                </div>
                <Progress
                  value={
                    source.healthyPeriods
                      ? (source.healthyPeriods /
                          (source.healthyPeriods + source.unhealthyPeriods)) *
                        100
                      : 0
                  }
                />
              </div>

              <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Last Healthy</div>
                  <div>{formatDate(source.lastHealthyAt)}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Last Unhealthy</div>
                  <div>{formatDate(source.lastUnhealthyAt)}</div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Connection</div>
                  {source.source?.ip || 'N/A'}:{source.source?.port || 'N/A'}
                </div>
                <div>
                  <div className="text-muted-foreground">Uptime</div>
                  <div>
                    {' '}
                    {formatDistanceToNow(subSeconds(new Date(), source?.totalUptime), {
                      includeSeconds: false
                    })}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

export default ChannelSourceAnalytics
