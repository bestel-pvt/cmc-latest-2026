const multer = require('multer');
const path = require('path');
const fs = require('fs/promises');
const mime = require('mime-types');
const Joi = require('joi');
const { fileParamsSchema, fileListSchema } = require('../utils/uploadSchemas.js');


// Create uploads directory structure
const BASE_DATA_DIR = path.join(process.cwd(), 'data')
const UPLOADS_DIR = path.join(BASE_DATA_DIR, 'uploads')
const IMAGES_DIR = path.join(UPLOADS_DIR, 'images')
const VIDEOS_DIR = path.join(UPLOADS_DIR, 'videos')
const DOCUMENTS_DIR = path.join(UPLOADS_DIR, 'documents')
const OTHERS_DIR = path.join(UPLOADS_DIR, 'others')


// Ensure directories exist
const ensureDirectories = async () => {
    const dirs = [UPLOADS_DIR, IMAGES_DIR, VIDEOS_DIR, DOCUMENTS_DIR, OTHERS_DIR];
    for (const dir of dirs) {
        try {
            await fs.access(dir);
        } catch {
            await fs.mkdir(dir, { recursive: true });
        }
    }
};

// Initialize directories
ensureDirectories();

// Helper function to determine file category
const getFileCategory = (mimetype) => {
    if (mimetype.startsWith('image/')) return 'images';
    if (mimetype.startsWith('video/')) return 'videos';
    if (mimetype.includes('pdf') || mimetype.includes('document') ||
        mimetype.includes('text') || mimetype.includes('spreadsheet') ||
        mimetype.includes('presentation')) return 'documents';
    return 'others';
};

// Helper function to get storage directory
const getStorageDir = (category) => {
    switch (category) {
        case 'images': return IMAGES_DIR;
        case 'videos': return VIDEOS_DIR;
        case 'documents': return DOCUMENTS_DIR;
        default: return OTHERS_DIR;
    }
};

// Configure multer storage
const storage = multer.diskStorage({
    destination: async (req, file, cb) => {
        try {
            const category = getFileCategory(file.mimetype);
            const storageDir = getStorageDir(category);

            // Ensure specific category directory exists
            try {
                await fs.access(storageDir);
            } catch {
                await fs.mkdir(storageDir, { recursive: true });
            }

            cb(null, storageDir);
        } catch (error) {
            cb(error);
        }
    },
    filename: (req, file, cb) => {
        // Generate unique filename with timestamp
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        const name = path.basename(file.originalname, ext);
        const sanitizedName = name.replace(/[^a-zA-Z0-9]/g, '-');
        cb(null, `${sanitizedName}-${uniqueSuffix}${ext}`);
    }
});

// File filter for security
const fileFilter = (req, file, cb) => {
    // List of allowed mime types
    const allowedTypes = [
        // Images
        'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml',
        // Videos
        'video/mp4', 'video/mpeg', 'video/quicktime', 'video/x-msvideo', 'video/webm',
        // Documents
        'application/pdf', 'text/plain', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        // Archives
        'application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed',
        // Others
        'application/json', 'text/csv'
    ];

    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error(`File type ${file.mimetype} is not allowed`), false);
    }
};

// Configure multer
const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 100 * 1024 * 1024, // 100MB limit
        files: 10 // Maximum 10 files at once
    }
});

// Upload single file
const uploadSingleFile = async (req, res) => {
    try {
        const uploadSingle = upload.single('file');
        uploadSingle(req, res, async (err) => {
            if (err instanceof multer.MulterError) {
                if (err.code === 'LIMIT_FILE_SIZE') {
                    return res.status(400).json({
                        success: false,
                        message: 'File too large. Maximum size is 100MB.'
                    });
                }
                return res.status(400).json({
                    success: false,
                    message: `Upload error: ${err.message}`
                });
            } else if (err) {
                return res.status(400).json({
                    success: false,
                    message: err.message
                });
            }

            if (!req.file) {
                return res.status(400).json({
                    success: false,
                    message: 'No file uploaded'
                });
            }

            // Validate file params (category, filename)
            const category = getFileCategory(req.file.mimetype);
            const { error: paramError } = fileParamsSchema.validate({ category, filename: req.file.filename });
            if (paramError) {
                return res.status(400).json({
                    success: false,
                    message: paramError.details[0].message
                });
            }

            const baseUrl = `${req.protocol}://${req.get('host')}`;
            const fileUrl = `${baseUrl}/api/uploads/${category}/${req.file.filename}`;

            res.status(201).json({
                success: true,
                data: {
                    filename: req.file.filename,
                    originalName: req.file.originalname,
                    mimetype: req.file.mimetype,
                    size: req.file.size,
                    category: category,
                    url: fileUrl,
                    path: req.file.path
                },
                message: 'File uploaded successfully'
            });
        });
    } catch (error) {
        console.error('Error uploading file:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

// Upload multiple files
const uploadMultipleFiles = async (req, res) => {
    try {
        const uploadMultiple = upload.array('files', 10);
        uploadMultiple(req, res, async (err) => {
            if (err instanceof multer.MulterError) {
                if (err.code === 'LIMIT_FILE_SIZE') {
                    return res.status(400).json({
                        success: false,
                        message: 'One or more files are too large. Maximum size is 100MB per file.'
                    });
                }
                if (err.code === 'LIMIT_FILE_COUNT') {
                    return res.status(400).json({
                        success: false,
                        message: 'Too many files. Maximum 10 files allowed.'
                    });
                }
                return res.status(400).json({
                    success: false,
                    message: `Upload error: ${err.message}`
                });
            } else if (err) {
                return res.status(400).json({
                    success: false,
                    message: err.message
                });
            }

            if (!req.files || req.files.length === 0) {
                return res.status(400).json({
                    success: false,
                    message: 'No files uploaded'
                });
            }

            const baseUrl = `${req.protocol}://${req.get('host')}`;
            const uploadedFiles = req.files.map(file => {
                const category = getFileCategory(file.mimetype);
                // Validate file params for each file
                const { error: paramError } = fileParamsSchema.validate({ category, filename: file.filename });
                if (paramError) {
                    return {
                        error: paramError.details[0].message,
                        filename: file.filename
                    };
                }
                return {
                    filename: file.filename,
                    originalName: file.originalname,
                    mimetype: file.mimetype,
                    size: file.size,
                    category: category,
                    url: `${baseUrl}/api/uploads/${category}/${file.filename}`,
                    path: file.path
                };
            });

            // Check for any validation errors
            const errors = uploadedFiles.filter(f => f.error);
            if (errors.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: `Validation error(s): ${errors.map(e => e.error).join(', ')}`,
                    errors
                });
            }

            res.status(201).json({
                success: true,
                data: {
                    files: uploadedFiles,
                    count: uploadedFiles.length
                },
                message: `${uploadedFiles.length} files uploaded successfully`
            });
        });
    } catch (error) {
        console.error('Error uploading files:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

// Serve file
const serveFile = async (req, res) => {
    try {
        const { category, filename } = req.params;
        // Joi validation
        const { error: paramError } = fileParamsSchema.validate({ category, filename });
        if (paramError) {
            return res.status(400).json({
                success: false,
                message: paramError.details[0].message
            });
        }

        const filePath = path.join(getStorageDir(category), filename);

        try {
            // Check if file exists
            await fs.access(filePath);

            // Get file stats
            const stats = await fs.stat(filePath);

            // Set appropriate headers
            const mimeType = mime.lookup(filePath) || 'application/octet-stream';
            res.setHeader('Content-Type', mimeType);
            res.setHeader('Content-Length', stats.size);
            res.setHeader('Cache-Control', 'public, max-age=86400'); // 24 hours cache

            // Send file
            res.sendFile(filePath);

        } catch (error) {
            return res.status(404).json({
                success: false,
                message: 'File not found'
            });
        }
    } catch (error) {
        console.error('Error serving file:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

// Delete file
const deleteFile = async (req, res) => {
    try {
        const { category, filename } = req.params;
        // Joi validation
        const { error: paramError } = fileParamsSchema.validate({ category, filename });
        if (paramError) {
            return res.status(400).json({
                success: false,
                message: paramError.details[0].message
            });
        }

        const filePath = path.join(getStorageDir(category), filename);

        try {
            // Check if file exists
            await fs.access(filePath);

            // Delete file
            await fs.unlink(filePath);

            res.status(200).json({
                success: true,
                message: 'File deleted successfully'
            });

        } catch (error) {
            if (error.code === 'ENOENT') {
                return res.status(404).json({
                    success: false,
                    message: 'File not found'
                });
            }
            throw error;
        }
    } catch (error) {
        console.error('Error deleting file:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

// Get file info
const getFileInfo = async (req, res) => {
    try {
        const { category, filename } = req.params;
        // Joi validation
        const { error: paramError } = fileParamsSchema.validate({ category, filename });
        if (paramError) {
            return res.status(400).json({
                success: false,
                message: paramError.details[0].message
            });
        }

        const filePath = path.join(getStorageDir(category), filename);

        try {
            // Check if file exists and get stats
            const stats = await fs.stat(filePath);
            const mimeType = mime.lookup(filePath) || 'application/octet-stream';
            const baseUrl = `${req.protocol}://${req.get('host')}`;

            res.status(200).json({
                success: true,
                data: {
                    filename: filename,
                    category: category,
                    mimetype: mimeType,
                    size: stats.size,
                    created: stats.birthtime,
                    modified: stats.mtime,
                    url: `${baseUrl}/api/uploads/${category}/${filename}`
                },
                message: 'File info retrieved successfully'
            });

        } catch (error) {
            if (error.code === 'ENOENT') {
                return res.status(404).json({
                    success: false,
                    message: 'File not found'
                });
            }
            throw error;
        }
    } catch (error) {
        console.error('Error getting file info:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

// List files in category
const listFiles = async (req, res) => {
    try {
        const { category } = req.params;
        const { page = 1, limit = 20 } = req.query;
        // Joi validation
        const { error: paramError } = fileListSchema.validate({ category, page, limit });
        if (paramError) {
            return res.status(400).json({
                success: false,
                message: paramError.details[0].message
            });
        }

        const storageDir = getStorageDir(category);

        try {
            const files = await fs.readdir(storageDir);
            const baseUrl = `${req.protocol}://${req.get('host')}`;

            // Get file stats for each file
            const fileInfoPromises = files.map(async (filename) => {
                try {
                    const filePath = path.join(storageDir, filename);
                    const stats = await fs.stat(filePath);
                    const mimeType = mime.lookup(filePath) || 'application/octet-stream';

                    return {
                        filename: filename,
                        mimetype: mimeType,
                        size: stats.size,
                        created: stats.birthtime,
                        modified: stats.mtime,
                        url: `${baseUrl}/api/uploads/${category}/${filename}`
                    };
                } catch {
                    return null; // Skip files that can't be accessed
                }
            });

            const fileInfos = (await Promise.all(fileInfoPromises)).filter(Boolean);

            // Pagination
            const startIndex = (parseInt(page) - 1) * parseInt(limit);
            const endIndex = startIndex + parseInt(limit);
            const paginatedFiles = fileInfos.slice(startIndex, endIndex);

            res.status(200).json({
                success: true,
                data: paginatedFiles,
                pagination: {
                    currentPage: parseInt(page),
                    totalPages: Math.ceil(fileInfos.length / parseInt(limit)),
                    totalFiles: fileInfos.length,
                    hasNext: endIndex < fileInfos.length,
                    hasPrev: startIndex > 0
                },
                message: `Retrieved ${paginatedFiles.length} files from ${category} category`
            });

        } catch (error) {
            if (error.code === 'ENOENT') {
                return res.status(200).json({
                    success: true,
                    data: [],
                    pagination: {
                        currentPage: parseInt(page),
                        totalPages: 0,
                        totalFiles: 0,
                        hasNext: false,
                        hasPrev: false
                    },
                    message: `No files found in ${category} category`
                });
            }
            throw error;
        }
    } catch (error) {
        console.error('Error listing files:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

module.exports = {
    uploadSingleFile,
    uploadMultipleFiles,
    serveFile,
    deleteFile,
    getFileInfo,
    listFiles
}
