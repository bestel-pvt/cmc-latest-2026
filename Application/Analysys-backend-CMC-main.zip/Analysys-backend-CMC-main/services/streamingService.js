
const { spawn } = require('child_process')
const queries = require('../queries')
const { generateUdpLink } = require('../utils/helpers.js')
const fs = require('fs-extra')
const path = require('path')
const express = require('express')
const http = require('http')
const recordingService = require('./recordingService.js')
const { streamsDir, ffmpegStatic } = require('../utils/path.js')
const { ProcessStateQueries } = require('../queries')



// Store active streaming processes
const activeStreams = new Map()

class StreamingService {
    constructor() {
        this.basePort = 8080 // Base port for HTTP streaming
        this.streamsDir = streamsDir
        this.httpServers = new Map() // Store HTTP servers for each stream
        this.processStates = new Map() // Store process state IDs
        this.ensureStreamsDirectory()
        this.recoverActiveStreams() // Recover streams on startup
    }

    async ensureStreamsDirectory() {
        try {
            await fs.ensureDir(this.streamsDir)
        } catch (error) {
            console.error('Failed to create streams directory:', error)
            throw new Error('Failed to initialize streams directory')
        }
    }

    // Recover active streams after system restart
    async recoverActiveStreams() {
        try {

            // await ProcessStateQueries.deleteAllProcessStates()
            const activeStates = ProcessStateQueries.getActiveProcessStates()
            const streamStates = activeStates.filter(state => state.processType === 'streaming')

            if (streamStates.length === 0) {
                console.log('✅ No active streams to recover')
                return
            }

            console.log(`📡 Found ${streamStates.length} active streams to recover`)

            for (const state of streamStates) {
                try {
                    console.log(`🔄 Recovering stream for channel ${state.channelId}...`)

                    // Get channel details
                    const channel = await queries.ChannelQueries.getChannelById(state.channelId)

                    if (!channel || !channel.isActive) {
                        console.log(`⚠️ Channel ${state.channelId} is not active, marking state as stopped`)
                        ProcessStateQueries.updateProcessState(state.id, { status: 'stopped' })
                        continue
                    }

                    // Restart the stream
                    await this.startStreaming(state.channelId)
                    console.log(`✅ Successfully recovered stream for channel ${state.channelId}`)

                } catch (error) {
                    console.error(`❌ Failed to recover stream for channel ${state.channelId}:`, error.message)
                    // Mark as failed in database
                    ProcessStateQueries.updateProcessState(state.id, { status: 'failed' })
                }
            }

            console.log('✅ Stream recovery process completed')
        } catch (error) {
            console.error('❌ Error during stream recovery:', error)
        }
    }

    // Find next available port for HTTP streaming
    findAvailablePort() {
        let port = this.basePort
        while (this.isPortInUse(port)) {
            port++
        }
        return port
    }

    // Check if port is already in use by active streams or system
    isPortInUse(port) {
        // Check active streams
        for (const [channelId, stream] of activeStreams.entries()) {
            if (stream.httpPort === port) {
                return true
            }
        }

        // Check if HTTP server exists for this port
        if (this.httpServers.has(port)) {
            return true
        }

        return false
    }

    // Create HTTP server to serve HLS files
    createHttpServer(channelId, httpPort) {
        const app = express()

        // Enable CORS for streaming
        app.use((req, res, next) => {
            res.header('Access-Control-Allow-Origin', '*')
            res.header('Access-Control-Allow-Methods', 'GET, OPTIONS')
            res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
            if (req.method === 'OPTIONS') {
                res.sendStatus(200)
            } else {
                next()
            }
        })

        // Serve HLS playlist with proper MIME type
        app.get('/playlist.m3u8', (req, res) => {
            const playlistPath = path.join(this.streamsDir, `stream_${channelId}.m3u8`)
            const altPlaylistPath = path.join(this.streamsDir, `stream_${channelId}_alt.m3u8`)

            // Try main playlist first, then alternative
            let finalPath = playlistPath
            if (!fs.existsSync(playlistPath) && fs.existsSync(altPlaylistPath)) {
                finalPath = altPlaylistPath
            }

            if (fs.existsSync(finalPath)) {
                res.setHeader('Content-Type', 'application/vnd.apple.mpegurl')
                res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')
                res.setHeader('Pragma', 'no-cache')
                res.setHeader('Expires', '0')
                res.sendFile(finalPath)
            } else {
                res.status(404).send('Playlist not found')
            }
        })

        // Serve all .ts segment files
        app.get('/*.ts', (req, res) => {
            const fileName = req.params[0] + '.ts'
            const filePath = path.join(this.streamsDir, fileName)

            if (fs.existsSync(filePath)) {
                res.setHeader('Content-Type', 'video/mp2t')
                res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')
                res.setHeader('Pragma', 'no-cache')
                res.setHeader('Expires', '0')
                res.sendFile(filePath)
            } else {
                res.status(404).send('Segment not found')
            }
        })

        const server = http.createServer(app)

        // Handle server errors
        server.on('error', (error) => {
            console.error(`HTTP server error for channel ${channelId}:`, error)
            if (error.code === 'EADDRINUSE') {
                console.error(`Port ${httpPort} is already in use for channel ${channelId}`)
            }
        })

        server.listen(httpPort, '0.0.0.0', (error) => {
            if (error) {
                console.error(`Failed to start HTTP server for channel ${channelId} on port ${httpPort}:`, error)
                throw error
            }
            console.log(`HTTP server for channel ${channelId} listening on port ${httpPort}`)
            // Track the server
            this.httpServers.set(httpPort, server)
        })

        return server
    }

    async validateUdpStream(ip, port, timeoutMs = 5000) {
        return new Promise((resolve) => {
            console.log(`Validating UDP stream at ${ip}:${port}`)

            const probeArgs = [
                '-f', 'mpegts',
                '-i', `udp://${ip}:${port}?timeout=5000000`,
                '-t', '1',
                '-f', 'null',
                '-'
            ]

            const probeProcess = spawn(ffmpegStatic, probeArgs, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            let streamFound = false
            const timeout = setTimeout(() => {
                if (!probeProcess.killed) {
                    probeProcess.kill('SIGTERM')
                }
                resolve({
                    valid: streamFound,
                    message: streamFound ? 'Stream detected' : 'Validation timeout - stream may still be valid'
                })
            }, timeoutMs)

            probeProcess.stderr.on('data', (data) => {
                const output = data.toString()
                if (output.includes('Stream #') || output.includes('Input #') || output.includes('Video:') || output.includes('Audio:')) {
                    streamFound = true
                    console.log(`UDP stream validation: Stream detected at ${ip}:${port}`)
                }
            })

            probeProcess.on('exit', (code) => {
                clearTimeout(timeout)
                resolve({
                    valid: streamFound || code === 0,
                    message: streamFound ? 'Stream validated successfully' : 'No stream detected but may still work'
                })
            })

            probeProcess.on('error', (error) => {
                clearTimeout(timeout)
                console.warn(`Stream validation error for ${ip}:${port}:`, error.message)
                resolve({
                    valid: false,
                    message: 'Validation failed - but streaming may still work'
                })
            })
        })
    }

    async startStreaming(channelId) {
        try {
            // Check if channel is already being streamed
            if (activeStreams.has(channelId)) {
                const existingStream = activeStreams.get(channelId)
                return {
                    success: true,
                    message: 'Stream already active',
                    data: {
                        channelId: channelId,
                        httpUrl: `http://localhost:${existingStream.httpPort}/playlist.m3u8`,
                        isActive: true,
                        startTime: existingStream.startTime
                    }
                }
            }

            // Get channel with primary source
            const channel = await queries.ChannelQueries.getChannelById(channelId)

            if (!channel) {
                throw new Error('Channel not found')
            }

            if (!channel.isActive) {
                throw new Error('Channel is not active')
            }

            const primarySource = channel.sources && channel.sources.length > 0 ? channel.sources[0] : null
            if (!primarySource) {
                throw new Error('No primary source found for this channel')
            }

            // Generate UDP link from primary source
            const udpLink = generateUdpLink(primarySource.ip, primarySource.port)
            console.log(`Generated UDP link for streaming: ${udpLink}`)

            // Validate the UDP stream
            const validation = await this.validateUdpStream(primarySource.ip, primarySource.port)
            console.log(`Stream validation result: ${validation.message}`)

            // Find available HTTP port
            const httpPort = this.findAvailablePort()

            // Create HTTP server to serve HLS files
            const httpServer = this.createHttpServer(channelId, httpPort)

            // Create FFmpeg process for UDP to HLS streaming
            const ffmpegProcess = this.createStreamingProcess(udpLink, httpPort, channelId)

            // Persist process state to database for recovery
            const processState = ProcessStateQueries.createProcessState({
                channelId: channelId,
                processType: 'streaming',
                status: 'active',
                httpPort: httpPort,
                udpLink: udpLink,
                startTime: new Date().toISOString(),
                metadata: {
                    channelName: channel.name,
                    sourceIp: primarySource.ip,
                    sourcePort: primarySource.port
                }
            })

            // Store the active stream
            activeStreams.set(channelId, {
                process: ffmpegProcess,
                httpServer: httpServer,
                httpPort: httpPort,
                udpLink: udpLink,
                startTime: new Date(),
                channelName: channel.name,
                stateId: processState.id
            })

            // Store state ID for later cleanup
            this.processStates.set(channelId, processState.id)

            return {
                success: true,
                message: 'Streaming started successfully',
                data: {
                    channelId: channel.id,
                    channelName: channel.name,
                    httpUrl: `http://localhost:${httpPort}/playlist.m3u8`,
                    udpLink: udpLink,
                    httpPort: httpPort,
                    isActive: true
                }
            }

        } catch (error) {
            console.error('Start streaming error:', error)
            throw error
        }
    }

    createStreamingProcess(udpLink, httpPort, channelId) {
        console.log(`Starting UDP to HLS file streaming for channel ${channelId} on port ${httpPort}`)

        // Extract IP and port from UDP link
        const urlMatch = udpLink.match(/udp:\/\/([^:]+):(\d+)/)
        if (!urlMatch) {
            throw new Error(`Invalid UDP link format: ${udpLink}`)
        }

        const [, ip, port] = urlMatch

        // Create channel-specific directory for HLS files
        const channelStreamDir = path.join(this.streamsDir)
        const playlistPath = path.join(channelStreamDir, `stream_${channelId}.m3u8`)
        const segmentPattern = path.join(channelStreamDir, `stream_${channelId}_%03d.ts`)

        console.log(`HLS playlist will be created at: ${playlistPath}`)
        console.log(`HLS segments pattern: ${segmentPattern}`)

        // FFmpeg command for UDP to HLS file streaming with transcoding
        // Transcoding ensures browser compatibility (H.264 + AAC format)
        const ffmpegArgs = [
            // Input settings - improved for corrupted/unstable streams
            '-f', 'mpegts',
            '-i', `udp://${ip}:${port}?localport=0&reuseaddr=1&fifo_size=1000000&overrun_nonfatal=1`,

            // Enhanced error handling and stream processing
            '-fflags', '+genpts+discardcorrupt+nobuffer+igndts',
            '-flags', 'low_delay',
            '-avoid_negative_ts', 'make_zero',
            '-analyzeduration', '1000000',
            '-probesize', '2000000',
            '-err_detect', 'ignore_err', // Ignore decoder errors

            // Video transcoding to H.264 for browser compatibility
            '-c:v', 'libx264',
            '-preset', 'veryfast',        // Fast encoding for low latency
            '-tune', 'zerolatency',       // Optimize for streaming
            '-profile:v', 'baseline',     // Maximum browser compatibility
            '-level', '3.0',              // Compatible with most devices
            '-pix_fmt', 'yuv420p',        // Standard pixel format for web
            '-b:v', '2500k',              // Video bitrate (adjust based on source)
            '-maxrate', '2500k',
            '-bufsize', '5000k',
            '-g', '50',                   // GOP size (keyframe interval)
            '-sc_threshold', '0',         // Disable scene change detection for consistent segments

            // Audio transcoding to AAC for browser compatibility
            '-c:a', 'aac',
            '-b:a', '128k',               // Audio bitrate
            '-ar', '44100',               // Sample rate
            '-ac', '2',                   // Stereo audio

            // HLS output settings optimized for low latency (FILE OUTPUT, NOT HTTP)
            '-f', 'hls',
            '-hls_time', '2',                    // 2-second segments for low latency
            '-hls_list_size', '10',              // Keep more segments to avoid conflicts (20 seconds buffer)
            '-hls_flags', 'delete_segments+discont_start+independent_segments',
            '-hls_segment_type', 'mpegts',
            '-hls_segment_filename', segmentPattern,
            '-hls_allow_cache', '0',
            '-hls_delete_threshold', '3',        // Only delete after 3 segments to avoid conflicts
            '-start_number', '0',
            playlistPath  // Output to file, NOT HTTP URL
        ]

        console.log(`FFmpeg HLS streaming command (with transcoding): ${ffmpegStatic} ${ffmpegArgs.join(' ')}`)
        console.log(`Note: Transcoding to H.264/AAC for maximum browser compatibility`)
        console.log(`Files will be served by Express server on port ${httpPort}`)

        // Spawn FFmpeg process
        const ffmpegProcess = spawn(ffmpegStatic, ffmpegArgs, {
            stdio: ['pipe', 'pipe', 'pipe'],
            windowsHide: true
        })

        let streamingStarted = false
        let startTimeout = null

        // Handle stdout
        ffmpegProcess.stdout.on('data', (data) => {
            const output = data.toString()
            if (output.includes('Opening') && !streamingStarted) {
                streamingStarted = true
                console.log(`HLS streaming started for channel ${channelId} on port ${httpPort}`)
            }
        })

        // Handle stderr for progress and error information
        ffmpegProcess.stderr.on('data', (data) => {
            const output = data.toString()

            // Log successful stream start
            if ((output.includes('Opening') || output.includes('Stream') || output.includes('frame=') || output.includes('segment')) && !streamingStarted) {
                streamingStarted = true
                console.log(`HLS streaming started successfully for channel ${channelId} on port ${httpPort}`)
                if (startTimeout) {
                    clearTimeout(startTimeout)
                }
            }

            // Log progress information (less verbose for streaming)
            if (output.includes('frame=') || output.includes('time=')) {
                const timeMatch = output.match(/time=(\d{2}:\d{2}:\d{2}.\d{2})/)
                if (timeMatch) {
                    // Only log every 30 seconds to reduce spam
                    const currentTime = timeMatch[1]
                    const seconds = parseInt(currentTime.split(':')[2])
                    if (seconds % 30 === 0) {
                        console.log(`Streaming ${channelId} progress: ${currentTime}`)
                    }
                }
            }

            // Log HLS segment creation
            if (output.includes('segment') || output.includes('.ts')) {
                console.log(`HLS ${channelId} segment: ${output.trim()}`)
            }

            // Log connection info
            if (output.includes('Opening') || output.includes('Stream') || output.includes('Input')) {
                console.log(`Streaming ${channelId} info: ${output.trim()}`)
            }

            // Log warnings/errors (but don't fail on many common warnings)
            if (output.includes('error') || output.includes('Error')) {
                // Filter out common H.264 decoder warnings that don't affect streaming
                if (!output.includes('decode_slice_header') &&
                    !output.includes('no frame') &&
                    !output.includes('non-existing PPS') &&
                    !output.includes('Last message repeated')) {
                    console.warn(`Streaming ${channelId} error: ${output.trim()}`)
                }
            } else if (output.includes('WARNING') || output.includes('warning')) {
                // Only log significant warnings
                if (output.includes('timeout') || output.includes('connection')) {
                    console.warn(`Streaming ${channelId} warning: ${output.trim()}`)
                }
            }
        })

        // Handle process exit
        ffmpegProcess.on('exit', (code, signal) => {
            if (startTimeout) {
                clearTimeout(startTimeout)
            }

            console.log(`Streaming ${channelId} process exited with code ${code}, signal: ${signal}`)

            // Update process state in database
            const stream = activeStreams.get(channelId)
            if (stream && stream.stateId) {
                try {
                    ProcessStateQueries.updateProcessState(stream.stateId, {
                        status: code === 0 || signal === 'SIGTERM' || signal === 'SIGINT' ? 'stopped' : 'failed'
                    })
                } catch (error) {
                    console.error(`Failed to update process state for channel ${channelId}:`, error)
                }
            }

            // Clean up HLS files safely
            this.safeCleanupHlsFiles(channelId)

            // Remove from active streams
            if (activeStreams.has(channelId)) {
                activeStreams.delete(channelId)
                console.log(`Removed streaming ${channelId} from active streams`)
            }

            // Remove state ID
            this.processStates.delete(channelId)

            if (code === 0) {
                console.log(`Streaming ${channelId} completed successfully`)
            } else if (signal === 'SIGTERM' || signal === 'SIGINT') {
                console.log(`Streaming ${channelId} was stopped by user`)
            } else {
                console.error(`Streaming ${channelId} failed with exit code ${code}`)

                // Try alternative approach if main method fails
                if (!streamingStarted) {
                    console.log(`Primary streaming method failed, trying alternative for channel ${channelId}`)
                    this.tryAlternativeStreaming(ip, port, httpPort, channelId)
                }
            }
        })

        // Handle process errors
        ffmpegProcess.on('error', (error) => {
            console.error(`Streaming ${channelId} process error:`, error)

            if (!streamingStarted) {
                console.log(`Process error occurred, trying alternative streaming for channel ${channelId}`)
                this.tryAlternativeStreaming(ip, port, httpPort, channelId)
            }
        })

        // Set timeout to detect if streaming never starts
        startTimeout = setTimeout(() => {
            if (!streamingStarted) {
                console.log(`Streaming ${channelId} didn't start within timeout, trying alternative`)
                ffmpegProcess.kill('SIGTERM')
                this.tryAlternativeStreaming(ip, port, httpPort, channelId)
            }
        }, 15000) // 15 second timeout

        return ffmpegProcess
    }

    // Clean up HLS files for a channel - improved to handle file locks
    async cleanupHlsFiles(channelId) {
        try {
            const files = await fs.readdir(this.streamsDir)
            const channelFiles = files.filter(file => file.includes(`stream_${channelId}`))

            for (const file of channelFiles) {
                const filePath = path.join(this.streamsDir, file)

                try {
                    // Check if file exists and is not locked
                    const stats = await fs.stat(filePath)
                    if (stats.isFile()) {
                        // Try to remove with retry logic for file locks
                        await this.removeFileWithRetry(filePath, 3, 1000)
                        console.log(`Cleaned up HLS file: ${file}`)
                    }
                } catch (fileError) {
                    // File might be in use by recording - skip with warning
                    if (fileError.code === 'EBUSY' || fileError.code === 'EACCES') {
                        console.warn(`Skipping cleanup of ${file} - file is in use (likely by recording)`)
                    } else {
                        console.warn(`Failed to cleanup ${file}:`, fileError.message)
                    }
                }
            }
        } catch (error) {
            console.warn(`Failed to cleanup HLS files for channel ${channelId}:`, error)
        }
    }

    // Helper method to retry file removal with exponential backoff
    async removeFileWithRetry(filePath, maxRetries = 3, delayMs = 1000) {
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                await fs.remove(filePath)
                return // Success
            } catch (error) {
                if (attempt === maxRetries) {
                    throw error // Final attempt failed
                }

                // Wait before retry with exponential backoff
                await new Promise(resolve => setTimeout(resolve, delayMs * attempt))
            }
        }
    }

    // Enhanced cleanup that respects active recordings
    async safeCleanupHlsFiles(channelId) {
        try {
            // Check if recording is active for this channel
            const recordingService = require('./recordingService.js')
            const hasActiveRecording = recordingService.hasActiveRecording(channelId)

            if (hasActiveRecording) {
                console.log(`Skipping HLS cleanup for ${channelId} - active recording detected`)
                return
            }

            // Wait a bit for any file handles to be released
            await new Promise(resolve => setTimeout(resolve, 2000))

            // Proceed with cleanup
            await this.cleanupHlsFiles(channelId)
        } catch (error) {
            console.warn(`Safe cleanup failed for channel ${channelId}:`, error)
        }
    }

    async tryAlternativeStreaming(ip, port, httpPort, channelId) {
        try {
            console.log(`Trying alternative HLS streaming for channel ${channelId}`)

            // Alternative: Use simplified HLS with basic settings
            const channelStreamDir = path.join(this.streamsDir)
            const playlistPath = path.join(channelStreamDir, `stream_${channelId}_alt.m3u8`)
            const segmentPattern = path.join(channelStreamDir, `stream_${channelId}_alt_%03d.ts`)

            const altArgs = [
                '-f', 'mpegts',
                '-i', `udp://${ip}:${port}?localport=0&reuseaddr=1&timeout=60000000`,
                '-fflags', '+genpts+discardcorrupt',
                '-c:v', 'copy',
                '-c:a', 'copy',
                // Basic HLS settings
                '-f', 'hls',
                '-hls_time', '4',                    // Longer segments for stability
                '-hls_list_size', '5',
                '-hls_flags', 'delete_segments',
                '-hls_segment_filename', segmentPattern,
                playlistPath
            ]

            console.log(`Alternative HLS streaming: ${ffmpegStatic} ${altArgs.join(' ')}`)

            const altProcess = spawn(ffmpegStatic, altArgs, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            let altStarted = false

            altProcess.stderr.on('data', (data) => {
                const output = data.toString()

                if ((output.includes('Opening') || output.includes('frame=') || output.includes('segment')) && !altStarted) {
                    altStarted = true
                    console.log(`Alternative HLS streaming started for channel ${channelId}`)
                }

                if (output.includes('segment') || output.includes('.ts')) {
                    console.log(`Alternative HLS ${channelId} segment: ${output.trim()}`)
                }
            })

            altProcess.on('exit', (code, signal) => {
                console.log(`Alternative HLS streaming ${channelId} exited with code ${code}`)

                // Update process state
                if (activeStreams.has(channelId)) {
                    const stream = activeStreams.get(channelId)
                    if (stream.stateId) {
                        ProcessStateQueries.updateProcessState(stream.stateId, {
                            status: code === 0 ? 'stopped' : 'failed'
                        })
                    }
                }

                this.cleanupHlsFiles(channelId)
                if (activeStreams.has(channelId)) {
                    activeStreams.delete(channelId)
                }

                if (!altStarted && code !== 0) {
                    console.log(`Alternative HLS also failed for ${channelId}`)
                }
            })

            altProcess.on('error', (error) => {
                console.error(`Alternative HLS streaming error for ${channelId}:`, error)
            })

            // Update active stream with alternative process
            if (activeStreams.has(channelId)) {
                const stream = activeStreams.get(channelId)
                stream.process = altProcess
                stream.isFailover = true
            }

        } catch (error) {
            console.error(`Alternative HLS streaming setup failed for ${channelId}:`, error)
        }
    }    // This method is no longer needed as we're using file-based HLS only
    async tryBasicHttpStreaming(ip, port, httpPort, channelId) {
        console.log(`All streaming methods exhausted for channel ${channelId}`)
        // Clean up and remove from active streams
        this.cleanupHlsFiles(channelId)
        if (activeStreams.has(channelId)) {
            activeStreams.delete(channelId)
        }
    }

    async stopStreaming(channelId) {
        try {
            const activeStream = activeStreams.get(channelId)

            if (!activeStream) {
                throw new Error('No active stream found for this channel')
            }

            // Update process state in database
            if (activeStream.stateId) {
                try {
                    if (activeStream.isFailover) {
                        ProcessStateQueries.deleteProcessState(activeStream.stateId)
                    } else {
                        ProcessStateQueries.updateProcessState(activeStream.stateId, {
                            status: 'stopped'
                        })
                    }
                } catch (error) {
                    console.error(`Failed to update process state for channel ${channelId}:`, error)
                }
            }

            // Kill the FFmpeg process gracefully
            if (activeStream.process) {
                console.log(`Stopping streaming for channel ${channelId}`)

                // Send SIGTERM for graceful shutdown
                activeStream.process.kill('SIGTERM')

                // Fallback: Force kill after 5 seconds if process doesn't respond
                setTimeout(() => {
                    if (activeStream.process && !activeStream.process.killed) {
                        console.log(`Force killing streaming process for channel ${channelId}`)
                        activeStream.process.kill('SIGKILL')
                    }
                }, 5000)
            }

            // Close HTTP server
            if (activeStream.httpServer) {
                const httpPort = activeStream.httpPort
                activeStream.httpServer.close(() => {
                    console.log(`HTTP server for channel ${channelId} closed`)
                    // Remove from server tracking
                    this.httpServers.delete(httpPort)
                })
            }

            // Clean up HLS files safely (respects active recordings)
            await this.safeCleanupHlsFiles(channelId)

            // Remove from active streams
            activeStreams.delete(channelId)

            // Remove state ID
            this.processStates.delete(channelId)

            return {
                success: true,
                message: 'Streaming stopped successfully',
                channelId: channelId
            }

        } catch (error) {
            console.error('Stop streaming error:', error)
            throw error
        }
    }

    async getStreamingStatus(channelId) {
        try {
            const activeStream = activeStreams.get(channelId)

            if (!activeStream) {
                return {
                    isStreaming: false,
                    message: 'No active stream found for this channel'
                }
            }

            // Get channel details
            const channel = await queries.ChannelQueries.getChannelById(channelId)

            return {
                isStreaming: true,
                channelId: channelId,
                channelName: channel ? channel.name : 'Unknown',
                httpUrl: `http://localhost:${activeStream.httpPort}/playlist.m3u8`,
                httpPort: activeStream.httpPort,
                udpLink: activeStream.udpLink,
                startTime: activeStream.startTime,
                duration: Math.floor((new Date() - activeStream.startTime) / 1000)
            }

        } catch (error) {
            console.error('Get streaming status error:', error)
            throw error
        }
    }

    getActiveStreams() {
        const active = []
        for (const [channelId, stream] of activeStreams.entries()) {
            active.push({
                channelId,
                channelName: stream.channelName,
                httpUrl: `http://localhost:${stream.httpPort}/playlist.m3u8`,
                httpPort: stream.httpPort,
                startTime: stream.startTime,
                duration: Math.floor((new Date() - stream.startTime) / 1000)
            })
        }
        return active
    }

    async getAllChannelStreams() {
        try {
            const result = await queries.ChannelQueries.getChannels({
                pageSize: 1000 // Get all active channels
            })
            const channels = result.data

            return channels.map(channel => {
                const activeStream = activeStreams.get(channel.id)
                const primarySource = channel.sources.find(source => source.isPrimary)

                return {
                    channelId: channel.id,
                    channelName: channel.name,
                    description: channel.description,
                    isActive: channel.isActive,
                    isAnyStreamActive: activeStreams.has(channel.id),
                    isAnyRecordingActive: recordingService.hasActiveRecording(channel.id),
                    hasSource: !!primarySource,
                    isStreaming: !!activeStream,
                    httpUrl: activeStream ? `http://localhost:${activeStream.httpPort}/playlist.m3u8` : null,
                    udpLink: primarySource ? generateUdpLink(primarySource.ip, primarySource.port) : null,
                    startTime: activeStream ? activeStream.startTime : null
                }
            })

        } catch (error) {
            console.error('Get all channel streams error:', error)
            throw error
        }
    }

    hasActiveStream(channelId) {
        return activeStreams.has(channelId)
    }
}

module.exports = new StreamingService()
