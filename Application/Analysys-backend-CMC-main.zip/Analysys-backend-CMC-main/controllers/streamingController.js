const streamingService = require('../services/streamingService.js')
const { idSchema } = require('../utils/validation.js')

// Helper function to format validation errors
const formatValidationError = (error) => {
    const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
    }))
    return {
        error: 'Validation failed',
        details: errors
    }
}

// Start streaming for a channel
const startStreaming = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.channelId)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { channelId } = req.params
        const result = await streamingService.startStreaming(channelId)

        res.json(result)
    } catch (error) {
        console.error('Start streaming error:', error)

        let statusCode = 500
        if (error.message.includes('Channel not found')) {
            statusCode = 404
        } else if (error.message.includes('already being streamed') || error.message.includes('not active')) {
            statusCode = 400
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to start streaming'
        })
    }
}

// Stop streaming for a channel
const stopStreaming = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.channelId)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { channelId } = req.params
        const result = await streamingService.stopStreaming(channelId)

        res.json(result)
    } catch (error) {
        console.error('Stop streaming error:', error)

        let statusCode = 500
        if (error.message.includes('No active stream')) {
            statusCode = 404
        }

        res.status(statusCode).json({
            success: false,
            error: error.message || 'Failed to stop streaming'
        })
    }
}

// Get streaming status for a channel
const getStreamingStatus = async (req, res) => {
    try {
        const { error } = idSchema.validate(req.params.channelId)
        if (error) {
            return res.status(400).json(formatValidationError(error))
        }

        const { channelId } = req.params
        const status = await streamingService.getStreamingStatus(channelId)

        res.json({
            success: true,
            ...status
        })
    } catch (error) {
        console.error('Get streaming status error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get streaming status'
        })
    }
}

// Get all active streams
const getActiveStreams = async (req, res) => {
    try {
        const activeStreams = streamingService.getActiveStreams()

        res.json({
            success: true,
            activeStreams,
            count: activeStreams.length
        })
    } catch (error) {
        console.error('Get active streams error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get active streams'
        })
    }
}

// Get all channels with streaming info
const getAllChannelStreams = async (req, res) => {
    try {
        const channelStreams = await streamingService.getAllChannelStreams()

        res.json({
            success: true,
            channels: channelStreams,
            count: channelStreams.length,
            activeCount: channelStreams.filter(channel => channel.isStreaming).length
        })
    } catch (error) {
        console.error('Get all channel streams error:', error)
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to get channel streams'
        })
    }
}

module.exports = {
    startStreaming,
    stopStreaming,
    getStreamingStatus,
    getActiveStreams,
    getAllChannelStreams
}
