import { useChannelAnalytics } from '@/hooks/use-analytics'
import { formatDistanceToNow, formatDuration, intervalToDuration } from 'date-fns'
import React from 'react'
import { toast } from 'react-hot-toast'
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card'
import {
  Activity,
  Clock,
  Download,
  Wifi,
  WifiOff,
  AlertCircle,
  RefreshCw,
  Copy
} from 'lucide-react'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { copyToClipboard, formatNumberShort, getPriorityLabel } from '@/lib/utils'

const ChannelStats = ({ channelId, stats }) => {
  const { data, isLoading, error, refetch } = useChannelAnalytics(channelId)
  console.log('stats', data)

  const channel = data?.data

  // Error handling
  React.useEffect(() => {
    if (error) {
      toast.error('Failed to load channel statistics')
    }
  }, [error])

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-64 space-y-4">
        <div className="flex items-center">
          <AlertCircle className="w-8 h-8 text-red-500 mr-2" />
          <span className="text-lg">Failed to load statistics</span>
        </div>
        <Button onClick={refetch} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Retry
        </Button>
      </div>
    )
  }

  const formatBytes = (bytes) => {
    if (!bytes || bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatRuntime = (seconds) => {
    if (!seconds) return '0'
    const duration = intervalToDuration({ start: 0, end: seconds * 1000 })
    return formatDuration(duration, {
      format: ['hours', 'minutes', 'seconds'],
      zero: false,
      delimiter: ' '
    })
  }

  const safeDateFormat = (dateString) => {
    try {
      return dateString ? formatDistanceToNow(new Date(dateString)) : 'Unknown'
    } catch (err) {
      console.error('Date formatting error:', err)
      return 'Invalid date'
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold tracking-tight">Channel Statistics</h2>
        <Button variant="outline" size="sm" onClick={refetch} disabled={isLoading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {isLoading && !channel ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Current Status</CardTitle>
                {channel?.realtimeStats?.isStreamActive ? (
                  <Wifi className=" text-green-500" />
                ) : (
                  <WifiOff className=" text-red-500" />
                )}
              </CardHeader>
              <CardContent>
                <div>
                  {channel?.realtimeStats?.isStreamActive ? (
                    <h6 className="text-green-500">Active</h6>
                  ) : (
                    <h6 className="text-destructive">Inactive</h6>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Last updated {safeDateFormat(channel?.updatedAt)} ago
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Current Bitrate</CardTitle>
                <Activity className=" text-blue-500" />
              </CardHeader>
              <CardContent>
                <h6>
                  {channel?.realtimeStats?.currentBytesPerSec
                    ? formatBytes(channel.realtimeStats.currentBytesPerSec) + '/s'
                    : '0/s'}
                </h6>
                <p className="text-xs text-muted-foreground mt-2">
                  {channel?.realtimeStats?.currentPacketsPerSec || 0} packets/s
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Session Runtime</CardTitle>
                <Clock className="text-orange-500" />
              </CardHeader>
              <CardContent>
                <p className="font-bold text-base md:text-xl">
                  {formatRuntime(channel?.realtimeStats?.sessionRuntime)}
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Started {safeDateFormat(channel?.createdAt)} ago
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Data</CardTitle>
                <Download className="text-purple-500" />
              </CardHeader>
              <CardContent>
                <h6>{channel?.totalBytes ? formatBytes(parseInt(channel.totalBytes)) : '0'}</h6>
                <p
                  className="text-xs text-muted-foreground mt-2"
                  title={Number(channel?.totalPackets)}
                >
                  {formatNumberShort(Number(channel?.totalPackets)) || 0} total packets
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>
                  <h5>Channel Information</h5>
                </CardTitle>
                <CardDescription>Details about this channel</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center">
                  <span className="font-medium w-32">Name:</span>
                  <span>{channel?.channel?.name || 'N/A'}</span>
                </div>
                <div className="flex items-center">
                  <span className="font-medium w-32">Description:</span>
                  <span>{channel?.channel?.description || 'No description'}</span>
                </div>
                <div className="flex items-center ">
                  <span className="font-medium w-32">Stream Link:</span>
                  <div className="flex gap-3 items-center">
                    <code className=" gap-3">{channel?.channel?.channelStreamLink || 'N/A'}</code>{' '}
                    <Button
                      onClick={() => copyToClipboard(channel?.channel?.channelStreamLink)}
                      size="icon"
                      variant="ghost"
                    >
                      <Copy />
                    </Button>
                  </div>
                </div>
                <div className="flex items-center">
                  <span className="font-medium w-32">Created:</span>
                  <span>{safeDateFormat(channel?.channel?.createdAt)} ago</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <h5>Sources </h5>
                  <Badge variant="pending">
                    Switch Count : {formatNumberShort(channel?.switchCount || 0)}
                  </Badge>
                </CardTitle>
                <CardDescription>Available stream sources</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {channel?.channel?.sources?.length > 0 ? (
                  channel.channel.sources.map((source) => (
                    <div key={source.id} className="border rounded-lg p-3">
                      <div className="flex justify-between items-center">
                        <div className="font-medium">{source.type || 'Unknown'}</div>
                        {source.isPrimary ? (
                          <Badge variant="default">Primary</Badge>
                        ) : (
                          <Badge variant="secondary">Backup</Badge>
                        )}
                      </div>
                      <div className="text-sm mt-1">
                        {source.ip}:{source.port}
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-2">
                        <span>Priority: {getPriorityLabel(source.priority)}</span>
                        <span>{source.isActive ? 'Active' : 'Inactive'}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-sm text-muted-foreground text-center py-4">
                    No sources configured
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  )
}

export default ChannelStats
