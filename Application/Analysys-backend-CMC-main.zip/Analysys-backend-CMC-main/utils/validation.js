const Joi = require('joi')

// ID validation schema
const idSchema = Joi.string().required().messages({
    'string.empty': 'ID is required',
    'any.required': 'ID is required'
})

// Channel validation schemas
const createChannelSchema = Joi.object({
    name: Joi.string().required().min(1).max(255).messages({
        'string.empty': 'Channel name is required',
        'string.min': 'Channel name must be at least 1 character',
        'string.max': 'Channel name cannot exceed 255 characters',
        'any.required': 'Channel name is required'
    }),
    description: Joi.string().optional().allow('').max(1000).messages({
        'string.max': 'Description cannot exceed 1000 characters'
    }),
    isActive: Joi.boolean().optional().default(true),
    logo: Joi.string().optional().allow('').max(500).messages({
        'string.max': 'Logo URL cannot exceed 500 characters'
    }),
    isPriority: Joi.boolean().optional().default(false),
    sources: Joi.array().items(
        Joi.object({
            type: Joi.string().required().messages({
                'string.empty': 'Source type is required',
                'any.required': 'Source type is required'
            }),
            port: Joi.number().integer().min(1).max(65535).required().messages({
                'number.base': 'Port must be a number',
                'number.integer': 'Port must be an integer',
                'number.min': 'Port must be at least 1',
                'number.max': 'Port cannot exceed 65535',
                'any.required': 'Port is required'
            }),
            ip: Joi.string().required().messages({
                'string.empty': 'IP address is required',
                'any.required': 'IP address is required'
            }),
            isActive: Joi.boolean().optional().default(true),
            isPrimary: Joi.boolean().optional().default(false),
            priority: Joi.number().integer().min(0).optional().default(0).messages({
                'number.base': 'Priority must be a number',
                'number.integer': 'Priority must be an integer',
                'number.min': 'Priority cannot be negative'
            })
        })
    ).optional().default([])
})

const updateChannelSchema = Joi.object({
    name: Joi.string().optional().min(1).max(255).messages({
        'string.empty': 'Channel name cannot be empty',
        'string.min': 'Channel name must be at least 1 character',
        'string.max': 'Channel name cannot exceed 255 characters'
    }),
    description: Joi.string().optional().allow('').max(1000).messages({
        'string.max': 'Description cannot exceed 1000 characters'
    }),
    isActive: Joi.boolean().optional(),
    logo: Joi.string().optional().allow('').max(500).messages({
        'string.max': 'Logo URL cannot exceed 500 characters'
    }),
    isPriority: Joi.boolean().optional()
}).min(1).messages({
    'object.min': 'At least one field must be provided for update'
})

// Source validation schemas
const createSourceSchema = Joi.object({
    channelId: Joi.string().required().messages({
        'string.empty': 'Channel ID is required',
        'any.required': 'Channel ID is required'
    }),
    type: Joi.string().required().messages({
        'string.empty': 'Source type is required',
        'any.required': 'Source type is required'
    }),
    port: Joi.number().integer().min(1).max(65535).required().messages({
        'number.base': 'Port must be a number',
        'number.integer': 'Port must be an integer',
        'number.min': 'Port must be at least 1',
        'number.max': 'Port cannot exceed 65535',
        'any.required': 'Port is required'
    }),
    ip: Joi.string().required().messages({
        'string.empty': 'IP address is required',
        'any.required': 'IP address is required'
    }),
    isActive: Joi.boolean().optional().default(true),
    isPrimary: Joi.boolean().optional().default(false),
    priority: Joi.number().integer().min(0).optional().default(0).messages({
        'number.base': 'Priority must be a number',
        'number.integer': 'Priority must be an integer',
        'number.min': 'Priority cannot be negative'
    })
})

const updateSourceSchema = Joi.object({
    type: Joi.string().optional().messages({
        'string.empty': 'Source type cannot be empty'
    }),
    port: Joi.number().integer().min(1).max(65535).optional().messages({
        'number.base': 'Port must be a number',
        'number.integer': 'Port must be an integer',
        'number.min': 'Port must be at least 1',
        'number.max': 'Port cannot exceed 65535'
    }),
    ip: Joi.string().optional().messages({
        'string.empty': 'IP address cannot be empty'
    }),
    isActive: Joi.boolean().optional(),
    isPrimary: Joi.boolean().optional(),
    priority: Joi.number().integer().min(0).optional().messages({
        'number.base': 'Priority must be a number',
        'number.integer': 'Priority must be an integer',
        'number.min': 'Priority cannot be negative'
    })
}).min(1).messages({
    'object.min': 'At least one field must be provided for update'
})

// Recent Search validation schemas
const createRecentSearchSchema = Joi.object({
    name: Joi.string().required().min(1).max(255).messages({
        'string.empty': 'Search name is required',
        'string.min': 'Search name must be at least 1 character',
        'string.max': 'Search name cannot exceed 255 characters',
        'any.required': 'Search name is required'
    }),
    type: Joi.string().valid('channel', 'clip', 'recording').required().messages({
        'any.only': 'Type must be one of: channel, clip, recording',
        'any.required': 'Type is required'
    }),
    query: Joi.string().required().messages({
        'string.empty': 'Query parameters are required',
        'any.required': 'Query parameters are required'
    })
})

const updateRecentSearchSchema = Joi.object({
    name: Joi.string().optional().min(1).max(255).messages({
        'string.empty': 'Search name cannot be empty',
        'string.min': 'Search name must be at least 1 character',
        'string.max': 'Search name cannot exceed 255 characters'
    }),
    type: Joi.string().valid('channel', 'clip', 'recording').optional().messages({
        'any.only': 'Type must be one of: channel, clip, recording'
    }),
    query: Joi.string().optional().messages({
        'string.empty': 'Query parameters cannot be empty'
    })
}).min(1).messages({
    'object.min': 'At least one field must be provided for update'
})

// Scheduled Recording validation schemas
const createScheduledRecordingSchema = Joi.object({
    channelId: Joi.string().required().messages({
        'string.empty': 'Channel ID is required',
        'any.required': 'Channel ID is required'
    }),
    name: Joi.string().required().min(1).max(255).messages({
        'string.empty': 'Recording name is required',
        'string.min': 'Recording name must be at least 1 character',
        'string.max': 'Recording name cannot exceed 255 characters',
        'any.required': 'Recording name is required'
    }),
    description: Joi.string().optional().allow('').max(1000).messages({
        'string.max': 'Description cannot exceed 1000 characters'
    }),
    scheduledStart: Joi.date().required().messages({
        'date.base': 'Scheduled start must be a valid date',
        'any.required': 'Scheduled start time is required'
    }),
    scheduledEnd: Joi.date().optional().greater(Joi.ref('scheduledStart')).messages({
        'date.base': 'Scheduled end must be a valid date',
        'date.greater': 'Scheduled end must be after scheduled start time'
    }),
    duration: Joi.number().integer().min(1).max(1440).optional().messages({
        'number.base': 'Duration must be a number',
        'number.integer': 'Duration must be an integer',
        'number.min': 'Duration must be at least 1 minute',
        'number.max': 'Duration cannot exceed 1440 minutes (24 hours)'
    }),
    isRecurring: Joi.boolean().optional().default(false),
    recurrenceType: Joi.string().valid('daily', 'weekly', 'monthly', 'custom').optional().messages({
        'any.only': 'Recurrence type must be one of: daily, weekly, monthly, custom'
    }),
    recurrenceRule: Joi.when('isRecurring', {
        is: true,
        then: Joi.string().optional(),
        otherwise: Joi.forbidden().messages({
            'any.unknown': 'Recurrence rule is only allowed when isRecurring is true'
        })
    }),
    priority: Joi.number().integer().min(1).max(5).optional().default(1).messages({
        'number.base': 'Priority must be a number',
        'number.integer': 'Priority must be an integer',
        'number.min': 'Priority must be at least 1',
        'number.max': 'Priority cannot exceed 5'
    }),
    notificationEnabled: Joi.boolean().optional().default(true)
}).custom((value, helpers) => {
    // Either scheduledEnd or duration must be provided, but not both
    const hasScheduledEnd = value.scheduledEnd !== undefined
    const hasDuration = value.duration !== undefined

    if (!hasScheduledEnd && !hasDuration) {
        return helpers.error('custom.missingEndTime')
    }

    if (hasScheduledEnd && hasDuration) {
        return helpers.error('custom.conflictingEndTime')
    }

    return value
}).messages({
    'custom.missingEndTime': 'Either scheduledEnd or duration must be provided',
    'custom.conflictingEndTime': 'Cannot specify both scheduledEnd and duration - choose one'
})

const updateScheduledRecordingSchema = Joi.object({
    name: Joi.string().optional().min(1).max(255).messages({
        'string.empty': 'Recording name cannot be empty',
        'string.min': 'Recording name must be at least 1 character',
        'string.max': 'Recording name cannot exceed 255 characters'
    }),
    description: Joi.string().optional().allow('').max(1000).messages({
        'string.max': 'Description cannot exceed 1000 characters'
    }),
    scheduledStart: Joi.date().optional().messages({
        'date.base': 'Scheduled start must be a valid date'
    }),
    scheduledEnd: Joi.date().optional().messages({
        'date.base': 'Scheduled end must be a valid date'
    }),
    duration: Joi.number().integer().min(1).max(1440).optional().messages({
        'number.base': 'Duration must be a number',
        'number.integer': 'Duration must be an integer',
        'number.min': 'Duration must be at least 1 minute',
        'number.max': 'Duration cannot exceed 1440 minutes (24 hours)'
    }),
    isRecurring: Joi.boolean().optional(),
    recurrenceType: Joi.string().valid('daily', 'weekly', 'monthly', 'custom').optional().messages({
        'any.only': 'Recurrence type must be one of: daily, weekly, monthly, custom'
    }),
    recurrenceRule: Joi.string().optional(),
    priority: Joi.number().integer().min(1).max(5).optional().messages({
        'number.base': 'Priority must be a number',
        'number.integer': 'Priority must be an integer',
        'number.min': 'Priority must be at least 1',
        'number.max': 'Priority cannot exceed 5'
    }),
    isActive: Joi.boolean().optional(),
    notificationEnabled: Joi.boolean().optional()
}).min(1).messages({
    'object.min': 'At least one field must be provided for update'
})

const scheduledRecordingQuerySchema = Joi.object({
    // Pagination
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(10),

    // Sorting
    sortBy: Joi.string().valid(
        'name', 'scheduledStart', 'scheduledEnd', 'priority', 'status',
        'createdAt', 'updatedAt', 'isRecurring', 'channelName'
    ).default('scheduledStart'),
    sortOrder: Joi.string().valid('asc', 'desc').default('asc'),

    // Filtering
    channelId: Joi.string().allow('').optional(),
    status: Joi.string().valid('scheduled', 'active', 'completed', 'failed', 'cancelled').allow('').optional(),
    isRecurring: Joi.boolean().optional(),
    isActive: Joi.boolean().optional(),
    priority: Joi.number().integer().min(1).max(5).optional(),

    // Date range filtering
    dateFrom: Joi.date().allow('').optional(),
    dateTo: Joi.date().allow('').optional(),

    // Search functionality
    search: Joi.string().allow('').optional()
})

const conflictResolutionSchema = Joi.object({
    resolution: Joi.string().valid('priority_win', 'user_resolved', 'auto_resolved').required().messages({
        'any.only': 'Resolution must be one of: priority_win, user_resolved, auto_resolved',
        'any.required': 'Resolution is required'
    }),
    winningScheduleId: Joi.string().optional().messages({
        'string.base': 'Winning schedule ID must be a string'
    })
})

module.exports = {
    idSchema,
    createChannelSchema,
    updateChannelSchema,
    createSourceSchema,
    updateSourceSchema,
    createRecentSearchSchema,
    updateRecentSearchSchema,
    createScheduledRecordingSchema,
    updateScheduledRecordingSchema,
    scheduledRecordingQuerySchema,
    conflictResolutionSchema
}
