const { RecentSearchQueries } = require('../queries')

class RecentSearchService {
    // Get recent searches by type with limit
    async getByType(type, limit = 10) {
        try {
            const searches = await RecentSearchQueries.findRecentSearches({
                type
            }, {
                orderBy: { createdAt: 'desc' },
                limit
            });

            return searches.map(search => ({
                ...search,
                query: JSON.parse(search.query)
            }));
        } catch (error) {
            throw new Error(`Failed to get recent searches by type: ${error.message}`);
        }
    }

    // Check if a search with the same name already exists for a type
    async searchExists(name, type) {
        try {
            const existingSearches = await RecentSearchQueries.findRecentSearches({
                name,
                type
            });
            return existingSearches.length > 0;
        } catch (error) {
            throw new Error(`Failed to check if search exists: ${error.message}`);
        }
    }

    // Create or update a recent search
    async createOrUpdate(name, type, queryParams) {
        try {
            const queryString = JSON.stringify(queryParams);

            // Check if search with same name and type exists
            const existingSearches = await RecentSearchQueries.findRecentSearches({
                name,
                type
            });

            if (existingSearches.length > 0) {
                // Update existing search
                const existingSearch = existingSearches[0];
                const updatedSearch = await RecentSearchQueries.updateRecentSearch(existingSearch.id, {
                    query: queryString,
                    updatedAt: new Date()
                });

                return {
                    ...updatedSearch,
                    query: JSON.parse(updatedSearch.query)
                };
            } else {
                // Create new search
                const newSearch = await RecentSearchQueries.createRecentSearch({
                    name,
                    type,
                    query: queryString
                });

                return {
                    ...newSearch,
                    query: JSON.parse(newSearch.query)
                };
            }
        } catch (error) {
            throw new Error(`Failed to create or update recent search: ${error.message}`);
        }
    }

    // Delete old searches (keep only latest N searches per type)
    async cleanupOldSearches(type, keepCount = 20) {
        try {
            // Get all searches for this type, ordered by creation date
            const allSearches = await RecentSearchQueries.findRecentSearches({
                type
            }, {
                orderBy: { createdAt: 'desc' }
            });

            // If we have more than keepCount, delete the oldest ones
            if (allSearches.length > keepCount) {
                const searchesToDelete = allSearches.slice(keepCount);
                const idsToDelete = searchesToDelete.map(search => search.id);

                let deletedCount = 0;
                for (const id of idsToDelete) {
                    await RecentSearchQueries.deleteRecentSearch(id);
                    deletedCount++;
                }

                return {
                    deleted: deletedCount,
                    remaining: keepCount
                };
            }

            return {
                deleted: 0,
                remaining: allSearches.length
            };
        } catch (error) {
            throw new Error(`Failed to cleanup old searches: ${error.message}`);
        }
    }

    // Get search statistics
    async getSearchStats() {
        try {
            const allSearches = await RecentSearchQueries.findRecentSearches();

            const totalSearches = allSearches.length;
            const channelSearches = allSearches.filter(search => search.type === 'channel').length;
            const clipSearches = allSearches.filter(search => search.type === 'clip').length;
            const recordingSearches = allSearches.filter(search => search.type === 'recording').length;

            return {
                total: totalSearches,
                byType: {
                    channel: channelSearches,
                    clip: clipSearches,
                    recording: recordingSearches
                }
            };
        } catch (error) {
            throw new Error(`Failed to get search statistics: ${error.message}`);
        }
    }

    // Validate query parameters based on type
    validateQueryParams(type, queryParams) {
        const commonParams = ['search', 'page', 'pageSize', 'sort'];

        switch (type) {
            case 'channel':
                const validChannelParams = [...commonParams, 'isActive', 'isPriority'];
                return this._validateParams(queryParams, validChannelParams);

            case 'clip':
                const validClipParams = [...commonParams, 'recordingId', 'status', 'tags'];
                return this._validateParams(queryParams, validClipParams);

            case 'recording':
                const validRecordingParams = [...commonParams, 'channelId', 'status', 'startDate', 'endDate'];
                return this._validateParams(queryParams, validRecordingParams);

            default:
                throw new Error(`Invalid search type: ${type}`);
        }
    }

    _validateParams(queryParams, validParams) {
        const invalidParams = Object.keys(queryParams).filter(param => !validParams.includes(param));

        if (invalidParams.length > 0) {
            throw new Error(`Invalid query parameters: ${invalidParams.join(', ')}`);
        }

        return true;
    }
}

module.exports = new RecentSearchService();
