import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form'
import { Button } from '@/components/ui/button'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { CalendarIcon } from 'lucide-react'
import { format } from 'date-fns'
import { cn } from '@/lib/utils'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { PRIORITY, RECORDING_PATTERN } from '@/constants/channel'

const fetchRecordingSettings = async () => {
  // Mock API call
  return {
    isActive: false,
    scheduleType: 'one-time',
    startDate: new Date(),
    startTime: '08:00',
    endTime: '09:00',
    channel: 'channel-1',
    priority: 'medium'
  }
}

const saveRecordingSettings = async (values) => {
  // Mock API call
  console.log('Saving settings:', values)
  return new Promise((resolve) => setTimeout(resolve, 1000))
}

const ChannelRecording = () => {
  const queryClient = useQueryClient()

  // Fetch initial settings
  const { data: initialData, isPending } = useQuery({
    queryKey: ['recordingSettings'],
    queryFn: fetchRecordingSettings
  })

  const form = useForm({
    defaultValues: initialData || {
      scheduleType: 'one-time',
      startDate: new Date(),
      startTime: '08:00',
      endTime: '09:00',
      priority: 'medium'
    }
  })

  // Update form defaults when data loads
  useEffect(() => {
    if (initialData) {
      form.reset(initialData)
    }
  }, [initialData, form])

  const mutation = useMutation({
    mutationFn: saveRecordingSettings,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recordingSettings'] })
      ToastSuccess('Recording settings saved successfully')
    },
    onError: () => {
      ToastError('Failed to save recording settings')
    }
  })

  const onSubmit = (values) => {
    mutation.mutate(values)
  }

  const scheduleType = form.watch('scheduleType')

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          <h4>Recording Settings</h4>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 md:w-1/2">
            {/* Program Name (Optional) */}
            <FormField
              control={form.control}
              name="programName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Program Name (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter program name" {...field} />
                  </FormControl>
                  <FormDescription>Helps identify the recording in your library</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Schedule Type */}
            <FormField
              control={form.control}
              name="scheduleType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Schedule Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl className="w-full">
                      <SelectTrigger>
                        <SelectValue placeholder="Select a schedule type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {RECORDING_PATTERN.map((pattern) => (
                        <SelectItem key={pattern?.value} value={pattern?.value}>
                          {pattern?.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Start Date */}
            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Start Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={'outline'}
                          className={cn(
                            'w-[240px] pl-3 text-left font-normal',
                            !field.value && 'text-muted-foreground'
                          )}
                        >
                          {field.value ? format(field.value, 'PPP') : <span>Pick a date</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Recurrence Pattern (for custom schedules) */}
            {scheduleType === 'custom' && (
              <FormField
                control={form.control}
                name="recurrencePattern"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Recurrence Pattern</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 0 9 * * 1-5 (Mon-Fri at 9 AM)" {...field} />
                    </FormControl>
                    <FormDescription>Use cron syntax to define custom recurrence</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Time Range */}
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Time</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Time</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Priority Settings */}
            <FormField
              control={form.control}
              name="priority"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Recording Priority</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a priority level" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {PRIORITY?.map((priority) => (
                        <SelectItem key={priority?.value} value={priority?.value}>
                          {priority?.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Higher priority recordings will get system resource preference
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end">
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? 'Saving...' : 'Save Settings'}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}

export default ChannelRecording
