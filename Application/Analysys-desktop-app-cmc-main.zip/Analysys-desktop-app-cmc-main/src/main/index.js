import { app, shell, BrowserWindow, ipcMain } from 'electron'
import path, { join } from 'path'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'
import icon from '../../resources/analysys.png?asset'
import splashScreen from '../../resources/splash/splash.html?asset'

import fs from 'fs'

// 🚨 Prevent multiple instances of the app
const gotTheLock = app.requestSingleInstanceLock()
if (!gotTheLock) {
  app.quit()
  process.exit(0)
} else {
  let mainWindow
  let splash

  // API BASE URL UPDATE
  const configPath = path.join(app.getPath('userData'), 'config.json')
  console.log(configPath)

  // Ensure config file exists in userData
  function initConfig() {
    if (!fs.existsSync(configPath)) {
      fs.writeFileSync(
        configPath,
        JSON.stringify(
          {
            API_BASE_URL: 'http://localhost:3000/api',
            API_WS_BASE_URL: 'ws://localhost:3000'
          },
          null,
          2
        )
      )
    }
  }

  function getConfig() {
    const data = fs.readFileSync(configPath, 'utf-8')
    return JSON.parse(data)
  }

  function updateConfig(newConfig) {
    // newConfig should contain both keys
    fs.writeFileSync(configPath, JSON.stringify(newConfig, null, 2))
  }

  // Setup IPC
  ipcMain.handle('get-api-config', () => getConfig())
  ipcMain.handle('update-api-config', (_, newConfig) => {
    updateConfig(newConfig)
    return true
  })

  function createWindow() {
    // Splash Window
    splash = new BrowserWindow({
      width: 766,
      height: 516,
      frame: false,
      transparent: true,
      alwaysOnTop: true
    })
    const splashPath = splashScreen
    splash.loadFile(splashPath)
    splash.center()

    // Create the browser window.
    mainWindow = new BrowserWindow({
      width: 1366,
      height: 768,
      show: false,
      autoHideMenuBar: true,
      ...(process.platform === 'linux' ? { icon } : {}),
      webPreferences: {
        preload: join(__dirname, '../preload/index.js'),
        sandbox: false
      }
    })

    mainWindow.webContents.setWindowOpenHandler((details) => {
      shell.openExternal(details.url)
      return { action: 'deny' }
    })

    // HMR for renderer based on electron-vite cli.
    if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
      mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
    } else {
      mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
    }

    // ===== Show Main Window After Load =====
    mainWindow.webContents.on('did-finish-load', () => {
      setTimeout(() => {
        if (splash) {
          initConfig()
          splash.close()
          splash = null
        }
        if (mainWindow) {
          mainWindow.show()
          mainWindow.focus()
        }
      }, 4000)
    })
  }

  // Handle second instance
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })

  // This method will be called when Electron has finished
  // initialization and is ready to create browser windows.
  app.whenReady().then(() => {
    // Set app user model id for windows
    electronApp.setAppUserModelId('com.electron')

    // Default open or close DevTools by F12 in development
    app.on('browser-window-created', (_, window) => {
      optimizer.watchWindowShortcuts(window)
    })

    // IPC test
    ipcMain.on('ping', () => console.log('pong'))

    createWindow()

    ipcMain.handle('get-app-version', () => app.getVersion())

    app.on('activate', function () {
      if (BrowserWindow.getAllWindows().length === 0) createWindow()
    })
  })

  // Quit when all windows are closed, except on macOS.
  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
}
