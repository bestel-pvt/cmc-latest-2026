import { buttonVariants } from '@/components/ui/button'
import { AppSidebar } from '@/components/ui/dashboard/app-sidebar'
import { Separator } from '@/components/ui/separator'
import { SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar'
import { cn } from '@/lib/utils'
import { Settings } from 'lucide-react'
import { Link, Outlet } from 'react-router-dom'

const DashboardLayout = () => {
  return (
    <SidebarProvider
      style={{
        '--sidebar-width': '19rem'
      }}
    >
      <AppSidebar />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 px-4 sticky top-0 backdrop-blur-xs z-50">
          <div className="flex items-center justify-between   w-full">
            <div className="flex items-center">
              <SidebarTrigger className="-ml-1" />
              <Separator orientation="vertical" className="mr-2 data-[orientation=vertical]:h-4" />
            </div>
            <Link
              to={'/settings'}
              className={cn(
                buttonVariants({
                  variant: 'ghost',
                  size: 'icon'
                })
              )}
            >
              <Settings />
            </Link>
          </div>
        </header>
        <div className="container mx-auto">
          <Outlet />
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}

export default DashboardLayout
