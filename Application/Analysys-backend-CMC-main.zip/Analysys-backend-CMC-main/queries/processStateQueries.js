const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')
const crypto = require('crypto')




class ProcessStateQueries {
    // Create a process state record
    static createProcessState(data) {
        try {
            const id = crypto.randomUUID()
            const now = new Date().toISOString()

            const sql = `
                INSERT INTO process_states (
                    id, channelId, processType, status, httpPort, udpLink, 
                    recordingId, startTime, metadata, createdAt, updatedAt
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `

            db.prepare(sql).run(
                id,
                data.channelId,
                data.processType,
                data.status,
                data.httpPort || null,
                data.udpLink || null,
                data.recordingId || null,
                data.startTime || now,
                data.metadata ? JSON.stringify(data.metadata) : null,
                now,
                now
            )

            return this.getProcessStateById(id)
        } catch (error) {
            console.error('Error creating process state:', error)
            throw new DatabaseError('Failed to create process state')
        }
    }

    // Get process state by ID
    static getProcessStateById(id) {
        try {
            const sql = `SELECT * FROM process_states WHERE id = ?`
            const row = db.prepare(sql).get(id)

            if (!row) {
                throw new DatabaseError('Process state not found', 'P2025')
            }

            if (row.metadata) {
                row.metadata = JSON.parse(row.metadata)
            }

            return serializeBigInt(row)
        } catch (error) {
            if (error instanceof DatabaseError) throw error
            console.error('Error getting process state:', error)
            throw new DatabaseError('Failed to get process state')
        }
    }

    // Get all process states for a channel
    static getProcessStatesByChannel(channelId) {
        try {
            const sql = `
                SELECT * FROM process_states 
                WHERE channelId = ? 
                ORDER BY createdAt DESC
            `
            const rows = db.prepare(sql).all(channelId)

            return rows.map(row => {
                if (row.metadata) {
                    row.metadata = JSON.parse(row.metadata)
                }
                return serializeBigInt(row)
            })
        } catch (error) {
            console.error('Error getting channel process states:', error)
            throw new DatabaseError('Failed to get channel process states')
        }
    }

    // Get all active process states
    static getActiveProcessStates() {
        try {
            const sql = `
                SELECT * FROM process_states 
                WHERE status = 'active' 
                ORDER BY createdAt DESC
            `
            const rows = db.prepare(sql).all()

            return rows.map(row => {
                if (row.metadata) {
                    row.metadata = JSON.parse(row.metadata)
                }
                return serializeBigInt(row)
            })
        } catch (error) {
            console.error('Error getting active process states:', error)
            throw new DatabaseError('Failed to get active process states')
        }
    }

    // Update process state
    static updateProcessState(id, data) {
        try {
            const updates = []
            const params = []

            if (data.status !== undefined) {
                updates.push('status = ?')
                params.push(data.status)
            }

            if (data.httpPort !== undefined) {
                updates.push('httpPort = ?')
                params.push(data.httpPort)
            }

            if (data.udpLink !== undefined) {
                updates.push('udpLink = ?')
                params.push(data.udpLink)
            }

            if (data.recordingId !== undefined) {
                updates.push('recordingId = ?')
                params.push(data.recordingId)
            }

            if (data.metadata !== undefined) {
                updates.push('metadata = ?')
                params.push(JSON.stringify(data.metadata))
            }

            updates.push('updatedAt = ?')
            params.push(new Date().toISOString())

            params.push(id)

            const sql = `
                UPDATE process_states 
                SET ${updates.join(', ')}
                WHERE id = ?
            `

            const result = db.prepare(sql).run(params)

            if (result.changes === 0) {
                throw new DatabaseError('Process state not found', 'P2025')
            }

            return this.getProcessStateById(id)
        } catch (error) {
            if (error instanceof DatabaseError) throw error
            console.error('Error updating process state:', error)
            throw new DatabaseError('Failed to update process state')
        }
    }

    // Delete process state
    static deleteProcessState(id) {
        try {
            const sql = `DELETE FROM process_states WHERE id = ?`
            const result = db.prepare(sql).run(id)

            if (result.changes === 0) {
                throw new DatabaseError('Process state not found', 'P2025')
            }

            return { success: true, message: 'Process state deleted successfully' }
        } catch (error) {
            if (error instanceof DatabaseError) throw error
            console.error('Error deleting process state:', error)
            throw new DatabaseError('Failed to delete process state')
        }
    }

    // Delete process states by channel
    static deleteProcessStatesByChannel(channelId) {
        try {
            const sql = `DELETE FROM process_states WHERE channelId = ?`
            db.prepare(sql).run(channelId)

            return { success: true, message: 'Process states deleted successfully' }
        } catch (error) {
            console.error('Error deleting process states:', error)
            throw new DatabaseError('Failed to delete process states')
        }
    }

    // Clean up old process states (older than specified days)
    static cleanupOldProcessStates(daysOld = 7) {
        try {
            const cutoffDate = new Date()
            cutoffDate.setDate(cutoffDate.getDate() - daysOld)

            const sql = `
                DELETE FROM process_states 
                WHERE status != 'active' 
                AND createdAt < ?
            `

            const result = db.prepare(sql).run(cutoffDate.toISOString())

            return {
                success: true,
                message: `Cleaned up ${result.changes} old process states`
            }
        } catch (error) {
            console.error('Error cleaning up old process states:', error)
            throw new DatabaseError('Failed to cleanup old process states')
        }
    }

    // Delete all process states
    static deleteAllProcessStates() {
        try {
            const sql = `DELETE FROM process_states`;
            const result = db.prepare(sql).run();

            return {
                success: true,
                message: `Deleted ${result.changes} process states`
            };
        } catch (error) {
            console.error('Error deleting all process states:', error);
            throw new DatabaseError('Failed to delete all process states');
        }
    }
}

module.exports = ProcessStateQueries
