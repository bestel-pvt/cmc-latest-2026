import { useState, useEffect, useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { useDebounce } from 'react-haiku'
import DataTable from '@/components/ui/data-table/data-table'
import { getAllClips } from '@/services/clipping/clipApi'
import { useClipColumns } from './columns'
import ClipFilters from '../clip-filters'

// Updated ClipTable component
const ClipTable = () => {
  const [searchParams, setSearchParams] = useSearchParams()

  // Pagination states
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1)
  const [limit, setLimit] = useState(Number(searchParams.get('limit')) || 10)

  // Extract filter values from URL params
  const filterParams = useMemo(() => {
    const params = {}
    const filterKeys = [
      'search',
      'status',
      'tags',
      'recordingId',
      'channelName',
      'clipName',
      'dateFrom',
      'dateTo',
      'sortBy',
      'sortOrder'
    ]

    filterKeys.forEach((key) => {
      const value = searchParams.get(key)
      if (value) params[key] = value
    })

    // Set defaults for sortBy and sortOrder if not present
    if (!params.sortBy) params.sortBy = 'createdAt'
    if (!params.sortOrder) params.sortOrder = 'desc'

    return params
  }, [searchParams])

  // Debounce filter params for API calls
  const debouncedFilterParams = useDebounce(filterParams, 1000)

  const { data, isPending } = useQuery({
    queryKey: ['clips', page, limit, debouncedFilterParams],
    queryFn: () =>
      getAllClips({
        page,
        limit,
        ...debouncedFilterParams
      }),
    keepPreviousData: true
  })

  // Update URL when pagination changes
  useEffect(() => {
    const params = new URLSearchParams(searchParams)
    params.set('page', page.toString())
    params.set('limit', limit.toString())
    setSearchParams(params, { replace: true })
  }, [page, limit, searchParams, setSearchParams])

  // Reset page when filters change
  useEffect(() => {
    if (page !== 1) {
      setPage(1)
    }
  }, [debouncedFilterParams])

  const clips = data?.clips || []
  const columns = useClipColumns()

  const handlePageChange = (newPage) => {
    setPage(newPage)
  }

  const handleLimitChange = (newLimit) => {
    setLimit(newLimit)
    setPage(1)
  }

  return (
    <div className="space-y-4">
      <ClipFilters />
      <DataTable
        columns={columns}
        data={clips}
        isPending={isPending}
        isPagination
        pagination={{
          page,
          limit,
          totalPages: data?.pagination?.totalPages || 1
        }}
        onPageChange={handlePageChange}
        onLimitChange={handleLimitChange}
      />
    </div>
  )
}

export default ClipTable
