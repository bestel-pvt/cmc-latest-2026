import { z } from 'zod'

// IPv4 regex
const ipRegex = '(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}'

// Port range (1–65535)
const portRegex = '(6553[0-5]|655[0-2]\\d|65[0-4]\\d{2}|6[0-4]\\d{3}|[1-5]?\\d{1,4})'

export const ConfigSchema = z
  .object({
    API_BASE_URL: z
      .string()
      .trim()
      .regex(
        new RegExp(`^http://${ipRegex}:${portRegex}/api$`),
        'Must be in format: http://<ip>:<port>/api'
      ),

    API_WS_BASE_URL: z
      .string()
      .trim()
      .regex(new RegExp(`^ws://${ipRegex}:${portRegex}$`), 'Must be in format: ws://<ip>:<port>')
  })
  .superRefine((vals, ctx) => {
    try {
      const http = new URL(vals.API_BASE_URL)
      const ws = new URL(vals.API_WS_BASE_URL)

      // Check same host + port
      const sameHost = http.hostname === ws.hostname && http.port === ws.port

      if (!sameHost) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['API_WS_BASE_URL'],
          message: 'WebSocket host/port must match API host/port'
        })
      }
    } catch {
      // ignore, regex validation already handles bad URLs
    }
  })
