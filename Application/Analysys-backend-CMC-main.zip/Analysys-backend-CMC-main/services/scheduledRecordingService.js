const cron = require('node-cron')
const { ScheduledRecordingQueries, ScheduledRecordingExecutionQueries, RecordingConflictQueries } = require('../queries')
const recordingService = require('./recordingService.js')

class ScheduledRecordingService {
    constructor() {
        this.scheduledJobs = new Map() // Store cron jobs
        this.activeSchedules = new Map() // Track active scheduled recordings
        this.initializeScheduler()
    }

    async initializeScheduler() {
        console.log('🔄 Initializing scheduled recording service...')

        // Start the main scheduler that runs every minute to check for upcoming recordings
        cron.schedule('* * * * *', async () => {
            try {
                console.log(`⏰ Cron job executing at ${new Date().toISOString()}`)
                await this.checkScheduledRecordings()
            } catch (error) {
                console.error('❌ Error in cron job execution:', error)
            }
        }, {
            scheduled: true,
            timezone: "UTC"
        })

        // Load existing scheduled recordings on startup
        await this.loadExistingSchedules()

        console.log('✅ Scheduled recording service initialized successfully')
    }

    async loadExistingSchedules() {
        try {
            const activeSchedules = await ScheduledRecordingQueries.findScheduledRecordings({
                where: {
                    isActive: true,
                    status: { in: ['scheduled', 'active'] }
                }
            })

            console.log(`Loading ${activeSchedules.length} active scheduled recordings`)

            for (const schedule of activeSchedules) {
                await this.scheduleRecording(schedule)
            }
        } catch (error) {
            console.error('Failed to load existing schedules:', error)
        }
    }

    async checkScheduledRecordings() {
        const now = new Date()
        const upcomingTime = new Date(now.getTime() + 60000) // 1 minute from now

        try {
            console.log(`🔍 Checking scheduled recordings at ${now.toISOString()}`)

            // Find recordings that should start in the next minute
            const upcomingRecordings = await ScheduledRecordingQueries.findScheduledRecordings({
                where: {
                    status: 'scheduled',
                    isActive: true
                },
                include: {
                    channel: true
                },
                take: 100 // Limit to prevent overload
            })

            console.log(`📋 Found ${upcomingRecordings.length} scheduled recordings to check`)

            // Filter by time range
            const recordingsToStart = upcomingRecordings.filter(recording => {
                const scheduledStart = new Date(recording.scheduledStart);
                const shouldStart = scheduledStart >= now && scheduledStart <= upcomingTime;
                if (shouldStart) {
                    console.log(`▶️ Recording "${recording.name}" should start at ${scheduledStart.toISOString()}`)
                }
                return shouldStart;
            });

            console.log(`🎬 ${recordingsToStart.length} recordings ready to start`)

            for (const recording of recordingsToStart) {
                try {
                    await this.executeScheduledRecording(recording)
                } catch (error) {
                    console.error(`❌ Failed to execute scheduled recording ${recording.id}:`, error)
                }
            }

            // Check for recordings that should stop
            const recordingsToStop = await ScheduledRecordingExecutionQueries.findScheduledRecordingExecutions({
                where: {
                    status: 'running'
                },
                include: {
                    scheduledRecording: {
                        include: {
                            channel: true
                        }
                    }
                },
                take: 100
            })

            console.log(`🔍 Found ${recordingsToStop.length} running executions to check`)

            // Filter by time
            const recordingsToEnd = recordingsToStop.filter(execution => {
                const shouldStop = new Date(execution.executionEnd) <= now;
                if (shouldStop) {
                    console.log(`⏹️ Recording execution ${execution.id} should stop at ${execution.executionEnd}`)
                }
                return shouldStop;
            });

            console.log(`🛑 ${recordingsToEnd.length} recordings ready to stop`)

            for (const execution of recordingsToEnd) {
                try {
                    await this.stopScheduledRecording(execution)
                } catch (error) {
                    console.error(`❌ Failed to stop scheduled recording execution ${execution.id}:`, error)
                }
            }

        } catch (error) {
            console.error('❌ Error checking scheduled recordings:', error)
            // Log the full error stack for debugging
            console.error(error.stack)
        }
    }

    async executeScheduledRecording(scheduledRecording) {
        try {
            console.log(`Starting scheduled recording: ${scheduledRecording.name}`)

            // Calculate end time
            const endTime = scheduledRecording.scheduledEnd
                ? new Date(scheduledRecording.scheduledEnd)
                : new Date(scheduledRecording.scheduledStart.getTime() + (scheduledRecording.duration * 60000))

            // Check for conflicts with higher priority recordings
            const conflicts = await this.checkForConflicts(scheduledRecording, scheduledRecording.scheduledStart, endTime)

            if (conflicts.length > 0) {
                console.log(`Conflicts detected for scheduled recording ${scheduledRecording.id}`)
                await this.handleConflicts(scheduledRecording, conflicts)
                return
            }

            // Create execution record
            const execution = await ScheduledRecordingExecutionQueries.createScheduledRecordingExecution({
                scheduledRecordingId: scheduledRecording.id,
                executionStart: new Date(),
                executionEnd: endTime,
                status: 'pending'
            })

            // Update scheduled recording status
            await ScheduledRecordingQueries.updateScheduledRecording(scheduledRecording.id, {
                status: 'active'
            })

            // Start the actual recording
            const recordingResult = await recordingService.startRecording(scheduledRecording.channelId)

            if (recordingResult.success) {
                // Update execution with recording ID
                await ScheduledRecordingExecutionQueries.updateScheduledRecordingExecution(execution.id, {
                    recordingId: recordingResult.recordingId,
                    status: 'running'
                })

                // Store active schedule
                this.activeSchedules.set(scheduledRecording.id, {
                    executionId: execution.id,
                    recordingId: recordingResult.recordingId,
                    channelId: scheduledRecording.channelId,
                    endTime
                })

                console.log(`Scheduled recording ${scheduledRecording.name} started successfully`)

                // Handle recurring recordings
                if (scheduledRecording.isRecurring) {
                    await this.createNextRecurrence(scheduledRecording)
                }

            } else {
                // Recording failed to start
                await ScheduledRecordingExecutionQueries.updateScheduledRecordingExecution(execution.id, {
                    status: 'failed',
                    failureReason: recordingResult.error || 'Failed to start recording'
                })

                await ScheduledRecordingQueries.updateScheduledRecording(scheduledRecording.id, {
                    status: 'failed'
                })
            }

        } catch (error) {
            console.error(`Failed to execute scheduled recording ${scheduledRecording.id}:`, error)

            // Update status to failed
            await ScheduledRecordingQueries.updateScheduledRecording(scheduledRecording.id, {
                status: 'failed'
            })
        }
    }

    async stopScheduledRecording(execution) {
        try {
            console.log(`⏹️ Stopping scheduled recording execution: ${execution.id}`)

            // Get the channelId from activeSchedules map or query the database
            let channelId = null

            // First try to get from active schedules
            const activeSchedule = this.activeSchedules.get(execution.scheduledRecordingId)
            if (activeSchedule) {
                channelId = activeSchedule.channelId
            } else {
                // If not in active schedules, query the database for the scheduled recording
                try {
                    const scheduledRecording = await ScheduledRecordingQueries.getScheduledRecordingById(execution.scheduledRecordingId)
                    if (scheduledRecording) {
                        channelId = scheduledRecording.channelId
                    }
                } catch (queryError) {
                    console.error(`Failed to get scheduled recording ${execution.scheduledRecordingId}:`, queryError)
                }
            }

            if (!channelId) {
                console.error(`❌ Could not determine channelId for execution ${execution.id}`)
                throw new Error('Could not determine channel ID for recording')
            }

            console.log(`🛑 Stopping recording for channel ${channelId}`)

            // Stop the recording
            await recordingService.stopRecording(channelId)

            // Update execution status
            await ScheduledRecordingExecutionQueries.updateScheduledRecordingExecution(execution.id, {
                status: 'completed'
            })

            // Update scheduled recording status
            await ScheduledRecordingQueries.updateScheduledRecording(execution.scheduledRecordingId, {
                status: 'completed'
            })

            // Remove from active schedules
            this.activeSchedules.delete(execution.scheduledRecordingId)

            console.log(`✅ Scheduled recording execution ${execution.id} stopped successfully`)

        } catch (error) {
            console.error(`❌ Failed to stop scheduled recording execution ${execution.id}:`, error)
            console.error(error.stack)

            // Mark as failed
            try {
                await ScheduledRecordingExecutionQueries.updateScheduledRecordingExecution(execution.id, {
                    status: 'failed',
                    failureReason: error.message
                })
            } catch (updateError) {
                console.error(`Failed to update execution status:`, updateError)
            }
        }
    }

    async createNextRecurrence(scheduledRecording) {
        try {
            const nextStart = this.calculateNextOccurrence(
                scheduledRecording.scheduledStart,
                scheduledRecording.recurrenceType,
                scheduledRecording.recurrenceRule
            )

            if (nextStart) {
                let nextEnd = null
                if (scheduledRecording.scheduledEnd) {
                    const originalDuration = new Date(scheduledRecording.scheduledEnd) - new Date(scheduledRecording.scheduledStart)
                    nextEnd = new Date(nextStart.getTime() + originalDuration)
                }

                await ScheduledRecordingQueries.createScheduledRecording({
                    channelId: scheduledRecording.channelId,
                    name: scheduledRecording.name,
                    description: scheduledRecording.description,
                    scheduledStart: nextStart,
                    scheduledEnd: nextEnd,
                    duration: scheduledRecording.duration,
                    isRecurring: true,
                    recurrenceType: scheduledRecording.recurrenceType,
                    recurrenceRule: scheduledRecording.recurrenceRule,
                    priority: scheduledRecording.priority,
                    notificationEnabled: scheduledRecording.notificationEnabled
                })

                console.log(`Created next occurrence for ${scheduledRecording.name} at ${nextStart}`)
            }
        } catch (error) {
            console.error(`Failed to create next recurrence for ${scheduledRecording.id}:`, error)
        }
    }

    calculateNextOccurrence(currentStart, recurrenceType, recurrenceRule) {
        const current = new Date(currentStart)

        switch (recurrenceType) {
            case 'daily':
                return new Date(current.getTime() + 24 * 60 * 60 * 1000)

            case 'weekly':
                return new Date(current.getTime() + 7 * 24 * 60 * 60 * 1000)

            case 'monthly':
                const nextMonth = new Date(current)
                nextMonth.setMonth(nextMonth.getMonth() + 1)
                return nextMonth

            case 'custom':
                // Parse custom recurrence rule (simplified implementation)
                try {
                    const rule = JSON.parse(recurrenceRule || '{}')
                    if (rule.interval && rule.unit) {
                        const multiplier = {
                            'minutes': 60 * 1000,
                            'hours': 60 * 60 * 1000,
                            'days': 24 * 60 * 60 * 1000,
                            'weeks': 7 * 24 * 60 * 60 * 1000
                        }[rule.unit]

                        if (multiplier) {
                            return new Date(current.getTime() + (rule.interval * multiplier))
                        }
                    }
                } catch (error) {
                    console.error('Invalid custom recurrence rule:', error)
                }
                return null

            default:
                return null
        }
    }

    async checkForConflicts(scheduledRecording, startTime, endTime) {
        const allRecordings = await ScheduledRecordingQueries.findScheduledRecordings({
            where: {
                channelId: scheduledRecording.channelId,
                isActive: true
            }
        });

        const conflicts = allRecordings.filter(recording => {
            if (recording.id === scheduledRecording.id) return false;
            if (!['scheduled', 'active'].includes(recording.status)) return false;

            const recordingStart = new Date(recording.scheduledStart);
            const recordingEnd = new Date(recording.scheduledEnd);

            // Check for overlaps
            return (
                (recordingStart <= startTime && recordingEnd >= startTime) ||
                (recordingStart <= endTime && recordingEnd >= endTime) ||
                (recordingStart >= startTime && recordingEnd <= endTime)
            );
        });

        return conflicts
    }

    async handleConflicts(scheduledRecording, conflicts) {
        for (const conflict of conflicts) {
            // Create conflict record
            await RecordingConflictQueries.createRecordingConflict({
                scheduledRecordingId1: scheduledRecording.id,
                scheduledRecordingId2: conflict.id,
                conflictType: 'overlap',
                conflictStart: scheduledRecording.scheduledStart,
                conflictEnd: scheduledRecording.scheduledEnd || new Date(scheduledRecording.scheduledStart.getTime() + (scheduledRecording.duration * 60000)),
                resolution: conflict.priority > scheduledRecording.priority ? 'priority_win' : 'auto_resolved'
            })

            // Handle based on priority
            if (conflict.priority > scheduledRecording.priority) {
                // Higher priority wins, cancel this recording
                await ScheduledRecordingQueries.updateScheduledRecording(scheduledRecording.id, {
                    status: 'cancelled'
                })

                console.log(`Scheduled recording ${scheduledRecording.name} cancelled due to higher priority conflict`)
                return
            } else if (scheduledRecording.priority > conflict.priority) {
                // This recording has higher priority, cancel the conflicting one
                await ScheduledRecordingQueries.updateScheduledRecording(conflict.id, {
                    status: 'cancelled'
                })

                console.log(`Cancelled lower priority recording ${conflict.name} due to conflict`)
            }
        }
    }

    // Service methods for CRUD operations
    async createScheduledRecording(data) {
        try {
            // Calculate end time if duration is provided
            let scheduledEnd = data.scheduledEnd
            if (!scheduledEnd && data.duration) {
                scheduledEnd = new Date(new Date(data.scheduledStart).getTime() + (data.duration * 60000))
            }

            const scheduledRecording = await ScheduledRecordingQueries.createScheduledRecording({
                ...data,
                scheduledEnd
            })

            // Need to get the full record with channel info for response
            const fullRecord = await ScheduledRecordingQueries.getScheduledRecordingById(scheduledRecording.id)

            // Add channel info - for simplicity, assuming it's available or fetched separately

            // Check for conflicts
            const conflicts = await this.checkForConflicts(fullRecord, fullRecord.scheduledStart, scheduledEnd)
            if (conflicts.length > 0) {
                console.log(`Created scheduled recording with ${conflicts.length} conflicts`)
            }

            return fullRecord
        } catch (error) {
            console.error('Create scheduled recording error:', error)
            throw error
        }
    }

    async getAllScheduledRecordings(filters = {}) {
        try {
            const {
                page = 1,
                limit = 10,
                sortBy = 'scheduledStart',
                sortOrder = 'asc',
                channelId,
                status,
                isRecurring,
                isActive,
                priority,
                dateFrom,
                dateTo,
                search
            } = filters

            // Build where clause
            const where = {}

            if (channelId) where.channelId = channelId
            if (status) where.status = status
            if (typeof isRecurring === 'boolean') where.isRecurring = isRecurring
            if (typeof isActive === 'boolean') where.isActive = isActive
            if (priority) where.priority = priority

            if (dateFrom || dateTo) {
                where.scheduledStart = {}
                if (dateFrom) where.scheduledStart.gte = new Date(dateFrom)
                if (dateTo) where.scheduledStart.lte = new Date(dateTo)
            }

            if (search) {
                where.OR = [
                    { name: { contains: search, mode: 'insensitive' } },
                    { description: { contains: search, mode: 'insensitive' } },
                    {
                        channel: {
                            name: { contains: search, mode: 'insensitive' }
                        }
                    }
                ]
            }

            // Get all recordings and apply filters in JavaScript
            let allScheduledRecordings = await ScheduledRecordingQueries.findScheduledRecordings({
                include: {
                    channel: true
                }
            })

            // Apply filters
            if (channelId) {
                allScheduledRecordings = allScheduledRecordings.filter(r => r.channelId === channelId)
            }
            if (status) {
                allScheduledRecordings = allScheduledRecordings.filter(r => r.status === status)
            }
            if (typeof isRecurring === 'boolean') {
                allScheduledRecordings = allScheduledRecordings.filter(r => r.isRecurring === isRecurring)
            }
            if (typeof isActive === 'boolean') {
                allScheduledRecordings = allScheduledRecordings.filter(r => r.isActive === isActive)
            }
            if (priority) {
                allScheduledRecordings = allScheduledRecordings.filter(r => r.priority === priority)
            }

            // Date filtering
            if (dateFrom) {
                const fromDate = new Date(dateFrom)
                allScheduledRecordings = allScheduledRecordings.filter(r => new Date(r.scheduledStart) >= fromDate)
            }
            if (dateTo) {
                const toDate = new Date(dateTo)
                allScheduledRecordings = allScheduledRecordings.filter(r => new Date(r.scheduledStart) <= toDate)
            }

            // Search filtering (name, description, and channel name)
            if (search) {
                const searchLower = search.toLowerCase()
                allScheduledRecordings = allScheduledRecordings.filter(r =>
                    r.name?.toLowerCase().includes(searchLower) ||
                    r.description?.toLowerCase().includes(searchLower) ||
                    r.channel?.name?.toLowerCase().includes(searchLower)
                )
            }

            // Sorting
            allScheduledRecordings.sort((a, b) => {
                const aValue = a[sortBy]
                const bValue = b[sortBy]

                if (sortOrder === 'desc') {
                    return aValue > bValue ? -1 : aValue < bValue ? 1 : 0
                } else {
                    return aValue > bValue ? 1 : aValue < bValue ? -1 : 0
                }
            })

            const total = allScheduledRecordings.length
            const skip = (page - 1) * limit
            const scheduledRecordings = allScheduledRecordings.slice(skip, skip + limit)

            return {
                scheduledRecordings,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    pages: Math.ceil(total / limit),
                    hasNext: page * limit < total,
                    hasPrev: page > 1
                }
            }
        } catch (error) {
            console.error('Get scheduled recordings error:', error)
            throw error
        }
    }

    async getScheduledRecordingById(id) {
        try {
            const scheduledRecordings = await ScheduledRecordingQueries.findScheduledRecordings({
                where: { id },
                include: {
                    channel: true
                }
            })

            if (!scheduledRecordings || scheduledRecordings.length === 0) {
                throw new Error('Scheduled recording not found')
            }

            return scheduledRecordings[0]
        } catch (error) {
            console.error('Get scheduled recording by ID error:', error)
            throw error
        }
    }

    async updateScheduledRecording(id, data) {
        try {
            // Calculate end time if duration is updated
            if (data.duration && !data.scheduledEnd) {
                const current = await ScheduledRecordingQueries.getScheduledRecordingById(id)
                if (current) {
                    data.scheduledEnd = new Date(new Date(data.scheduledStart || current.scheduledStart).getTime() + (data.duration * 60000))
                }
            }

            const scheduledRecording = await ScheduledRecordingQueries.updateScheduledRecording(id, data)

            return scheduledRecording
        } catch (error) {
            console.error('Update scheduled recording error:', error)
            throw error
        }
    }

    async deleteScheduledRecording(id) {
        try {
            // Cancel if it's currently active
            const activeSchedule = this.activeSchedules.get(id)
            if (activeSchedule) {
                await recordingService.stopRecording(activeSchedule.channelId)
                this.activeSchedules.delete(id)
            }

            await ScheduledRecordingQueries.deleteScheduledRecording(id)

            return { success: true, message: 'Scheduled recording deleted successfully' }
        } catch (error) {
            console.error('Delete scheduled recording error:', error)
            throw error
        }
    }

    async getConflicts(filters = {}) {
        try {
            const { page = 1, limit = 10, isResolved } = filters

            const where = {}
            if (typeof isResolved === 'boolean') where.isResolved = isResolved

            // Get all conflicts and apply filters
            let allConflicts = await RecordingConflictQueries.findRecordingConflicts()

            if (typeof isResolved === 'boolean') {
                allConflicts = allConflicts.filter(c => c.isResolved === isResolved)
            }

            // Sort by creation date (newest first)
            allConflicts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

            const total = allConflicts.length
            const skip = (page - 1) * limit
            const conflicts = allConflicts.slice(skip, skip + limit)

            return {
                conflicts,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    pages: Math.ceil(total / limit)
                }
            }
        } catch (error) {
            console.error('Get conflicts error:', error)
            throw error
        }
    }

    async resolveConflict(id, resolution, winningScheduleId = null) {
        try {
            await RecordingConflictQueries.updateRecordingConflict(id, {
                resolution,
                isResolved: true
            })

            return { success: true, message: 'Conflict resolved successfully' }
        } catch (error) {
            console.error('Resolve conflict error:', error)
            throw error
        }
    }

    scheduleRecording(scheduledRecording) {
        // This method can be used to set up individual cron jobs if needed
        // For now, we rely on the main scheduler checking every minute
        console.log(`Scheduled recording registered: ${scheduledRecording.name}`)
    }
}

module.exports = new ScheduledRecordingService()
