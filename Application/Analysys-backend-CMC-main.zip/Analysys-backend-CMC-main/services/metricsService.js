const fs = require('fs-extra')
const path = require('path')
const { ClipQueries, RecordingQueries } = require('../queries')
const os = require('os')
const { recordingsDir, clipsDir } = require('../utils/path')

class MetricsService {
    constructor() {
        const BASE_DATA_DIR = path.join(process.cwd(), 'data')
        this.recordingsDir = path.join(BASE_DATA_DIR, 'recordings')
        this.clipsDir = path.join(BASE_DATA_DIR, 'clips')
        this.uploadsDir = path.join(BASE_DATA_DIR, '..', 'uploads')

        // Performance tracking
        this.performanceMetrics = {
            activeRecordings: 0,
            processingClips: 0,
            cpuUsage: [],
            memoryUsage: [],
            systemLoad: []
        }

        // Start monitoring system performance
        this.startPerformanceMonitoring()
    }

    // Clip Creation Metrics
    async getClipCreationMetrics(options = {}) {
        try {
            const { dateFrom, dateTo, limit = 10 } = options
            const whereClause = {}

            // Date filtering
            if (dateFrom || dateTo) {
                whereClause.createdAt = {}
                if (dateFrom) whereClause.createdAt.gte = new Date(dateFrom)
                if (dateTo) whereClause.createdAt.lte = new Date(dateTo)
            }

            // Get clip statistics grouped by various criteria
            const [
                clipsByRecording,
                clipsByChannel,
                clipsByStatus,
                clipsByFormat,
                clipsByDay,
                totalClips,
                averageClipDuration,
                totalStorageUsed
            ] = await Promise.all([
                this.getClipsByRecording(whereClause, limit),
                this.getClipsByChannel(whereClause, limit),
                this.getClipsByStatus(whereClause),
                this.getClipsByFormat(whereClause),
                this.getClipsByDay(whereClause, 30), // Last 30 days
                this.getTotalClipsCount(whereClause),
                this.getAverageClipDuration(whereClause),
                this.getClipStorageUsage(whereClause)
            ])

            return {
                success: true,
                data: {
                    overview: {
                        totalClips,
                        averageClipDuration: Math.round(averageClipDuration * 100) / 100,
                        totalStorageUsed: this.formatBytes(totalStorageUsed)
                    },
                    groupedData: {
                        byRecording: clipsByRecording,
                        byChannel: clipsByChannel,
                        byStatus: clipsByStatus,
                        byFormat: clipsByFormat,
                        byDay: clipsByDay
                    }
                }
            }
        } catch (error) {
            console.error('Get clip creation metrics error:', error)
            throw error
        }
    }

    async getClipsByRecording(whereClause, limit) {
        // Convert whereClause to filters for ClipQueries
        const filters = {}

        if (whereClause.createdAt) {
            if (whereClause.createdAt.gte) filters.createdAtFrom = whereClause.createdAt.gte
            if (whereClause.createdAt.lte) filters.createdAtTo = whereClause.createdAt.lte
        }

        const result = await ClipQueries.findClipsMany({
            filters,
            includeRecording: true,
            limit: 0,
            offset: 0
        })

        const clips = result.clips

        // Group by recording
        const recordingStats = {}
        clips.forEach(clip => {
            const recordingId = clip.recordingId
            if (!recordingStats[recordingId]) {
                recordingStats[recordingId] = {
                    recordingId,
                    recordingName: clip.recordingFileName || 'Unknown',
                    channelName: clip.channelName || 'Unknown',
                    clipsCount: 0
                }
            }
            recordingStats[recordingId].clipsCount++
        })

        return Object.values(recordingStats)
            .sort((a, b) => b.clipsCount - a.clipsCount)
            .slice(0, limit)
    }

    async getClipsByChannel(whereClause, limit) {
        // Convert whereClause to filters for ClipQueries
        const filters = {}

        if (whereClause.createdAt) {
            if (whereClause.createdAt.gte) filters.createdAtFrom = whereClause.createdAt.gte
            if (whereClause.createdAt.lte) filters.createdAtTo = whereClause.createdAt.lte
        }

        // Get all clips within the criteria (without limit for grouping)
        const result = await ClipQueries.findClipsMany({
            filters,
            includeRecording: true,
            limit: 0,
            offset: 0
        })

        const clips = result.clips

        // Group by channel
        const channelStats = {}
        clips.forEach(clip => {
            const channelName = clip.channelName || 'Unknown'
            if (!channelStats[channelName]) {
                channelStats[channelName] = {
                    channelName,
                    clipsCount: 0,
                    totalDuration: 0,
                    channelId: clip.channelId || null
                }
            }
            channelStats[channelName].clipsCount++
            channelStats[channelName].totalDuration += (clip.duration || 0)
        })

        return Object.values(channelStats)
            .sort((a, b) => b.clipsCount - a.clipsCount)
            .slice(0, limit)
    }

    async getClipsByStatus(whereClause) {
        // Convert whereClause to filters for ClipQueries
        const filters = {}

        if (whereClause.createdAt) {
            if (whereClause.createdAt.gte) filters.createdAtFrom = whereClause.createdAt.gte
            if (whereClause.createdAt.lte) filters.createdAtTo = whereClause.createdAt.lte
        }

        const result = await ClipQueries.findClipsMany({ filters, limit: 0, offset: 0 })
        const clips = result.clips

        // Group by status
        const statusStats = {}
        clips.forEach(clip => {
            const status = clip.status || 'unknown'
            if (!statusStats[status]) {
                statusStats[status] = { status, _count: { id: 0 } }
            }
            statusStats[status]._count.id++
        })

        return Object.values(statusStats)
    }

    async getClipsByFormat(whereClause) {
        // Convert whereClause to filters for ClipQueries
        const filters = {}

        if (whereClause.createdAt) {
            if (whereClause.createdAt.gte) filters.createdAtFrom = whereClause.createdAt.gte
            if (whereClause.createdAt.lte) filters.createdAtTo = whereClause.createdAt.lte
        }

        const result = await ClipQueries.findClipsMany({ filters, limit: 0, offset: 0 })
        const clips = result.clips

        // Group by format
        const formatStats = {}
        clips.forEach(clip => {
            const format = clip.format || 'unknown'
            if (!formatStats[format]) {
                formatStats[format] = { format, _count: { id: 0 } }
            }
            formatStats[format]._count.id++
        })

        return Object.values(formatStats)
    }

    async getClipsByDay(whereClause, days = 30) {
        const endDate = new Date()
        const startDate = new Date(endDate.getTime() - (days * 24 * 60 * 60 * 1000))

        // Build filters
        const filters = {}

        // Apply original whereClause filters
        if (whereClause.createdAt) {
            if (whereClause.createdAt.gte) filters.createdAtFrom = whereClause.createdAt.gte
            if (whereClause.createdAt.lte) filters.createdAtTo = whereClause.createdAt.lte
        }

        // Override with day range
        filters.createdAtFrom = startDate
        filters.createdAtTo = endDate

        const result = await ClipQueries.findClipsMany({
            filters,
            limit: 0,
            offset: 0
        })

        const clips = result.clips

        // Group by day
        const dailyStats = {}
        clips.forEach(clip => {
            const day = new Date(clip.createdAt).toISOString().split('T')[0]
            if (!dailyStats[day]) {
                dailyStats[day] = {
                    date: day,
                    clipsCount: 0,
                    totalDuration: 0
                }
            }
            dailyStats[day].clipsCount++
            dailyStats[day].totalDuration += (clip.duration || 0)
        })

        return Object.values(dailyStats).sort((a, b) => new Date(a.date) - new Date(b.date))
    }

    async getTotalClipsCount(whereClause) {
        // Convert whereClause to filters for ClipQueries
        const filters = {}

        if (whereClause.createdAt) {
            if (whereClause.createdAt.gte) filters.createdAtFrom = whereClause.createdAt.gte
            if (whereClause.createdAt.lte) filters.createdAtTo = whereClause.createdAt.lte
        }

        const result = await ClipQueries.findClipsMany({ filters, limit: 0, offset: 0 })
        return result.total
    }

    async getAverageClipDuration(whereClause) {
        // Convert whereClause to filters for ClipQueries
        const filters = {}

        if (whereClause.createdAt) {
            if (whereClause.createdAt.gte) filters.createdAtFrom = whereClause.createdAt.gte
            if (whereClause.createdAt.lte) filters.createdAtTo = whereClause.createdAt.lte
        }

        const result = await ClipQueries.findClipsMany({ filters, limit: 0, offset: 0 })
        const clips = result.clips

        if (clips.length === 0) return 0

        const totalDuration = clips.reduce((sum, clip) => sum + (clip.duration || 0), 0)
        return totalDuration / clips.length
    }

    async getClipStorageUsage(whereClause) {
        // Convert whereClause to filters for ClipQueries
        const filters = {}

        if (whereClause.createdAt) {
            if (whereClause.createdAt.gte) filters.createdAtFrom = whereClause.createdAt.gte
            if (whereClause.createdAt.lte) filters.createdAtTo = whereClause.createdAt.lte
        }

        const result = await ClipQueries.findClipsMany({ filters, limit: 0, offset: 0 })
        const clips = result.clips

        return clips.reduce((sum, clip) => sum + (clip.fileSize || 0), 0)
    }

    // Storage Utilization Metrics
    async getStorageUtilization() {
        try {
            const [
                recordingsStorage,
                clipsStorage,
                uploadsStorage,
                systemStorage
            ] = await Promise.all([
                this.getDirectorySize(this.recordingsDir),
                this.getDirectorySize(this.clipsDir),
                this.getDirectorySize(this.uploadsDir),
                this.getSystemStorageInfo()
            ])

            const totalUsed = recordingsStorage + clipsStorage + uploadsStorage
            const usageBreakdown = {
                recordings: {
                    size: recordingsStorage,
                    formatted: this.formatBytes(recordingsStorage),
                    percentage: totalUsed > 0 ? Math.round((recordingsStorage / totalUsed) * 100) : 0
                },
                clips: {
                    size: clipsStorage,
                    formatted: this.formatBytes(clipsStorage),
                    percentage: totalUsed > 0 ? Math.round((clipsStorage / totalUsed) * 100) : 0
                },
                uploads: {
                    size: uploadsStorage,
                    formatted: this.formatBytes(uploadsStorage),
                    percentage: totalUsed > 0 ? Math.round((uploadsStorage / totalUsed) * 100) : 0
                }
            }

            return {
                success: true,
                data: {
                    totalUsed: {
                        size: totalUsed,
                        formatted: this.formatBytes(totalUsed)
                    },
                    breakdown: usageBreakdown,
                    system: systemStorage,
                    timestamp: new Date().toISOString()
                }
            }
        } catch (error) {
            console.error('Get storage utilization error:', error)
            throw error
        }
    }

    async getDirectorySize(dirPath) {
        try {
            if (!await fs.pathExists(dirPath)) {
                return 0
            }

            const files = await fs.readdir(dirPath, { withFileTypes: true })
            let totalSize = 0

            for (const file of files) {
                const filePath = path.join(dirPath, file.name)
                if (file.isDirectory()) {
                    totalSize += await this.getDirectorySize(filePath)
                } else {
                    const stats = await fs.stat(filePath)
                    totalSize += stats.size
                }
            }

            return totalSize
        } catch (error) {
            console.warn(`Error calculating directory size for ${dirPath}:`, error.message)
            return 0
        }
    }

    async getSystemStorageInfo() {
        try {
            const stats = await fs.stat(path.join(process.cwd(), '..'))
            const diskUsage = {
                total: 0,
                free: 0,
                used: 0
            }

            try {
                const statvfs = await fs.statfs(path.resolve(process.cwd(), '..'))
                diskUsage.total = statvfs.bsize * statvfs.blocks
                diskUsage.free = statvfs.bsize * statvfs.bfree
                diskUsage.used = diskUsage.total - diskUsage.free
                diskUsage.available = true
            } catch {
                diskUsage.available = false
            }

            return diskUsage
        } catch (error) {
            return { available: false, error: error.message }
        }
    }

    // System Performance Metrics
    async getSystemPerformanceMetrics() {
        try {
            const currentMetrics = this.getCurrentPerformanceSnapshot()

            return {
                success: true,
                data: {
                    current: currentMetrics,
                    history: {
                        cpuUsage: this.performanceMetrics.cpuUsage.slice(-20), // Last 20 readings
                        memoryUsage: this.performanceMetrics.memoryUsage.slice(-20),
                        systemLoad: this.performanceMetrics.systemLoad.slice(-20)
                    },
                    active: {
                        recordings: this.performanceMetrics.activeRecordings,
                        processingClips: this.performanceMetrics.processingClips
                    },
                    timestamp: new Date().toISOString()
                }
            }
        } catch (error) {
            console.error('Get system performance metrics error:', error)
            throw error
        }
    }

    getCurrentPerformanceSnapshot() {
        const memUsage = process.memoryUsage()
        const cpuUsage = process.cpuUsage()
        const systemLoad = os.loadavg()
        const freeMemory = os.freemem()
        const totalMemory = os.totalmem()
        const cpus = os.cpus()

        // Calculate CPU usage percentage based on actual CPU time
        const totalCpuTime = cpus.reduce((sum, cpu) => {
            const times = cpu.times
            return sum + times.user + times.nice + times.sys + times.idle + times.irq
        }, 0)
        const idleCpuTime = cpus.reduce((sum, cpu) => sum + cpu.times.idle, 0)
        const cpuUsagePercent = totalCpuTime > 0 ? ((totalCpuTime - idleCpuTime) / totalCpuTime) * 100 : 0

        return {
            cpu: {
                user: cpuUsage.user,
                system: cpuUsage.system,
                usage: Math.round(cpuUsagePercent * 100) / 100, // Use actual CPU percentage
                cores: cpus.length,
                speed: cpus[0]?.speed || 0 // MHz of first core
            },
            memory: {
                rss: memUsage.rss,
                heapTotal: memUsage.heapTotal,
                heapUsed: memUsage.heapUsed,
                external: memUsage.external,
                arrayBuffers: memUsage.arrayBuffers,
                systemFree: freeMemory,
                systemTotal: totalMemory,
                systemUsage: Math.round(((totalMemory - freeMemory) / totalMemory) * 100)
            },
            system: {
                loadAverage: systemLoad,
                platform: os.platform(),
                arch: os.arch(),
                cpuCount: cpus.length,
                uptime: os.uptime(),
                nodeVersion: process.version
            }
        }
    }

    startPerformanceMonitoring() {
        // Store previous CPU times for delta calculation
        let previousCpuTimes = os.cpus().map(cpu => ({ ...cpu.times }))

        // Collect performance metrics every 10 seconds
        setInterval(() => {
            const snapshot = this.getCurrentPerformanceSnapshot()
            const timestamp = Date.now()
            const currentCpus = os.cpus()

            // Calculate CPU usage since last measurement
            let totalDelta = 0
            let idleDelta = 0

            currentCpus.forEach((cpu, index) => {
                const prevTimes = previousCpuTimes[index]
                const times = cpu.times

                const total = Object.values(times).reduce((sum, val) => sum + val, 0)
                const prevTotal = Object.values(prevTimes).reduce((sum, val) => sum + val, 0)
                totalDelta += total - prevTotal
                idleDelta += times.idle - prevTimes.idle
            })

            const cpuUsagePercent = totalDelta > 0 ? ((totalDelta - idleDelta) / totalDelta) * 100 : 0

            // Update previous CPU times
            previousCpuTimes = currentCpus.map(cpu => ({ ...cpu.times }))

            // Store CPU usage percentage
            this.performanceMetrics.cpuUsage.push({
                timestamp,
                value: Math.round(cpuUsagePercent * 100) / 100
            })

            // Store memory usage percentage
            this.performanceMetrics.memoryUsage.push({
                timestamp,
                value: snapshot.memory.systemUsage
            })

            // Store system load average
            this.performanceMetrics.systemLoad.push({
                timestamp,
                value: snapshot.system.loadAverage[0]
            })

            // Keep only last 100 readings (about 16 minutes of data)
            if (this.performanceMetrics.cpuUsage.length > 100) {
                this.performanceMetrics.cpuUsage = this.performanceMetrics.cpuUsage.slice(-100)
            }
            if (this.performanceMetrics.memoryUsage.length > 100) {
                this.performanceMetrics.memoryUsage = this.performanceMetrics.memoryUsage.slice(-100)
            }
            if (this.performanceMetrics.systemLoad.length > 100) {
                this.performanceMetrics.systemLoad = this.performanceMetrics.systemLoad.slice(-100)
            }
        }, 10000) // 10 seconds
    }

    // Update active counters (called from other services)
    updateActiveRecordings(count) {
        this.performanceMetrics.activeRecordings = count
    }

    updateProcessingClips(count) {
        this.performanceMetrics.processingClips = count
    }

    // Utility function to format bytes
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes'
        const k = 1024
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
        const i = Math.floor(Math.log(bytes) / Math.log(k))
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
    }

    // Get metrics for real-time socket updates
    async getRealTimeMetrics() {
        try {
            const [storageData, performanceData] = await Promise.all([
                this.getStorageUtilization(),
                this.getSystemPerformanceMetrics()
            ])

            return {
                storage: storageData.data,
                performance: performanceData.data,
                timestamp: new Date().toISOString()
            }
        } catch (error) {
            console.error('Get real-time metrics error:', error)
            return {
                error: error.message,
                timestamp: new Date().toISOString()
            }
        }
    }
}

module.exports = new MetricsService()