import { useState, useEffect, useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { useDebounce } from 'react-haiku'
import { useRecordingColumns } from './columns'
import { getAllRecordings } from '@/services/recording/recordingApi'
import DataTable from '@/components/ui/data-table/data-table'
import RecordingFilters from '../recording-filters'

// Updated RecordingTable component
const RecordingTable = () => {
  const [searchParams, setSearchParams] = useSearchParams()

  // Pagination states
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1)
  const [limit, setLimit] = useState(Number(searchParams.get('limit')) || 10)

  // Extract filter values from URL params
  const filterParams = useMemo(() => {
    const params = {}
    const filterKeys = [
      'search',
      'status',
      'format',
      'channelId',
      'channelName',
      'fileName',
      'sourceIp',
      'sourcePort',
      'dateFrom',
      'dateTo',
      'startTimeFrom',
      'startTimeTo',
      'endTimeFrom',
      'endTimeTo',
      'minFileSize',
      'maxFileSize',
      'minDuration',
      'maxDuration'
    ]

    filterKeys.forEach((key) => {
      const value = searchParams.get(key)
      if (value) params[key] = value
    })

    return params
  }, [searchParams])

  // Debounce filter params for API calls
  const debouncedFilterParams = useDebounce(filterParams, 1000)

  const { data, isPending } = useQuery({
    queryKey: ['recordings', page, limit, debouncedFilterParams],
    queryFn: () =>
      getAllRecordings({
        page,
        limit,
        sortBy: searchParams.get('sortBy') || 'createdAt',
        sortOrder: searchParams.get('sortOrder') || 'desc',
        ...debouncedFilterParams
      })
  })

  // Update URL when pagination changes
  useEffect(() => {
    const params = new URLSearchParams(searchParams)
    params.set('page', page.toString())
    params.set('limit', limit.toString())
    setSearchParams(params, { replace: true })
  }, [page, limit, searchParams, setSearchParams])

  // Reset page when filters change
  useEffect(() => {
    if (page !== 1) {
      setPage(1)
    }
  }, [debouncedFilterParams])

  console.log('Recordings List:', data)
  const recordings = data?.recordings || []
  const columns = useRecordingColumns()

  const handlePageChange = (newPage) => {
    setPage(newPage)
  }

  const handleLimitChange = (newLimit) => {
    setLimit(newLimit)
    setPage(1)
  }

  return (
    <div className="space-y-4">
      <RecordingFilters />
      <DataTable
        columns={columns}
        data={recordings}
        isPending={isPending}
        isPagination
        pagination={{
          page,
          limit,
          totalPages: data?.pagination?.totalPages || 1
        }}
        onPageChange={handlePageChange}
        onLimitChange={handleLimitChange}
      />
    </div>
  )
}

export default RecordingTable
