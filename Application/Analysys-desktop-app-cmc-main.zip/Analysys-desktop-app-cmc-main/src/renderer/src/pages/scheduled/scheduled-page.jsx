import Container from '@/components/common/dash-container'
import ScheduleTable from '@/components/scheduled/table/schedule-table'

import { buttonVariants } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import { Link } from 'react-router-dom'

const ScheduledPage = () => {
  return (
    <Container>
      <Card>
        <CardHeader>
          <CardTitle>
            <div className="flex items-center justify-between">
              <h4>Recording Schedules</h4>
              <Link
                to="/scheduled-recordings/new"
                className={cn(
                  buttonVariants({
                    variant: 'default',
                    size: 'sm'
                  })
                )}
              >
                Create schedule
              </Link>
            </div>
          </CardTitle>
        </CardHeader>

        <CardContent>
          <ScheduleTable />
        </CardContent>
      </Card>
    </Container>
  )
}

export default ScheduledPage
