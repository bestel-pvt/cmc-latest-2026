import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { CalendarIcon, Filter, Save, Search, X } from 'lucide-react'
import { format } from 'date-fns'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Checkbox } from '@/components/ui/checkbox'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'

// Demo data
const demoChannels = [
  { id: 'news24', name: 'News 24' },
  { id: 'sports-hd', name: 'Sports HD' },
  { id: 'movie-central', name: 'Movie Central' },
  { id: 'kids-tv', name: 'Kids TV' }
]

const demoRecordings = [
  {
    id: '1',
    title: 'Morning News Update',
    channel: 'news24',
    date: '2023-11-15',
    duration: 30,
    metadata: 'Breaking news about economic developments and market trends'
  },
  {
    id: '2',
    title: 'Football Highlights',
    channel: 'sports-hd',
    date: '2023-11-14',
    duration: 45,
    metadata: 'Weekly football highlights from premier league matches'
  },
  {
    id: '3',
    title: 'Cartoon Time',
    channel: 'kids-tv',
    date: '2023-11-15',
    duration: 60,
    metadata: 'Popular cartoon series for children ages 5-12'
  },
  {
    id: '4',
    title: 'Blockbuster Movie',
    channel: 'movie-central',
    date: '2023-11-13',
    duration: 120,
    metadata: 'Action packed movie with famous actors and special effects'
  }
]

// Form schema
const formSchema = z.object({
  searchText: z.string().optional(),
  channels: z.array(z.string()).optional(),
  startDate: z.date().optional(),
  endDate: z.date().optional(),
  savedSearchName: z.string().optional()
})

const SearchComponent = () => {
  const [searchResults, setSearchResults] = useState([])
  const [savedSearches, setSavedSearches] = useState([])
  const [showSavedSearches, setShowSavedSearches] = useState(false)

  // Load saved searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('savedSearches')
    if (saved) setSavedSearches(JSON.parse(saved))
  }, [])

  // Initialize form
  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      searchText: '',
      channels: [],
      startDate: undefined,
      endDate: undefined,
      savedSearchName: ''
    }
  })

  // Load form state from localStorage
  useEffect(() => {
    const savedForm = localStorage.getItem('searchFormState')
    if (savedForm) {
      const parsed = JSON.parse(savedForm)
      // Convert string dates back to Date objects
      if (parsed.startDate) parsed.startDate = new Date(parsed.startDate)
      if (parsed.endDate) parsed.endDate = new Date(parsed.endDate)
      form.reset(parsed)
    }
  }, [form])

  // Save form state to localStorage
  useEffect(() => {
    const subscription = form.watch((value) => {
      localStorage.setItem('searchFormState', JSON.stringify(value))
    })
    return () => subscription.unsubscribe()
  }, [form])

  // Search function
  const onSubmit = (data) => {
    const results = demoRecordings.filter((recording) => {
      // Full-text search
      if (data.searchText) {
        const searchLower = data.searchText.toLowerCase()
        const matchesText =
          recording.title.toLowerCase().includes(searchLower) ||
          recording.metadata.toLowerCase().includes(searchLower)
        if (!matchesText) return false
      }

      // Channel filter
      if (data.channels && data.channels.length > 0) {
        if (!data.channels.includes(recording.channel)) return false
      }

      // Date range filter
      if (data.startDate || data.endDate) {
        const recordingDate = new Date(recording.date)
        if (data.startDate && recordingDate < data.startDate) return false
        if (data.endDate && recordingDate > data.endDate) return false
      }

      return true
    })

    setSearchResults(results)
  }

  // Save search function
  const saveSearch = () => {
    const currentValues = form.getValues()
    const newSavedSearch = {
      name: currentValues.savedSearchName || `Search ${savedSearches.length + 1}`,
      filters: {
        searchText: currentValues.searchText,
        channels: currentValues.channels,
        startDate: currentValues.startDate,
        endDate: currentValues.endDate
      }
    }

    const updatedSearches = [...savedSearches, newSavedSearch]
    setSavedSearches(updatedSearches)
    localStorage.setItem('savedSearches', JSON.stringify(updatedSearches))
    form.setValue('savedSearchName', '')
  }

  const removeSavedSearch = (indexToRemove) => {
    const updatedSearches = savedSearches.filter((_, index) => index !== indexToRemove)
    setSavedSearches(updatedSearches)
    localStorage.setItem('savedSearches', JSON.stringify(updatedSearches))
  }

  // Load saved search
  const loadSavedSearch = (search) => {
    form.reset({
      searchText: search.filters.searchText,
      channels: search.filters.channels,
      startDate: search.filters.startDate,
      endDate: search.filters.endDate,
      savedSearchName: ''
    })
    onSubmit(search.filters)
  }

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="flex items-center gap-4">
            <FormField
              control={form.control}
              name="searchText"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormLabel>Search Text</FormLabel>
                  <FormControl>
                    <Input placeholder="Search in titles and metadata..." {...field} />
                  </FormControl>
                </FormItem>
              )}
            />

            <Button type="submit" className="self-end" size="icon">
              <Search />
            </Button>
          </div>

          <div className="flex flex-wrap gap-4">
            <FormField
              control={form.control}
              name="channels"
              render={({ field }) => (
                <FormItem className="w-full md:w-auto">
                  <FormLabel>Channels</FormLabel>
                  <Select
                    onValueChange={(value) => {
                      const current = field.value || []
                      if (current.includes(value)) {
                        field.onChange(current.filter((ch) => ch !== value))
                      } else {
                        field.onChange([...current, value])
                      }
                    }}
                  >
                    <FormControl>
                      <SelectTrigger className="w-[200px]">
                        <div className="flex items-center">
                          <Filter className="h-4 w-4 mr-2" />
                          <span>Select channels</span>
                        </div>
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {demoChannels.map((channel) => (
                        <SelectItem
                          key={channel.id}
                          value={channel.id}
                          className="flex items-center"
                        >
                          <div className="flex items-center">
                            <Checkbox
                              checked={field.value?.includes(channel.id)}
                              className="mr-2"
                            />
                            {channel.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Start Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={'outline'}
                          className="w-[200px] pl-3 text-left font-normal"
                        >
                          {field.value ? format(field.value, 'PPP') : <span>Pick a date</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date > new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="endDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>End Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={'outline'}
                          className="w-[200px] pl-3 text-left font-normal"
                        >
                          {field.value ? format(field.value, 'PPP') : <span>Pick a date</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date > new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </FormItem>
              )}
            />
          </div>

          <div className="flex items-center gap-4">
            <FormField
              control={form.control}
              name="savedSearchName"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormLabel>Save this search as</FormLabel>
                  <div className="flex gap-2">
                    <FormControl>
                      <Input placeholder="My favorite search..." {...field} />
                    </FormControl>
                    <Button type="button" variant="secondary" onClick={saveSearch}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                  </div>
                </FormItem>
              )}
            />

            <Button
              type="button"
              variant="outline"
              onClick={() => setShowSavedSearches(!showSavedSearches)}
              className="self-end"
            >
              {showSavedSearches ? 'Hide' : 'Show'} Saved Searches
            </Button>
          </div>
        </form>
      </Form>

      {showSavedSearches && savedSearches.length > 0 && (
        <div className="space-y-2">
          <h6 className="font-medium">Saved Searches</h6>
          <div className="flex flex-wrap gap-2">
            {savedSearches.map((search, index) => (
              <div key={index} className="relative group">
                <Badge
                  variant="outline"
                  className="cursor-pointer hover:bg-secondary pr-6"
                  onClick={() => loadSavedSearch(search)}
                >
                  {search.name}
                </Badge>
                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    removeSavedSearch(index)
                  }}
                  className="absolute right-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
          <Separator className="my-4" />
        </div>
      )}

      {searchResults.length > 0 ? (
        <div className="space-y-4">
          <h3 className="font-medium">Results ({searchResults.length})</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {searchResults.map((result) => (
              <Card key={result.id}>
                <CardHeader>
                  <CardTitle>{result.title}</CardTitle>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{demoChannels.find((c) => c.id === result.channel)?.name}</span>
                    <span>•</span>
                    <span>{result.date}</span>
                    <span>•</span>
                    <span>{result.duration} mins</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">{result.metadata}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ) : (
        form.formState.isSubmitted && (
          <div className="text-center py-8 text-muted-foreground">
            No results found. Try adjusting your search criteria.
          </div>
        )
      )}
    </div>
  )
}

export default SearchComponent
