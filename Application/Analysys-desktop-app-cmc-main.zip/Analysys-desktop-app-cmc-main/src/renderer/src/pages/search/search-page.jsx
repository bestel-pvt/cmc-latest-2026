import Container from '@/components/common/dash-container'
import SearchComponent from '@/components/search/search-files'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const SearchPage = () => {
  return (
    <Container>
      <Card className="">
        <CardHeader>
          <CardTitle>
            <h4>Search</h4>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <SearchComponent />

          <iframe
            className="aspect-video h-68"
            src="https://www.youtube.com/embed/RqUZ2Fv9l8w"
            title="🔴 ARY NEWS LIVE | Latest Pakistan News 𝟐𝟒/𝟕 | Headlines, Bulletins, Breaking News"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen; "
            referrerPolicy="strict-origin-when-cross-origin"
            allowfullscreen
          ></iframe>
        </CardContent>
      </Card>
    </Container>
  )
}

export default SearchPage
