const path = require('path')
const fs = require('fs')

// Choose a writable base directory
const baseDir = path.join(process.cwd(), 'data')

// Make sure it exists
if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(baseDir, { recursive: true })
}

// Example directories
const recordingsDir = path.join(baseDir, 'recordings')
const streamsDir = path.join(baseDir, 'streams')
const clipsDir = path.join(baseDir, 'clips')

// Ensure they exist
for (const dir of [recordingsDir, streamsDir, clipsDir]) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true })
    }
}


const ffmpegStatic = path.join(process.cwd(), 'bin', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');

// Export paths so your services can use them
module.exports = {
    recordingsDir,
    streamsDir,
    clipsDir,
    ffmpegStatic
}