import { format } from 'date-fns'
import { CalendarIcon, Search, X, Filter } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'
import { SORTBY, STATUS } from '@/constants/clip'
import { useEffect, useMemo, useState } from 'react'
import { useDebounce } from 'react-haiku'
import { useSearchParams } from 'react-router-dom'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { createAndupdateSearch } from '@/services/search/searchApi'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '../ui/dialog'
import SaveSearches from './save-searches'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../ui/form'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { searchSchema } from '@/services/clipping/schema'
import toast from 'react-hot-toast'

const ClipFilters = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [openFilter, setOpenfilter] = useState(false)
  const [openSave, setOpenSave] = useState(false)
  const queryClient = useQueryClient()

  // Filter states
  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    status: searchParams.get('status') || '',
    tags: searchParams.get('tags') || '',
    recordingId: searchParams.get('recordingId') || '',
    channelName: searchParams.get('channelName') || '',
    clipName: searchParams.get('clipName') || '',
    dateFrom: searchParams.get('dateFrom') || '',
    dateTo: searchParams.get('dateTo') || '',
    sortBy: searchParams.get('sortBy') || 'createdAt',
    sortOrder: searchParams.get('sortOrder') || 'desc'
  })
  // Debounced filters
  const debouncedFilters = useDebounce(filters, 1000)

  // Date states for calendar pickers
  const [dateFromCalendar, setDateFromCalendar] = useState(
    filters.dateFrom ? new Date(filters.dateFrom) : undefined
  )
  const [dateToCalendar, setDateToCalendar] = useState(
    filters.dateTo ? new Date(filters.dateTo) : undefined
  )

  // Update URL when debounced filters change
  useEffect(() => {
    const params = new URLSearchParams(searchParams)

    Object.entries(debouncedFilters).forEach(([key, value]) => {
      if (value && value.trim() !== '') {
        params.set(key, value)
      } else {
        params.delete(key)
      }
    })

    // Reset page to 1 when filters change
    if (params.toString() !== searchParams.toString()) {
      params.set('page', '1')
      setSearchParams(params, { replace: true })
    }
  }, [debouncedFilters, searchParams, setSearchParams])

  // Handle filter changes
  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value
    }))
  }

  // Handle date changes
  const handleDateChange = (key, date, setCalendarState) => {
    const dateValue = date ? format(date, 'yyyy-MM-dd') : ''
    setCalendarState(date)
    handleFilterChange(key, dateValue)
  }

  // Check if any filters are active
  const hasActiveFilters = useMemo(() => {
    return Object.entries(filters).some(([key, value]) => {
      if (key === 'sortBy' && value === 'createdAt') return false
      if (key === 'sortOrder' && value === 'desc') return false
      return value && value.trim() !== ''
    })
  }, [filters])

  // Clear all filters
  const clearAllFilters = () => {
    const clearedFilters = {
      search: '',
      status: '',
      tags: '',
      recordingId: '',
      channelName: '',
      clipName: '',
      dateFrom: '',
      dateTo: '',
      sortBy: 'createdAt',
      sortOrder: 'desc'
    }

    setFilters(clearedFilters)
    setDateFromCalendar(undefined)
    setDateToCalendar(undefined)

    // Clear URL params except page and limit
    const params = new URLSearchParams()
    if (searchParams.get('page')) params.set('page', searchParams.get('page'))
    if (searchParams.get('limit')) params.set('limit', searchParams.get('limit'))
    params.set('sortBy', 'createdAt')
    params.set('sortOrder', 'desc')
    setSearchParams(params, { replace: true })
  }

  // Get active filter count
  const activeFilterCount = useMemo(() => {
    return Object.entries(filters).filter(([key, value]) => {
      if (key === 'sortBy' && value === 'createdAt') return false
      if (key === 'sortOrder' && value === 'desc') return false
      return value && value.trim() !== ''
    }).length
  }, [filters])

  const form = useForm({
    defaultValues: {
      name: ''
    },
    resolver: zodResolver(searchSchema),
    mode: 'onSubmit'
  })

  const mutationSaveSearch = useMutation({
    mutationFn: async (values) => {
      console.log(values)
      return await createAndupdateSearch(values)
    },
    onSuccess: (success) => {
      queryClient.invalidateQueries(['saved-searches'])
      toast.success(success?.message || 'Recent search added successfully!')
      console.log(success)
      form.reset()
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || 'An error occurred')
    }
  })
  const onSubmit = async (values) => {
    console.log(values)
    await mutationSaveSearch.mutateAsync({
      name: values.name,
      type: 'clip',
      query: JSON.stringify(filters)
    })
  }

  const handleApplySaved = (savedQuery) => {
    setFilters((prev) => ({
      ...prev,
      ...savedQuery
    }))
    // Optionally sync with URL:
    Object.entries(savedQuery).forEach(([key, value]) => {
      if (value) searchParams.set(key, value)
      else searchParams.delete(key)
    })
    setSearchParams(searchParams)
  }

  return (
    <div className="mb-6">
      <div className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setOpenfilter(!openFilter)}>
              <Filter />
              Filters
            </Button>
            <SaveSearches
              type="clip"
              open={openSave}
              setOpen={setOpenSave}
              onApply={handleApplySaved}
            />
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-2">
                {activeFilterCount} active
              </Badge>
            )}
          </div>
          {hasActiveFilters && (
            <Button
              variant="outline"
              size="sm"
              onClick={clearAllFilters}
              className="flex items-center gap-2"
            >
              <X className="h-4 w-4" />
              Clear Filters
            </Button>
          )}
        </div>
      </div>

      {openFilter && (
        <div className="space-y-6">
          {/* Search */}
          <div className="space-y-2">
            <Label htmlFor="search">Search</Label>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                id="search"
                placeholder="Search clips..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                className="pl-8"
              />
            </div>
          </div>

          <Separator />

          {/* Basic Filters and Sorting */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={filters.status}
                onValueChange={(value) => handleFilterChange('status', value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {/* <SelectItem value="">All Status</SelectItem> */}
                  {STATUS?.map((s, idx) => (
                    <SelectItem key={idx} value={s?.value}>
                      {s?.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sortBy">Sort By</Label>
              <Select
                value={filters.sortBy}
                onValueChange={(value) => handleFilterChange('sortBy', value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  {SORTBY?.map((s, idx) => (
                    <SelectItem key={idx} value={s?.value}>
                      {s?.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sortOrder">Sort Order</Label>
              <Select
                value={filters.sortOrder}
                onValueChange={(value) => handleFilterChange('sortOrder', value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Sort order" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asc">Ascending</SelectItem>
                  <SelectItem value="desc">Descending</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tags">Tags</Label>
              <Input
                id="tags"
                placeholder="Search by tags"
                value={filters.tags}
                onChange={(e) => handleFilterChange('tags', e.target.value)}
              />
            </div>
          </div>

          <Separator />

          {/* Content Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="recordingId">Recording ID</Label>
              <Input
                id="recordingId"
                placeholder="Enter recording ID"
                value={filters.recordingId}
                onChange={(e) => handleFilterChange('recordingId', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="channelName">Channel Name</Label>
              <Input
                id="channelName"
                placeholder="Enter channel name"
                value={filters.channelName}
                onChange={(e) => handleFilterChange('channelName', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="clipName">Clip Name</Label>
              <Input
                id="clipName"
                placeholder="Enter clip name"
                value={filters.clipName}
                onChange={(e) => handleFilterChange('clipName', e.target.value)}
              />
            </div>
          </div>

          <Separator />

          {/* Date Filters */}
          <div>
            <h6 className="text-base">Date Range</h6>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="space-y-2">
                <Label htmlFor="dateFrom">From Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !dateFromCalendar && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateFromCalendar ? format(dateFromCalendar, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      captionLayout="dropdown"
                      selected={dateFromCalendar}
                      onSelect={(date) => handleDateChange('dateFrom', date, setDateFromCalendar)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dateTo">To Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !dateToCalendar && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateToCalendar ? format(dateToCalendar, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      captionLayout="dropdown"
                      selected={dateToCalendar}
                      onSelect={(date) => handleDateChange('dateTo', date, setDateToCalendar)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>
          <div className="flex justify-end">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="">Save Search</Button>
              </DialogTrigger>

              <DialogContent className="sm:max-w-[425px]">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)}>
                    <DialogHeader>
                      <DialogTitle>Save Search</DialogTitle>
                      <DialogDescription>
                        Save your current search so you can quickly access it later. Click save when
                        you&apos;re ready.
                      </DialogDescription>
                    </DialogHeader>

                    <div className="py-6">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name of Search</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter name of this search" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <DialogFooter>
                      <DialogClose asChild>
                        <Button variant="outline" type="button" size="sm">
                          Cancel
                        </Button>
                      </DialogClose>
                      <Button type="submit" size="sm" disabled={form.formState.isSubmitting}>
                        Save search
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      )}
    </div>
  )
}

export default ClipFilters
