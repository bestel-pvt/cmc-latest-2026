import { TrendingUp } from 'lucide-react'
import { Area, AreaChart, CartesianGrid, XAxis, ResponsiveContainer } from 'recharts'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { useMemo } from 'react'

const ChartAreaStackedExpand = ({
  data = [],
  xAxis = 'month',
  yAxis = [],
  colors = [],
  maxWidth = 800,
  maxHeight = 500
}) => {
  // Build chart config dynamically based on yAxis & colors
  const chartConfig = useMemo(() => {
    return yAxis.reduce((acc, key, index) => {
      acc[key] = {
        label: key.charAt(0).toUpperCase() + key.slice(1),
        color: colors[index] || `var(--chart-${index + 1})`
      }
      return acc
    }, {})
  }, [yAxis, colors])

  const hasData = Array.isArray(data) && data.length > 0

  return (
    <Card>
      <CardHeader>
        <CardTitle>Stream Health Trends</CardTitle>
        <CardDescription>Showing health percentage for the last 6 months</CardDescription>
      </CardHeader>
      <CardContent>
        <div
          className="mx-auto w-full"
          style={{
            maxWidth,
            maxHeight,
            minHeight: 160,
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          <ChartContainer config={chartConfig}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={
                  hasData
                    ? data
                    : [
                        {
                          [xAxis]: 'No data',
                          ...Object.fromEntries(yAxis.map((k) => [k, 0]))
                        }
                      ]
                }
                margin={{ left: 12, right: 12, top: 12 }}
                stackOffset="expand"
              >
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey={xAxis}
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tickFormatter={(value) => (value ? value.slice(0, 3) : '')}
                />
                <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="line" />} />
                {yAxis.map((key, index) => (
                  <Area
                    key={key}
                    dataKey={key}
                    type="natural"
                    fill={colors[index] || `var(--chart-${index + 1})`}
                    fillOpacity={0.4}
                    stroke={colors[index] || `var(--chart-${index + 1})`}
                    stackId="a"
                  />
                ))}
              </AreaChart>
            </ResponsiveContainer>
          </ChartContainer>
        </div>
      </CardContent>
    </Card>
  )
}

export default ChartAreaStackedExpand
