import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { format } from 'date-fns'
import { Skeleton } from '../ui/skeleton'

const DasboardOverview = ({ data, isPending = false }) => {
  if (isPending) {
    return <Skeleton className="h-96 w-full" />
  }
  return (
    <div>
      <Card>
        <CardHeader>
          <CardTitle>
            <h6>System Overview</h6>
          </CardTitle>
          <CardDescription>Last updated: {format(new Date(), 'PPpp')}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <h6>Priority Channels</h6>
              <ul className="space-y-2 pt-2">
                {data
                  ?.filter((item) => item.channel.isPriority)
                  .map((item) => (
                    <li key={item.id} className="flex items-center gap-2">
                      <div
                        className={`w-2 h-2 rounded-full ${item.streamStoppedAt ? 'bg-red-500' : 'bg-green-500'}`}
                      />
                      {item.channel.name}
                    </li>
                  ))}
              </ul>
            </div>
            <div>
              <h6>Data Leaders</h6>
              <ul className="space-y-2 pt-2">
                {data
                  ?.sort((a, b) => parseInt(b.totalBytes) - parseInt(a.totalBytes))
                  ?.slice(0, 3)
                  ?.map((item) => (
                    <li key={item.id}>
                      {item.channel.name}: {(parseInt(item.totalBytes) / (1024 * 1024)).toFixed(1)}{' '}
                      MB
                    </li>
                  ))}
              </ul>
            </div>
            <div>
              <h6>Performance Leaders</h6>
              <ul className="space-y-2 pt-2">
                {data
                  ?.sort((a, b) => b.avgPacketsPerSec - a.avgPacketsPerSec)
                  ?.slice(0, 3)
                  ?.map((item) => (
                    <li key={item.id}>
                      {item.channel.name}: {item.avgPacketsPerSec} pkt/s
                    </li>
                  ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default DasboardOverview
