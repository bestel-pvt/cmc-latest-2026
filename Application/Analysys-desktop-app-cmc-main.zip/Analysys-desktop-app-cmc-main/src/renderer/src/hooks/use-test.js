import { useEffect, useState } from 'react'
import socketService from '@/services/socket/socketService'

export const useRealtimeAnalytics = () => {
  const [overviewData, setOverviewData] = useState(null)
  const [channelData, setChannelData] = useState({})
  const [events, setEvents] = useState([])
  const [isConnected, setIsConnected] = useState(socketService.isConnected)

  // Loading states
  const [loadingOverview, setLoadingOverview] = useState(true)
  const [loadingChannels, setLoadingChannels] = useState({})
  const [loadingEvents, setLoadingEvents] = useState(true)

  // Handle connection status
  useEffect(() => {
    const handleConnect = () => {
      setIsConnected(true)
      // Reset loading states when reconnecting
      setLoadingOverview(true)
      setLoadingEvents(true)
    }

    const handleDisconnect = () => setIsConnected(false)

    // Set initial connection status
    setIsConnected(socketService.isConnected)

    // Set up listeners for connection status
    if (socketService.socket) {
      socketService.socket.on('connect', handleConnect)
      socketService.socket.on('disconnect', handleDisconnect)
    }

    return () => {
      if (socketService.socket) {
        socketService.socket.off('connect', handleConnect)
        socketService.socket.off('disconnect', handleDisconnect)
      }
    }
  }, [])

  // Handle overview analytics
  useEffect(() => {
    const handleOverview = (data) => {
      // The data comes as an array where the second element is the payload
      const payload = Array.isArray(data) && data[0] === 'overview-analytics' ? data[1] : data

      setOverviewData(payload)
      setLoadingOverview(false)
    }

    setLoadingOverview(true)
    socketService.subscribeToOverview(handleOverview)

    return () => {
      socketService.unsubscribeFromOverview(handleOverview)
    }
  }, [])

  // Handle events
  useEffect(() => {
    const handleEvent = (event) => {
      setEvents((prev) => {
        // Keep last 100 events to prevent memory issues
        const newEvents = [...prev, event]
        return newEvents.slice(-100)
      })
      setLoadingEvents(false)
    }

    setLoadingEvents(true)
    socketService.subscribeToEvents(handleEvent)

    return () => {
      socketService.unsubscribeFromEvents(handleEvent)
    }
  }, [])

  // Function to subscribe to a specific channel
  const subscribeToChannel = (channelId) => {
    setLoadingChannels((prev) => ({
      ...prev,
      [channelId]: true
    }))

    const handleChannelData = (data) => {
      setChannelData((prev) => ({
        ...prev,
        [channelId]: data
      }))
      setLoadingChannels((prev) => ({
        ...prev,
        [channelId]: false
      }))
    }

    socketService.subscribeToChannel(channelId, handleChannelData)

    // Return cleanup function
    return () => {
      socketService.unsubscribeFromChannel(channelId, handleChannelData)
      setLoadingChannels((prev) => {
        const newState = { ...prev }
        delete newState[channelId]
        return newState
      })
    }
  }

  // Helper to check if a specific channel is loading
  const isChannelLoading = (channelId) => {
    return loadingChannels[channelId] === true
  }

  return {
    overviewData,
    channelData,
    events,
    isConnected,
    loadingOverview,
    loadingEvents,
    isChannelLoading,
    subscribeToChannel
  }
}
