import { useState, useEffect } from 'react'

let configCache = null
let loadingPromise = null

async function fetchConfig() {
  if (configCache) return configCache
  if (!loadingPromise) {
    loadingPromise = window.apiConfig.get().then((cfg) => {
      configCache = cfg
      return cfg
    })
  }
  return loadingPromise
}

export function useConfig() {
  const [config, setConfig] = useState(configCache)
  const [loading, setLoading] = useState(!configCache)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!configCache) {
      setLoading(true)
      fetchConfig()
        .then((cfg) => {
          setConfig(cfg)
          setLoading(false)
        })
        .catch((err) => {
          setError(err)
          setLoading(false)
        })
    }
  }, [])

  return { config, loading, error }
}

export function useApiUrl() {
  const { config, loading, error } = useConfig()
  return { apiUrl: config ? config.API_BASE_URL : null, loading, error }
}
