import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button, buttonVariants } from '@/components/ui/button'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { cn, copyToClipboard, getPriorityScheduleLabel } from '@/lib/utils'
import { format } from 'date-fns/format'
import { CheckCircle, Copy, ExternalLink, MoreHorizontal, XCircle } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import ScheduleDetail from '../schedule-detail'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { deleteScheduleRecording } from '@/services/scheduled-recordings/scheduledRecordingApi'
import ScheduleCancelDialog from '../schedule-cancel-dailog'

export const useScheduleColumns = () => {
  const queryClient = useQueryClient()
  const navigate = useNavigate()

  const mutationDelete = useMutation({
    mutationFn: async (id) => {
      return await deleteScheduleRecording(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Schedule deleted successful!')
      queryClient.invalidateQueries(['schedule-recordings'])
    },
    onError: (error) => {
      ToastError(error?.response?.data?.message)
    }
  })

  return [
    {
      header: 'Sr. no.',
      size: 60,
      enableResizing: true,
      cell: ({ row, table }) => {
        const pagination = table.options.meta?.pagination
        const currentPage = pagination?.page || 1
        const pageSize = pagination?.limit || 10
        return (currentPage - 1) * pageSize + row.index + 1
      }
    },
    {
      accessorKey: 'name',
      header: 'Show Name',
      cell: ({ row }) => {
        const show = row.original
        return (
          <div className="flex items-start gap-4">
            <div>
              <p className="font-semibold">{show?.name}</p>
              <small className="text-muted-foreground max-w-1/2 truncate overflow-hidden line-clamp-1">
                {show.description || 'No description'}
              </small>
            </div>
          </div>
        )
      }
    },
    {
      accessorKey: 'channel.name',
      header: 'Channel',
      size: 150,
      cell: ({ row }) => {
        const channel = row.original
        return channel ? (
          <div>
            <Link
              className={cn(
                buttonVariants({
                  variant: 'link',
                  size: 'sm'
                })
              )}
              to={`/channel/${channel?.channelId}`}
            >
              {channel?.channel.name}
              <ExternalLink />
            </Link>
          </div>
        ) : (
          '—'
        )
      }
    },
    // {
    //   accessorKey: 'isActive',
    //   header: 'Status',
    //   size: 120,
    //   cell: ({ cell }) => {
    //     const isActive = cell.getValue()
    //     return isActive ? (
    //       <div className="flex items-center gap-3">
    //         <span className="relative flex size-3">
    //           <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-500 opacity-75"></span>
    //           <span className="relative inline-flex size-3 rounded-full bg-green-500"></span>
    //         </span>
    //         Active
    //       </div>
    //     ) : (
    //       <p className="text-destructive">Inactive</p>
    //     )
    //   }
    // }

    {
      accessorKey: 'priority',
      header: 'Priority',
      size: 80,
      cell: ({ cell }) => {
        const priority = cell.getValue()
        return <Badge>{getPriorityScheduleLabel(priority)}</Badge>
      }
    },
    {
      accessorKey: 'scheduledStart',
      header: 'Scheduled Start',
      size: 150,
      cell: ({ cell }) => {
        const date = cell.getValue()
        return (
          <div>
            <p>{date && format(new Date(date), 'MMM dd, yyyy')}</p>
            <p className="text-muted-foreground text-xs">{date && format(new Date(date), 'pp')}</p>
          </div>
        )
      }
    },
    {
      accessorKey: 'scheduledEnd',
      header: 'Scheduled End',
      size: 150,
      cell: ({ cell }) => {
        const date = cell.getValue()
        return (
          <div>
            <p>{date && format(new Date(date), 'MMM dd, yyyy')}</p>
            <p className="text-muted-foreground text-xs">{date && format(new Date(date), 'pp')}</p>
          </div>
        )
      }
    },
    {
      accessorKey: 'isRecurring',
      header: 'Recurring',
      size: 100,
      cell: ({ cell }) => {
        const isRecurring = cell.getValue()
        return isRecurring ? (
          <div className="flex items-center gap-2">
            <CheckCircle className="size-4 text-green-500" />
            Yes
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <XCircle className="size-4 text-destructive" />
            No
          </div>
        )
      }
    },
    {
      accessorKey: 'recurrenceType',
      header: 'Recurrence Type',
      size: 120,
      cell: ({ cell }) => {
        const type = cell.getValue()
        return type ? (
          <Badge variant="outline" className="capitalize">
            {type}
          </Badge>
        ) : (
          '—'
        )
      }
    },
    {
      accessorKey: 'status',
      header: 'Status',
      size: 80,
      cell: ({ row }) => {
        const schedule = row.original
        const getStatusVariant = (status) => {
          switch (status) {
            case 'scheduled':
              return 'ghost'
            case 'recording':
              return 'secondary'
            case 'completed':
              return 'outline'
            case 'cancelled':
              return 'destructive'
            default:
              return 'outline'
          }
        }
        return (
          <div className="flex items-center gap-2">
            <Badge className="capitalize " variant={getStatusVariant(schedule?.status)}>
              {schedule?.status}
            </Badge>
            {schedule?.status !== 'cancelled' && <ScheduleCancelDialog schedule={schedule} />}
          </div>
        )
      }
    },
    {
      accessorKey: 'createdAt',
      header: 'Creation Date',
      size: 150,
      cell: ({ cell }) => {
        const date = cell.getValue()
        return date ? format(new Date(date), 'PPP, pp') : '—'
      }
    },
    {
      id: 'actions',
      enableHiding: false,
      cell: ({ row }) => {
        const schedule = row.original
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => copyToClipboard(schedule.id)}>
                Copy schedule ID
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {/* <DropdownMenuItem> */}
              <ScheduleDetail details={schedule} />

              {/* </DropdownMenuItem> */}
              <DropdownMenuItem
                onClick={() => navigate(`/scheduled-recordings/edit/${schedule?.id}`)}
              >
                Edit schedule
              </DropdownMenuItem>
              <Dialog>
                <DialogTrigger asChild>
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600">
                    Delete schedule
                  </DropdownMenuItem>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Are you sure?</DialogTitle>
                    <DialogDescription>
                      This action cannot be undone. This will permanently delete the schedule
                      <strong> {schedule.name} </strong> and all its associated data.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button
                      variant="destructive"
                      onClick={() => mutationDelete.mutate(schedule.id)}
                      loading={mutationDelete.isPending}
                    >
                      Confirm
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </DropdownMenuContent>
          </DropdownMenu>
        )
      }
    }
  ]
}
