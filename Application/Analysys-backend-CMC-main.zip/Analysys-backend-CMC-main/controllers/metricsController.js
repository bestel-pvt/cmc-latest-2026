const metricsService = require('../services/metricsService.js')

class MetricsController {
    // Get clip creation metrics
    async getClipMetrics(req, res) {
        try {
            const { dateFrom, dateTo, limit } = req.query

            const options = {}
            if (dateFrom) options.dateFrom = dateFrom
            if (dateTo) options.dateTo = dateTo
            if (limit) options.limit = parseInt(limit)

            const metrics = await metricsService.getClipCreationMetrics(options)

            res.json({
                success: true,
                message: 'Clip creation metrics retrieved successfully',
                ...metrics
            })
        } catch (error) {
            console.error('Get clip metrics error:', error)
            res.status(500).json({
                success: false,
                message: error.message || 'Failed to get clip metrics'
            })
        }
    }

    // Get storage utilization metrics
    async getStorageMetrics(req, res) {
        try {
            const metrics = await metricsService.getStorageUtilization()

            res.json({
                success: true,
                message: 'Storage utilization metrics retrieved successfully',
                ...metrics
            })
        } catch (error) {
            console.error('Get storage metrics error:', error)
            res.status(500).json({
                success: false,
                message: error.message || 'Failed to get storage metrics'
            })
        }
    }

    // Get system performance metrics
    async getPerformanceMetrics(req, res) {
        try {
            const metrics = await metricsService.getSystemPerformanceMetrics()

            res.json({
                success: true,
                message: 'System performance metrics retrieved successfully',
                ...metrics
            })
        } catch (error) {
            console.error('Get performance metrics error:', error)
            res.status(500).json({
                success: false,
                message: error.message || 'Failed to get performance metrics'
            })
        }
    }

    // Get all metrics combined
    async getAllMetrics(req, res) {
        try {
            const { dateFrom, dateTo, limit } = req.query

            const clipOptions = {}
            if (dateFrom) clipOptions.dateFrom = dateFrom
            if (dateTo) clipOptions.dateTo = dateTo
            if (limit) clipOptions.limit = parseInt(limit)

            const [clipMetrics, storageMetrics, performanceMetrics] = await Promise.all([
                metricsService.getClipCreationMetrics(clipOptions),
                metricsService.getStorageUtilization(),
                metricsService.getSystemPerformanceMetrics()
            ])

            res.json({
                success: true,
                message: 'All metrics retrieved successfully',
                data: {
                    clips: clipMetrics.data,
                    storage: storageMetrics.data,
                    performance: performanceMetrics.data
                },
                timestamp: new Date().toISOString()
            })
        } catch (error) {
            console.error('Get all metrics error:', error)
            res.status(500).json({
                success: false,
                message: error.message || 'Failed to get metrics'
            })
        }
    }

    // Get real-time metrics for socket updates
    async getRealTimeMetrics(req, res) {
        try {
            const metrics = await metricsService.getRealTimeMetrics()

            res.json({
                success: true,
                message: 'Real-time metrics retrieved successfully',
                data: metrics,
                timestamp: new Date().toISOString()
            })
        } catch (error) {
            console.error('Get real-time metrics error:', error)
            res.status(500).json({
                success: false,
                message: error.message || 'Failed to get real-time metrics'
            })
        }
    }
}

module.exports = new MetricsController()
