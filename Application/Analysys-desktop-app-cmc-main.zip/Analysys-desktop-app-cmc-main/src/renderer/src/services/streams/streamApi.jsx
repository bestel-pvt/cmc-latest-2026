import { api } from '@/lib/axios-instance'

export const getAllStrems = async () => {
  const response = await api.get('/streaming/channels')
  return response?.data
}
