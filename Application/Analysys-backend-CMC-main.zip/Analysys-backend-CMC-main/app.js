const express = require('express')
const cors = require('cors')
const dotenv = require('dotenv')
const path = require('path')
const { createServer } = require('http')
const { Server } = require('socket.io')

// Import routes
const channelRoutes = require('./routes/channelRoutes.js')
const sourceRoutes = require('./routes/sourceRoutes.js')
const uploadRoutes = require('./routes/uploadRoutes.js')
const searchRoutes = require('./routes/searchRoutes.js')
const recordingRoutes = require('./routes/recordingRoutes.js')
const streamingRoutes = require('./routes/streamingRoutes.js')
const clippingRoutes = require('./routes/clippingRoutes.js')
const recentSearchRoutes = require('./routes/recentSearchRoutes.js')
const scheduledRecordingRoutes = require('./routes/scheduledRecordingRoutes.js')
const metricsRoutes = require('./routes/metricsRoutes.js')

// Initialize scheduled recording service
require('./services/scheduledRecordingService.js')
// Import metrics service for real-time updates
const metricsService = require('./services/metricsService.js')

// Load environment variables
dotenv.config()

const app = express()
const server = createServer(app)
const io = new Server(server, {
    cors: {
        origin: "*", // Configure this properly for production
        methods: ["GET", "POST"]
    }
})
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json({ limit: '50mb' }))
app.use(express.urlencoded({ extended: true, limit: '50mb' }))

// Serve static files for news logos
function getAssetPath(relativePath) {
  if (process.pkg) {
    return path.join(path.dirname(process.execPath), relativePath);
  }
  return path.join(__dirname, relativePath);
}

// tell express to serve news_logos
const logosPath = getAssetPath("news_logos");
app.use("/news_logos", express.static(logosPath));


// Serve static files for recordings  
app.use('/recordings', express.static(path.join(__dirname, 'public', 'recordings')))

// Serve static files for HLS streams
app.use('/streams', express.static(path.join(__dirname, 'public', 'streams')))

// Serve static files for clips
app.use('/clips', express.static(path.join(__dirname, 'public', 'clips')))

// Serve test HTML file
app.use(express.static(path.join(__dirname, 'public')))

// API Routes
app.use('/api/channels', channelRoutes)
app.use('/api/sources', sourceRoutes)
app.use('/api/uploads', uploadRoutes)
app.use('/api/search', searchRoutes)
app.use('/api/recordings', recordingRoutes)
app.use('/api/streaming', streamingRoutes)
app.use('/api/clips', clippingRoutes)
app.use('/api/recent-searches', recentSearchRoutes)
app.use('/api/scheduled-recordings', scheduledRecordingRoutes)
app.use('/api/metrics', metricsRoutes)

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        success: true,
        message: 'CMC Backend API is running',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || 'development'
    })
})

// Root endpoint
app.get('/', (req, res) => {
    res.json({
        success: true,
        message: 'Welcome to CMC Backend API',
        version: '1.0.0',
        endpoints: {
            channels: '/api/channels',
            sources: '/api/sources',
            uploads: '/api/uploads',
            search: '/api/search',
            recordings: '/api/recordings',
            streaming: '/api/streaming',
            clips: '/api/clips',
            recentSearches: '/api/recent-searches',
            scheduledRecordings: '/api/scheduled-recordings',
            metrics: '/api/metrics',
            health: '/health'
        }
    })
})

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'Route not found',
        path: req.originalUrl
    })
})

// Global error handler
app.use((error, req, res, next) => {
    console.error('Global error handler:', error)

    res.status(error.status || 500).json({
        success: false,
        message: error.message || 'Internal Server Error',
        ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
    })
})

// Socket.IO connection handling
io.on('connection', (socket) => {
    console.log(`🔌 Socket client connected: ${socket.id}`)

    // Join metrics room
    socket.join('metrics')

    // Send initial metrics data
    metricsService.getRealTimeMetrics().then(metrics => {
        socket.emit('metrics:initial', metrics)
    }).catch(error => {
        console.error('Error sending initial metrics:', error)
        socket.emit('metrics:error', { error: error.message })
    })

    // Handle client requesting metrics update
    socket.on('metrics:request', async () => {
        try {
            const metrics = await metricsService.getRealTimeMetrics()
            socket.emit('metrics:update', metrics)
        } catch (error) {
            console.error('Error handling metrics request:', error)
            socket.emit('metrics:error', { error: error.message })
        }
    })

    socket.on('disconnect', (reason) => {
        console.log(`🔌 Socket client disconnected: ${socket.id}, reason: ${reason}`)
    })
})

// Broadcast real-time metrics every 10 seconds for better real-time experience
setInterval(async () => {
    try {
        const metrics = await metricsService.getRealTimeMetrics()
        io.to('metrics').emit('metrics:update', metrics)
        console.log(`📊 Broadcasting metrics to ${io.sockets.sockets.size} connected clients`)
    } catch (error) {
        console.error('Error broadcasting metrics:', error)
        io.to('metrics').emit('metrics:error', { error: error.message })
    }
}, 10000) // 10 seconds for more responsive updates

// Start server
server.listen(PORT, () => {
    console.log(`🚀 CMC Backend API is running on port ${PORT}`)
    console.log(`📱 Environment: ${process.env.NODE_ENV || 'development'}`)
    console.log(`🌐 Server URL: http://localhost:${PORT}`)
    console.log(`🔌 Socket.IO enabled for real-time metrics`)
    console.log(`📋 API Endpoints:`)
    console.log(`   - Health: http://localhost:${PORT}/health`)
    console.log(`   - Channels: http://localhost:${PORT}/api/channels`)
    console.log(`   - Sources: http://localhost:${PORT}/api/sources`)
    console.log(`   - Uploads: http://localhost:${PORT}/api/uploads`)
    console.log(`   - Search: http://localhost:${PORT}/api/search`)
    console.log(`   - Recordings: http://localhost:${PORT}/api/recordings`)
    console.log(`   - Streaming: http://localhost:${PORT}/api/streaming`)
    console.log(`   - Clips: http://localhost:${PORT}/api/clips`)
    console.log(`   - Recent Searches: http://localhost:${PORT}/api/recent-searches`)
    console.log(`   - Scheduled Recordings: http://localhost:${PORT}/api/scheduled-recordings`)
    console.log(`   - Metrics: http://localhost:${PORT}/api/metrics`)
    console.log(`   - Recording Files: http://localhost:${PORT}/recordings`)
})

module.exports = app
