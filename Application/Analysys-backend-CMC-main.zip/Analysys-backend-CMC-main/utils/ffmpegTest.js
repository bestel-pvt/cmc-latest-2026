const ffmpegStatic = require('./bin/ffmpeg.exe')
const { spawn } = require('child_process')

// Test FFmpeg installation and capabilities
async function testFFmpegInstallation() {
    return new Promise((resolve) => {
        console.log('🔧 Testing FFmpeg installation...')
        console.log(`FFmpeg binary: ${ffmpegStatic}`)

        const ffmpegProcess = spawn(ffmpegStatic, ['-version'], {
            stdio: ['pipe', 'pipe', 'pipe'],
            windowsHide: true
        })

        let output = ''
        let errorOutput = ''

        ffmpegProcess.stdout.on('data', (data) => {
            output += data.toString()
        })

        ffmpegProcess.stderr.on('data', (data) => {
            errorOutput += data.toString()
        })

        ffmpegProcess.on('exit', (code) => {
            if (code === 0 || output.includes('ffmpeg version')) {
                console.log('✅ FFmpeg is working correctly')

                // Extract version
                const versionMatch = (output || errorOutput).match(/ffmpeg version ([^\s]+)/)
                if (versionMatch) {
                    console.log(`📦 Version: ${versionMatch[1]}`)
                }

                // Check for UDP support
                const hasUdp = (output || errorOutput).includes('--enable-protocol=udp') ||
                    (output || errorOutput).toLowerCase().includes('udp')
                console.log(`📡 UDP Support: ${hasUdp ? '✅' : '⚠️  (may still work)'}`)

                resolve({
                    success: true,
                    version: versionMatch ? versionMatch[1] : 'unknown',
                    hasUdp,
                    output: output || errorOutput
                })
            } else {
                console.log('❌ FFmpeg test failed')
                console.log('Output:', output)
                console.log('Error:', errorOutput)

                resolve({
                    success: false,
                    error: errorOutput || 'Unknown error',
                    output: output || errorOutput
                })
            }
        })

        ffmpegProcess.on('error', (error) => {
            console.log('❌ FFmpeg process error:', error.message)
            resolve({
                success: false,
                error: error.message
            })
        })
    })
}

// Test UDP connection capabilities
async function testUdpCapabilities(testIp = '127.0.0.1', testPort = 1234) {
    return new Promise((resolve) => {
        console.log(`🔗 Testing UDP capabilities with ${testIp}:${testPort}...`)

        // Test basic UDP input format recognition
        const testArgs = [
            '-f', 'lavfi',
            '-i', 'testsrc=duration=1:size=320x240:rate=1',
            '-f', 'mpegts',
            '-c:v', 'libx264',
            '-preset', 'ultrafast',
            '-t', '1',
            `udp://${testIp}:${testPort}?pkt_size=1316`
        ]

        const testProcess = spawn(ffmpegStatic, testArgs, {
            stdio: ['pipe', 'pipe', 'pipe'],
            windowsHide: true
        })

        let output = ''
        let errorOutput = ''

        testProcess.stdout.on('data', (data) => {
            output += data.toString()
        })

        testProcess.stderr.on('data', (data) => {
            errorOutput += data.toString()
        })

        testProcess.on('exit', (code) => {
            const fullOutput = output + errorOutput
            const hasUdpOutput = fullOutput.toLowerCase().includes('udp')
            const bindingIssue = fullOutput.toLowerCase().includes('address already in use') ||
                fullOutput.toLowerCase().includes('bind failed')

            console.log(`🔍 UDP Test Result: ${bindingIssue ? '⚠️  Port binding detected' : '✅ No binding issues'}`)

            resolve({
                success: !bindingIssue,
                hasUdpSupport: hasUdpOutput,
                bindingIssue,
                output: fullOutput
            })
        })

        testProcess.on('error', (error) => {
            console.log('❌ UDP test error:', error.message)
            resolve({
                success: false,
                error: error.message
            })
        })

        // Kill the test after 5 seconds
        setTimeout(() => {
            if (!testProcess.killed) {
                testProcess.kill('SIGTERM')
            }
        }, 5000)
    })
}

module.exports = {
    testFFmpegInstallation,
    testUdpCapabilities
}
