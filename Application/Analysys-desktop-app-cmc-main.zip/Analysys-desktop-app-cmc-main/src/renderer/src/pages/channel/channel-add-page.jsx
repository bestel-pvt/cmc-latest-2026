import ChannelForm from '@/components/channel/channel-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import Container from '@/components/common/dash-container'

const ChannelAddPage = () => {
  console.log('hello')

  return (
    <Container>
      <Card className="space-y-4 max-w-7xl p-4">
        <CardHeader>
          <CardTitle>
            <h4>Add Channel</h4>
          </CardTitle>
        </CardHeader>

        <CardContent>
          <ChannelForm />
        </CardContent>
      </Card>
    </Container>
  )
}

export default ChannelAddPage
