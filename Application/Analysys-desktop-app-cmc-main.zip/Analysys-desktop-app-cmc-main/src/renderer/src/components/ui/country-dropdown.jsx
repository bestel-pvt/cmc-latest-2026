import { COUNTRIES } from '@/constants/countries'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './select'
import { CircleFlag } from 'react-circle-flags'

const CountryDropdown = ({ placeholder = 'Select a country', ...props }) => {
  return (
    <Select {...props}>
      <SelectTrigger className="w-full">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {COUNTRIES?.map((country) => (
          <SelectItem key={country.name} value={country.code}>
            <div className="flex items-center gap-2">
              <CircleFlag countryCode={country.code.toLowerCase()} height={20} className="size-6" />
              {country.name}
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}

export default CountryDropdown
