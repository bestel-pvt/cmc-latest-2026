const Joi = require('joi');

// File upload validation schemas
const fileParamsSchema = Joi.object({
    category: Joi.string().valid('images', 'videos', 'documents', 'others').required().messages({
        'any.only': 'Category must be one of: images, videos, documents, others',
        'any.required': 'Category is required'
    }),
    filename: Joi.string().required().messages({
        'string.empty': 'Filename is required',
        'any.required': 'Filename is required'
    })
});

const fileListSchema = Joi.object({
    category: Joi.string().valid('images', 'videos', 'documents', 'others').required().messages({
        'any.only': 'Category must be one of: images, videos, documents, others',
        'any.required': 'Category is required'
    }),
    page: Joi.number().integer().min(1).default(1).messages({
        'number.base': 'Page must be a number',
        'number.integer': 'Page must be an integer',
        'number.min': 'Page must be at least 1'
    }),
    limit: Joi.number().integer().min(1).max(100).default(20).messages({
        'number.base': 'Limit must be a number',
        'number.integer': 'Limit must be an integer',
        'number.min': 'Limit must be at least 1',
        'number.max': 'Limit cannot exceed 100'
    })
});

module.exports = {
    fileParamsSchema,
    fileListSchema
};
