import ClipTable from '@/components/clipping/table/clip-table'
import Container from '@/components/common/dash-container'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import VideoClipEditor from '@/components/clipping/video-clip-editor'

const ClippingPage = () => {
  return (
    <Container>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <h4>Clips List</h4>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ClipTable />
        </CardContent>
      </Card>
    </Container>
  )
}

export default ClippingPage
