import { Card } from '@/components/ui/card'
import Container from '@/components/common/dash-container'

import CreateSourceForm from '@/components/source/create-source-form'

const SourceAddPage = () => {
  return (
    <Container>
      <div className="max-w-4xl ">
        <Card className="space-y-4 p-4">
          <h5>Add Source</h5>

          <CreateSourceForm />
        </Card>
      </div>
    </Container>
  )
}

export default SourceAddPage
