const express = require('express')
const metricsController = require('../controllers/metricsController.js')

const router = express.Router()

// Get clip creation metrics
router.get('/clips', metricsController.getClipMetrics)

// Get storage utilization metrics  
router.get('/storage', metricsController.getStorageMetrics)

// Get system performance metrics
router.get('/performance', metricsController.getPerformanceMetrics)

// Get all metrics combined
router.get('/all', metricsController.getAllMetrics)

// Get real-time metrics for socket updates
router.get('/realtime', metricsController.getRealTimeMetrics)

module.exports = router
