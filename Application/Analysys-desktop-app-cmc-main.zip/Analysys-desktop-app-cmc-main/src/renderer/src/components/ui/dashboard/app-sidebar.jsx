import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail
} from '@/components/ui/sidebar'

import { Tv, LayoutGrid, BarChart, Calendar } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'

import Logo from '@/assets/logo/analysys.png'
import { cn } from '@/lib/utils'
import { buttonVariants } from '../button'
import { useEffect, useState } from 'react'

// This is sample data.
const data = {
  user: {
    name: 'shadcn',
    email: 'm@example.com',
    avatar: '/avatars/shadcn.jpg'
  },

  navMain: [
    {
      title: 'Dashboard',
      url: '/',
      icon: BarChart
    },

    {
      title: 'Channel',
      url: 'channel',
      icon: Tv,
      items: [
        { title: 'Channel list', url: 'channel' },
        { title: 'Channel Sources', url: 'sources' }
      ]
    },
    {
      title: 'Recordings & Clips',
      url: 'recordings',
      icon: Calendar,
      items: [
        { title: 'Recordings', url: '/recordings' },
        { title: 'Clips ', url: '/clips' },
        { title: 'Recording Schedules', url: '/scheduled-recordings' }
      ]
    },
    {
      title: 'Video Wall Display',
      url: 'streams',
      icon: LayoutGrid,
      items: [{ title: '32x IPTV Channel Streaming', url: '/streams' }]
    }
  ]
}

export function AppSidebar({ ...props }) {
  const [version, setVersion] = useState('')
  const location = useLocation()

  const normalizePath = (path) => (path.startsWith('/') ? path : `/${path}`)

  const isActivePath = (path) => {
    const fullPath = normalizePath(path)
    return location.pathname === fullPath || location.pathname.startsWith(fullPath + '/')
  }

  const isParentActive = (item) => {
    if (isActivePath(item.url)) return true
    if (item.items?.some((sub) => isActivePath(sub.url))) return true
    return false
  }

  useEffect(() => {
    window.api.getAppVersion().then(setVersion)
  }, [])

  return (
    <Sidebar variant="floating" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild>
              <Link to="/">
                <div>
                  <img src={Logo} className="size-10" />
                </div>
                <div className="flex flex-col gap-0.5 leading-none">
                  <h6 className="font-medium">Analysys</h6>
                  <span>v {version}</span>
                </div>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarContent className="py-4">
        <SidebarGroup>
          <SidebarMenu>
            {data?.navMain?.map((item) => (
              <SidebarMenuItem key={item.title}>
                <SidebarMenuButton asChild isActive={isParentActive(item)}>
                  <Link to={normalizePath(item.url)}>
                    <item.icon /> {item.title}
                  </Link>
                </SidebarMenuButton>

                {item.items?.length ? (
                  <SidebarMenuSub>
                    {item.items.map((subItem) => (
                      <SidebarMenuSubItem key={subItem.title}>
                        <SidebarMenuSubButton asChild isActive={isActivePath(subItem.url)}>
                          <Link to={normalizePath(subItem.url)}>{subItem.title}</Link>
                        </SidebarMenuSubButton>
                      </SidebarMenuSubItem>
                    ))}
                  </SidebarMenuSub>
                ) : null}
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenuButton size="lg" asChild>
          <small className="flex items-center justify-center !text-muted-foreground">
            Powered by
            <a
              href="https://bestel.tech"
              className={cn('!p-0', buttonVariants({ variant: 'link' }))}
              target="_blank"
              rel="noreferrer"
            >
              BesTel
            </a>
          </small>
        </SidebarMenuButton>
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  )
}
