# CMC Backend API

A complete CRUD API for managing news channels, sources, uploads, and search functionality.

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Setup database and seed with sample data
npm run db:setup

# Start the server
npm start
```

The server will be running at **http://localhost:3000**

## ✅ Recent Fixes

- **SQLite Compatibility**: Resolved `mode: "insensitive"` error by implementing JavaScript-based case-insensitive search
- **Route Conflicts**: Fixed Express routing conflicts in upload endpoints  
- **UDP Stream Links**: Implemented proper UDP streaming link generation (udp://127.0.0.1:9000-9999)

## Features

- ✅ **Channel Management**: Full CRUD operations for news channels
- ✅ **Source Management**: Manage streaming sources for each channel
- ✅ **File Upload**: Upload and manage media files (images, videos, documents)
- ✅ **Search**: Search channels by name and description
- ✅ **Database**: SQLite with Prisma ORM
- ✅ **Validation**: Joi schema validation for all endpoints
- ✅ **UDP Streaming**: Generate UDP stream links for channels

## Installation & Setup

```bash
# Clone or navigate to the project directory
cd cmcbackend

# Install dependencies
npm install

# Generate Prisma client and setup database
npm run db:setup

# Start the server
npm start

# For development (with auto-reload)
npm run dev
```

## Database Commands

```bash
# Generate Prisma client
npm run db:generate

# Push schema to database
npm run db:push

# Create and run migrations
npm run db:migrate

# Reset database
npm run db:reset

# Open Prisma Studio
npm run db:studio

# Seed database with sample data
npm run db:seed

# Complete setup (generate + push + seed)
npm run db:setup
```

## API Endpoints

### Health Check
- `GET /health` - Server health status

### Channels
- `GET /api/channels` - Get all channels (with pagination, filtering, search)
- `GET /api/channels/:id` - Get channel by ID
- `POST /api/channels` - Create new channel
- `PUT /api/channels/:id` - Update channel
- `DELETE /api/channels/:id` - Delete channel

### Sources
- `GET /api/sources` - Get all sources (with pagination, filtering, search)
- `GET /api/sources/:id` - Get source by ID
- `GET /api/sources/channel/:channelId` - Get sources by channel ID
- `POST /api/sources` - Create new source
- `PUT /api/sources/:id` - Update source
- `DELETE /api/sources/:id` - Delete source

### Search
- `GET /api/search` - Search channels by keyword
- `GET /api/search/channels` - Get all channels
- `GET /api/search/suggestions` - Get channel suggestions

### File Uploads
- `POST /api/uploads/single` - Upload single file
- `POST /api/uploads/multiple` - Upload multiple files
- `GET /api/uploads/:category/files` - List files in category
- `GET /api/uploads/:category/:filename` - Download/serve file
- `GET /api/uploads/:category/:filename/info` - Get file info
- `DELETE /api/uploads/:category/:filename` - Delete file

## Example Usage

### Create a Channel
```bash
curl -X POST http://localhost:3000/api/channels \
  -H "Content-Type: application/json" \
  -d '{
    "name": "CNN News",
    "description": "International news coverage",
    "isPriority": true,
    "sources": [
      {
        "type": "primary",
        "port": 8001,
        "ip": "192.168.1.200",
        "isPrimary": true,
        "priority": 1
      }
    ]
  }'
```

### Search Channels
```bash
curl "http://localhost:3000/api/search?q=geo&limit=5"
```

### Upload a File
```bash
curl -X POST http://localhost:3000/api/uploads/single \
  -F "file=@path/to/your/image.jpg"
```

## Channel Stream Links

Each channel automatically gets a UDP stream link in the format:
```
udp://127.0.0.1:9000-9999
```

## File Categories

Uploaded files are automatically categorized into:
- `images` - JPEG, PNG, GIF, WebP, SVG
- `videos` - MP4, MPEG, QuickTime, AVI, WebM  
- `documents` - PDF, Word, Excel, PowerPoint, Text
- `others` - All other supported file types

## Environment Variables

Create a `.env` file:
```env
NODE_ENV=development
PORT=3000
DATABASE_URL="file:./dev.db"
```

## Technologies Used

- **Node.js** - Runtime
- **Express.js** - Web framework
- **Prisma** - Database ORM
- **SQLite** - Database
- **Joi** - Validation
- **Multer** - File uploads
- **CORS** - Cross-origin resource sharing

## Server Status

The server runs on `http://localhost:3000` with the following endpoints ready to use:
- Health: http://localhost:3000/health
- Channels: http://localhost:3000/api/channels
- Sources: http://localhost:3000/api/sources
- Uploads: http://localhost:3000/api/uploads
- Search: http://localhost:3000/api/search
# crmbackend
