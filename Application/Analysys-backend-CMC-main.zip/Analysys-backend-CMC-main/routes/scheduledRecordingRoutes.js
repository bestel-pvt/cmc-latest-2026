const express = require('express')
const {
    createScheduledRecording,
    getScheduledRecordings,
    getScheduledRecordingById,
    updateScheduledRecording,
    deleteScheduledRecording,
    getUpcomingRecordings,
    getActiveScheduledRecordings,
    getChannelScheduledRecordings,
    cancelScheduledRecording,
    getConflicts,
    resolveConflict,
    getScheduleStats
} = require('../controllers/scheduledRecordingController.js')

const router = express.Router()

// GET /api/scheduled-recordings - Get all scheduled recordings with filtering
router.get('/', getScheduledRecordings)

// GET /api/scheduled-recordings/stats - Get schedule statistics
router.get('/stats', getScheduleStats)

// GET /api/scheduled-recordings/upcoming - Get upcoming recordings (next 24 hours)
router.get('/upcoming', getUpcomingRecordings)

// GET /api/scheduled-recordings/active - Get active scheduled recordings
router.get('/active', getActiveScheduledRecordings)

// GET /api/scheduled-recordings/conflicts - Get recording conflicts
router.get('/conflicts', getConflicts)

// POST /api/scheduled-recordings/conflicts/:id/resolve - Resolve a recording conflict
router.post('/conflicts/:id/resolve', resolveConflict)

// GET /api/scheduled-recordings/channel/:channelId - Get scheduled recordings for a channel
router.get('/channel/:channelId', getChannelScheduledRecordings)

// POST /api/scheduled-recordings - Create new scheduled recording
router.post('/', createScheduledRecording)

// GET /api/scheduled-recordings/:id - Get scheduled recording by ID
router.get('/:id', getScheduledRecordingById)

// PUT /api/scheduled-recordings/:id - Update scheduled recording
router.put('/:id', updateScheduledRecording)

// DELETE /api/scheduled-recordings/:id - Delete scheduled recording
router.delete('/:id', deleteScheduledRecording)

// POST /api/scheduled-recordings/:id/cancel - Cancel scheduled recording
router.post('/:id/cancel', cancelScheduledRecording)

module.exports = router
