const { PrismaClient } = require('@prisma/client')
const { generateChannelStreamLink } = require('../utils/helpers.js')

const prisma = new PrismaClient()

const sampleChannels = [
    {
        name: "GEO News",
        description: "Pakistan's leading news channel",
        isActive: true,
        isPriority: true,
        sources: [
            {
                type: "primary",
                port: 4000,
                ip: "127.0.0.1",
                isActive: true,
                isPrimary: true,
                priority: 1
            },
            {
                type: "backup",
                port: 4001,
                ip: "127.0.0.1",
                isActive: true,
                isPrimary: false,
                priority: 2
            }
        ]
    },
    {
        name: "ARY News",
        description: "Breaking news and current affairs",
        isActive: true,
        isPriority: true,
        sources: [
            {
                type: "primary",
                port: 9003,
                ip: "192.168.1.102",
                isActive: true,
                isPrimary: true,
                priority: 1
            }
        ]
    },
    {
        name: "Dawn News",
        description: "Pakistan's premier English news channel",
        isActive: true,
        isPriority: false,
        sources: [
            {
                type: "primary",
                port: 9004,
                ip: "192.168.1.103",
                isActive: true,
                isPrimary: true,
                priority: 1
            },
            {
                type: "secondary",
                port: 9005,
                ip: "192.168.1.104",
                isActive: true,
                isPrimary: false,
                priority: 2
            }
        ]
    },
    {
        name: "Express News",
        description: "Fast and reliable news coverage",
        isActive: true,
        isPriority: false,
        sources: [
            {
                type: "primary",
                port: 9006,
                ip: "192.168.1.105",
                isActive: true,
                isPrimary: true,
                priority: 1
            }
        ]
    },
    {
        name: "BOL News",
        description: "Bold and unbiased news reporting",
        isActive: true,
        isPriority: false,
        sources: [
            {
                type: "primary",
                port: 9007,
                ip: "192.168.1.106",
                isActive: true,
                isPrimary: true,
                priority: 1
            }
        ]
    }
]

const sampleRecentSearches = [
    {
        name: "Active Channels Search",
        type: "channel",
        query: JSON.stringify({
            search: "news",
            isActive: "true",
            sort: "asc"
        })
    },
    {
        name: "Priority News Channels",
        type: "channel",
        query: JSON.stringify({
            isPriority: "true",
            sort: "desc"
        })
    },
    {
        name: "GEO Recordings",
        type: "recording",
        query: JSON.stringify({
            search: "GEO",
            status: "completed",
            sort: "desc"
        })
    },
    {
        name: "Today's Recordings",
        type: "recording",
        query: JSON.stringify({
            startDate: "2025-08-27",
            endDate: "2025-08-27",
            sort: "desc"
        })
    },
    {
        name: "News Highlight Clips",
        type: "clip",
        query: JSON.stringify({
            search: "highlight",
            status: "completed",
            sort: "desc"
        })
    },
    {
        name: "Recent Clips",
        type: "clip",
        query: JSON.stringify({
            sort: "desc",
            pageSize: "20"
        })
    }
]

async function main() {
    console.log('🌱 Starting database seeding...')

    // Clear existing data
    console.log('🧹 Cleaning existing data...')
    await prisma.source.deleteMany({})
    await prisma.channel.deleteMany({})
    await prisma.recentSearch.deleteMany({})

    // Create channels with sources
    console.log('📺 Creating channels with sources...')
    for (const channelData of sampleChannels) {
        const { sources, ...channelInfo } = channelData

        const channel = await prisma.channel.create({
            data: {
                ...channelInfo,
                channelStreamLink: generateChannelStreamLink(),
                sources: {
                    create: sources
                }
            },
            include: {
                sources: true
            }
        })

        console.log(`✅ Created channel: ${channel.name} with ${channel.sources.length} source(s)`)
        console.log(`   Stream Link: ${channel.channelStreamLink}`)
    }

    // Create recent searches
    console.log('🔍 Creating recent searches...')
    for (const searchData of sampleRecentSearches) {
        const search = await prisma.recentSearch.create({
            data: searchData
        })
        console.log(`✅ Created recent search: ${search.name} (${search.type})`)
    }

    // Get statistics
    const totalChannels = await prisma.channel.count()
    const totalSources = await prisma.source.count()
    const activeChannels = await prisma.channel.count({ where: { isActive: true } })
    const priorityChannels = await prisma.channel.count({ where: { isPriority: true } })
    const totalRecentSearches = await prisma.recentSearch.count()
    const searchesByType = {
        channel: await prisma.recentSearch.count({ where: { type: 'channel' } }),
        clip: await prisma.recentSearch.count({ where: { type: 'clip' } }),
        recording: await prisma.recentSearch.count({ where: { type: 'recording' } })
    }

    console.log('\n📊 Database Statistics:')
    console.log(`   Total Channels: ${totalChannels}`)
    console.log(`   Total Sources: ${totalSources}`)
    console.log(`   Active Channels: ${activeChannels}`)
    console.log(`   Priority Channels: ${priorityChannels}`)
    console.log(`   Total Recent Searches: ${totalRecentSearches}`)
    console.log(`   Recent Searches by Type:`)
    console.log(`     - Channel: ${searchesByType.channel}`)
    console.log(`     - Clip: ${searchesByType.clip}`)
    console.log(`     - Recording: ${searchesByType.recording}`)

    console.log('🎉 Database seeding completed successfully!')
}

main()
    .catch((e) => {
        console.error('❌ Error during seeding:', e)
        process.exit(1)
    })
    .finally(async () => {
        await prisma.$disconnect()
    })
