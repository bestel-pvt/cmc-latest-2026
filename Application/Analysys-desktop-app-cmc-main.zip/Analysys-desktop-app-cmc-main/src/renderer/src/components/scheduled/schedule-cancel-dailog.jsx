import React, { useState } from 'react'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '../ui/dialog'
import { DropdownMenuItem } from '../ui/dropdown-menu'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { cancelScheduleRecording } from '@/services/scheduled-recordings/scheduledRecordingApi'
import { ToastError, ToastSuccess } from '@/lib/toast'
import { Button } from '../ui/button'
import {
  Loader2,
  CalendarX,
  Clock,
  Calendar,
  AlertCircle,
  Repeat,
  Bell,
  BarChart3
} from 'lucide-react'
import { Badge } from '../ui/badge'
import { getPriorityScheduleLabel } from '@/lib/utils'

const ScheduleCancelDialog = ({ schedule }) => {
  const queryClient = useQueryClient()
  const [open, setOpen] = useState(false)

  const mutationCancel = useMutation({
    mutationFn: async (id) => {
      return await cancelScheduleRecording(id)
    },
    onSuccess: (success) => {
      ToastSuccess(success?.message || 'Schedule canceled successfully!')
      queryClient.invalidateQueries(['schedule-recordings'])
      setOpen(false)
    },
    onError: (error) => {
      ToastError(error?.response?.data?.message || 'Failed to cancel schedule. Please try again.')
    }
  })

  const handleConfirm = () => {
    mutationCancel.mutate(schedule.id)
  }

  // Format date and time for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  const formatTime = (dateString) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    })
  }

  // Get status badge variant
  const getStatusVariant = (status) => {
    switch (status) {
      case 'scheduled':
        return 'ghost'
      case 'recording':
        return 'secondary'
      case 'completed':
        return 'outline'
      case 'canceled':
        return 'destructive'
      default:
        return 'outline'
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="destructive" size="icon">
          <CalendarX />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarX className="h-5 w-5 text-destructive" />
            Cancel Schedule Recording
          </DialogTitle>
          <DialogDescription className="mt-2">
            Are you sure you want to cancel this recording schedule? This action cannot be undone.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Schedule Details Card */}
          <div className="bg-muted p-4 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">{schedule.name}</h3>
            <p className="text-muted-foreground mb-3">{schedule.description}</p>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>{formatDate(schedule.scheduledStart)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>
                  {formatTime(schedule.scheduledStart)} - {formatTime(schedule.scheduledEnd)}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
                <span>Priority: {getPriorityScheduleLabel(schedule.priority)}</span>
              </div>

              <div className="flex items-center gap-2">
                <Badge variant={getStatusVariant(schedule.status)} className="capitalize">
                  {schedule.status}
                </Badge>
              </div>

              {schedule.isRecurring && (
                <div className="flex items-center gap-2 col-span-2">
                  <Repeat className="h-4 w-4 text-muted-foreground" />
                  <span>Recurring: {schedule.recurrenceType}</span>
                </div>
              )}

              <div className="flex items-center gap-2 col-span-2">
                <Bell className="h-4 w-4 text-muted-foreground" />
                <span>Notifications: {schedule.notificationEnabled ? 'Enabled' : 'Disabled'}</span>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-border">
              <p className="text-sm font-medium">Channel: {schedule?.channel?.name}</p>
              <p className="text-sm text-muted-foreground">{schedule?.channel?.description}</p>
            </div>
          </div>

          {/* Warning Message */}
          <div className="flex gap-3 p-3 border border-amber-200 bg-amber-50 rounded-lg">
            <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
            <div className="text-amber-800 text-sm">
              <p className="font-medium">Canceling this schedule will:</p>
              <ul className="list-disc list-inside mt-1 space-y-1">
                <li>Immediately stop any ongoing recording for this schedule</li>
                <li>Prevent all future recordings in this series</li>
                <li>Remove this schedule from your active recordings list</li>
                {schedule.isRecurring && (
                  <li>Cancel all future occurrences of this recurring recording</li>
                )}
              </ul>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-2">
          <DialogClose asChild>
            <Button
              type="button"
              variant="outline"
              disabled={mutationCancel.isPending}
              className="flex-1"
            >
              Keep Schedule
            </Button>
          </DialogClose>
          <Button
            type="button"
            variant="destructive"
            onClick={handleConfirm}
            disabled={mutationCancel.isPending}
            aria-label="Confirm cancellation"
            className="flex-1"
          >
            {mutationCancel.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Canceling...
              </>
            ) : (
              'Cancel Schedule'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export default ScheduleCancelDialog
