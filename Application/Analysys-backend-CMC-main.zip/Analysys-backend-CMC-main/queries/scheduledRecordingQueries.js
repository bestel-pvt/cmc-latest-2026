const { db, serializeBigInt, DatabaseError } = require('../utils/database.js')

class ScheduledRecordingQueries {
    // Get scheduled recordings with pagination and filtering
    static getScheduledRecordings({ page = 1, pageSize = 10, channelId, status, isActive = 'all' }) {
        let whereClauses = []
        let params = {}

        // Build WHERE clauses
        if (channelId) {
            whereClauses.push('sr.channelId = :channelId')
            params.channelId = channelId
        }

        if (status) {
            whereClauses.push('sr.status = :status')
            params.status = status
        }

        if (isActive !== 'all') {
            whereClauses.push('sr.isActive = :isActive')
            params.isActive = isActive === 'true' ? 1 : 0
        }

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Get total count
        const countQuery = `
            SELECT COUNT(*) as count
            FROM scheduled_recordings sr
            ${whereClause}
        `
        const totalCount = db.prepare(countQuery).get(params)?.count || 0

        // Calculate pagination
        const take = parseInt(pageSize, 10) || 10
        const skip = (parseInt(page, 10) - 1) * take

        // Get scheduled recordings with channel info
        const query = `
            SELECT
                sr.*,
                c.name as channelName,
                c.description as channelDescription,
                c.logo as channelLogo,
                c.channelStreamLink as channelStreamUrl,
                c.isActive as channelIsActive
            FROM scheduled_recordings sr
            LEFT JOIN channels c ON sr.channelId = c.id
            ${whereClause}
            ORDER BY sr.scheduledStart DESC
            LIMIT :take OFFSET :skip
        `

        params.take = take
        params.skip = skip

        const rows = db.prepare(query).all(params)

        const scheduledRecordings = rows.map(row => ({
            ...row,
            isActive: Boolean(row.isActive),
            isRecurring: Boolean(row.isRecurring),
            notificationEnabled: Boolean(row.notificationEnabled),
            channel: {
                id: row.channelId,
                name: row.channelName,
                description: row.channelDescription,
                logo: row.channelLogo,
                streamUrl: row.channelStreamUrl,
                isActive: Boolean(row.channelIsActive)
            }
        }))

        return {
            data: serializeBigInt(scheduledRecordings),
            pagination: {
                total: totalCount,
                page: parseInt(page, 10),
                pageSize: take,
                totalPages: Math.ceil(totalCount / take)
            }
        }
    }

    // Get scheduled recording by ID
    static getScheduledRecordingById(id) {
        const query = `
            SELECT
                sr.*,
                c.name as channelName,
                c.description as channelDescription,
                c.logo as channelLogo,
                c.channelStreamLink as channelStreamUrl,
                c.isActive as channelIsActive
            FROM scheduled_recordings sr
            LEFT JOIN channels c ON sr.channelId = c.id
            WHERE sr.id = ?
        `

        const row = db.prepare(query).get(id)
        if (!row) return null

        return serializeBigInt({
            ...row,
            isActive: Boolean(row.isActive),
            isRecurring: Boolean(row.isRecurring),
            notificationEnabled: Boolean(row.notificationEnabled),
            channel: {
                id: row.channelId,
                name: row.channelName,
                description: row.channelDescription,
                logo: row.channelLogo,
                streamUrl: row.channelStreamUrl,
                isActive: Boolean(row.channelIsActive)
            }
        })
    }

    // Create a new scheduled recording
    static createScheduledRecording(data) {
        const {
            channelId,
            name,
            description,
            scheduledStart,
            scheduledEnd,
            duration,
            isRecurring = false,
            recurrenceType,
            recurrenceRule,
            priority = 1,
            status = 'scheduled',
            isActive = true,
            notificationEnabled = true
        } = data

        // Convert dates to ISO strings for SQLite binding
        const startTime = scheduledStart instanceof Date ? scheduledStart.toISOString() : scheduledStart
        const endTime = scheduledEnd instanceof Date ? scheduledEnd.toISOString() : scheduledEnd

        const insertScheduledRecording = db.prepare(`
            INSERT INTO scheduled_recordings (
                id, channelId, name, description, scheduledStart, scheduledEnd,
                duration, isRecurring, recurrenceType, recurrenceRule, priority,
                status, isActive, notificationEnabled, createdAt, updatedAt
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `)

        // Generate CUID-like ID
        const scheduledRecordingId = 'cm' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9)

        insertScheduledRecording.run(
            scheduledRecordingId,
            channelId,
            name,
            description,
            startTime,
            endTime,
            duration,
            isRecurring ? 1 : 0,
            recurrenceType,
            recurrenceRule,
            priority,
            status,
            isActive ? 1 : 0,
            notificationEnabled ? 1 : 0
        )

        return this.getScheduledRecordingById(scheduledRecordingId)
    }

    // Update scheduled recording
    static updateScheduledRecording(id, updates) {
        const allowedFields = [
            'name', 'description', 'scheduledStart', 'scheduledEnd', 'duration',
            'isRecurring', 'recurrenceType', 'recurrenceRule', 'priority',
            'status', 'isActive', 'notificationEnabled'
        ]
        const setClauses = []
        const params = { id }

        allowedFields.forEach(field => {
            if (updates[field] !== undefined) {
                setClauses.push(`${field} = :${field}`)
                if (field === 'scheduledStart' || field === 'scheduledEnd') {
                    params[field] = updates[field] instanceof Date ? updates[field].toISOString() : updates[field]
                } else if (field === 'isActive' || field === 'isRecurring' || field === 'notificationEnabled') {
                    params[field] = updates[field] ? 1 : 0
                } else {
                    params[field] = updates[field]
                }
            }
        })

        if (setClauses.length === 0) {
            throw new DatabaseError('No valid fields to update')
        }

        setClauses.push('updatedAt = datetime(\'now\')')

        const query = `UPDATE scheduled_recordings SET ${setClauses.join(', ')} WHERE id = :id`
        const result = db.prepare(query).run(params)

        if (result.changes === 0) {
            throw new DatabaseError('Scheduled recording not found', 'P2025')
        }

        return this.getScheduledRecordingById(id)
    }

    // Delete scheduled recording
    static deleteScheduledRecording(id) {
        const result = db.prepare('DELETE FROM scheduled_recordings WHERE id = ?').run(id)

        if (result.changes === 0) {
            throw new DatabaseError('Scheduled recording not found', 'P2025')
        }

        return { success: true }
    }

    // Find scheduled recordings by criteria
    static findScheduledRecordings(options = {}) {
        const {
            where = {},
            include = {},
            skip = 0,
            take = 10,
            orderBy = { scheduledStart: 'desc' }
        } = options

        let whereClauses = []
        let params = {}
        let joins = []

        // Build WHERE clauses
        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                if (typeof where[key] === 'object' && where[key].lte) {
                    whereClauses.push(`sr.${key} <= :${key}`)
                    params[key] = where[key].lte instanceof Date ? where[key].lte.toISOString() : where[key].lte
                } else if (typeof where[key] === 'object' && where[key].gte) {
                    whereClauses.push(`sr.${key} >= :${key}`)
                    params[key] = where[key].gte instanceof Date ? where[key].gte.toISOString() : where[key].gte
                } else if (typeof where[key] === 'object' && where[key].in) {
                    const placeholders = where[key].in.map((_, index) => `:${key}_${index}`).join(', ')
                    whereClauses.push(`sr.${key} IN (${placeholders})`)
                    where[key].in.forEach((value, index) => {
                        params[`${key}_${index}`] = value
                    })
                } else {
                    whereClauses.push(`sr.${key} = :${key}`)
                    if (key === 'isActive' || key === 'isRecurring' || key === 'notificationEnabled') {
                        params[key] = where[key] ? 1 : 0
                    } else {
                        params[key] = where[key]
                    }
                }
            }
        })

        // Handle includes
        if (include.channel) {
            joins.push('LEFT JOIN channels c ON sr.channelId = c.id')
        }

        const joinClause = joins.join(' ')
        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''

        // Build ORDER BY
        let orderByClause = 'ORDER BY sr.scheduledStart DESC'
        if (orderBy) {
            const orderField = Object.keys(orderBy)[0]
            const orderDirection = orderBy[orderField].toUpperCase()
            orderByClause = `ORDER BY sr.${orderField} ${orderDirection}`
        }

        const query = `
            SELECT 
                sr.*
                ${include.channel ? ', c.name as channelName, c.description as channelDescription, c.logo as channelLogo, c.channelStreamLink as channelStreamUrl, c.isActive as channelIsActive' : ''}
            FROM scheduled_recordings sr
            ${joinClause}
            ${whereClause}
            ${orderByClause}
            LIMIT ${take} OFFSET ${skip}
        `

        const rows = db.prepare(query).all(params)

        return serializeBigInt(rows.map(row => {
            const scheduledRecording = {
                ...row,
                isActive: Boolean(row.isActive),
                isRecurring: Boolean(row.isRecurring),
                notificationEnabled: Boolean(row.notificationEnabled)
            }
            if (include.channel) {
                scheduledRecording.channel = {
                    name: row.channelName,
                    description: row.channelDescription,
                    logo: row.channelLogo,
                    streamUrl: row.channelStreamUrl,
                    isActive: Boolean(row.channelIsActive)
                }
            }
            return scheduledRecording
        }))
    }

    // Get scheduled recording count
    static getScheduledRecordingCount(where = {}) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            if (where[key] !== undefined) {
                if (typeof where[key] === 'object' && where[key].lte) {
                    whereClauses.push(`${key} <= :${key}`)
                    params[key] = where[key].lte instanceof Date ? where[key].lte.toISOString() : where[key].lte
                } else if (typeof where[key] === 'object' && where[key].gte) {
                    whereClauses.push(`${key} >= :${key}`)
                    params[key] = where[key].gte instanceof Date ? where[key].gte.toISOString() : where[key].gte
                } else if (typeof where[key] === 'object' && where[key].in) {
                    const placeholders = where[key].in.map((_, index) => `:${key}_${index}`).join(', ')
                    whereClauses.push(`${key} IN (${placeholders})`)
                    where[key].in.forEach((value, index) => {
                        params[`${key}_${index}`] = value
                    })
                } else {
                    whereClauses.push(`${key} = :${key}`)
                    if (key === 'isActive' || key === 'isRecurring' || key === 'notificationEnabled') {
                        params[key] = where[key] ? 1 : 0
                    } else {
                        params[key] = where[key]
                    }
                }
            }
        })

        const whereClause = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : ''
        const query = `SELECT COUNT(*) as count FROM scheduled_recordings ${whereClause}`

        return db.prepare(query).get(params)?.count || 0
    }

    // Find unique scheduled recording
    static findUniqueScheduledRecording(where) {
        let whereClauses = []
        let params = {}

        Object.keys(where).forEach(key => {
            whereClauses.push(`${key} = :${key}`)
            params[key] = where[key]
        })

        const whereClause = `WHERE ${whereClauses.join(' AND ')}`
        const query = `SELECT * FROM scheduled_recordings ${whereClause} LIMIT 1`

        const row = db.prepare(query).get(params)
        if (!row) return null

        return serializeBigInt({
            ...row,
            isActive: Boolean(row.isActive),
            isRecurring: Boolean(row.isRecurring),
            notificationEnabled: Boolean(row.notificationEnabled)
        })
    }
}

module.exports = ScheduledRecordingQueries
