import { io } from 'socket.io-client'

class SocketService {
  constructor() {
    this.socket = null
    this.isConnected = false
    this.connectingPromise = null
  }

  async connect() {
    if (this.isConnected) return this.socket
    if (this.connectingPromise) return this.connectingPromise

    this.connectingPromise = new Promise(async (resolve, reject) => {
      try {
        const config = await window.apiConfig.get() // { API_BASE_URL, API_WS_BASE_URL }

        this.socket = io(config.API_WS_BASE_URL, {
          transports: ['websocket'],
          autoConnect: true
        })

        this.socket.on('connect', () => {
          this.isConnected = true
          console.log('[Socket] Connected:', this.socket.id)
          resolve(this.socket)
        })

        this.socket.on('disconnect', () => {
          this.isConnected = false
          console.log('[Socket] Disconnected')
        })

        this.socket.on('connect_error', (err) => {
          console.error('[Socket] Connection error:', err)
          this.isConnected = false
          reject(err)
        })
      } catch (err) {
        reject(err)
      }
    })

    return this.connectingPromise
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect()
      this.socket = null
      this.isConnected = false
      this.connectingPromise = null
    }
  }

  // ------------------------
  // Overview
  // ------------------------
  async subscribeToOverview(callback) {
    const socket = await this.connect()
    socket.emit('subscribe-overview')
    socket.on('overview-analytics', callback)
  }

  unsubscribeFromOverview(callback) {
    if (this.socket) {
      this.socket.off('overview-analytics', callback)
    }
  }

  // ------------------------
  // Channels
  // ------------------------
  async subscribeToChannel(channelId, callback) {
    const socket = await this.connect()

    socket.emit('subscribe-channel', channelId)

    socket.on('channel-analytics', (data) => {
      if (data.channelId === channelId) {
        callback(data)
      }
    })

    socket.on('channel-event', (event) => {
      if (event.channelId === channelId) {
        callback(event)
      }
    })

    socket.on('source-switch', (event) => {
      if (event.channelId === channelId) {
        callback(event)
      }
    })

    socket.on('health-change', (event) => {
      if (event.channelId === channelId) {
        callback(event)
      }
    })
  }

  unsubscribeFromChannel(channelId, callback) {
    if (this.socket) {
      this.socket.emit('unsubscribe-channel', channelId)
      this.socket.off('channel-analytics', callback)
      this.socket.off('channel-event', callback)
      this.socket.off('source-switch', callback)
      this.socket.off('health-change', callback)
    }
  }

  // ------------------------
  // Top Active Channels
  // ------------------------
  async subscribeToTopActive(callback) {
    const socket = await this.connect()
    socket.emit('subscribe-top-active')
    socket.on('top-active-channels', callback)
  }

  unsubscribeFromTopActive(callback) {
    if (this.socket) {
      this.socket.off('top-active-channels', callback)
    }
  }

  // ------------------------
  // Top Stable Sources
  // ------------------------
  async subscribeToTopStable(callback) {
    const socket = await this.connect()
    socket.emit('subscribe-top-stable')
    socket.on('top-stable-sources', callback)
  }

  unsubscribeFromTopStable(callback) {
    if (this.socket) {
      this.socket.off('top-stable-sources', callback)
    }
  }

  // ------------------------
  // Global Events
  // ------------------------
  async subscribeToEvents(callback) {
    const socket = await this.connect()
    socket.emit('subscribe-events')
    socket.on('new-event', callback)
  }

  unsubscribeFromEvents(callback) {
    if (this.socket) {
      this.socket.off('new-event', callback)
    }
  }

  // ------------------------
  // Real-time Metrics
  // ------------------------
  async subscribeToMetrics(callback) {
    const socket = await this.connect()
    socket.emit('metrics:request') // Request initial metrics
    socket.on('metrics:initial', callback)
    socket.on('metrics:update', callback)
    socket.on('metrics:error', (err) => {
      console.error('[Socket] Metrics error:', err)
      callback({ error: err })
    })
  }

  unsubscribeFromMetrics(callback) {
    if (this.socket) {
      this.socket.off('metrics:initial', callback)
      this.socket.off('metrics:update', callback)
      this.socket.off('metrics:error', callback)
    }
  }
}

// Export singleton instance
const socketService = new SocketService()
export default socketService
