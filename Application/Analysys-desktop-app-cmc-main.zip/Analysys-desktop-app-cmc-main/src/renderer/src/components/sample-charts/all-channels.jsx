import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from 'recharts'

// Sample uptime/downtime data
const uptimeData = [
  { name: 'Uptime', value: 83 },
  { name: 'Downtime', value: 17 }
]

const COLORS = ['#4ade80', '#f87171'] // green, red

// Sample packet history over time
const packetHistory = [
  { time: '16:00', packets: 120, bytes: 2048 },
  { time: '16:10', packets: 150, bytes: 4096 },
  { time: '16:20', packets: 170, bytes: 8192 },
  { time: '16:30', packets: 140, bytes: 5120 },
  { time: '16:40', packets: 180, bytes: 10240 },
  { time: '16:50', packets: 200, bytes: 12288 }
]

// Sample stats
const stats = {
  switchCount: 2,
  avgPacketsPerSec: 5.6,
  avgBytesPerSec: 1024
}

export default function AllChannelChart() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Stats Cards */}
      <Card>
        <CardHeader>
          <CardTitle>Switch Count</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">{stats.switchCount}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Avg Packets/sec</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">{stats.avgPacketsPerSec}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Avg Bytes/sec</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold">{stats.avgBytesPerSec}</p>
        </CardContent>
      </Card>

      {/* Uptime/Downtime Pie Chart */}
      <Card className="lg:col-span-1">
        <CardHeader>
          <CardTitle>Uptime vs Downtime</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={uptimeData} dataKey="value" nameKey="name" outerRadius={80} label>
                {uptimeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Packets Over Time Line Chart */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Packets Over Time</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={packetHistory}>
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="packets" stroke="#3b82f6" name="Packets" />
              <Line type="monotone" dataKey="bytes" stroke="#9333ea" name="Bytes" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}
