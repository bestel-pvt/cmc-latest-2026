import { api } from '@/lib/axios-instance'

export const createScheduleRecording = async (data) => {
  const response = await api.post('/scheduled-recordings', data)
  return response?.data
}

export const getAllScheduleRecording = async ({ page = 1, limit = 10, ...filters }) => {
  const response = await api.get('/scheduled-recordings', {
    params: {
      page,
      limit,
      ...filters
    }
  })
  return response?.data
}

export const getScheduleRecording = async (id) => {
  const response = await api.get(`/scheduled-recordings/${id}`)
  return response?.data
}

export const updateScheduleRecording = async (id, data) => {
  const response = await api.put(`/scheduled-recordings/${id}`, data)
  return response?.data
}
export const deleteScheduleRecording = async (id) => {
  const response = await api.delete(`/scheduled-recordings/${id}`)
  return response?.data
}

export const cancelScheduleRecording = async (id) => {
  const response = await api.post(`/scheduled-recordings/${id}/cancel`)
  return response?.data
}
