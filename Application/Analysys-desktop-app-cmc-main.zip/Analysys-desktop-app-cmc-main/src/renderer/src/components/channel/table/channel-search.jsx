const ChannelSearch = () => {
  return <div>ChannelSearch</div>
}

export default ChannelSearch
