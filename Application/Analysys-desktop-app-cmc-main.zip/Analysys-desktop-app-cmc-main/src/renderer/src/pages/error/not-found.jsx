import { Button } from '@/components/ui/button'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter
} from '@/components/ui/card'
import { FileSearchIcon } from 'lucide-react'
import { useEffect } from 'react'

import { Link, useLocation, useNavigate } from 'react-router-dom'

const NotFoundPage = () => {
  const location = useLocation()
  const navigate = useNavigate()

  console.log(location.pathname.includes('app.asar'))

  useEffect(() => {
    if (location.pathname.includes('app.asar')) {
      navigate('/')
    }
    navigate(-1)
  }, [navigate])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted/50 p-4">
      <Card className="w-full max-w-md border border-foreground/10">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center">
            <div className="rounded-full bg-primary/10 p-4">
              <FileSearchIcon className="h-8 w-8 text-primary" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold tracking-tight">404 - Page Not Found</CardTitle>
          <CardDescription className="text-lg">
            Oops! The page you're looking for doesn't exist.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4 text-center">
          <p className="text-muted-foreground">
            You may have mistyped the address or the page may have moved.
          </p>

          <div className="flex justify-center">
            <div className="inline-flex h-10 w-24 items-center justify-center rounded-lg bg-muted text-sm font-medium">
              {window.location.pathname}
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex flex-col gap-3">
          <Button asChild className="w-full">
            <Link to="/">Return to Homepage</Link>
          </Button>

          <div className="flex justify-center gap-4 pt-2">
            {/* <Button
                            variant="link"
                            size="sm"
                            asChild
                            className="text-muted-foreground"
                        >
                            <Link to="/support">
                                Contact Support
                            </Link>
                        </Button> */}
            <Button
              variant="link"
              size="sm"
              onClick={() => window.history.back()}
              className="text-muted-foreground"
            >
              Go Back
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}

export default NotFoundPage
