import { api } from '@/lib/axios-instance'

export const getAllChannels = async ({
  page = 1,
  limit = 10,
  search = '',
  isActive = 'all',
  isPriority = 'all'
}) => {
  const response = await api.get('/channels', {
    params: {
      page,
      pageSize: limit,
      search,
      isActive,
      isPriority
    }
  })
  return response?.data
}

export const getChannel = async (id) => {
  const response = await api.get(`/channels/${id}`)
  return response?.data
}

export const createChannel = async (data) => {
  const response = await api.post('/channels', data)
  return response?.data
}

export const updateChannel = async (id, data) => {
  console.log(id)
  const response = await api.put(`/channels/${id}`, data)
  return response?.data
}

export const deleteChannel = async (id) => {
  const response = await api.delete(`/channels/${id}`)
  return response?.data
}

export const getChannelStats = async () => {
  const response = await api.get('/channels/stats')
  return response?.data
}

// Channel Analytics
export const channelAnalytics = async (id) => {
  const response = await api.get(`/analytics/channels/${id}`)
  return response?.data
}
export const channelSourceAnalytics = async (id) => {
  const response = await api.get(`/analytics/channels/${id}/sources`)
  return response?.data
}

// Streaming
export const startChannelStream = async (id) => {
  const response = await api.post(`/streaming/${id}/start`)
  return response?.data
}
export const stopChannelStream = async (id) => {
  const response = await api.post(`/streaming/${id}/stop`)
  return response?.data
}

export const startAllChannelStream = async () => {
  const response = await api.post(`/streaming/start-all`)
  return response?.data
}
export const stopAllChannelStream = async () => {
  const response = await api.post(`/streaming/stop-all`)
  return response?.data
}

// Channel Recordings
export const getChannelRecordings = async (id, params = {}) => {
  const searchParams = new URLSearchParams()

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      searchParams.append(key, value)
    }
  })

  const query = searchParams.toString()
  const url = query ? `/recordings/channel/${id}?${query}` : `/recordings/channel/${id}`

  const response = await api.get(url)
  return response?.data
}

// Recordings

export const startChannelRecording = async (id) => {
  const response = await api.post(`/channels/${id}/recording/start`)
  return response?.data
}

export const stopChannelRecording = async (id) => {
  const response = await api.post(`/channels/${id}/recording/stop`)
  return response?.data
}
