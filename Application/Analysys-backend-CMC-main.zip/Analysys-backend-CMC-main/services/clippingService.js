
const fs = require('fs-extra')
const path = require('path')
const { spawn } = require('child_process')
const { RecordingQueries, ClipQueries } = require('../queries')
const metricsService = require('./metricsService.js')
const { clipsDir, ffmpegStatic } = require('../utils/path.js')




class ClippingService {
    constructor() {
        this.clipsDir = clipsDir
        this.ensureClipsDirectory()
        this.processingClips = new Set() // Track processing clips
    }

    // Helper method to convert relative path to absolute path
    getAbsolutePath(relativePath) {
        if (path.isAbsolute(relativePath)) {
            return relativePath
        }

        if (path.isAbsolute(relativePath)) {
            return relativePath // Already absolute (backward compatibility)
        }
        return path.resolve(process.cwd(), relativePath)
    }


    async ensureClipsDirectory() {
        try {
            await fs.ensureDir(this.clipsDir)
        } catch (error) {
            console.error('Failed to create clips directory:', error)
            throw new Error('Failed to initialize clips directory')
        }
    }

    generateClipFileName(clipName, recordingId, format) {
        const sanitizedName = clipName.replace(/[^a-zA-Z0-9-_]/g, '_')
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
        return `clip_${sanitizedName}_${recordingId}_${timestamp}.${format}`
    }

    async createClip(clipData) {
        const { recordingId, clipName, description, startTime, endTime, format, tags } = clipData

        let clip = null
        try {

            console.log(recordingId)
            // Validate recording exists and get file path
            const recording = await RecordingQueries.getRecordingById(recordingId)

            console.log(recording)

            if (!recording) {
                throw new Error('Recording not found')
            }
            console.log("Checking the Path  === ", this.getAbsolutePath(recording.filePath))
            console.log(recording.filePath)
            if (!await fs.pathExists(this.getAbsolutePath(recording.filePath))) {
                throw new Error('Recording file not found form absolute path')
            }

            // Validate time parameters
            if (startTime >= endTime) {
                throw new Error('Start time must be less than end time')
            }

            if (startTime < 0) {
                throw new Error('Start time cannot be negative')
            }

            // Generate clip filename and path
            const fileName = this.generateClipFileName(clipName, recordingId, format)
            const absoluteFilePath = path.join(this.clipsDir, fileName)
            // Store relative path in database for portability
            const relativeFilePath = path.join('data', 'clips', fileName)

            // Create clip record in database
            const clip = await ClipQueries.createClip({
                recordingId,
                clipName,
                description,
                startTime: parseFloat(startTime),
                endTime: parseFloat(endTime),
                format,
                fileName,
                filePath: relativeFilePath,
                tags: tags ? JSON.stringify(tags) : null,
                status: 'processing'
            })

            // Start clipping process
            this.processingClips.add(clip.id)
            metricsService.updateProcessingClips(this.processingClips.size)

            const success = await this.performClipping(this.getAbsolutePath(recording.filePath), absoluteFilePath, startTime, endTime, format)

            if (success) {
                // Get file size after clipping
                const stats = await fs.stat(absoluteFilePath)
                const fileSize = stats.size

                // Calculate duration
                const duration = parseFloat(endTime) - parseFloat(startTime)

                // Update clip status with fileSize and duration
                await ClipQueries.updateClip(clip.id, {
                    status: 'completed',
                    fileSize,
                    duration
                })

                // Remove from processing and update metrics
                this.processingClips.delete(clip.id)
                metricsService.updateProcessingClips(this.processingClips.size)

                return {
                    success: true,
                    clip: {
                        ...clip,
                        status: 'completed',
                        fileSize,
                        duration
                    },
                    message: 'Clip created successfully'
                }
            } else {
                // Update clip status to failed
                await ClipQueries.updateClip(clip.id, {
                    status: 'failed'
                })

                // Remove from processing and update metrics
                this.processingClips.delete(clip.id)
                metricsService.updateProcessingClips(this.processingClips.size)

                throw new Error('Failed to create clip')
            }

        } catch (error) {
            console.error('Create clip error:', error)
            // Remove from processing on error
            if (clip && clip.id) {
                this.processingClips.delete(clip.id)
                metricsService.updateProcessingClips(this.processingClips.size)
            }
            throw error
        }
    }

    async performClipping(inputPath, outputPath, startTime, endTime, format) {
        return new Promise((resolve, reject) => {
            const duration = parseFloat(endTime) - parseFloat(startTime)

            let ffmpegArgs

            if (format === 'mkv') {
                // For MKV format, use libx264 and aac to ensure compatibility
                ffmpegArgs = [
                    '-i', inputPath,
                    '-ss', startTime.toString(),
                    '-t', duration.toString(),
                    '-c:v', 'libx264',
                    '-c:a', 'aac',
                    '-preset', 'fast',
                    '-crf', '23',
                    '-avoid_negative_ts', 'make_zero',
                    '-y',
                    outputPath
                ]
            } else {
                // For MP4 format, try copy first, fallback to re-encode if needed
                ffmpegArgs = [
                    '-i', inputPath,
                    '-ss', startTime.toString(),
                    '-t', duration.toString(),
                    '-c:v', 'copy',
                    '-c:a', 'copy',
                    '-avoid_negative_ts', 'make_zero',
                    '-y',
                    outputPath
                ]
            }

            console.log(`FFmpeg clipping command: ${ffmpegStatic} ${ffmpegArgs.join(' ')}`)

            const ffmpegProcess = spawn(ffmpegStatic, ffmpegArgs, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            let errorOutput = ''
            let progressOutput = ''

            ffmpegProcess.stdout.on('data', (data) => {
                progressOutput += data.toString()
            })

            ffmpegProcess.stderr.on('data', (data) => {
                const output = data.toString()
                errorOutput += output

                if (output.includes('time=') || output.includes('frame=')) {
                    const timeMatch = output.match(/time=(\d{2}:\d{2}:\d{2}.\d{2})/);
                    if (timeMatch) {
                        console.log(`Clipping progress: ${timeMatch[1]}`)
                    }
                }
            })

            ffmpegProcess.on('exit', (code) => {
                if (code === 0) {
                    console.log('Clipping completed successfully')
                    resolve(true)
                } else {
                    console.error('Clipping failed with exit code:', code)
                    console.error('Error output:', errorOutput)

                    // If MP4 copy failed, try re-encoding
                    if (format === 'mp4' && errorOutput.includes('Invalid data found')) {
                        console.log('Copy failed for MP4, trying re-encode...')
                        this.performClippingWithReencode(inputPath, outputPath, startTime, endTime, format)
                            .then(resolve)
                            .catch(reject)
                        return
                    }

                    resolve(false)
                }
            })

            ffmpegProcess.on('error', (error) => {
                console.error('Clipping process error:', error)
                reject(error)
            })
        })
    }

    async performClippingWithReencode(inputPath, outputPath, startTime, endTime, format) {
        return new Promise((resolve, reject) => {
            const duration = parseFloat(endTime) - parseFloat(startTime)

            const ffmpegArgs = [
                '-i', inputPath,
                '-ss', startTime.toString(),
                '-t', duration.toString(),
                '-c:v', 'libx264',
                '-c:a', 'aac',
                '-preset', 'fast',
                '-crf', '23',
                '-avoid_negative_ts', 'make_zero',
                '-y',
                outputPath
            ]

            console.log(`FFmpeg re-encode command: ${ffmpegStatic} ${ffmpegArgs.join(' ')}`)

            const ffmpegProcess = spawn(ffmpegStatic, ffmpegArgs, {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true
            })

            let errorOutput = ''

            ffmpegProcess.stderr.on('data', (data) => {
                const output = data.toString()
                errorOutput += output

                if (output.includes('time=') || output.includes('frame=')) {
                    const timeMatch = output.match(/time=(\d{2}:\d{2}:\d{2}.\d{2})/);
                    if (timeMatch) {
                        console.log(`Re-encode progress: ${timeMatch[1]}`)
                    }
                }
            })

            ffmpegProcess.on('exit', (code) => {
                if (code === 0) {
                    console.log('Re-encoding completed successfully')
                    resolve(true)
                } else {
                    console.error('Re-encoding failed with exit code:', code)
                    console.error('Error output:', errorOutput)
                    resolve(false)
                }
            })

            ffmpegProcess.on('error', (error) => {
                console.error('Re-encoding process error:', error)
                reject(error)
            })
        })
    }

    async getAllClips(options = {}) {
        const {
            page = 1,
            limit = 10,
            sortBy = 'createdAt',
            sortOrder = 'desc',
            recordingId,
            status,
            tags,
            channelName,
            dateFrom,
            dateTo,
            clipName,
            search
        } = options

        try {
            // Build filters object for ClipQueries
            const filters = {}

            if (recordingId) {
                filters.recordingId = recordingId
            }

            if (status) {
                filters.status = status
            }

            // Only filter by tags if tags is provided and not empty string/null/undefined
            if (tags !== undefined && tags !== null && tags !== '') {
                filters.tags = tags
            }

            // Date range filter (createdAt)
            if ((dateFrom && dateFrom !== '') || (dateTo && dateTo !== '')) {
                if (dateFrom && dateFrom !== '') {
                    filters.createdAtFrom = new Date(dateFrom)
                }
                if (dateTo && dateTo !== '') {
                    filters.createdAtTo = new Date(dateTo)
                }
            }

            // Clip name search (partial match)
            if (clipName && clipName !== '') {
                filters.clipName = clipName
            }

            // General search (clipName, description)
            if (search && search !== '') {
                filters.search = search
            }

            // Channel name filter
            if (channelName && channelName !== '') {
                filters.channelName = channelName
            }

            const offset = (page - 1) * limit

            // Get clips with pagination and include recording/channel info
            const result = await ClipQueries.findClipsMany({
                where: filters,
                include: {
                    recording: {
                        include: {
                            channel: true // Always include channel info for complete data
                        }
                    }
                },
                take: parseInt(limit),
                skip: offset,
                orderBy: { [sortBy]: sortOrder.toLowerCase() }
            })

            const formattedClips = result.clips.map(clip => ({
                ...clip,
                tags: clip.tags ? JSON.parse(clip.tags) : [],
                duration: clip.duration || (clip.endTime - clip.startTime), // Fallback calculation
                recording: clip.recording ? {
                    id: clip.recordingId,
                    fileName: clip.recordingFileName || clip.recording.fileName,
                    filePath: clip.recording.filePath,
                    fileSize: clip.recording.fileSize,
                    duration: clip.recording.duration,
                    status: clip.recording.status,
                    createdAt: clip.recording.createdAt,
                    channelId: clip.recording.channelId,
                    channel: clip.recording.channel ? {
                        id: clip.recording.channelId,
                        name: clip.recording.channel.name,
                        description: clip.recording.channel.description,
                        logo: clip.recording.channel.logo,
                        streamUrl: clip.recording.channel.streamUrl,
                        isActive: clip.recording.channel.isActive
                    } : null
                } : null
            }))

            return {
                clips: formattedClips,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: result.total,
                    pages: Math.ceil(result.total / limit)
                }
            }

        } catch (error) {
            console.error('Get all clips error:', error)
            throw error
        }
    }

    async getClipById(clipId) {
        try {
            const clip = await ClipQueries.getClipById(clipId, { includeRecording: true })

            if (!clip) {
                return null
            }

            return {
                ...clip,
                tags: clip.tags ? JSON.parse(clip.tags) : [],
                duration: clip.duration || (clip.endTime - clip.startTime), // Fallback calculation
                recording: clip.recording ? {
                    id: clip.recordingId,
                    fileName: clip.recordingFileName || clip.recording.fileName,
                    filePath: clip.recording.filePath,
                    fileSize: clip.recording.fileSize,
                    duration: clip.recording.duration,
                    status: clip.recording.status,
                    createdAt: clip.recording.createdAt,
                    channelId: clip.recording.channelId,
                    channel: clip.recording.channel ? {
                        id: clip.recording.channelId,
                        name: clip.recording.channel.name,
                        description: clip.recording.channel.description,
                        logo: clip.recording.channel.logo,
                        streamUrl: clip.recording.channel.streamUrl,
                        isActive: clip.recording.channel.isActive
                    } : null
                } : null
            }

        } catch (error) {
            console.error('Get clip by ID error:', error)
            throw error
        }
    }

    async updateClip(clipId, updateData) {
        try {
            const { clipName, description, tags } = updateData

            const updateObj = {}
            if (clipName !== undefined) updateObj.clipName = clipName
            if (description !== undefined) updateObj.description = description
            if (tags !== undefined) updateObj.tags = tags ? JSON.stringify(tags) : null

            await ClipQueries.updateClip(clipId, updateObj)

            // Get the updated clip with related data
            const updatedClip = await ClipQueries.getClipById(clipId, { includeRecording: true })

            return {
                ...updatedClip,
                tags: updatedClip.tags ? JSON.parse(updatedClip.tags) : [],
                duration: updatedClip.duration || (updatedClip.endTime - updatedClip.startTime), // Fallback calculation
                recording: updatedClip.recording ? {
                    id: updatedClip.recordingId,
                    fileName: updatedClip.recordingFileName || updatedClip.recording.fileName,
                    filePath: updatedClip.recording.filePath,
                    fileSize: updatedClip.recording.fileSize,
                    duration: updatedClip.recording.duration,
                    status: updatedClip.recording.status,
                    createdAt: updatedClip.recording.createdAt,
                    channelId: updatedClip.recording.channelId,
                    channel: updatedClip.recording.channel ? {
                        id: updatedClip.recording.channelId,
                        name: updatedClip.recording.channel.name,
                        description: updatedClip.recording.channel.description,
                        logo: updatedClip.recording.channel.logo,
                        streamUrl: updatedClip.recording.channel.streamUrl,
                        isActive: updatedClip.recording.channel.isActive
                    } : null
                } : null
            }

        } catch (error) {
            console.error('Update clip error:', error)
            throw error
        }
    }

    async deleteClip(clipId) {
        try {
            // Get the clip first to check if it exists and get file path
            const clip = await ClipQueries.getClipById(clipId)

            if (!clip) {
                throw new Error('Clip not found')
            }

            // Delete the file if it exists
            try {
                const absolutePath = this.getAbsolutePath(clip.filePath)
                if (await fs.pathExists(absolutePath)) {
                    await fs.remove(absolutePath)
                    console.log(`Deleted clip file: ${absolutePath}`)
                }
            } catch (fileError) {
                console.warn('Could not delete clip file:', fileError.message)
                // Continue with database deletion even if file deletion fails
            }

            // Delete from database
            await ClipQueries.deleteClip(clipId)

            return {
                success: true,
                message: 'Clip deleted successfully',
                clipId: clipId
            }

        } catch (error) {
            console.error('Delete clip error:', error)
            throw error
        }
    }

    async getRecordingClips(recordingId, options = {}) {
        const { page = 1, limit = 10, sortBy = 'createdAt', sortOrder = 'desc' } = options

        try {
            const filters = { recordingId }
            const offset = (page - 1) * limit

            const result = await ClipQueries.findClipsMany({
                where: filters,
                include: { recording: true },
                take: parseInt(limit),
                skip: offset,
                orderBy: { [sortBy]: sortOrder.toLowerCase() }
            })

            const formattedClips = result.clips.map(clip => ({
                ...clip,
                tags: clip.tags ? JSON.parse(clip.tags) : [],
                duration: clip.duration || (clip.endTime - clip.startTime), // Fallback calculation
                recording: clip.recording ? {
                    id: clip.recordingId,
                    fileName: clip.recordingFileName || clip.recording.fileName,
                    filePath: clip.recording.filePath,
                    fileSize: clip.recording.fileSize,
                    duration: clip.recording.duration,
                    status: clip.recording.status,
                    createdAt: clip.recording.createdAt,
                    channelId: clip.recording.channelId,
                    channel: clip.recording.channel ? {
                        id: clip.recording.channelId,
                        name: clip.recording.channel.name,
                        description: clip.recording.channel.description,
                        logo: clip.recording.channel.logo,
                        streamUrl: clip.recording.channel.streamUrl,
                        isActive: clip.recording.channel.isActive
                    } : null
                } : null
            }))

            return {
                clips: formattedClips,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: result.total,
                    pages: Math.ceil(result.total / limit)
                }
            }

        } catch (error) {
            console.error('Get recording clips error:', error)
            throw error
        }
    }
}

module.exports = new ClippingService()
