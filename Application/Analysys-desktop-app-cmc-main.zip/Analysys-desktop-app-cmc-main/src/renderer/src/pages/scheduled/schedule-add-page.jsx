import Container from '@/components/common/dash-container'
import ScheduleForm from '@/components/scheduled/schedule-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const ScheduleAddPage = () => {
  return (
    <Container>
      <Card>
        <CardHeader>
          <CardTitle>
            <h4>Add Recording Schedule</h4>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScheduleForm className="max-w-3xl" />
        </CardContent>
      </Card>
    </Container>
  )
}

export default ScheduleAddPage
