import { Loader, MoreHorizontal, Scissors } from 'lucide-react'
import { format } from 'date-fns'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { useNavigate } from 'react-router-dom'
import { copyToClipboard, formatFileSize, getRecordingStatus } from '@/lib/utils'
import { useApiUrl } from '@/hooks/use-config'

export const useRecordingColumns = () => {
  const navigate = useNavigate()

  const { apiUrl, loading } = useApiUrl()

  return [
    {
      header: 'Sr. no.',
      size: 60,
      enableResizing: true,
      cell: ({ row, table }) => {
        const pagination = table.options.meta?.pagination
        const currentPage = pagination?.page || 1
        const pageSize = pagination?.limit || 10
        return (currentPage - 1) * pageSize + row.index + 1
      }
    },
    {
      accessorKey: 'channelName',
      header: 'Channel Name',
      cell: ({ row }) => <span className="flex items-center">{row.getValue('channelName')}</span>
    },
    {
      accessorKey: 'startTime',
      header: 'Start Date',
      cell: ({ row }) => {
        const date = row.getValue('startTime')
        return <span className="text-sm">{format(new Date(date), 'PPP, pp')}</span>
      }
    },
    {
      accessorKey: 'endTime',
      header: 'End Date',
      cell: ({ row }) => {
        const date = row.getValue('endTime')
        return <span className="text">{date ? format(new Date(date), 'PPP, pp') : 'N/A'}</span>
      }
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => {
        const status = row.getValue('status')
        return <span className="capitalize">{getRecordingStatus(status)}</span>
      }
    },
    {
      accessorKey: 'fileSize',
      header: 'File Size',
      cell: ({ row }) => {
        const size = row.getValue('fileSize')

        return <span>{formatFileSize(size)}</span>
      }
    },
    {
      accessorKey: 'createdAt',
      header: 'Created Date',
      cell: ({ row }) => {
        const date = row.getValue('createdAt')
        return <span className="text-sm">{format(new Date(date), 'PPP, pp')}</span>
      }
    },
    // {
    //     accessorKey: "filePath",
    //     header: "Recording",
    //     cell: ({ row }) => {
    //         const recording = row.original
    //         return (
    //             <a href={recording.filePath} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
    //                 {recording.fileName}
    //             </a>
    //         )
    //     }
    // },
    {
      id: 'actions',
      enableHiding: false,
      cell: ({ row }) => {
        const recording = row.original
        console.log(recording)
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => copyToClipboard(recording.id)}>
                Copy recording ID
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => navigate(`/recording/${recording?.id}`, { state: recording })}
              >
                View recording
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() =>
                  navigate(`/clips/new/${recording?.id}`, {
                    state: { filePath: `${apiUrl}/recordings/${recording?.id}/file` }
                  })
                }
                className="text-green-500 hover:!bg-green-500/10 hover:!text-green-500 font-medium"
              >
                {loading ? (
                  <Loader className="animate-spin" />
                ) : (
                  <div className="flex items-center gap-2">
                    <Scissors className="text-green-500" />
                    Create clip
                  </div>
                )}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )
      }
    }
  ]
}
